// pages/agent/fan/fanEdit/fanEdit.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    name: '',
    cardId: '',
    agentSonId: '',
    mobile: '',
    sex: 2,
    item: [{ text: '女', value: 2, checked: false }, { text: '男', value: 1, checked: false }]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      cardId: options.id,
      name: options.name,
      mobile: options.mobile,
      sex: options.sex,
      agentSonId: options.agentSonId
    })
    if (options.sex == 2) {
      this.setData({
        item: [{ text: '男', value: 1, checked: false }, { text: '女', value: 2, checked: true }]
      })
    } else {
      this.setData({
        item: [{ text: '男', value: 1, checked: true }, { text: '女', value: 2, checked: false }]
      })
    }
  },
  agentAccountUpdate: function () {
    let json = {
      agentSonId: this.data.agentSonId,
      cardId: this.data.cardId,
      mobile: this.data.mobile,
      name: this.data.name,
      sex: this.data.sex
    }
    base.http_post(json, '/agentAccountUpdate', (res) => {
      if (res.code == 0) {
        base.toast('succ', res.message);
        wx.navigateBack()
      } else {
        base.toast('warn', res.message);
      }
    })
  },
  bindname: function (e) {
    this.setData({
      name: e.detail.value
    })
  },
  bindmobile: function (e) {
    this.setData({
      mobile: e.detail.value
    })
  },
  bindcardId: function (e) {
    this.setData({
      cardId: e.detail.value
    })
  },
  radioChange: function (e) {
    this.setData({
      sex: parseInt(e.detail.value)
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})