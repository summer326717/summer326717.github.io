var base = require('../../../../utils/common/base')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    pageNo: 1,
    pageSize: 10,
    isNoData: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //this.getData()
  },
  getData: function () {
    let json = {
      advertState: this.data.advertState,
      advertStyle: this.data.advertStyle,
      pageNo: this.data.pageNo,
      pageSize: this.data.pageSize
    }
    base.http_post(json, '/getData', (res) => {
      if (res.code == 0) {
        let result = []
        if (this.data.pageNo > 1) {
          result = this.data.dataList
        }
        let finalResult = util.concattArr(result, res.data.resultList)
        this.setData({
          dataList: finalResult,
          isNoData: false
        })
        if (res.data.resultList.length < this.data.pageSize) {
          this.setData({
            isToBottom: true
          })
        }
      } else if (res.code == 8) {
        this.setData({
          isNoData: true
        })
      } else {
        base.toast('warn', res.message);
      }
    })
  },
  /**
   * 复制链接
   */
  copyLink: function (e) {
    wx.setClipboardData({
      data: e.target.dataset.text,
      success(res) {
        base.toast('succ', '复制成功');
      }
    })
  },
  /**
   * 删除粉丝
   */
  deleteFan: function (e) {
    wx.showModal({
      title: '提示',
      content: '确认删除该粉丝？',
      success: res => {
        if (res.confirm) {
          let json = {
            advertId: e.target.dataset.id
          }
          base.http_post(json, '/fan', (res) => {
            if (res.code == 0) {
              base.toast('succ', res.message)
              this.advertisementQryList()
            } else {
              base.toast('warn', res.message)
            }
          })
        }
      }
    })
  },
  /**
   * 编辑粉丝
   */
  editFan: function (e) {
    wx.navigateTo({
      url: '/pages/agent/fan/fanEdit/fanEdit?advertId=' + e.target.dataset.id
    })
  },
  /**
   * 指定设备
   */
  toEquipment: function () {
    wx.showActionSheet({
      itemList: ['自选设备', '分配到全部设备'],
      success(res) {
        console.log(res.tapIndex)
      },
      fail(res) {
        console.log(res.errMsg)
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})