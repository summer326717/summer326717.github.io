<template>
  <div class="content audit">
    <el-tabs v-model="activeName" @tab-click="handleClick">

      <el-tab-pane label="待审核" name="first">
        <div v-if="tableData1!=''" class="table">
          <table>
            <tr class="row">
              <th>ID</th>
              <th>商家名称</th>
              <th>联系人</th>
              <th>手机号码</th>
              <th style="text-align: right">账户余额</th>
              <th style="text-align: right">提现金额</th>
              <th>申请时间</th>
              <th>操作</th>
            </tr>
            <tr v-for="(v,k) in tableData1" :key="k">
              <td>{{k+1}}</td>
              <td style="text-align: left">{{v.sup_name}}</td>
              <td style="text-align:center">{{v.contacts}}</td>
              <td>{{v.phone}}</td>
              <td style="text-align: right">{{(v.account_balance/100).toFixed(2)}}</td>
              <td style="text-align: right">{{(v.change_amount/100).toFixed(2)}}</td>
              <td>{{v.created_time}}</td>
              <td>
                <el-button type="primary" size="mini" @click="sure(k)">通过</el-button>
                <el-button type="danger" size="mini" @click="no_sure(k)">驳回</el-button>
              </td>
            </tr>
          </table>
          <el-pagination
                  @current-change="handleCurrentChange"
                  :current-page.sync="currentPage1"
                  :page-size="12"
                  layout="prev, pager, next, jumper"
                  :total="totpage1">
          </el-pagination>
        </div>
        <div class="no_data" v-if="tableData1==''"><img src="../../assets/image/no_data.png"/></div>
      </el-tab-pane>

      <el-tab-pane label="已驳回" name="second" >
        <div class="no_data" v-if="tableData2==''"><img src="../../assets/image/no_data.png"/></div>
        <div  v-if="tableData2!=''" class="table">
          <table>
            <tr class="row">
              <th>ID</th>
              <th>商家名称</th>
              <th>联系人</th>
              <th>手机号码</th>
              <th style="text-align: right">账户余额</th>
              <th style="text-align: right">提现金额</th>
              <th>申请时间</th>
              <th>审核意见</th>
            </tr>
            <tr v-for="(v,k) in tableData2" :key="k">
              <td>{{k+1}}</td>
              <td style="text-align: left">{{v.sup_name}}</td>
              <td>{{v.contacts}}</td>
              <td>{{v.phone}}</td>
              <td style="text-align: right">{{(v.account_balance/100).toFixed(2)}}</td>
              <td style="text-align: right">{{(v.change_amount/100).toFixed(2)}}</td>
              <td>{{v.created_time}}</td>
              <td class="audit_idea" :title="v.opinion">{{v.opinion}}</td>
            </tr>
          </table>
          <el-pagination
                  @current-change="handleCurrentChange1"
                  :current-page.sync="currentPage2"
                  :page-size="12"
                  layout="prev, pager, next, jumper"
                  :total="totpage2">
          </el-pagination>
        </div>
      </el-tab-pane>

      <el-dialog title="驳回意见" :visible.sync="dialogFormVisible" :show-close="false" class="noPassBox">
        <el-input type="textarea" placeholder="请输入200字以内的驳回理由" v-model="textarea">
        </el-input>
        <div slot="footer" class="dialog-footer" style="padding-right: 37%;border-top: none">
          <el-button size="small" @click="dialogFormVisible = false">取 消</el-button>
          <el-button size="small" type="primary" @click="no_pass">确 定</el-button>
        </div>
      </el-dialog>

    </el-tabs>
  </div>
</template>
<script>
    import base from '../../basics/base.js';
    export default {
        data() {
            return {
                showIdea:-1,
                totpage1:0,
                totpage2:0,
                currentPage1:1,
                currentPage2:1,
                activeName:'first',
                tableData1:[],
                tableData2:[],
                dialogFormVisible:false,
                textarea:'',//驳回意见
                row_id:[],
                id:''

            }
        },
        mounted(){
            this.getData(1,1);// 0审核失败 1待审核 2待处理 3完成
        },
        methods: {
            handleClick(tab, event){
              if(tab.index==0){
                  this.getData(1,1);
              }else if(tab.index==1){
                  this.getData(1,0);
              };
            },
            getData(pageno,state){
                var data  ={
                    page_size:12,
                    page_no:pageno,
                    change_state:state
                }
                var me =this;
                base.axios_post(data, '/api/1/admin/userCenter/withdrawalByPage', function(res) {
                    if(res.code==0){
                        var id_list = [];
                        for(var i in res.data.list){
                            res.data.list[i].created_time = me.getLocalTime(res.data.list[i].created_time);
                            id_list.push(res.data.list[i].supplier_fund_change_id);
                        }
                        me.row_id = id_list;
                        me.totpage1 = res.data.totalPage*12;
                        me.totpage2 = res.data.totalPage*12;
                        me.tableData1 = res.data.list;
                        me.tableData2 = res.data.list;
                    };
                })
            },
            //通过
            sure(k){
                this.$confirm('确定通过该用户的提现申请吗?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.audit(2,'',this.row_id[k]);//不通过0；通过2；处理3
                }).catch(() => {});
            },
            //不通过
            no_sure(k){
                this.id = this.row_id[k];
                this.dialogFormVisible = true;
            },
            //确定不通过审核
            no_pass(){
                if(this.textarea==''){
                  this.$message.error('驳回意见不能为空！');
                  return false
                }else{
                    this.audit(0,this.textarea,this.id);//不通过0；通过2；处理3
                }
            },
            //审核请求
            audit(state,opinion,id){
                var data = {
                    supplier_fund_change_id:id,
                    change_state:state,
                    opinion:opinion
                }
                var _this = this;
                base.axios_post(data,'/api/1/admin/userCenter/auditWithdrawal',function (res) {
                    if(res.code==0){
                        base.alerter('已完成');
                        _this.dialogFormVisible = false;
                        _this.getData(1,1);
                    }else{
                        base.alerter(res.message);
                    }
                });
            },
            handleCurrentChange(index){
                this.getData(index,1);
            },
            handleCurrentChange1(index){
                this.getData(index,0);
            },
            getLocalTime(t) {
                var d = new Date(t);
                var y = d.getFullYear();
                var m = d.getMonth() + 1;
                var dd = d.getDate();
                var h = d.getHours();
                var mm = d.getMinutes();
                var s = d.getSeconds();
                return y + '-' + e(m) + '-' + e(dd) + ' ' + e(h) + ':' + e(mm) + ':' + e(s);
                function e(t) {
                    if (t < 10) {
                        return t = '0' + t;
                    } else {
                        return t;
                    }
                }
            },
        }
    }
</script>
<style type="text/css">
  .audit{
    margin-left: 10px;
    margin-right: 15px;
    margin-top: 20px;
    background-color: #fff;
  }
  .audit .table{
    width: 96%;
    margin: 0 auto;
  }
  .audit .noPassBox>div{
    width: 560px!important;
  }
  .audit .table table{
    width: 100%;
    border-collapse: collapse;
  }
  .audit .table table tr{
    border-bottom: solid 1px #d7d7d7;
  }
  .audit .table table tr:first-child{
  }
  .audit .table table th{
    font-size: 14px;
    padding: 15px 0;
    color: #666666;
    font-weight:400;
  }
  .audit .table table .audit_idea{
    display: inline-block;
    max-width: 150px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    cursor: pointer;
  }
  .audit .table table td{
    font-size: 14px;
    padding: 5px 0;
    min-width:60px;
  }
  .audit .table img{
    width: 35px;
    height: 35px;
    border-radius: 50%;
    vertical-align: middle;
    margin-right: 4px;
  }
</style>

