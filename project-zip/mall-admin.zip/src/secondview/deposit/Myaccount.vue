<template>
  <div class="content my_account myAccount">
    <div class="top">
      <div class="m_herder_list now">
        <p>保证金</p>
        <p style="color: #FF850A">￥{{deposite}}</p>
      </div>
      <div class="m_herder_list have">
        <p>总收入</p>
        <p style="color: #FF850A">￥{{totalIncome}}</p>
      </div>
      <div class="classes">
        <div class="classes_title">分类</div>
        <div class="classes_content">
          <span :class="{activity:isActivity==1}" @click="all_choose()">全部</span>
          <span :class="{activity:isActivity==2}" @click="deal_choose">商品交易</span>
          <span :class="{activity:isActivity==3}" @click="fade_choose">退货</span>
          <span :class="{activity:isActivity==4}" @click="ready_choose">提现</span>
          <span :class="{activity:isActivity==5}" @click="full_choose">充值</span>
        </div>
      </div>
      <div class="m_date">
        <div class="m_date_title">日期</div>
        <div class="m_date_content">
          <div class="bbbb">
            <el-date-picker v-model="value1" type="date" value-format="yyyy-MM-dd" @change="getTime1" placeholder="开始日期">
            </el-date-picker>
            <el-date-picker v-model="value2" type="date" value-format="yyyy-MM-dd" @change="getTime2" placeholder="结束日期">
            </el-date-picker>
          </div>
          <el-button class="search" size="small" type="primary" icon="el-icon-search" @click="changes">搜 索</el-button>
        </div>
      </div>
    </div>
    <div class="bottom">
      <div  class="b_header">
        <span>&nbsp;交易记录&nbsp;</span>
      </div>
        <div class="table">
          <table v-if="!no_data">
            <tr>
              <th>流水号</th>
              <th>日期</th>
              <th>分类</th>
              <th class="number">金额</th>
              <th>明细</th>
              <th>状态</th>
            </tr>
            <tr v-for="(v,k) in tableData" :key="k">
              <td>{{v.change_number}}</td>
              <td>{{v.changed_time}}</td>
              <td>{{v.transaction_type}}</td>
              <td class="number">{{v.platfrom_profit}}</td>
              <td>{{v.detail}}</td>
              <td>{{v.state}}</td>
            </tr>
          </table>
          <div class="no_data" v-if="no_data"><img src="../../assets/image/no_data.png"/></div>
        </div>
      <!--分页容器-->
      <el-pagination
              v-if="tableData!=''&&total_pages>1"
              @current-change="turn_page"
              :current-page.sync="currentPage"
              :page-size="10"
              layout="prev, pager, next, jumper"
              :total="total_pages">
      </el-pagination>
    </div>
  </div>
</template>
<script>
  import axios from "axios";
  import base from "../../basics/base";
  export default {
    data() {
      return {
          no_data:false,
          totalIncome:0,
          isActivity:0,
          currentPage:1,
          total_pages:1,
          value1:'',
          value2:'',
          start:'',
          end:'',
          tableData:[],
          deposite:0,
      }
    },
    created(){
      this.getData(1,this.currentPage,this.start,this.end);
    },
    methods: {
      getLocalTime(t) {
            var d = new Date(t);
            var y = d.getFullYear();
            var m = d.getMonth() + 1;
            var dd = d.getDate();
            var h = d.getHours();
            var mm = d.getMinutes();
            var s = d.getSeconds();
            return y + '-' + e(m) + '-' + e(dd) + ' ' + e(h) + ':' + e(mm) + ':' + e(s);
            function e(t) {
                if (t < 10) {
                    return t = '0' + t;
                } else {
                    return t;
                }
            }
        },
      getData(type,page_no){
        var me = this;
        var data = {
            type:type,
            page_no:page_no,
            page_size:10,
            begin_time:this.start,
            end_time:this.end,
            token:localStorage.getItem("token")
        };
        base.axios_post(data,"/api/1/admin/payCenter/listPlatformDetail",function (res) {
            if(res.code==0) {
                me.totalIncome = (res.data.totalIncome/100).toFixed(2);
                me.deposite = (res.data.deposite /100).toFixed(2);
                me.total_pages = res.data.total_page*10;
              if(res.data.list.length!=0){
                  for(var i in res.data.list){

                      if(res.data.list[i].state==0){
                          res.data.list[i].state = "失败";
                      }else if(res.data.list[i].state==1){
                          res.data.list[i].state = "交易中";
                      }else if(res.data.list[i].state==2){
                          res.data.list[i].state = "成功";
                      }else if(res.data.list[i].state==3){
                          res.data.list[i].state = "取消";
                      }

                      if(res.data.list[i].platfrom_profit_type==1){
                          res.data.list[i].platfrom_profit = "+"+(res.data.list[i].platfrom_profit/100).toFixed(2);
                      }else{
                          res.data.list[i].platfrom_profit = "-"+(res.data.list[i].platfrom_profit/100).toFixed(2);
                      }

                      if(res.data.list[i].transaction_type==1){
                          res.data.list[i].transaction_type = "商品交易";
                      }else if(res.data.list[i].transaction_type==2){
                          res.data.list[i].transaction_type = "退款";
                      }else if(res.data.list[i].transaction_type==3){
                          res.data.list[i].transaction_type = "充值";
                      }else if(res.data.list[i].transaction_type==4){
                          res.data.list[i].transaction_type = "提现";
                      }else if(res.data.list[i].transaction_type==5&&res.data.list[i].platfrom_profit_type==1){
                          res.data.list[i].transaction_type = "代理缴纳保证金";
                      }else if(res.data.list[i].transaction_type==5&&res.data.list[i].platfrom_profit_type==2){
                          res.data.list[i].transaction_type = "退还代理保证金";
                      }

                      res.data.list[i].changed_time = me.getLocalTime(res.data.list[i].changed_time);

                  }
                  me.tableData = res.data.list;
                  me.no_data = false;
              }else{
                  me.no_data = true;
              }
            }else{
                me.no_data = true;
            }
        });
      },
      //分类--选择全部
      all_choose(){
        this.isActivity = 1;
        this.getData(this.isActivity,this.currentPage);
      },
        //商品交易
      deal_choose(){
        this.isActivity = 2;
        this.getData(this.isActivity,this.currentPage);
      },
      fade_choose(){
        this.isActivity = 3;
        this.getData(this.isActivity,this.currentPage);
      },
      ready_choose(){
        this.isActivity = 4;
        this.getData(this.isActivity,this.currentPage);
      },
      full_choose(){
        this.isActivity = 5;
        this.getData(this.isActivity,this.currentPage);
      },

      getTime1(val){
        this.start = val;
        /*var str = val; // 日期字符串
        str = str.replace(/-/g,',');
        var date = new Date(str);
        this.start = date.getTime();*/
      },
      getTime2(value){
          this.end = value;
          /*var str = value; // 日期字符串
          str = str.replace(/-/g,',');
          var date = new Date(str);
          this.end = date.getTime();*/
      },
      changes(){
          if(this.value1>this.value2){
              this.$message.error("结束时间不能早于开始时间");
              this.value2 = "";
          }else{
            this.getData(this.isActivity,this.currentPage);
          }
      },
      turn_page: function(i) {
        this.currentPage = i;
        this.getData(this.isActivity,this.currentPage,this.start,this.end);
      },
    }
  }
</script>

<style>
.myAccount .top,.bottom{
  width: 100%;
  overflow: hidden;
  border-radius: 16px;
  background: #fff;
  padding: 20px;
}
.myAccount .bottom{
  margin-top: 20px;
}
.myAccount .top .m_herder_list{
  width: 20%;
  overflow: hidden;
  box-shadow: 2px 2px 3px 1px #bfbfbf;
  display: inline-block;
  margin-left: 30px;
  text-align: center;
  padding:0 10px;
  font-size: 20px;
}
.myAccount .top .m_herder_list:last-child{
  margin-left: 0;
}
.myAccount .top .classes{
  width: 80%;
  margin: 30px auto;
  text-align: left;
}
.myAccount .top .classes>div{
  display: inline-block;

}
.classes_title{
  margin: 0 45px;
}
.classes_content{
  font-size: 0;
  width:84%;
}
.myAccount .top .activity{
  color: #008cff;
  font-size: 18px;
}
.classes_content>span{
  font-size: 16px;
  color: #727272;
  border-left: solid 1px #cacaca;
  padding:0 7%;
  cursor: pointer;
}
.classes_content>span:first-child{
  border-left: none;
}
.myAccount .top .m_date{
  width: 80%;
  margin: 0 auto;
  text-align: left;
}
.myAccount .top .m_date>div,.bbbb{
  display: inline-block;
}
.myAccount .top .m_date .bbbb{
  width: 70%;
}
.el-input--prefix .el-input__inner{
  padding-left: 42px!important;
}
.el-date-editor.el-input, .el-date-editor.el-input__inner{
  width: 171px!important;
  margin-left: 8%;
}
.myAccount .top .m_date .m_date_title{
  margin: 0 45px;
  text-align: center;
}
.myAccount .top .m_date .m_date_content{
  width: 80%;
  margin-left: 30px;
}
.myAccount .bottom .b_header{
  text-align: left;
  height: 36px;
  line-height: 36px;
  margin-bottom: 5px;
}
.myAccount .bottom .b_header>span{
  display: inline-block;
  height: 100%;
  border-bottom: solid 3px #62B6F7;
  color: #62B6F7;
  font-size: 20px;
}
.myAccount .table{
  width: 96%;
  margin: 0 auto;
}
.myAccount table tr img {
  width: 35px;
  height: 35px;
  border-radius: 50%;
  vertical-align: middle;
  margin-right: 3px;
}
.myAccount table tr .number{
  text-align: right;
}
.myAccount table{
  width: 100%;
  border-collapse: collapse;
  margin: 0 auto;
}
.myAccount table tr{
  border-bottom: solid 1px #d7d7d7;
}
.myAccount table tr td{
  padding: 5px 0;
  font-size: 14px;
}
.myAccount table th{
  font-size: 14px;
  padding: 15px 0;
  color: #666666;
  font-weight:400;
}
</style>
