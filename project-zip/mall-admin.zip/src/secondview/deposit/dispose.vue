<template>
  <div class="content dispose">
    <el-tabs v-model="activeName" @tab-click="handleClick">

      <el-tab-pane label="待处理" name="first">
        <div v-if="!no_data" class="table">
          <table>
            <tr class="row">
              <th>ID</th>
              <th>商家名称</th>
              <th>联系人</th>
              <th>手机号码</th>
              <th style="text-align: right">提现金额</th>
              <th>申请时间</th>
              <th>审核时间</th>
              <th>操作</th>
            </tr>
            <tr v-for="(v,k) in tableData1" :key="k">
              <td>{{k+1}}</td>
              <td style="text-align: left">{{v.sup_name}}</td>
              <td style="text-align:center">{{v.contacts}}</td>
              <td>{{v.phone}}</td>
              <td style="text-align: right">{{(v.change_amount/100).toFixed(2)}}</td>
              <td>{{v.created_time}}</td>
              <td>{{v.change_time}}</td>
              <td>
                <el-button type="primary" size="mini" @click="sure(k,v.sup_name)">处理</el-button>
              </td>
            </tr>
          </table>
          <el-pagination
                  @current-change="handleCurrentChange"
                  :current-page.sync="currentPage1"
                  :page-size="12"
                  layout="prev, pager, next, jumper"
                  :total="totpage1">
          </el-pagination>
        </div>
        <div class="no_data" v-if="no_data"><img src="../../assets/image/no_data.png"/></div>
      </el-tab-pane>

      <el-tab-pane label="已完成" name="second" >
        <div v-if="!no_data" class="table">
          <table>
            <tr class="row">
              <th>ID</th>
              <th>商家名称</th>
              <th>联系人</th>
              <th>手机号码</th>
              <th style="text-align: right">账户余额</th>
              <th style="text-align: right">提现金额</th>
              <th>申请时间</th>
              <th>处理时间</th>
            </tr>
            <tr v-for="(v,k) in tableData2" :key="k">
              <td>{{k+1}}</td>
              <td style="text-align: left">{{v.sup_name}}</td>
              <td>{{v.contacts}}</td>
              <td>{{v.phone}}</td>
              <td style="text-align: right">{{(v.account_balance/100).toFixed(2)}}</td>
              <td style="text-align: right">{{(v.change_amount/100).toFixed(2)}}</td>
              <td>{{v.created_time}}</td>
              <td>{{v.change_time}}</td>
            </tr>
          </table>
          <el-pagination
                  @current-change="handleCurrentChange1"
                  :current-page.sync="currentPage2"
                  :page-size="12"
                  layout="prev, pager, next, jumper"
                  :total="totpage2">
          </el-pagination>
        </div>
        <div class="no_data" v-if="no_data"><img src="../../assets/image/no_data.png"/></div>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>
<script>
    import base from '../../basics/base.js';
    export default {
        data() {
            return {
                showIdea:-1,
                totpage1:1,
                totpage2:1,
                currentPage1:1,
                currentPage2:1,
                activeName:'first',
                tableData1:[],
                tableData2:[],
                textarea:'',//驳回意见
                row_id:[],
                id:'',
                no_data:false

            }
        },
        mounted(){
            this.getData(1,2);// 0审核失败 1待审核 2待处理 3完成
        },
        methods: {
            handleClick(tab, event){
                if(tab.index==0){
                    this.getData(1,2);
                }else if(tab.index==1){
                    this.getData(1,3);
                }
            },
            getData(pageno,state){
                var data  ={
                    page_size:12,
                    page_no:pageno,
                    change_state:state
                }
                var me =this;
                base.axios_post(data, '/api/1/admin/userCenter/withdrawalByPage', function(res) {
                    if(res.code==0){
                        if(res.data){
                            var id_list = [];
                            for(var i in res.data.list){
                                res.data.list[i].created_time = me.getLocalTime(res.data.list[i].created_time);
                                res.data.list[i].change_time = me.getLocalTime(res.data.list[i].change_time);
                                id_list.push(res.data.list[i].supplier_fund_change_id);
                            }
                            me.row_id = id_list;
                            me.totpage1 = res.data.totalPage*12;
                            me.totpage2 = res.data.totalPage*12;
                            me.tableData1 = res.data.list;
                            me.tableData2 = res.data.list;
                            me.no_data = true;
                        }
                    };
                })
            },
            //处理
            sure(index,name){
                this.$confirm('确定已经给该用户转账了吗?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.audit(3,'',this.row_id[index],name);//不通过0；通过2；处理3
                }).catch(() => {});
            },
            //审核请求
            audit(state,opinion,id,name){
                var data = {
                    supplier_fund_change_id:id,
                    change_state:state,
                    opinion:opinion,
                    sup_name:name
                }
                var _this = this;
                base.axios_post(data,'/api/1/admin/userCenter/auditWithdrawal',function (res) {
                    if(res.code==0){
                        base.alerter('已完成');
                        _this.getData(1,2);
                    }else{
                        base.alerter(res.message);
                    }
                });
            },
            handleCurrentChange(index){
                this.getData(index,2);
            },
            handleCurrentChange1(index){
                this.getData(index,3);
            },
            getLocalTime(t) {
                var d = new Date(t);
                var y = d.getFullYear();
                var m = d.getMonth() + 1;
                var dd = d.getDate();
                var h = d.getHours();
                var mm = d.getMinutes();
                var s = d.getSeconds();
                return y + '-' + e(m) + '-' + e(dd) + ' ' + e(h) + ':' + e(mm) + ':' + e(s);
                function e(t) {
                    if (t < 10) {
                        return t = '0' + t;
                    } else {
                        return t;
                    }
                }
            },
        }
    }
</script>
<style type="text/css">
  .dispose{
    margin-left: 10px;
    margin-right: 15px;
    margin-top: 20px;
    background-color: #fff;
  }
  .dispose .table{
    width: 96%;
    margin: 0 auto;
  }
  .dispose .noPassBox>div{
    width: 560px!important;
  }
  .dispose .table table{
    width: 100%;
    border-collapse: collapse;
  }
  .dispose .table table tr{
    border-bottom: solid 1px #d7d7d7;
  }
  .dispose .table table tr:first-child{
  }
  .dispose .table table th{
    font-size: 14px;
    padding: 15px 0;
    color: #666666;
    font-weight:400;
  }
  .dispose .table table .audit_idea{
    display: inline-block;
    max-width: 150px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    cursor: pointer;
  }
  .dispose .table table td{
    font-size: 14px;
    padding: 5px 0;
    min-width:60px;
  }
  .dispose .table img{
    width: 35px;
    height: 35px;
    border-radius: 50%;
    vertical-align: middle;
    margin-right: 4px;
  }
</style>

