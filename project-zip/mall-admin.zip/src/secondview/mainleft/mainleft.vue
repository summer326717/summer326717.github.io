<template>
  <div class="content">
        <div class="top_box">
            <div class="spgl"></div>
            <div class="xstj"></div>
        </div>

        <div class="bottom_box">
              <div class="ddgl"></div>
              <div class="sjdb"></div>
        </div>
  </div>
</template>
<script>
import base from '../../basics/base.js';
export default {
  name: 'mainleft',
  data() {
    return {
      state: 1,
      imgarr:'',
      course_file:'',
      course_no:'',
      course_name:'',  
      getdata:'',
      nowdata:'',
      dataarrs:'',
      audiopaly:false,
      audioaddr:'',
      changitem:'1',
      oral_work_code:''
    }
  },
   mounted(){
    
  },
  methods: {

  }
}
</script>
<style type="text/css">
  .content{
    background-color: #fbfbfb;
  }
  .top_box{
    width:100%;
    height:250px;
    margin-top:15px;
    background-color: #fff;
    margin-left: 10px;
  }
  .spgl{
    width:30%;
    height:250px;
  }
</style>

