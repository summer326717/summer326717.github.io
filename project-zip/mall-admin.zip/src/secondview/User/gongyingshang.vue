<template>
  <div class="outer gys">
    <el-tabs v-model="activeName" @tab-click="handleClick">
    
      <el-tab-pane label="未认证商家" name="second" >
        <div class="no_data" v-if="tableData1==''"><img src="../../assets/image/no_data.png"/></div>
        <div v-if="tableData1!=''" class="table">
          <table style="width: 100%" >
              <tr>
                  <th>商家名称</th>
                  <th>联系人</th>
                  <th>手机号</th>
                  <th>用户名</th>
                  <th>注册时间</th>
              </tr>
              <tr v-for="(v,k) in tableData1" :key="k">
                  <td class="overflow">{{v.sup_name}}</td>
                  <td>{{v.contacts}}</td>
                  <td>{{v.phone}}</td>
                  <td class="overflow">{{v.supplier_accounts}}</td>
                  <td>{{v.reg_time_str}}</td>
              </tr>
          </table>
          <el-pagination
            @current-change="handleCurrentChange1"
            :current-page.sync="currentPage1"
            :page-size="10"
            layout="prev, pager, next, jumper"            
            :total="allpage1">
          </el-pagination>
        </div>
      </el-tab-pane>
      <el-tab-pane label="认证待审核" name="third">
          <div class="no_data" v-if="tableData2==''"><img src="../../assets/image/no_data.png"/></div>
        <div v-if="tableData2!=''" class="table">
           <table style="width: 100%" v-if="in_shenghe == false">
               <tr>
                   <th>商家名称</th>
                   <th>联系人</th>
                   <th>手机号</th>
                   <th>用户名</th>
                   <th>注册时间</th>
                   <th>操作</th>
               </tr>
               <tr v-for="(v,k) in tableData2" :key="k">
                   <td class="overflow">{{v.sup_name}}</td>
                   <td>{{v.contacts}}</td>
                   <td>{{v.phone}}</td>
                   <td>{{v.supplier_accounts}}</td>
                   <td>{{v.reg_time_str}}</td>
                   <td>
                       <el-button
                               @click.native.prevent="shenghe(k,tableData2)"
                               type="text"
                               size="small">
                           审核
                       </el-button>
                   </td>
               </tr>
          </table>
           <el-pagination
            @current-change="handleCurrentChange2"
            :current-page.sync="currentPage2"
            :page-size="10"
            v-if="in_shenghe == false"
            layout="prev, pager, next, jumper"
            :total="allpage2">
          </el-pagination>
        </div>
        <div class="info_main" v-if="in_shenghe == true">
              <div class="goback" @click="his_go"> <span class="back"></span>返回上一页</div>
              <div class="main">
                     <el-button type="primary" @click="getpass" class="pass">通过审核</el-button>
                      <el-button type="danger" @click="getreject" class="reject">驳回申请</el-button>
                      <img :src="sup_icon_url" class="yyzz">
                      <div class="mid_box">
                        <p>
                          <span class="title">商家名称</span><span class="main_info">{{sup_name}}</span>
                        </p>
                         <p>
                          <span class="title">紧急联系人</span><span class="main_info">{{urgent_contacts}}</span>
                        </p>
                        <p>
                          <span class="title">紧急联系人电话</span><span class="main_info">{{urgent_phone}}</span>
                        </p>
                         <p>
                          <span class="title">是否三证合一</span><span class="main_info">{{credentials_merge}}</span>
                        </p>
                        <div class="box" v-if="credentials_merge == '否'">
                           <p class="havepic">
                            <span class="title">营业执照</span>
                            <span class="main_info">{{business_licence}}</span>
                            <img :src="business_licence_img_url" @mouseover="showpic(business_licence_img_url)" @mouseout="hidepic()">
                          </p>
                           <p class="havepic">
                            <span class="title">组织机构代码号</span>
                            <span class="main_info">{{organization_code}}</span>
                            <img :src="organization_code_img_url" @mouseover="showpic(organization_code_img_url)" @mouseout="hidepic()">
                          </p>
                           <p class="havepic">
                            <span class="title">纳税人识别码</span>
                            <span class="main_info">{{taxpayer_code}}</span>
                            <img :src="taxpayer_code_img_url" @mouseover="showpic(taxpayer_code_img_url)" @mouseout="hidepic()">
                          </p>
                         </div>
                         <div class="box" v-if="credentials_merge == '是'">
                            <p class="havepic">
                            <span class="title">统一社会信用代码</span>
                            <span class="main_info">{{business_onebianhao}}</span>
                            <img :src="business_onepic" @mouseover="showpic(business_onepic)" @mouseout="hidepic()">
                          </p>
                         </div>
                          <div class="take_pic1" id="take_pic2">
                              <img :src="nowpic">
                          </div>
                      </div>
              </div>
          </div>

      </el-tab-pane>
      <el-tab-pane label="认证驳回" name="fourth">
          <div class="no_data" v-if="tableData3==''"><img src="../../assets/image/no_data.png"/></div>
          <div v-if="tableData3!=''" class="table">
            <table style="width: 100%">
                <tr>
                    <th>商家名称</th>
                    <th>驳回意见</th>
                    <th>驳回时间</th>
                </tr>
                <tr v-for="(v,k) in tableData3" :key="k">
                    <td class="overflow">{{v.sup_name}}</td>
                    <td class="overflow">{{v.audit_opinion}}</td>
                    <td>{{v.verify_time_str}}</td>
                </tr>
            </table>

          <el-pagination
          
            @current-change="handleCurrentChange3"
            :current-page.sync="currentPage3"
            :page-size="10"
            layout="prev, pager, next, jumper"
            :total="allpage3">
          </el-pagination>
          </div>
      </el-tab-pane>
      <el-tab-pane label="已认证商家" name="five">
          <div class="no_data" v-if="tableData4==''"><img src="../../assets/image/no_data.png"/></div>
          <div v-if="tableData4!=''" class="table">
            <table style="width: 100%">
                <tr>
                    <th>商家名称</th>
                    <th>联系人</th>
                    <th>手机号</th>
                    <th>注册时间</th>
                    <th>平台服务费(比率)</th>
                    <th>操作</th>
                </tr>
                <tr v-for="(v,k) in tableData4" :key="k">
                    <td class="overflow">{{v.sup_name}}</td>
                    <td>{{v.contacts}}</td>
                    <td>{{v.phone}}</td>
                    <td>{{v.reg_time_str}}</td>
                    <td>{{v.proportion}}</td>
                    <td>
                        <el-button
                                @click.native.prevent="deleteRow(k,tableData4)"
                                type="text"
                                size="small">
                            冻结
                        </el-button>
                        <el-button
                                @click.native.prevent="set_fuwufei(k,tableData4)"
                                type="text"
                                size="small">
                            修改服务费
                        </el-button>
                    </td>
                </tr>
            </table>
            <el-pagination
            @current-change="handleCurrentChange4"
            :current-page.sync="currentPage4"
            :page-size="10"
            layout="prev, pager, next, jumper"
            :total="allpage4">
          </el-pagination>
          </div>
      </el-tab-pane>
      <el-tab-pane label="已冻结商家" name="six">
          <div class="no_data" v-if="tableData5==''"><img src="../../assets/image/no_data.png"/></div>
          <div v-if="tableData5!=''" class="table">
            <table style="width: 100%">
                <tr>
                    <th>商家名称</th>
                    <th>联系人</th>
                    <th>手机号码</th>
                    <th>平台服务费(比率)</th>
                    <th>冻结时间</th>
                    <th>冻结原因</th>
                    <th>操作</th>
                </tr>
                <tr v-for="(v,k) in tableData5" :key="k">
                    <td class="overflow"><img :src="v.url_address">{{v.sup_name}}</td>
                    <td>{{v.contacts}}</td>
                    <td>{{v.phone}}</td>
                    <td>{{v.proportion}}</td>
                    <td>{{v.update_time_str}}</td>
                    <td class="overflow">{{v.reason}}</td>
                    <td>
                        <el-button @click.native.prevent="jieD(k,tableData5)" type="text" size="small">解冻</el-button>
                    </td>
                </tr>
            </table>
            <el-pagination
            @current-change="handleCurrentChange5"
            :current-page.sync="currentPage5"
            :page-size="10"
            layout="prev, pager, next, jumper"
            :total="allpage5">
          </el-pagination>
          </div>
      </el-tab-pane>

    </el-tabs>

    <el-dialog
      title="审核意见"
      :visible.sync="dialogVisible"
      width="30%"
      >
      <textarea  class="input_box" v-model="input_txt" placeholder="请输入驳回理由"></textarea>
      <span slot="footer" class="dialog-footer">

        <el-button type="primary" @click="shenghe_sure">确 定</el-button>
      </span>
    </el-dialog>

     <el-dialog title="" :visible.sync="dongjie_show" :show-close="false" width="30%">
      <span class="dongjie_title">{{dongjie_title}}</span>
      <span slot="footer" class="dialog-footer">
        <el-button size="small" @click="dongjie_show = false">取 消</el-button>
        <el-button size="small" type="primary" @click="dongjie_sure">确 定</el-button>
      </span>
    </el-dialog>

    <el-dialog title="请输入冻结原因" :visible.sync="dongjie_Visible" :show-close="false" width="30%" center>
        <el-input type="textarea" :autosize="{ minRows: 2, maxRows: 4}" placeholder="冻结原因" v-model="dongJie_idea">
        </el-input>
          <span slot="footer" class="dialog-footer" style="text-align: center">
    <el-button size="small" @click="dongjie_Visible = false">取 消</el-button>
    <el-button size="small" type="primary" @click="dongjieSure">确 定</el-button>
  </span>
    </el-dialog>

      <el-dialog title="平台服务费比例" :visible.sync="fuwufei_show" width="660px" :show-close="false">
          <span>
              <el-input class="fuwu" v-model="fuwufei"></el-input>
          </span>
          <p style="width: 54%;margin: 17px auto;text-align: left;color: #ff6150">
              *按照每笔订单实际成交金额，平台收取一定的服务费<br/>
              *服务费比例值在0-1之间(最多允许保留3位小数)<br/>
              *服务费 = 成交金额 * 服务费比例(四舍五入)
          </p>
          <span slot="footer" class="dialog-footer" style="padding-right: 37%;border-top: none">
        <el-button size="small" @click="fuwufei_show = false">取 消</el-button>
        <el-button size="small" type="primary" @click="fuwufei_sure">提 交</el-button>
      </span>
      </el-dialog>
      <el-dialog title="修改平台服务费比例" :visible.sync="fuwufei2_show" width="660px" :show-close="false">
          <span>
              <el-input class="fuwu" v-model="fuwufei2"></el-input>
          </span>
          <p style="width: 54%;margin: 17px auto;text-align: left;color: #ff6150">
              *按照每笔订单实际成交金额，平台收取一定的服务费<br/>
              *服务费比例值在0-1之间(最多允许保留3位小数)<br/>
              *服务费 = 成交金额 * 服务费比例(四舍五入)
          </p>
          <span slot="footer" class="dialog-footer" style="padding-right: 37%;border-top: none">
        <el-button size="small" @click="fuwufei2_show = false">取 消</el-button>
        <el-button size="small" type="primary" @click="fuwufei2_sure">提 交</el-button>
      </span>
      </el-dialog>


  </div>
</template>
<script>
import base from '../../basics/base.js';
export default {
  name: 'mainleft',
  data() {
    return {
      state: 1,
      activeName: 'second',
      in_shenghe:false,
      tableData1:null,
      dialogVisible:false,
      currentPage1:1,
      allpage1:10,
      tableData2:null,
      currentPage2:1,
      allpage2:10,
      tableData3:null,
      currentPage3:1,
      allpage3:10,
      tableData4:null,
      currentPage4:1,
      allpage4:10,
      tableData5:[],
      currentPage5:1,
      allpage5:10,
      sup_icon_url:'',
      sup_name:'',
      urgent_contacts:'',
      urgent_phone:'',
      credentials_merge:'',
      business_licence:'',
      business_licence_img_url:'',
      organization_code:'',
      organization_code_img_url:'',
      taxpayer_code:'',
      taxpayer_code_img_url:'',
      input_txt:'',
      dongjie_show:false,
      dongjie_title:'',
      dongjie_id:'',
      nowpage1:1,
      nowpage2:1,
      nowpage3:1,
      nowpage4:1,
      nowpage5:1,
      business_onebianhao:'',
      business_onepic:'',
        nowpic:'',
        dongjie_Visible:false,
        dongJie_idea:'',
        fuwufei_show:false,
        fuwufei2_show:false,
        fuwufei:'',
        fuwufei2:'',
        supplier_id:"",
        supplier2_id:"",
    }
  },
   mounted(){
        this.getdata(3)
  },
  methods: {
       handleClick(tab, event) {
        if(tab.index == 0){
          this.getdata(3,this.nowpage1)
        }else if(tab.index == 1){
          this.getdata(1,this.nowpage2)
        }else if(tab.index ==2){
           this.getdata(0,this.nowpage3)
        }else if(tab.index ==3){
          this.getdata(2,this.nowpage4)
        }else if(tab.index ==4){
          this.get_dongJ_data(this.nowpage5);
        }
        console.log(tab.index, event);
      },
      shenghe(index,data){
          var shenghe_id = data[index].sup_info_id;
          this.supplier_id = data[index].supplier_id;
          this.in_shenghe = true;
          this.getshenghedata(shenghe_id)
      },
      handleSizeChange(){
      },
      dongjie_and_jieD(id,state,reason){
          var me =this;
          var data = {
              supplier_accounts:id,
              supplier_state:state,
              reason:reason
          };
          base.axios_post(data, '/api/1/admin/userCenter/supplierLock', function(res) {
              if(res.code == 0){
                  if(state==0){
                      me.$message({
                          message: '冻结成功!',
                          type: 'success'
                      });
                      me.getdata(2,me.nowpage4)
                      me.dongjie_show= false;
                      me.dongjie_title ='';
                  }else if(state==1){
                      me.$message({
                          type: 'success',
                          message: '解冻成功!'
                      });
                      me.get_dongJ_data(me.nowpage5);
                  }
              }else{
                  me.$message({
                      message: '系统繁忙请稍后再试',
                      type: 'warning'
                  });
              }
          })
      },
      dongjie_sure(){//冻结接口
          this.dongjie_and_jieD(this.dongjie_id,0,this.dongJie_idea);
      },
      deleteRow(index,data){
          this.dongjie_Visible = true;
          this.dongjie_id = data[index].supplier_accounts;
          this.dongjie_title = '确定要冻结供应商：'+data[index].sup_name+'吗？';
      },
      dongjieSure(){
          if(this.dongJie_idea==''){
              this.$message.error('冻结原因不能为空');
          }else{
              this.dongjie_Visible = false;
              var _this = this;
              setTimeout(function () {
                  _this.dongjie_show = true;
              },500);
          }
      },
      getdata(val,pageno){
          var me= this;
          var data = {
            page_no:pageno?pageno:1,
            page_size:10,
            authentication_state:val
          }
           base.axios_post(data, '/api/1/admin/userCenter/supplierFindAuditMessage', function(res) {
            if(res.code ==0){
               if(val == 3){
                  me.tableData1 = res.data.list;
                  me.allpage1 = res.data.total_page*10;
              }else if(val == 1){
                  me.tableData2 = res.data.list;
                  me.allpage2 = res.data.total_page*10;
              }else if(val == 0){
                  me.tableData3 = res.data.list;
                  me.allpage3 = res.data.total_page*10;
              }else{
                  me.tableData4 = res.data.list;
                  me.allpage4 = res.data.total_page*10;
              }
            }else if(res.code==100){
                me.$emit("login_state",false)
            }else{
               me.tableData1 = [];
               me.tableData2 = [];
               me.tableData3 = [];
               me.tableData4 = [];
               me.tableData5 = [];
               me.$message({
                      message: res.message,
                      type: 'warning'
                    });
            }
           })            
      },
      get_dongJ_data(pageNo){
          var _this = this;
          var data = {
              authentication_state:4,
              page_no:pageNo,
              page_size:10
          };
          base.axios_post(data,"/api/1/admin/userCenter/supplierFindAuditMessage",function (res) {
              if(res.code==0){
                  _this.tableData5 = res.data.list;
                  _this.allpage5 = res.data.total_page*10;
              }else{
                  _this.$message({
                      message: res.message,
                      type: 'warning'
                  });
              }
          });
      },
      getshenghedata(shenghe_id){
        var me = this;
        me.shenghe_id = shenghe_id;
        var data = {
          sup_info_id:shenghe_id
        }        
         base.axios_post(data, '/api/1/admin/userCenter/supplierDetailMessage ', function(res) {
              if(res.code ==0){
                  me.sup_icon_url = res.data.sup_icon_url?res.data.sup_icon_url.url_address:'';
                  me.sup_name = res.data.sup_name;
                  me.urgent_contacts =res.data.urgent_contacts;
                  me.urgent_phone = res.data.urgent_phone;
                  me.credentials_merge = res.data.credentials_merge==0?'否':'是';
                  me.business_licence =res.data.business_licence;
                  me.business_licence_img_url = res.data.business_licence_img_url?res.data.business_licence_img_url.url_address:'';
                  me.organization_code =res.data.organization_code;
                  me.organization_code_img_url = res.data.organization_code_img_url?res.data.organization_code_img_url.url_address:'';
                  me.taxpayer_code = res.data.taxpayer_code;
                  me.taxpayer_code_img_url  = res.data.taxpayer_code_img_url?res.data.taxpayer_code_img_url.url_address:'';
                  if(me.credentials_merge =='是'){
                    me.business_onepic = res.data.credentials_merge_img_url.url_address;
                    me.business_onebianhao =res.data.credit_code;
                  }
              }else{
                 me.$message({
                      message: '系统繁忙请稍后再试',
                      type: 'warning'
                    });
              }

         })
      },
      his_go(){
        this.in_shenghe = false;
      },
      turnback(){
        this.sup_icon_url='';
        this.sup_name='';
        this.urgent_contacts='';
        this.urgent_phone='';
        this.credentials_merge='';
        this.business_licence='';
        this.business_licence_img_url='';
        this.organization_code='';
        this.organization_code_img_url='';
        this.taxpayer_code='';
        this.taxpayer_code_img_url='';
      },
      getpass(){//通过申请
        this.fuwufei_show = true;
          this.fuwufei = '';
      },
      fuwufei_sure(){
          if(this.fuwufei){
              if( !/^(0|0\.\d{1,2}|0\.\d[1-9]\d|0\.00[1-9])$/g.test(this.fuwufei)){
                  this.$message.error('请输入合法的平台服务费!');
                  return false;
              }else{
                  var data = {
                      sup_info_id:this.shenghe_id,
                      supplier_id:this.supplier_id,
                      proportion:this.fuwufei,
                      authentication_state:2,
                      audit_opinion:''
                  }
                  var me = this;
                  base.axios_post(data, '/api/1/admin/userCenter/auditSupplierMessage', function(res){
                      if(res.code ==0){
                          me.$message({
                              showClose: true,
                              message: '审核成功',
                              type: 'success'
                          });
                          me.in_shenghe = false;
                          me.fuwufei_show = false;
                          me.getdata(1);
                          me.turnback();
                      }else{
                          me.$message({
                              message: '系统繁忙请稍后再试',
                              type: 'warning'
                          });
                      }
                  })
              }
          }else{
              this.$message.error('请输入平台服务费!');
              return false;
          }
      },
      getreject(){
        this.dialogVisible =true;
       
      },
      showpic(picaddr){
          var e = window.event;
          var x = e.pageX;
          var y  =e.pageY;
          this.nowpic = picaddr;
          var picbox = document.getElementById('take_pic2');
          picbox.style.left=x-100+'px';
          picbox.style.display="block";
          setTimeout(()=>{
                    var gei =  picbox.offsetHeight;
                    picbox.style.top=y-gei-20+'px';
          },50)


      },
      hidepic(){
          this.nowpic = '';
          var picbox = document.getElementById('take_pic2');
          picbox.style.display="none";
      },
      shenghe_sure(){//驳回申请
        var me=this;
        if(this.input_txt == ''){
            me.$message({
                message: '请输入驳回理由',
                type: 'warning'
            });
            return;
        }
         var data = {
              sup_info_id:this.shenghe_id,
              authentication_state:0,
              audit_opinion:this.input_txt
        }
          base.axios_post(data, '/api/1/admin/userCenter/auditSupplierMessage', function(res){
              if(res.code == 0){
                   me.$message({
                    showClose: true,
                    message: '驳回成功',
                    type: 'success'
                  });
                   me.in_shenghe = false;
                   me.getdata(1,me.nowpage2)
                    me.turnback();
                    me.dialogVisible= false;
                    me.input_txt ='';
              }else{
                 me.$message({
                      message: '系统繁忙请稍后再试',
                      type: 'warning'
                    });
              }
          })
      },
      jieD(k,data){
          this.$confirm('确定对该供应商解除冻结吗?', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
          }).then(() => {
              this.dongjie_and_jieD(data[k].supplier_accounts,1,'');

          }).catch(() => {});

      },
      set_fuwufei(index,d){
          this.fuwufei2 = d[index].proportion;
          this.fuwufei2_show = true;
          this.supplier2_id = d[index].supplier_id;

      },
      fuwufei2_sure(){
          if(this.fuwufei2){
              if(!/^(0|0\.\d{1,2}|0\.\d[1-9]\d|0\.00[1-9])$/g.test(this.fuwufei2)){
                  this.$message.error('请输入合法的平台服务费!');
                  return false;
              }else{
                  let data = {
                      supplier_id:this.supplier2_id,
                      proportion:this.fuwufei2
                  };
                  let me = this;
                  base.axios_post(data, '/api/1/admin/userCenter/updateProportion', function(res){
                      if(res.code == 0){
                          me.$message({
                              showClose: true,
                              message: '修改服务费成功',
                              type: 'success'
                          });
                          me.fuwufei2_show = false;
                          me.getdata(2);
                          me.turnback();
                      }else{
                          me.$message({
                              message: '系统繁忙请稍后再试',
                              type: 'warning'
                          });
                      }
                  })
              }
          }else{
              this.$message.error('请输入平台服务费!');
              return false;
          }
      },
      handleCurrentChange1(index){ //分页
          this.nowpage1= index;
          this.getdata(3,index)
      },
       handleCurrentChange2(index){ //分页
          this.nowpage2 =index;
          this.getdata(1,index)
      },
       handleCurrentChange3(index){ //分页
          this.nowpage3 =index;
          this.getdata(0,index)
      },
       handleCurrentChange4(index){ //分页
          this.nowpage4 =index;
          this.getdata(2,index)
      },
       handleCurrentChange5(index){ //分页
          this.nowpage5 = index;
          this.get_dongJ_data(index)
      }

  }
}
</script>
<style type="text/css">

.outer{
    margin-left: 10px;
    margin-right: 15px;
    margin-top: 20px;
    background-color: #ffff;
}

.gys .table{
    width: 96%;
    margin: 0 auto;
}
.gys table tr img {
    width: 35px;
    height: 35px;
    border-radius: 50%;
    vertical-align: middle;
    margin-right: 3px;
}
.gys table tr .number{
    text-align: right;
}
.gys table{
    width: 100%;
    border-collapse: collapse;
    margin: 0 auto;
}
.gys table tr{
    border-bottom: solid 1px #d7d7d7;
}
.gys table tr td{
    padding: 5px 3px;
    font-size: 14px;
}
.gys table tr:first-child{
}
.gys table th{
    font-size: 14px;
    padding: 15px 0;
    color: #666666;
    font-weight:400;
}
.gys .table .overflow{
    max-width: 150px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    text-align: left;
}



.el-dialog__body{
  padding: 10px 20px;
}

.input_box{
  width:90%;
  height:100px;
  border: #ccc solid 1px;
  border-radius: 5px;
  padding: 5px;
}
.el-tabs__header {
    border-bottom: none;
    background-color: #fff;
    
    padding-left: 30px;
    border-radius: 12px;
}
.el-tabs__content {
    overflow: hidden;
    position: relative;

    background-color: #fff;
}
.el-table th>.cell{
  text-align: center;
}

.goback{
  border-bottom: #62b6f7 solid 3px;
  text-align: left;
  padding-left: 20px;
  height: 40px;
  line-height: 40px;
  font-size: 14px;
  cursor: pointer;
  margin-left: 20px;
  width: 300px;
}
.back {
  width: 0;
    height: 0;
    display: inline-block;
    border-top: 5px solid transparent;
    border-right: 10px solid #20a0ff;
    border-bottom: 5px solid transparent;
    margin-right: 10px;
}
.main{
  position: relative;
}
.pass{
  position: absolute;
  top:30px;
  right: 180px;
}
.reject{
  position: absolute;
  top:30px;
  right: 60px;
}
.yyzz{
    width: 120px;
    height: 120px;
    display: inline-block;
    position: absolute;   
    top: 85px;
    left: 74px;
}
.mid_box{
    position: relative;
    width: 40%;
    text-align: left;
    padding-top: 80px;
    margin-left: 220px;
}
.title{
    display: inline-block;
    width: 140px;
    font-size: 14px;
    text-align: left;
}
.main_info{
  padding-left: 40px;
  font-size: 14px;
      display: inline-block;
    min-width: 122px;  
}
.mid_box p{
    margin-bottom: 30px;
    margin-top: 0;
    position: relative;
}
.havepic img{
  width: 100px;
  height: 30px;
  cursor: pointer;
}
.take_pic1{
    width:300px;
    height:auto;
    overflow: hidden;
    padding: 10px 20px;
    display: none;
    position: fixed;
    background-color: #fff;
    border-radius: 8px;
    z-index: 200;
    -moz-box-shadow:0px 0px 3px #333333; -webkit-box-shadow:0px 0px 3px #333333; box-shadow:0px 0px 3px #333333;
}
.take_pic1 img{
    width:300px;
    border-radius: 5px;
}
.picbox11{
    padding-top: 10px;
}
    .fuwu{
        width: 50%;
    }
</style>

