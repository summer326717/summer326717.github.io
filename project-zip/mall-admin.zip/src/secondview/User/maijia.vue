<template>
  <div class="content maijia">
      <el-tabs v-model="activeName" @tab-click="handleClick">
      <el-tab-pane label="未认证" name="first">
        <div class="no_data" v-if="tableData1==''"><img src="../../assets/image/no_data.png"/></div>
        <div v-if="tableData1!=''" class="table">
          <table style="width: 100%">
              <tr>
                  <th>用户名</th>
                  <th>微信号</th>
                  <th>注册时间</th>
              </tr>
              <tr v-for="(v,k) in tableData1" :key="k">
                  <td  class="overflow">{{v.buyers_name}}</td>
                  <td>{{v.open_id}}</td>
                  <td>{{v.reg_time}}</td>
              </tr>
          </table>

          <el-pagination          
            @current-change="handleCurrentChange1"
            :current-page.sync="currentPage1"
            :page-size="10"
            layout="prev, pager, next, jumper"
            :total="allpage1">
          </el-pagination>
        </div>
      </el-tab-pane>
      <el-tab-pane label="已认证" name="second">
        <div class="no_data" v-if="tableData2==''"><img src="../../assets/image/no_data.png"/></div>
        <div v-if="tableData2 != ''" class="table">
          <table style="width: 100%">
              <tr>
                  <th>用户名</th>
                  <th>微信号</th>
                  <th>手机号</th>
                  <th>注册时间</th>
                  <th>操作</th>
              </tr>
              <tr v-for="(v,k) in tableData2" :key="k">
                  <td class="overflow">{{v.buyers_name}}</td>
                  <td>{{v.open_id}}</td>
                  <td>{{v.phone}}</td>
                  <td>{{v.reg_time}}</td>
                  <td>
                      <el-button
                              @click.native.prevent="deleteRow(k,tableData2)"
                              type="text"
                              size="small">
                          冻结
                      </el-button>
                  </td>
              </tr>
          </table>
          
          <el-pagination          
            @current-change="handleCurrentChange2"
            :current-page.sync="currentPage2"
            :page-size="10"
            layout="prev, pager, next, jumper"
            :total="allpage2">
          </el-pagination>
        </div>
      </el-tab-pane>
      <el-tab-pane label="已冻结" name="third">
        <div class="no_data" v-if="tableData3==''"><img src="../../assets/image/no_data.png"/></div>
        <div  v-if="tableData3!=''" class="table">
          <table style="width: 100%">
              <tr>
                  <th>用户名</th>
                  <th>微信号</th>
                  <th>手机号</th>
                  <th>冻结时间</th>
                  <th>冻结原因</th>
                  <th>操作</th>
              </tr>
              <tr v-for="(v,k) in tableData3" :key="k">
                  <td class="overflow"><img :src="v.head_portrait">{{v.buyers_name}}</td>
                  <td>{{v.open_id}}</td>
                  <td>{{v.phone}}</td>
                  <td>{{v.change_time}}</td>
                  <td class="overflow">{{v.reason}}</td>
                  <td>
                      <el-button
                              @click.native.prevent="jieD(k,tableData3)"
                              type="text"
                              size="small">
                          解冻
                      </el-button>
                  </td>
              </tr>
          </table>

          <el-pagination
            @current-change="handleCurrentChange3"
            :current-page.sync="currentPage3"
            :page-size="10"
            layout="prev, pager, next, jumper"
            :total="allpage3">
          </el-pagination>
        </div>
      </el-tab-pane>

    </el-tabs>

     <el-dialog
      title=""
      :visible.sync="dongjie_show"
      width="30%"
     >
      <span class="dongjie_title">{{dongjie_title}}</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dongjie_show = false">取 消</el-button>
        <el-button type="primary" @click="dongjie_sure">确 定</el-button>
      </span>
    </el-dialog>

     <el-dialog title="请输入冻结原因" :visible.sync="dongjie_Visible" :show-close="false" width="30%" center>
          <el-input type="textarea" :autosize="{ minRows: 2, maxRows: 4}" placeholder="冻结原因" v-model="dongJie_idea">
          </el-input>
          <span slot="footer" class="dialog-footer" style="text-align: center">
    <el-button size="small" @click="dongjie_Visible = false">取 消</el-button>
    <el-button size="small" type="primary" @click="dongjieSure">确 定</el-button>
  </span>
      </el-dialog>
  </div>
</template>
<script>
import base from '../../basics/base.js';
export default {
  name: 'mainleft',
  data() {
    return {
      state: 1,
      activeName:'first',
      tableData1:null,
      tableData2:null,
      tableData3:[{
          phone:111111
      },{phone:111111}],
      currentPage1:1,
      allpage1:10,
      currentPage2:1,
      allpage2:10,
      currentPage3:1,
      allpage3:10,
      dongjie_show:false,
      dongjie_title:'',
      pagenow1:1,
      pagenow2:1,
      pagenow3:1,
        dongjie_Visible:false,
        dongJie_idea:''
    }
  },
   mounted(){
       this.getdata(0,this.pagenow1,1,1);
  },
  methods: {
      getdata(val,pageno,state,tab){
        var me =this;
        var data = {
            page_no:pageno?pageno:1,
            page_size:10,
            state:val,
            buyers_state:state
          }
           base.axios_post(data, '/api/1/admin/userCenter/buyer/listBuyer', function(res){
               if(res.code == 0){
                    if(tab == 1){
                        me.tableData1 = res.data.list;
                        if(me.tableData1 != ''){
                          me.tableData1.map((v,k)=>{
                            me.tableData1[k].reg_time = me.getLocalTime(me.tableData1[k].reg_time)
                        })
                        }
                        
                        me.allpage1 = res.data.total_page*10;
                    }else if(tab==2){
                        me.tableData2 = res.data.list;
                        if(me.tableData2 != ''){
                           me.tableData2.map((v,k)=>{
                            me.tableData2[k].reg_time = me.getLocalTime(me.tableData2[k].reg_time)
                          })
                        }
                       
                        me.allpage2 = res.data.total_page*10;
                    }else if(tab==3){
                        me.tableData3 = res.data.list;
                        if(me.tableData3 != ''){
                            me.tableData3.map((v,k)=>{
                                me.tableData3[k].change_time = me.getLocalTime(me.tableData3[k].change_time)
                            })
                        }
                    }
                    
               }else if(res.code==100){
                me.$emit("login_state",false)
                }else{
                   me.tableData1 = [];
                   me.tableData2 = [];
                   me.$message({
                          message: res.message,
                          type: 'warning'
                        });
                }
           })
      },
      getLocalTime(t) {
        var d = new Date(t);
        var y = d.getFullYear();
        var m = d.getMonth() + 1;
        var dd = d.getDate();
        var h = d.getHours();
        var mm = d.getMinutes();
        var s = d.getSeconds();
        return y + '-' + e(m) + '-' + e(dd) + ' ' + e(h) + ':' + e(mm) + ':' + e(s);
        function e(t) {
          if (t < 10) {
            return t = '0' + t;
          } else {
            return t;
          }
        }
      }, 
      deleteRow(index,data){
        this.dongjie_Visible = true;
        this.dongjie_id = data[index].buyers_id;
        this.dongjie_title = '确定要冻结'+data[index].buyers_name+'吗？';
      },
      dongjieSure(){
          if(this.dongJie_idea==''){
              this.$message.error('冻结原因不能为空');
          }else{
              this.dongjie_Visible = false;
              var _this = this;
              setTimeout(function () {
                  _this.dongjie_show = true;
              },200);
          }
      },
       handleCurrentChange1(index){ //分页
          this.pagenow1 =index;
          this.getdata(0,this.pagenow1,1,1);
      },
       handleCurrentChange2(index){ //分页
          this.pagenow2 = index;
          this.getdata(1,this.pagenow2,1,2);
      },
       handleCurrentChange3(index){ //分页
          this.pagenow3 = index;
          this.getdata(1,this.pagenow3,0,3);
      },
       dongjie_sure(){
           this.dongjie_and_jieD(this.dongjie_id,0,this.dongJie_idea)
      },
      dongjie_and_jieD(id,state,reason){
          var me =this;
          var data = {
              buyers_id:id,
              state:state,
              reason:reason
          };
          base.axios_post(data, '/api/1/admin/userCenter/buyer/lockBuyer', function(res) {
              if(res.code == 0){
                  if(state==0){
                      me.$message({
                          message: '冻结成功',
                          type: 'success'
                      });
                      me.getdata(1,me.pagenow2,1,2);
                      me.dongjie_show= false;
                      me.dongjie_title ='';
                  }else if(state==1){
                      me.$message({
                          type: 'success',
                          message: '解冻成功!'
                      });
                      me.getdata(1,me.pagenow3,0,3);

                  }

              }else{
                  me.$message({
                      message: '系统繁忙请稍后再试',
                      type: 'warning'
                  });
              }
          })
      },
      jieD(k,data){
          this.$confirm('是否对该供应商解除冻结?', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
          }).then(() => {
              this.dongjie_and_jieD(data[k].buyers_id,1,"");
          }).catch(() => {});

      },
      handleClick(tab, event){
         if(tab.index == 0){
          this.getdata(0,this.pagenow1,1,1);
        }else if(tab.index == 1){
          this.getdata(1,this.pagenow2,1,2);
        }else if(tab.index == 2){
          this.getdata(1,this.pagenow3,0,3)
         }
      }
  }
}
</script>
<style type="text/css">
  .content{
    margin-left: 10px;
    margin-right: 15px;
    margin-top: 20px;
    background-color: #fff;
  }
  .maijia .table{
      width: 96%;
      margin: 0 auto;
  }
  .maijia table tr img {
      width: 35px;
      height: 35px;
      border-radius: 50%;
      vertical-align: middle;
      margin-right: 3px;
  }
  .maijia table tr .number{
      text-align: right;
  }
  .maijia table{
      width: 100%;
      border-collapse: collapse;
      margin: 0 auto;
  }
  .maijia table tr{
      border-bottom: solid 1px #d7d7d7;
  }
  .maijia table tr td{
      padding: 5px 3px;
      font-size: 14px;
  }
  .maijia table tr:first-child{
  }
  .maijia table th{
      font-size: 14px;
      padding: 15px 0;
      color: #666666;
      font-weight:400;
  }
  .maijia .table .overflow{
      max-width: 150px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      text-align: left;
  }
</style>

