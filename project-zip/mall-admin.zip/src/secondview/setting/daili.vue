<template>
  <div class="cat">
    <p style="text-align: left"><el-button @click="add_cate">添 加</el-button></p>
    <div class="no_data" v-if="data_list==''"><img src="../../assets/image/no_data.png"/></div>
    <div class="con" style="overflow: hidden" v-if="data_list!=''">
      <el-row class="head">
        <el-col :span="6" class="t3">保证金(元)</el-col>
        <el-col :span="6" class="t3">可代理商品种类</el-col>
        <el-col :span="6" class="t3">平台佣金(%)</el-col>
        <el-col :span="6">操作</el-col>
      </el-row>
      <div class="first_menu" v-for="(item,i) in data_list" :key="i">
        <el-row>
          <el-col :span="6" class="t2">
              <span>{{item.deposit/100}}</span>
          </el-col>
          <el-col :span="6" class="t2">{{item.goodsNumber}}</el-col>
          <el-col :span="6" class="t2"><span>{{item.platformCommission}}</span></el-col>
          <el-col :span="6"><el-button size="mini" type="primary" @click="delete_menu(item.agentId)">删除</el-button></el-col>
        </el-row>
      </div>
      <el-pagination layout="prev, pager, next" :total="total_pages" @current-change="turn_page"></el-pagination>
    </div>

    <el-dialog title="设置保证金" width="600px" :visible.sync="open_dialog">
        <div class="dialogBody">
          <p>
            <span>保证金(元)</span>
            <el-input v-model="deposit"></el-input>
          </p>
          <p>
            <span>可代理商品种类</span>
            <el-input v-model="workNum"></el-input>
          </p>
          <p>
            <span>平台佣金(%)</span>
            <el-input v-model="brokerage"></el-input>
            <span class="broRule">*设置范围为0~100</span>
          </p>
        </div>
      <div slot="footer" style="text-align: center">
        <el-button type="primary" size="small" @click="save_deposit()">保存</el-button>
      </div>
    </el-dialog>

  </div>
</template>
<script>
import base from "../../basics/base.js";
export default {
  name: "daili",
  data() {
    return {
      page_no: 1,
      page_size: 10,
      total_pages: 1,
      data_list: [],
      open_dialog:false,
      deposit:'',//保证金
      workNum:'',//可代理商品数量
      brokerage:'',//佣金
    };
  },
  created() {
    this.get_data();
  },
  methods: {
    checkout(){
        let data = {
            deposit:this.deposit*100,
            goodsNumber:this.workNum,
            platformCommission:this.brokerage
        };
        let _this = this;
        base.axios_post(data,'/api/1/centerConfig/saveAgentDeposit',function (res) {
            if(res.code==0){
                _this.$message.success('配置代理人保证金成功');
                _this.open_dialog = false;
                _this.deposit = '';
                _this.workNum = '';
                _this.brokerage = '';
                _this.get_data();
            }
        });
    },
    //获取代理保证金
    get_data() {
      let _this = this;
      let json = {
        pageNo: this.page_no,
        pageSize: this.page_size
      };
      base.axios_post(json, "/api/1/centerConfig/queryAgentDepositList", function(res) {
        if (res.code == 0) {
            if(res.data.resultList.length>0){
                _this.total_pages = res.data.pages * 10;
                _this.data_list = res.data.resultList;
            }
        }else{
            _this.data_list = [];
        }
      });
    },
    delete_menu(id){
        let data = {
            agentId:id,
            dr:0
        };
        let _this = this;
        base.axios_post(data,'/api/1/centerConfig/updateAgentDepositInfo',function (res) {
            if(res.code==0){
                _this.$message.success('删除成功!');
                _this.get_data();
            }
        });
    },
    save_deposit(){
        //this.open_dialog = false;
        if(this.deposit==''){
            this.$message.error('保证金不允许为空!')
        }else if( !/^[0-9]\d*$/.test(this.deposit)){
            this.$message.error('保证金只允许为【正整数】哦~')
        }else if(this.workNum==''){
            this.$message.error('可代理的商品种类不允许为空!')
        }else if( !/^[1-9]\d*$/.test(this.workNum)){
            this.$message.error('请输入正确的商品种类!')
        }else if(this.brokerage==''){
            this.$message.error('平台佣金不允许为空!')
        }else if(this.brokerage==100){
            this.checkout();
        }else if(!/^[0-9]\d?(\.\d)?$/.test(this.brokerage)){
            this.$message.error('请输入正确的平台佣金!');
        }else{
            this.checkout();
        }
    },
    turn_page(i){
      this.page_no = i;
      this.get_data();
    },
    add_cate(){
        this.open_dialog = true;
    },
  }
};
</script>
<style>
.cat {
  margin: 0 30px;
  padding: 20px;
  font-size: 14px;
  border-radius: 10px;
  background: #ffffff;
}
.cat .hide {
  display: none;
}
.cat .t2 {
  text-align:right;
  margin: 0;
  padding-right: 10%;
}
.cat .t3 {
  text-align:center;
  margin: 0;
}
.cat .con .el-col {
  color: #48576a;
  line-height: 35px;
}
.cat .con .head {
  background: #edf2fb;
  margin-top: 20px;
}
.cat .con .first_menu {
  border-top: 1px solid #dfe6ec;
}
.cat .con .first_menu .el-row:hover {
  background: #f5f7fa;
}
.cat .con .first_menu .first_txt {
  padding-left: 100px;
}
.cat .con .first_menu .first_txt span {
  padding-left: 10px;
}
.cat .con .first_menu .second_menu .second_txt {
  padding-left: 130px;
}
.cat .con .first_menu .second_menu .second_txt span {
  padding-left: 10px;
}
.cat .con .first_menu .second_menu .second_btn {
  padding-left: 130px;
}
.cat .con .first_menu .second_menu img {
  width: 30px;
}
.se_dialog img{
  width: 100px;
  vertical-align: middle;
  margin-right: 15px;
}
 .dialogBody p{
    width: 74%;
    margin: 20px auto;
   overflow: hidden;
  }
.dialogBody p >span{
  float: left;
  display: inline-block;
  width: 100px;
  height: 40px;
  line-height: 40px;
  margin-right: 20px;
  text-align: left;
}
.dialogBody p >div{
  width: 150px;
  float: left;
}
.dialogBody p .broRule{
  float: left;
  width: 117px;
  color: #ee551c;
  margin-left: 5px;
  }
</style>
