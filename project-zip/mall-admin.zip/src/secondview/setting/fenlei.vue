<template>
  <div class="cat">
    <p class="tl"><el-button @click="add_cate">添加分类</el-button></p>
    <div class="con" style="overflow: hidden">
      <el-row class="head">
        <el-col :span="6">分类名称</el-col>
        <el-col :span="6">分类图片</el-col>
        <el-col :span="6">隐藏/显示</el-col>
        <el-col :span="6">操作</el-col>
      </el-row>
      <div class="first_menu" v-for="(item,i) in data_list" :key="i">
        <el-row>
          <el-col :span="6" class="tl">
            <div @click="item.is_show=!item.is_show">
              <span class="first_txt"><el-button v-if="item.is_show" icon="el-icon-caret-bottom" type="text"></el-button><el-button v-if="!item.is_show" icon="el-icon-caret-right" type="text"></el-button></i><span>{{item.parentName}}</span></span>
            </div>
          </el-col>
          <el-col :span="6">&nbsp;</el-col>
          <el-col :span="6"><el-switch v-model="item.pTypeState" @change="update_state(1,item)"></el-switch></el-col>
          <el-col :span="6"><el-button size="mini" type="primary" @click="to_update_menu(1,item)">修改</el-button></el-col>
        </el-row>
        <el-collapse-transition>
          <div class="second_menu" v-show="item.is_show">
            <el-row v-for="(item2,i) in item.children" :key="i">
              <el-col :span="6" class="tl"><span class="second_txt"><i class="el-icon-minus"></i><span>{{item2.typeChinese}}</span></span></el-col>
              <el-col :span="6"><img :src="item2.typeIcon"></el-col>
              <el-col :span="6"><el-switch v-model="item2.pTypeState" @change="update_state(2,item2)"></el-switch></el-col>
              <el-col :span="6"><el-button size="mini" type="primary" @click="to_update_menu(2,item2)">修改</el-button></el-col>
            </el-row>
            <el-row>
              <el-col :span="6" class="tl"><span class="second_btn"><el-button icon="el-icon-circle-plus" type="text" @click="add_second(item.parentId)">添加二级分类</el-button></span></el-col>
            </el-row>
          </div>
        </el-collapse-transition>
      </div>
      <el-pagination layout="prev, pager, next" :total="total_pages" @current-change="turn_page"></el-pagination>
    </div>
    <el-dialog title="添加分类" width="450px" :visible.sync="open_first_dialog">
      <el-form>
        <el-form-item label="分类名称：" label-width="120px">
          <el-input size="small" v-model="first_menu" auto-complete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" style="text-align: center">
        <el-button type="primary" size="small" @click="save_menu(1)">保存</el-button>
      </div>
    </el-dialog>
    <el-dialog title="添加二级分类" width="450px" :visible.sync="open_second_dialog">
      <el-form class="se_dialog">
        <el-form-item label="分类名称：" label-width="120px">
          <el-input size="small" v-model="second_menu" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="分类图片：" label-width="120px">
          <p class="tl"><img v-if="second_menu_img!=''" :src="second_menu_img"><el-button type="primary" size="small" @click="upload">上传图片</el-button></p>
          <form enctype="multipart/form-data" style="display:none" id="uploadForm_default_tea">
            <input type="file" @change="upload_img" id="tea_cate_img" name="file" accept="image/png,image/gif,image/jpeg"/>
            <input type="hidden" name="goods" value="123456" />
          </form>
        </el-form-item>
      </el-form>
      <div slot="footer" style="text-align: center">
        <el-button type="primary" size="small" @click="save_menu(2)">保存</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import base from "../../basics/base.js";
export default {
  name: "fenlei",
  data() {
    return {
      value: "",
      open_first_dialog: false,
      open_second_dialog: false,
      first_menu: "",
      second_menu: "",
      second_menu_img: "",
      page_no: 1,
      page_size: 10,
      total_pages: 1,
      data_list: [],
      parentId: '',
      update_menu_obj:'',
      is_update_menu: false
    };
  },
  created() {
    this.get_data();
  },
  methods: {
    //获取分类列表信息
    get_data() {
      let _this = this;
      let json = {
        pageNo: this.page_no,
        pageSize: this.page_size
      };
      base.axios_post(json, "/api/1/centerConfig/queryTreeGoodsType", function(res) {
        if (res.code == 0) {
          _this.total_pages = res.data.pages * 10;
          res.data.resultList.map(function(item, i) {
            item.is_show = false;
            if (item.pTypeState == 0) {
              item.pTypeState = false;
            } else {
              item.pTypeState = true;
            }
            item.children.map(function(item2,j){
              if (item2.cTypeState == 0) {
                item2.pTypeState = false;
              } else {
                item2.pTypeState = true;
              }
            })
          });
          _this.data_list = res.data.resultList;
        }
      });
    },
    turn_page(i){
      this.page_no = i;
      this.get_data();
    },
    to_update_menu(type,item){
      if (type == 1) {
        this.first_menu = item.parentName;
        this.open_first_dialog = true;
      }
      if (type == 2) {
        this.second_menu = item.typeChinese;
        this.second_menu_img = item.typeIcon;
        this.open_second_dialog = true;
      }
      this.is_update_menu = true;
      this.update_menu_obj = item;
    },
    //修改分类
    update_menu(type,item) {
      let json = {
        typeId: '',
        typeChinese: '',
        typeState: 1,
        typeIcon: ''
      }
      if (!item.pTypeState) {
        json.typeState = 0;
      } else {
        json.typeState = 1;
      }
      if (type == 1) {
        json.typeId = item.parentId;
        if (this.first_menu == '') {
          json.typeChinese = item.parentName;
        } else {
          json.typeChinese = this.first_menu;
        }
      }
      if (type == 2) {
        json.typeId = item.typeId;
        if (this.second_menu == '') {
          json.typeChinese = item.typeChinese;
          json.typeIcon = item.typeIcon;
        } else {
          json.typeChinese = this.second_menu;
          json.typeIcon = this.second_menu_img;
        }
      }
      let _this = this;
      base.axios_post(json,"/api/1/centerConfig/updateGoodsType",function(res){
        _this.$message({message: res.message});
        if (res.code == 0) {
          _this.open_first_dialog = false;
          _this.open_second_dialog = false;
          _this.get_data();
        }
      });
    },
    update_state(type,item){
      let json = {};
      if (type == 1) {
        json.typeId = item.parentId;
      }
      if (type == 2) {
        json.typeId = item.typeId;
      }
      if (item.pTypeState) {
        json.typeState = 1;
      } else {
        json.typeState = 0;
      }
      let _this = this;
      base.axios_post(json,"/api/1/centerConfig/updateGoodsTypeState",function(res){
        _this.$message({message: res.message});
        if (res.code == 0) {
          _this.get_data();
        }
      });
    },
    save_menu(type) {
      if (this.is_update_menu) {
        this.update_menu(type,this.update_menu_obj);
        return;
      }
      let _this = this;
      if (type == 1) {
        //保存一级菜单
        if (this.first_menu == "") {
          this.$message("请输入分类名称");
          return;
        }
        var json = {
          typeChinese: this.first_menu,
          typeEnglish: '',
          typeMode: 1
        };
        var data = {
          typeId: "",
          typeMode: 1
        }
      }
      if (type == 2) {
        if (this.second_menu == "") {
          this.$message("请输入分类名称");
          return;
        }
        if (this.second_menu_img == "") {
          this.$message("请上传分类图片");
          return;
        }
        var json = {
          typeChinese: this.second_menu,
          typeEnglish: '',
          typeMode: 2,
          parentId: this.parentId,
          typeIcon: this.second_menu_img
        };
        var data = {
          typeId: this.parentId,
          typeMode: 1
        }
      }
      base.axios_post(data,"/api/1/centerConfig/queryTypeSortNum",function(res){
        if (res.code == 0) {
          json.typeSort = res.data;
          base.axios_post(json, "/api/1/centerConfig/saveGoodsType", function(res) {
            _this.$message(res.message);
            if (res.code == 0) {
              _this.page_no == 1;
              _this.get_data();
              _this.open_first_dialog = false;
              _this.open_second_dialog = false;
            }
          });
        }
      })
    },
    add_cate(){
      this.first_menu = '';
      this.open_first_dialog = true;
    },
    add_second(parentId){
      this.second_menu = '';
      this.second_menu_img = '';
      this.parentId = parentId;
      this.open_second_dialog = true;
    },
    upload() {
      document.getElementById("tea_cate_img").click();
    },
    upload_img() {
      let _this = this;
      var option = {
        url: "/oss/uploadGoodsFile",
        type: "post",
        dataType: "json",
        timeout: 10000,
        success: function(data) {
          console.log(data);
          _this.second_menu_img = data.data;
          document.getElementById("tea_cate_img").value = "";
        }
      };
      jQuery("#uploadForm_default_tea").ajaxSubmit(option);
      return false;
    }
  }
};
</script>
<style>
.cat {
  margin: 0 30px;
  padding: 20px;
  font-size: 14px;
  border-radius: 10px;
  background: #ffffff;
}
.cat .hide {
  display: none;
}
.cat .tl {
  text-align: left;
  margin: 0;
}
.cat .con .el-col {
  color: #48576a;
  line-height: 35px;
}
.cat .con .head {
  background: #edf2fb;
  margin-top: 20px;
}
.cat .con .first_menu {
  border-top: 1px solid #dfe6ec;
}
.cat .con .first_menu .el-row:hover {
  background: #f5f7fa;
}
.cat .con .first_menu .first_txt {
  padding-left: 100px;
}
.cat .con .first_menu .first_txt span {
  padding-left: 10px;
}
.cat .con .first_menu .second_menu .second_txt {
  padding-left: 130px;
}
.cat .con .first_menu .second_menu .second_txt span {
  padding-left: 10px;
}
.cat .con .first_menu .second_menu .second_btn {
  padding-left: 130px;
}
.cat .con .first_menu .second_menu img {
  width: 30px;
}
.se_dialog img{
  width: 100px;
  vertical-align: middle;
  margin-right: 15px;
}
</style>
