<template>
    <div class="content groupBuying">
        <div v-if="!add_group" class="title">
            <el-button @click="add_group = true;" type="primary">发起企业团购</el-button>
        </div>
        <div class="no_data" v-if="tableData1==''"><img src="../../assets/image/no_data.png"/></div>
        <div  v-if="!add_group">
            <div v-if="tableData1!=''" class="table">
                <table style="width: 100%">
                    <tr>
                        <th>商品名称</th>
                        <th class="number">市场价</th>
                        <th class="number">团购价</th>
                        <th>状态</th>
                        <th>操作</th>
                    </tr>
                    <tr v-for="(v,k) in tableData1" :key="k">
                        <td class="overflow"><img :src="v.goodsIcon">{{v.goodsName}}</td>
                        <td class="number">{{(v.marketPrice/100).toFixed(2)}}</td>
                        <td class="number">{{(v.groupPrice/100).toFixed(2)}}</td>
                        <td>{{v.state}}</td>
                        <td style="text-align: center">
                            <el-button class="copyBtn"
                                    v-if="v.state=='有效' && !sure_URL"
                                    @click="copy(k,tableData1)"
                                    :data-clipboard-text = "'testwechat.hotol.cn/views/emall/theme.html?src='+encodeURIComponent(v.imgUrl)+'&id='+v.goodsId"
                                    type="primary" plain
                                    size="mini">
                                专题链接
                            </el-button>
                            <el-button class="copyBtn"
                                    v-if="v.state=='有效' && sure_URL"
                                    @click="copy(k,tableData1)"
                                    :data-clipboard-text = "'wechat.hotol.cn/views/emall/theme.html?src='+encodeURIComponent(v.imgUrl)+'&id='+v.goodsId"
                                    type="primary" plain
                                    size="mini">
                                专题链接
                            </el-button>
                            <el-button
                                    class="copyBtn2"
                                    v-if="v.state=='有效'&& sure_URL"
                                    @click.native.prevent="check(k, tableData1)"
                                    :data-clipboard-text = "'wechat.hotol.cn/user/share.html?gid='+v.goodsId"
                                    type="success" plain
                                    size="mini">
                                商品链接
                            </el-button>
                            <el-button
                                    class="copyBtn2"
                                    v-if="v.state=='有效' && !sure_URL"
                                    @click.native.prevent="check(k, tableData1)"
                                    :data-clipboard-text = "'testwechat.hotol.cn/user/share.html?gid='+v.goodsId"
                                    type="success" plain
                                    size="mini">
                                商品链接
                            </el-button>
                        </td>
                    </tr>
                </table>
                <el-pagination
                        @current-change="handleSizeChange"
                        :current-page.sync="currentPage1"
                        :page-size="10"
                        layout="prev, pager, next, jumper"
                        :total="totPage1">
                </el-pagination>
            </div>
        </div>

        <div v-if="add_group" class="group_rules">
            <div class="Bback"><span @click="add_group = false"><i class="el-icon-caret-left"></i>返回上一页</span></div>
            <div class="group_content">
                <div  class="left">
                    <p>商品名称</p>
                    <p>市场价</p>
                    <p>团购价</p>
                    <p>活动图片</p>
                </div>
                <div class="right">
                    <p>
                        <span class="goods_name">{{goodsName}}</span>
                        <el-button @click="choose_goods" type="primary" size="mini" style="vertical-align: top">选择</el-button>
                    </p>
                    <p>{{(marketPrice/100).toFixed(2)}}</p>
                    <p>{{(groupPrice/100).toFixed(2)}}</p>
                    <p style="height: auto">
                        <el-button @click="choose_pic" type="primary" size="mini" style="margin-left:20%">选择</el-button>
                    <form enctype="multipart/form-data" style="display:none" id="uploadForm_default_tea">
                        <input type="file" @change="upload_img()" id="tea_cate_img" name="file" accept="image/png,image/gif,image/jpeg"/>
                        <input type="hidden" name="goods" value="123456" />
                    </form>
                        <span v-if="!icon"  v-loading="loading" class="loading"></span>
                        <img v-if="icon" :src="icon">
                    </p>
                </div>
            </div>
            <el-button @click="submitPic" type="primary" style="margin:0 0 10% 44%">提交</el-button>
        </div>

        <el-dialog class="showGoods" title="请选择商品" :visible.sync="goods_Visible" :show-close="false">
            <el-radio-group v-model="goods" @change="addGoods" v-if="goodsList!=''">
                <el-radio v-for="(v,k) in goodsList" :label="k" :key="k">{{v.goodsName}}</el-radio>
            </el-radio-group>
            <div class="no_data" v-if="goodsList==''"><img src="../../assets/image/no_data.png"/></div>
            <el-pagination
                    @current-change="handleCurrentChange2"
                    :current-page.sync="currentPage2"
                    :page-size="10"
                    layout="prev, pager, next, jumper"
                    :total="totalPages2">
            </el-pagination>

        </el-dialog>
    </div>
</template>
<script>
    import base from '../../basics/base.js';
    import Clipboard from 'clipboard';
    let clipboard = new Clipboard('.copyBtn');
    let clipboard2 = new Clipboard('.copyBtn2');
    export default {
        name: '',
        data() {
            return {
                tableData1:[],
                totPage1:1,
                currentPage1:1,
                goods_id:null,
                goods_Visible:false,//选择商品
                goods:-1,//单选按钮 默认选中
                currentPage2:1,//商品选择的当前页
                totalPages2:10,
                add_group:false,//发起企业团购
                goodsList:[],//商品列表
                goodsName:'',
                marketPrice:0,
                groupPrice:0,
                icon:'',
                goodsId:'',
                img_msg:[],
                loading:false,
                sure_URL:false,

            }
        },
        created(){
            if(window.location.host.indexOf('test')===-1){
                this.sure_URL = true;
            }

        },
        mounted() {
            this.getData();
        },
        methods: {
            copy(index,data){

                base.alerter('复制专题链接成功')
            },
            check(index,data){
                base.alerter('复制商品链接成功')
            },
            getinfo(index){
                var me = this;
                var data = {};
                base.axios_post(data, ' ', function(res) {
                    /*if(res.code == 0){

                        if (res.data!=null) {

                        }
                    }else{
                        me.$message({message: res.message,type: 'error'});
                        return;
                    }*/
                });
            },
            getData(){
                var me =this;
                var data = {
                    page_no:this.currentPage1,
                    page_size:10
                };
                base.axios_post(data, '/api/1/goods/backQryEnterpriseReleaseList', function(res) {
                    if (res.code == 0) {
                        if(res.data != null){
                            me.totPage1 = res.data.pages;
                            me.tableData1 = res.data.resultList;
                            for(let i in me.tableData1){
                                if(me.tableData1[i].state == 1){
                                    me.tableData1[i].state = '有效';
                                }else{
                                    me.tableData1[i].state = '无效';
                                }
                            }
                        }
                    }else{
                        me.$message({message: res.message,type: 'error'});
                        return;
                    }
                })
            },
            handleSizeChange(index){
                this.currentPage1 = index;
                this.getData();
            },
            choose_goods(){
                this.goods_Visible = true;
                this.get_goodsList();
            },
            choose_pic(){
                document.getElementById("tea_cate_img").click();
            },
            submitPic(){
                if(!this.goodsName){
                    this.$message.error('请选择要团购的商品!');
                }else if(!this.icon){
                    this.$message.error('请选择商品图片!');
                }else{
                    //this.icon.substring(this.icon.indexOf(',')+1,this.icon.length);
                    let data = {
                        groupPrice:this.groupPrice,
                        goodsId:this.goodsId,
                        imgUrl:this.icon,
                    };
                    let _this = this;
                    base.axios_post(data,'/api/1/goods/backSaveEnterpriseGroupRelease',function (res) {
                        if(res.code==0){
                            _this.$message.success('已成功发起企业团购!');
                            _this.add_group = false;
                            _this.goodsName = '';
                            _this.marketPrice = 0;
                            _this.groupPrice = 0;
                            _this.icon = '';
                            _this.goodsId = '';
                            _this.loading = false;
                            _this.img_msg = [];
                            _this.getData();
                        }else{
                            _this.alerter(res.message);
                        }
                    });
                }
            },
            handleCurrentChange2(i){
                this.currentPage2 = i;
                this.get_goodsList();
            },
            //选中商品时触发
            addGoods(){
                this.goodsName = this.goodsList[this.goods].goodsName;
                this.marketPrice = this.goodsList[this.goods].marketPrice;
                this.groupPrice = this.goodsList[this.goods].groupPrice;
                this.goodsId = this.goodsList[this.goods].goodsId;
                this.goods_Visible = false;
            },
            get_goodsList(){
                let data = {
                    page_no:this.currentPage2,
                    page_size:10
                };
                let _this = this;
                base.axios_post(data,'/api/1/goods/backQryEnterpriseGroupGoods',function (res) {
                    if(res.code==0){
                        if(res.data){
                            _this.totalPages2 = res.data.pages*10;
                            _this.goodsList = res.data.resultList;
                        }
                    }
                });
            },
            upload_img(){
                this.loading = true;
                let _this = this;
                let option = {
                    url: "/oss/uploadGoodsFile",
                    type: "post",
                    dataType: "json",
                    //timeout: 10000,
                    success: function (data) {
                        _this.icon = data.data;
                        this.loading = false;
                            let $ipt_file = document.getElementById("tea_cate_img").files[0];
                        let name_arr = $ipt_file.name.split(".");
                        let obj = {
                            fileName: $ipt_file.name,
                            fileSize: $ipt_file.size,
                            fileType: 3, //1小图标 2轮播图 3详情图片
                            suffixName: name_arr[name_arr.length-1],
                            thumbnailAddress: data.data,
                            urlAddress: data.data,
                            goodsId: _this.goodsId
                        };
                        _this.img_msg.push(obj);
                        document.getElementById("tea_cate_img").value = "";
                    },
                    error: function(err){
                        base.msg.hide();
                        _this.$message.error("图片上传失败");
                    }
                };
                jQuery("#uploadForm_default_tea").ajaxSubmit(option);
            }
        }
    }
</script>
<style type="text/css">
    .groupBuying{
        margin-left: 10px;
        margin-right: 15px;
        background-color: #f9f9f9;
        border-radius: 12px;
        text-align: left;
        position: relative;
    }
    .groupBuying .showGoods>div{
        width: 700px!important;
    }
    .groupBuying .title{
        background: #fff;
        padding: 15px;
        border-radius: 12px;
        text-align: left;
        width: 97%;
    }
    .groupBuying .table{
        width: 96%;
        margin: 0 auto;
        padding: 20px;
        border-radius: 12px;
        margin-top: 15px;
        background-color: #fff;
    }
    .groupBuying table tr img {
        width: 35px!important;
        height: 35px!important;
        border-radius: 50%;
        vertical-align: middle;
        margin-right: 3px;
    }
    .groupBuying table{
        width: 100%;
        border-collapse: collapse;
        margin: 0 auto;
    }
    .groupBuying table tr{
        border-bottom: solid 1px #d7d7d7;
    }
    .groupBuying table tr td{
        padding: 5px 3px;
        font-size: 14px;
        text-align: center;
    }
    .groupBuying table th{
        font-size: 14px;
        padding: 15px 0;
        color: #666666;
        font-weight:400;
        text-align: center;
    }
    .groupBuying .table .overflow{
        max-width: 150px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        text-align: left;
    }
    .groupBuying .table .number{
        text-align: right!important;
    }
    .groupBuying .el-pagination {
        text-align: right!important;
        margin-top: 20px;
        margin-bottom: 30px;
        float:none;
    }
    .groupBuying .group_rules{
        background: #fff;
        padding: 10px 30px 0 10px;
        border-radius: 8px;
    }
    .groupBuying .Bback{
        text-align: left;
    }
    .groupBuying .Bback span{
        display: inline-block;
        padding:15px;
        font-size:20px;
        color: #008cff;
        cursor: pointer;
    }
    .group_rules .group_content{
        text-align: left;
        padding: 30px 0;
        width:60%;
        margin: 0 auto;
        overflow: hidden;
        padding-left: 10%;
    }
    .group_rules .group_content p{
        margin: 10px 0;
        height: 36px;
        line-height: 36px;
    }
    .groupBuying .left{
        float: left;
        width:15%;
    }

    .groupBuying .right{
        float: right;
        width: 85%;
    }
    .groupBuying .right input{
        position: relative;
        left:-15%;
        bottom: 14%;
        cursor: pointer;
        opacity: 1;
    }
    .groupBuying .right img{
        display: block;
        width: 150px;
        height: 150px;
        margin:10px 0 0 10% ;
    }
    .groupBuying .right .loading{
        display: inline-block!important;
        width: 150px;
        height: 150px;
        margin:10px 0 0 10% ;

    }
    .groupBuying .right .goods_name{
        display: inline-block;
        max-width:80%;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        min-width: 18.9%;
    }
    .el-radio-group{
        width: 100%;
    }
    .el-radio{
        width: 100%;
        margin: 10px 0!important;
        display: block;
        text-align: left;
    }
    .el-radio .el-radio__label{
        display: inline-block;
        width:90%;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;

    }
</style>

