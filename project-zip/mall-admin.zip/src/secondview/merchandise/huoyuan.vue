<template>
  <div class="content huoyuan">
      <el-tabs v-model="activeName" @tab-click="handleClick">
      <el-tab-pane label="待审核" name="first">
          <div class="no_data" v-if="tableData1==''"><img src="../../assets/image/no_data.png"/></div>
          <div v-if="tableData1!=''" class="table">
            <table style="width: 100%" v-if="in_shenghe == false" >
              <tr>
                  <th>商品名称</th>
                  <th class="number">市场价</th>
                  <th class="number">供货价</th>
                  <th class="number">库存量</th>
                  <th>提交时间</th>
                  <th>操作</th>
              </tr>
              <tr v-for="(v,k) in tableData1" :key="k">
                  <td class="overflow"><img :src="v.goodsIcon">{{v.goodsName}}</td>
                  <td class="number">{{v.marketPrice}}</td>
                  <td class="number">{{v.supplyPrice}}</td>
                  <td class="number">{{v.stockAmount}}</td>
                  <td>{{v.submitTime}}</td>
                  <td>
                      <el-button
                              @click.native.prevent="deleteRow(k,tableData1)" type="text" size="small">审核
                      </el-button>
                  </td>
              </tr>
          </table>
            <el-pagination
            v-if="in_shenghe == false"
            @current-change="handleCurrentChange1"
            :current-page.sync="currentPage1"
            :page-size="10"
            layout="prev, pager, next, jumper"
            :total="totalpage1">
          </el-pagination>
            <div class="info_main" v-if="in_shenghe == true">
              <div class="goback" @click="his_go"> <span class="back"></span>返回上一页</div>
              <div class="main">
                  <el-button type="primary"  @click="getpass" class="pass">通过审核</el-button>
                  <el-button type="danger" @click="reject" class="reject">驳回申请</el-button>
                  <div class="info_box">
                     <div class="select_box">
                          <p class="select_in" v-for="(item,index) in righttit" v-bind:class="{active:item.hightlight == '1'}" @click="showchange(index)">{{item.tit}}</p>
                    </div>
                     <div class="cont_right" v-if="nowshow == 0">
                          <p><span class="titlename">商品图片</span><span class="datashow goodsicon"><img :src="goodsIcon"></span></p>
                          <p><span class="titlename">商品名称</span><span class="datashow">{{goods_name}}</span></p>
                          <p><span class="titlename">分类</span><span class="datashow">{{goods_classify}}</span></p>
                          <p><span class="titlename">属性</span><span  class="datashow">{{goods_nature}}</span></p>
                          <p><span class="titlename">商品品牌</span><span class="datashow">{{goods_brands}}</span></p>
                          <p><span class="titlename">市场价</span><span  class="datashow">{{goods_market}}（元）</span></p>
                          <p><span class="titlename">供货价</span><span class="datashow blue">{{goods_supply}}（元）</span></p>
                          <p><span class="titlename">商品介绍</span>
                              <span class="area1">{{goodsIntroduce}}</span>
                          </p>
                      </div>
                     <div class="cont_right" v-if="nowshow == 1">
                            <p class="box2"><span class="titlename">可售数量</span><span class="titlename">规格</span></p>
                            <!--<p class="box2"><span class="titlename">规格</span></p>-->
                            <div class="guige_box">
                              <ul v-for=" item in xiangxi" >
                                <li>{{item.stockAmount}}</li>
                                <li>{{item.magnitude}}  {{item.colour}}</li>
                              </ul>
                            </div>
                      </div>
                     <div class="cont_right" v-if="nowshow == 2">
                        <div class="ban" id="demo1">
                          <div class="ban2" id="ban_pic1">
                            <div class="prev1" id="prev1"><img src="../../assets/image/big_left.png" width="28" height="51"></div>
                            <div class="next1" id="next1"><img src="../../assets/image/big_right.png" width="28" height="51"  alt=""></div>
                            <ul>
                                <li v-for="item in picarr"><a href="javascript:;"><img :src="item" width="480" height="480"></a></li>
                            </ul>
                          </div>
                          <div class="min_pic">
                            <div class="prev_btn1" id="prev_btn1"><img src="../../assets/image/small_left.png" width="9" height="18"  alt=""></div>
                            <div class="num clearfix" id="ban_num1">
                              <ul>
                                <li v-for="item in picarr"><a href="javascript:;"><img :src="item" width="80" height="80" alt=""></a></li>      
                              </ul>
                            </div>
                            <div class="next_btn1" id="next_btn1"><img src="../../assets/image/small_right.png" width="9" height="18"  alt=""></div>
                          </div>
                        </div>
                        <div class="mhc"></div>
                        <div class="pop_up" id="demo2">
                          <div class="pop_up_xx"><img src="../../assets/image/chacha3.png" width="40" height="40"  alt=""></div>
                          <div class="pop_up2" id="ban_pic2">
                            <ul>
                              <li v-for="item in picarr"><a href="javascript:;"><img :src="item" width="500" height="500" alt=""></a></li> 
                            </ul>
                          </div>
                        </div>
                     </div>
                     <div class="cont_right" v-if="nowshow == 3">
                          <div class="ban" id="demo1">
                              <div class="ban2" id="ban_pic1">
                                  <div class="prev1" id="prev1"><img src="../../assets/image/big_left.png" width="28" height="51"></div>
                                  <div class="next1" id="next1"><img src="../../assets/image/big_right.png" width="28" height="51"  alt=""></div>
                                  <ul>
                                      <li v-for="item in picText"><a href="javascript:;"><img :src="item.urlAddress" width="480"></a></li>
                                  </ul>
                              </div>
                              <div class="min_pic">
                                  <div class="prev_btn1" id="prev_btn1"><img src="../../assets/image/small_left.png" width="9" height="18"  alt=""></div>
                                  <div class="num clearfix" id="ban_num1">
                                      <ul>
                                          <li v-for="item in picText"><a href="javascript:;"><img :src="item.urlAddress" width="80" alt=""></a></li>
                                      </ul>
                                  </div>
                                  <div class="next_btn1" id="next_btn1"><img src="../../assets/image/small_right.png" width="9" height="18"  alt=""></div>
                              </div>
                          </div>
                          <div class="mhc"></div>
                          <div class="pop_up" id="demo2">
                              <div class="pop_up_xx"><img src="../../assets/image/chacha3.png" width="40" height="40"  alt=""></div>
                              <div class="pop_up2" id="ban_pic2">
                                  <ul style="padding:0;">
                                      <li v-for="item in picText"><a href="javascript:;"><img :src="item.urlAddress" width="500" alt=""></a></li>
                                  </ul>
                              </div>
                          </div>
                      </div>
                     <div class="cont_right" v-if="nowshow == 4">
                            <p class="box2"><span class="titlename">发货时间</span><span>{{startday}}</span></p>
                            <p class="box2"><span class="titlename">7天无理由退货</span><span>{{day7}}</span></p>
                    </div>
                  </div>
              </div>
          </div>
          </div>
      </el-tab-pane>
      <el-tab-pane label="已驳回" name="second">
          <div class="no_data" v-if="tableData2==''"><img src="../../assets/image/no_data.png"/></div>
          <div v-if="tableData2!=''" class="table">
             <table style="width: 100%">
                 <tr>
                     <th>用户名</th>
                     <th>驳回意见</th>
                     <th>驳回时间</th>
                 </tr>
                 <tr v-for="(v,k) in tableData2">
                     <td class="overflow"><img :src="v.goodsIcon">{{v.goodsName}}</td>
                     <td>{{v.finalRejection}}</td>
                     <td>{{v.examineTime}}</td>
                 </tr>
             </table>
            <el-pagination
            @current-change="handleCurrentChange2"
            :current-page.sync="currentPage2"
            :page-size="10"
            layout="prev, pager, next, jumper"
            :total="totalpage2">
          </el-pagination>
          </div>
      </el-tab-pane>
        
    </el-tabs>
     <el-dialog
      title="审核意见"
      :visible.sync="dialogVisible"
      width="30%"
      :showClose="false"
      >
      <textarea  class="input_box" v-model="input_txt" placeholder="请输入驳回理由"></textarea>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="shenghe_sure">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<!--<script src="http://www.17sucai.com/preview/1/2016-07-26/tab/js/pic_tab.js"></script>-->
<script>
/*import pic_tab from "../../common/pic_tab.js";*/

import base from '../../basics/base.js';
export default {
  name: 'mainleft',
  data() {
    return {
      state: 1,
      dialogVisible:false,
      activeName:'first',
      in_shenghe:false,
      currentPage1:1,
      currentPage2:1,
      nowshow:'0',
      totalpage1:10,
      totalpage2:10,
      goodsIcon:'',
      goods_classify:'',
      goods_brands:'',
      goods_nature:'',
      goods_market:'',
      goods_supply:'',
      goods_name:'',
      goods_number:'',
      goodsIntroduce:"",
      getid:'',
      startday:'',
      day7:'',
      input_txt:'',
      getaddr:'',
      tableData2:null,
      xiangxi:null,
      righttit:[
        {
          tit:"基础信息",
          hightlight:"1"
        },{
          tit:"规格信息",
          hightlight:"0"
        },{
          tit:"轮播图片",
          hightlight:"0"
        },{
           tit:"图文信息",
           hightlight:"0"
          },{
          tit:"其他信息",
          hightlight:"0"
        }],
      tableData1: [],
      picarr:[],
      picText:[],
      pagenow1:1,
      pagenow2:1,
    }
  },
   created(){
      this.getdata(2,1)
  },
  methods: {
      handleClick(tab, event){
        if(tab.index ==0){
            this.in_shenghe = false;
            this.getdata(2,this.pagenow1);
        }else{
            this.in_shenghe = false;
            this.getdata(3,this.pagenow2);
        }
      },
      getPrice(value){
          var f = Math.round(value*100)/100;
          var s = f.toString();
          var rs = s.indexOf('.');
          if (rs < 0) {
              rs = s.length;
              s += '.';
          }
          while (s.length <= rs + 2) {
              s += '0';
          }
          return s;
      },
      getdata(val,pageno){
        var me = this;
        var data = {
          "goods_state":val,
          "page_no": pageno,
          "page_size": 10
        }
          base.axios_post(data, '/api/1/goods/queryBackStockGoodsInfoList', function(res) {
            if(res.code ==0){
                if(val ==2){
                      me.tableData1 = res.data.list;
                       me.totalpage1 = res.data.pages*10;  
                       if(me.tableData1.length != 0){
                           me.tableData1.map((v,k)=>{
                              //var time = new Date(me.tableData1[k].submitTime);
                              me.tableData1[k].submitTime = me.getLocalTime(me.tableData1[k].submitTime);
                              me.tableData1[k].marketPrice = me.getPrice(me.tableData1[k].marketPrice/100);
                              me.tableData1[k].supplyPrice = me.getPrice(me.tableData1[k].supplyPrice/100);
                              if(me.tableData1[k].validityTime == null){
                                  me.tableData1[k].validityTime = '无'
                              }else{
                                 me.tableData1[k].validityTime = me.getLocalTime(me.tableData1[k].validityTime);
                              }
                           })
                        }  
                }else{
                    me.tableData2 =  res.data.list;
                    me.totalpage2 = res.data.pages*10;  
                    if(me.tableData2.length != 0){
                         me.tableData2.map((v,k)=>{
                             //var time = new Date(me.tableData2[k].examineTime);
                             me.tableData2[k].examineTime = me.getLocalTime(me.tableData2[k].examineTime);
                         })
                    }
                }
            } else {
              me.tableData1 = [];
              me.tableData2 = [];
            }
          })
      },
      getLocalTime(t) {
        var d = new Date(t);
        var y = d.getFullYear();
        var m = d.getMonth() + 1;
        var dd = d.getDate();
        var h = d.getHours();
        var mm = d.getMinutes();
        var s = d.getSeconds();
        return y + '-' + e(m) + '-' + e(dd) + ' ' + e(h) + ':' + e(mm) + ':' + e(s);
        function e(t) {
          if (t < 10) {
            return t = '0' + t;
          } else {
            return t;
          }
        }
      },
      getpass(){
          this.gotpassagent(4,'')
      },
      shenghe_sure(){
          this.gotpassagent(3,this.input_txt);
      },
      reject(){            
           this.dialogVisible = true;
      },
      replay_sp(){//审批数据重置
        this.goodsIcon='';
        this.goods_classify='';
        this.goods_brands='';
        this.goods_nature='';
        this.goods_market='';
        this.goods_supply='';
        this.goods_name='';
        this.goods_validity='';
        this.goods_number='';
        this.startday='';
        this.day7='';
        this.getaddr='';
        this.xiangxi=[];
      },
      gotpassagent(val,txt){//审批接口
          if(val==3){
              if(txt==''){
                  this.$message.error('驳回理由不能为空!');
                  return false;
              }
          }

        var me =this;
        var data = {
          goodsId:this.getid,
          goods_state:val,
          reason:txt
        }
          base.axios_post(data, '/api/1/goods/approveGoodsInfo', function(res) {
            if(res.code ==0){
                me.$message({
                    message: '操作成功',
                    type: 'success'
                });
                me.dialogVisible =false;
                me.input_txt ='';
                setTimeout(()=>{
                   me.in_shenghe = false;
                  me.replay_sp()
              },1000)
                me.getdata(2,me.pagenow1);
            }else{
              me.$message({
                message: '系统繁忙请稍后再试',
                type: 'warning'
              });
            }
          })
      },
      mods(){
       setTimeout(function(){
        console.log("111111")
        jq('#demo1').banqh({
            box:"#demo1",//总框架
            pic:"#ban_pic1",//大图框架
            pnum:"#ban_num1",//小图框架
            prev_btn:"#prev_btn1",//小图左箭头
            next_btn:"#next_btn1",//小图右箭头
            pop_prev:"#prev2",//弹出框左箭头
            pop_next:"#next2",//弹出框右箭头
            prev:"#prev1",//大图左箭头
            next:"#next1",//大图右箭头
            pop_div:"#demo2",//弹出框框架
            pop_pic:"#ban_pic2",//弹出框图片框架
            pop_xx:".pop_up_xx",//关闭弹出框按钮
            mhc:".mhc",//朦灰层
            autoplay:false,//是否自动播放
            interTime:5000,//图片自动切换间隔
            delayTime:400,//切换一张图片时间
            pop_delayTime:400,//弹出框切换一张图片时间
            order:0,//当前显示的图片（从0开始）
            picdire:true,//大图滚动方向（true为水平方向滚动）
            mindire:true,//小图滚动方向（true为水平方向滚动）
            min_picnum:3,//小图显示数量
            pop_up:true//大图是否有弹出框
          })            
       },100)
        
      },
      deleteRow(index,d){
        this.in_shenghe = true;
        this.getid = d[index].goodsId;
        this.replay_sp();
        var me =this;
        var data = {
          goodsId:this.getid
        };
         base.axios_post(data, '/api/1/goods/queryGoodsInfoByGoodsId', function(res) {//基础信息
            if(res.code ==0){

                me.goodsIcon = res.data.goodsIcon;
                me.goods_name = res.data.goodsName;
                me.goods_number = res.data.goodsCode;
                if(res.data.secondTypeName==""){
                    me.goods_classify = res.data.firstTypeName
                }else{
                    me.goods_classify = res.data.firstTypeName+' / '+res.data.secondTypeName;
                }

                me.goods_nature =res.data.goodsAttribute;
                me.goods_brands = res.data.goodsBrand;
                me.goods_market = me.getPrice(res.data.marketPrice/100);
                me.goods_supply = me.getPrice(res.data.supplyPrice/100);
                me.goodsIntroduce = res.data.goodsIntroduce;
            }
         })
                 
      },
      detailedInfo(){ //详细信息
        var me =this;
        var data = {
          goodsId:this.getid
        }
        base.axios_post(data, '/api/1/goods/queryGoodsSpecifications', function(res){//详细信息
             console.log(res);
              if(res.code == 0){
                  me.xiangxi = res.data;
              }
        })
      },
      pictureInfo(){ //图片信息
        var me =this;
        var outarr = [];
        var data = {
          goodsId:this.getid
        }
        base.axios_post(data, '/api/1/goods/queryGoodsEnclosure', function(res) {//详细信息
              if(res.code == 0){
                  res.data.map((v,k)=>{
                      outarr.push(v.urlAddress)
                  });
                me.picarr = outarr;
                me.mods();
              }else{
                  base.alerter(res.message);
              }
        })
      },
      formatDate(now) {
          var year=now.getYear();
          var month=now.getMonth()+1;
          var date=now.getDate();
          var hour=now.getHours();
          var minute=now.getMinutes();
          var second=now.getSeconds();
          var y = String(year);
          //console.log(year-100);
          return "20"+(year-100)+"-"+month+"-"+date+" "+hour+":"+minute+":"+second;
      },
      image_text(){//图文信息
         var data = {
             goodsId:this.getid
         };
         var _this = this;
          base.axios_post(data,"/api/1/goods/queryGoodsImgText",function (res) {
              var outarr = [];
              if(res.code == 0){
                  res.data.map((v,k)=>{
                      outarr.push(v)
                  });
                  console.log(outarr);
                  _this.picText = outarr;
                  _this.mods();
              }else{
                  base.alerter(res.message);
              }
          });
      },
      otherInfo(){
        var me =this;
         var data = {
            goodsId:this.getid
          }
          base.axios_post(data, '/api/1/goods/queryGoodsAuxiliary', function(res) {//详细信息
              console.log(res);
              if(res.code == 0){
                if(res.data==null){
                    base.alerter("暂时没有数据提供");
                }else {
                    me.startday = res.data.deliverHour == 1 ? '24小时' : '48小时';
                    me.day7 = res.data.sevenDaysRefund == 0 ? '不支持' : '支持';
                }
              }else{
                  base.alerter(res.message);
              }
        })
      },
      his_go(){
        this.in_shenghe = false;
      },
      showchange(index){
       this.righttit.map((v,k)=>{
          this.righttit[k].hightlight = 0;
       });
       this.righttit[index].hightlight = 1;
       this.nowshow =index;
       if(index ==2){
          this.pictureInfo();         
       }else if(index ==1){
          this.detailedInfo();
       }else if(index ==3){
           this.image_text();
       }else if(index ==4){
           this.otherInfo();
       }
      },
      handleCurrentChange1(index){ //分页
        this.pagenow1 = index;
        this.getdata(2,index)
      },
      handleCurrentChange2(index){
        this.pagenow2 = index;
         this.getdata(3,index)
      }
  }
}
</script>

<style type="text/css">
  .huoyuan{
    margin-left: 10px;
    margin-right: 15px;
    margin-top: 20px;
    background-color: #fff;
  }
  .huoyuan .table{
      width: 96%;
      margin: 0 auto;
  }
  .huoyuan table tr img {
      width: 35px;
      height: 35px;
      border-radius: 50%;
      vertical-align: middle;
      margin-right: 3px;
  }
  .huoyuan table tr .number{
      text-align: right;
  }
  .huoyuan table{
      width: 100%;
      border-collapse: collapse;
      margin: 0 auto;
  }
  .huoyuan table tr{
      border-bottom: solid 1px #d7d7d7;
  }
  .huoyuan table tr td{
      padding: 5px 3px;
      font-size: 14px;
  }
  .huoyuan table tr:first-child{
  }
  .huoyuan table th{
      font-size: 14px;
      padding: 15px 0;
      color: #666666;
      font-weight:400;
  }
  .huoyuan .table .overflow{
      max-width: 150px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      text-align: left;
  }


  .area1{
      display: inline-block;
      height: 36px;
      line-height: 36px;
      vertical-align: middle;
  }

.input_box{
  width:90%;
  height:100px;
  border: #ccc solid 1px;
  border-radius: 5px;
  padding: 5px;
}

.goback{
  border-bottom: #62b6f7 solid 3px;
  width: 100px;
    margin-left: 20px;
  text-align: left;
  padding-left: 20px;
  height: 40px;
  line-height: 40px;
  font-size: 16px!important;
  cursor: pointer;
}
.back {
    width: 0;
    height: 0;
    display: inline-block;
    border-top: 5px solid transparent;
    border-right: 10px solid #20a0ff;
    border-bottom: 5px solid transparent;
    margin-right: 10px;
}
.main{
  position: relative;
}
.pass{
  position: absolute;
  top:30px;
  right: 180px;
}
.reject{
  position: absolute;
  top:30px;
  right: 60px;
}
.yyzz{
    width: 120px;
    height: 120px;
    display: inline-block;
    position: absolute;   
    top: 85px;
    left: 74px;
}
.cont_right{
    position: relative;
    width: 100%;
    text-align: left;
    margin-left: 220px;
}
.title{
    display: inline-block;
    width: 140px;
    font-size: 14px;
    text-align: right;
}

.main_info{
  padding-left: 40px;
  font-size: 14px;  
}
.mid_box p{
    margin-bottom: 30px;
    margin-top: 0px;
    position: relative;
}
.havepic img{
  width: 100px;
  height: 30px;

}
.select_box{
  width: 100px;
  min-height: 240px;
  float: left;
}
.info_box{
  width: 60%;
  padding-top: 66px;
  margin-left: 6%;
}
.select_box p{
     color: #8e8d8d;
    margin-bottom: 30px;
    padding-top: 5px;
    padding-bottom: 5px;
    border-radius: 10px;
    cursor: pointer;
}

.active{
  background-color: #20a0ff !important;
  color: #fff !important;
}
.cont_right p{
  margin-bottom: 12px;
}
.cont_right .goodsicon img{
  height: 150px;
  vertical-align: middle;
}
.titlename{
  width: 200px;
    display: inline-block;
    font-size: 18px;
}
.blue{
  color: #6770ef;
}
.box2 span{
  min-width: 100px;
  display: inline-block;
    text-align: center;
}
.guige_box{
    width: 80%;
   margin-top: 20px;
}
.guige_box ul{
    padding-left: 0!important;
    font-size: 0;
}
.guige_box ul li{
    font-size: 16px;
      height: 35px;
    line-height: 35px;
    display: inline-block;
    width: 200px;
    border: solid 1px #000;
    text-align: center;
}
img{ border:0;}
.ban{ width:600px; height:580px; position:relative; overflow:hidden;margin:0 auto;}
.ban2{ width:100%; height:480px; position:relative; overflow:hidden;}
.ban2:hover .prev1{
    display:block;
}
  .ban2:hover .next1{
      display:block;
  }
.ban2 ul{ position:absolute; left:0; top:0;}
.ban2 ul li{ width:603px; height:500px;}
.prev{ float:left; cursor:pointer;}
.num{ height: 100px;
    overflow: hidden;
    width: 88%;
    position: relative;
    float: left;
    margin-left: 37px;}
.min_pic{ padding-top:10px; width:100%;  overflow: hidden;   position: relative;}
.num ul{ position:absolute; left:0; top:0;}
.num ul li{ width:80px; height:80px; margin-right:5px; padding:1px;}
.num ul li.on{ border:1px solid red; padding:0;width: 80px;height: 80px;margin-top: -10px;}
.prev_btn1{ width:16px; text-align:center; height:18px; margin-top:40px; margin-right:20px; cursor:pointer; float:left;     position: absolute;}
.next_btn1{  width:16px; text-align:center; height:18px; margin-top:40px;cursor:pointer;float:right;}
.prev1{ display:none; position:absolute; top:200px; left:0px; width:28px; height:51px;z-index:9;cursor:pointer;}
.next1{ display: none; position:absolute; top:200px; right:0px; width:28px; height:51px;z-index:9;cursor:pointer;}
.mhc{ background:#000; width:100%;opacity:0.5;-moz-opacity:0.5;filter:alpha(Opacity=50); position:fixed; left:0; top:0; display:none;z-index:3;}
.pop_up{ width:500px; height:500px; padding:10px; background:#fff; position:fixed; -position:absolute; left:50%; top:50%; margin-left:-255px; margin-top:-255px; display:none; z-index:99;}
.pop_up_xx{ width:40px; height:40px; position:absolute; top:-40px; right:0; cursor:pointer;}
.pop_up2{ width:500px; height:500px; position:relative; overflow-y:scroll;}
.pop_up2{ width:500px; height:500px; position:relative; overflow-y:scroll; float:left;}
.pop_up2 ul{ position:absolute; left:0; top:0;}
.pop_up2 ul li{ width:454px; height:500px; float:left;}
.pop_up2 ul li img{width:100%;}
*{  list-style:none;}
.ban2 ul li img{
      margin-left: 20px;
}
#ban_num1 ul{
      padding-left: 5px;
}
</style>

