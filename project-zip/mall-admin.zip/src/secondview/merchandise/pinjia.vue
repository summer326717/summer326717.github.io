<template>
    <div class="content pinjia">
        <div class="no_data" v-if="tableData1==''"><img src="../../assets/image/no_data.png"/></div>
        <div v-if="tableData1!=''" class="table">
            <table style="width: 100%">
                <tr>
                    <th>商品名称</th>
                    <th>好评度</th>
                    <th>操作</th>
                </tr>
                <tr v-for="(v,k) in tableData1" :key="k">
                    <td class="overflow"><img :src="v.goodsIcon">{{v.goodsName}}</td>
                    <td>{{v.goodDegree}}</td>
                    <td>
                        <el-button
                                @click.native.prevent="deleteRow2(k, tableData1)"
                                type="text"
                                size="small" style="color: #ff4949">
                            评价明细
                        </el-button>
                    </td>
                </tr>
            </table>
            <el-pagination
            @current-change="handleSizeChange"
            :current-page.sync="currentPage1"
            :page-size="10"
            layout="prev, pager, next, jumper"
            :total="totpage1">
    </el-pagination>
        </div>
        <div class="shadow_pj" v-if="inshow == true">
            <div class="pinjia_main">
                <div class="close" @click="closetc">×</div>
                <p class="the_title1">全部评价(<span class="pinjia_num">{{pinjia_num}}</span>) <span class="get_good">好评度<span class="pinjia_point">{{pinjia_point}}</span></span></p>
                <div class="all_pj">
                <ul class="data_list">
                    <li v-for="item in pinjiadata">
                        <div class="star">
                            <el-rate
                                    v-model="item.matchScore"
                                    disabled
                                    show-score
                                    text-color="#ff9900"
                                    score-template="{value}">
                            </el-rate>

                        </div>
                        <span class="time">{{item.createTime}}</span>
                        <p class="main_tit">{{item.goodsComment}}</p>
                        <div class="picbox11">
                            <img v-for="item in item.picture" :src="item" @mouseover="showpic(item)" @mouseout="hidepic()">
                        </div>
                        <div class="take_pic" id="take_pic1">
                            <img :src="nowpic">
                        </div>
                    </li>

                </ul>
                    <el-pagination
                            @current-change="pagechange"
                            :current-page.sync="currentPage2"
                            :page-size="10"
                            layout="prev, pager, next, jumper"
                            :total="totpage2">
                    </el-pagination>
                </div>

            </div>
        </div>
    </div>
</template>
<script>
    import base from '../../basics/base.js';
    export default {
        name: '',
        data() {
            return {
                tableData1:null,
                totpage1:1,
                currentPage1:1,
                value5:4,
                inshow:false,
                nowpic:'',
                nowindex:1,
                pinjiadata:null,
                currentPage2:1,
                totpage2:10,
                pinjia_num:0,
                goodsid:null,
                pinjia_point:0,
                picarr:[]
            }
        },
        mounted() {
                this.getdata(this.nowindex);
        },
        methods: {
            handleSizeChange(index){
              this.nowindex = index;
              this.getdata(this.nowindex);
            },
            deleteRow2(index,data){
                this.currentPage2 =1;
                this.goodsid = data[index].goodsId;
                this.pinjia_point = data[index].goodDegree;
                this.getinfo(1);
            },
            getinfo(index){
                var me = this;
                var data = {
                    goodsId:this.goodsid,
                    page_size:10,
                    page_no:index

                }
                base.axios_post(data, '/api/1/orderCenter/backQryGoodsCommentDetail', function(res) {
                    if(res.code ==1){
                        me.pinjia_num=0;
                        me.pinjia_point ='--';
                    }else if(res.code == 0){

                        if (res.data!=null) {
                          me.pinjia_num = res.data.total;
                          me.totpage2 = res.data.total;
                          me.pinjiadata = [];
                          res.data.CommentList.map((v,k)=>{
                              console.log(v,k);
                              var obj = {};
                              obj.matchScore = v.goodsCommentH.matchScore;
                              obj.goodsComment = v.goodsCommentH.goodsComment;
                              obj.createTime = me.getLocalTime(v.goodsCommentH.createTime);
                              var piced = []
                              if (v.goodsCommentBList!=null) {
                                v.goodsCommentBList.map((v1,k1)=>{
                                  var pic = v1.imgUrl;
                                  piced.push(pic);
                                })
                                obj.picture =piced;
                              }
                               me.pinjiadata.push(obj);
                          })
                        }
                        console.log(me.pinjiadata)
                    }else{
                        me.$message({message: res.message,type: 'error'});
                        return;
                    }
                })
                this.inshow = true;
            },
            getLocalTime(nS) {
                return new Date(parseInt(nS)).toLocaleString().substr(0,22)
            },
            getdata(index){
                var me =this;
                var data = {
                    page_no:index,
                    page_size:10
                }
                base.axios_post(data, '/api/1/orderCenter/backQryGoodsCommentSum', function(res) {
                    console.log(res)
                    if (res.code == 0) {
                        if(res.data != null){
                            me.totpage1 = res.data.pages*10;
                            me.tableData1 = res.data.resultList;
                            me.tableData1.map((v,k)=>{
                                v.scoreSum  =(v.scoreSum/10).toFixed(4)*100+'%';
                                v.goodDegree  =(v.goodDegree)*100+'%';
                            })
                        }

                    }else{
                        me.$message({message: res.message,type: 'error'});
                        return;
                    }
                })
            },
            showpic(picaddr){
                var e = window.event;
                var x = e.pageX;
                var y  =e.pageY;
                this.nowpic = picaddr;
                var picbox = document.getElementById('take_pic1');
                picbox.style.left=x+10+'px';
                picbox.style.top=y+10+'px';
                picbox.style.display="block";
            },
            hidepic(){
                this.nowpic = '';
                var picbox = document.getElementById('take_pic1');
                picbox.style.display="none";
            },
            closetc(){
                this.inshow = false;
            },
            pagechange(index){
                this.currentPage2 = index;

                this.getinfo(index);
            }
        }
    }
</script>
<style type="text/css">
    .pinjia{
        margin-left: 10px;
        margin-right: 15px;
        margin-top: 20px;
        background-color: #ffff;
        padding: 20px 0;
    }

    .pinjia .table{
        width: 96%;
        margin: 0 auto;
    }
    .pinjia table tr img {
        width: 35px;
        height: 35px;
        border-radius: 50%;
        vertical-align: middle;
        margin-right: 3px;
    }
    .pinjia table{
        width: 100%;
        border-collapse: collapse;
        margin: 0 auto;
    }
    .pinjia table tr{
        border-bottom: solid 1px #d7d7d7;
    }
    .pinjia table tr td{
        padding: 5px 3px;
        font-size: 14px;
    }
    .pinjia table th{
        font-size: 14px;
        padding: 15px 0;
        color: #666666;
        font-weight:400;
    }
    .pinjia .table .overflow{
        max-width: 150px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        text-align: left;
    }



    .shadow_pj{
        position: fixed;
        width: 100%;
        height:100%;
        top:0;
        left:0;
        background: rgba(0,0,0,0.5);
        z-index: 99;
        overflow:hidden;
    }
    .pinjia_main{
        margin-left: 200px;
        margin-right: 200px;
        margin-top: 30px;
        position: relative;
        background-color: #fff;
        height:600px;
    }
    .cell img{
        width: 40px;
        display: inline-block;
    }
    .smalltitle2{
        display: inline-block;
        width: 100px;
        position: absolute;
        top: 34px;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
    }
    .close{
        width: 40px;
        background-color: #fbfbfb;
        height: 40px;
        position: absolute;
        top:-20px;
        right: -20px;
        color: #000000;
        font-size: 32px;
        line-height: 35px;
        border-radius: 40px;
        text-align: center;
        cursor: pointer;
    }
    .the_title1{
        margin-left: 20px;
        margin-right: 20px;
        height:50px;
        line-height:70px;
        padding-left: 30px;
        text-align: left;
        border-bottom:#ccc solid 1px;

    }
    .get_good{
        padding-left: 50px;
    }
    .shadow_pj ul{
        padding: 0;
        margin: 0;
        margin-left: 20px;
        margin-right: 20px;
    }
    .shadow_pj .data_list li{
        list-style: none;
        height: 145px;
        border-bottom: #ccc dotted 2px;
        text-align: left;
        padding-left: 60px;
        position: relative;
        padding-top: 10px;
    }
    .shadow_pj .data_list li .time{
        position: absolute;
        right:10px;
        top:10px;
        color:#737272;
    }
    .main_tit{
        margin-bottom: 0;
        height:40px;
        overflow: hidden;
        margin-top: 5px;
    }
    .picbox11 img{
        width:100px;
        height:55px;
        display: inline-block;
        float: left;
        margin-right: 20px;
    }
    .all_pj{width:100%;height:500px; overflow-y: scroll;}
    .take_pic{
        width:300px;
        height:auto;
        overflow: hidden;
        padding: 10px 20px;
        display: none;
        position: fixed;
        background-color: #fff;
        border-radius: 8px;
        z-index: 200;
        -moz-box-shadow:0px 0px 3px #333333; -webkit-box-shadow:0px 0px 3px #333333; box-shadow:0px 0px 3px #333333;
    }
    .take_pic img{
        width:300px;
        border-radius: 5px;
    }
    .picbox11{
        padding-top: 10px;
    }
    .pinjia .el-pagination {
        text-align: right!important;
        margin-top: 20px;
        margin-bottom: 30px;
        float:none;
    }
</style>

