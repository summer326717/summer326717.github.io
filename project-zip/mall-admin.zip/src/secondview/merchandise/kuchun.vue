<template>
  <div class="content kucun">
      <el-tabs v-model="activeName" @tab-click="handleClick">
        <el-tab-pane label="库存商品" name="first">
           <div class="no_data" v-if="tableData1==''"><img src="../../assets/image/no_data.png"/></div>
          <div v-if="tableData1!=''" class="table">
            <table style="width: 100%" v-if="in_shenghe == false">
                <tr>
                    <th>商品名称</th>
                    <th class="number">市场价</th>
                    <th class="number">供货价</th>
                    <th class="number">库存量</th>
                    <th class="number">售出数量</th>
                    <th class="number">赠送数量</th>
                    <th>操作</th>
                </tr>
                <tr v-for="(v,k) in tableData1" :key="k">
                    <td class="overflow"><img :src="v.goodsIcon">{{v.goodsName}}</td>
                    <td class="number">{{v.marketPrice}}</td>
                    <td class="number">{{v.supplyPrice}}</td>
                    <td class="number">{{v.stockAmount}}</td>
                    <td class="number">{{v.soldAmount}}</td>
                    <td class="number">{{v.giftNum}}</td>
                    <td>
                        <el-button type="text" v-if="v.groupState != 1" size="small">&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;</el-button>
                        <el-button @click.native.prevent="deleteRow(k,tableData1)" type="text" v-if="v.groupState == 1" size="small">{{check_pintuan}}</el-button>
                        <el-button @click.native.prevent="deleteRow2(k, tableData1)" type="text" size="small" style="color: #ff4949">下架</el-button>
                        <el-button @click="give(k, tableData1)" type="text" size="small" plain>赠送</el-button>
                    </td>
                </tr>
            </table>
            <el-pagination
            v-if="in_shenghe == false"
            @current-change="handleSizeChange"
            :current-page.sync="currentPage1"
            :page-size="10"
            layout="prev, pager, next, jumper"
            :total="totpage1">
          </el-pagination>
          </div>
        </el-tab-pane>
        <el-tab-pane label="拼团中" name="second">
            <div class="no_data" v-if="tableData2==''"><img src="../../assets/image/no_data.png"/></div>
            <div v-if="tableData2!=''" class="table">
                <table style="width: 100%" v-if="in_shenghe == false">
                    <tr>
                        <th>商品名称</th>
                        <th>开始时间</th>
                        <th>结束时间</th>
                        <th>结算时间</th>
                        <th class="number">库存量</th>
                        <th class="number">售出数量</th>
                        <th>操作</th>
                    </tr>
                    <tr v-for="(v,k) in tableData2" :key="k">
                        <td class="overflow"><img :src="v.goodsIcon">{{v.goodsName}}</td>
                        <td>{{v.startTime}}</td>
                        <td>{{v.endTime}}</td>
                        <td>{{v.settlementTime}}</td>
                        <td class="number">{{v.stockAmount}}</td>
                        <td class="number">{{v.soldAmount}}</td>
                        <td>
                            <el-button
                                    @click.native.prevent="deleteRow(k,tableData2)"
                                    type="text" size="small">{{check_pintuan}}</el-button>
                            <el-button
                                    @click.native.prevent="deleteRow3(k, tableData2)"
                                    type="text"
                                    size="small" style="color: #ff4949">
                                取消
                            </el-button>
                        </td>
                    </tr>
                </table>
                <el-pagination
                  v-if="in_shenghe == false"
                    @current-change="handleCurrentChange2"
                    :current-page.sync="currentPage2"
                    :page-size="10"
                    layout="prev, pager, next, jumper"
                    :total="totpage2">
            </el-pagination>
            </div>
        </el-tab-pane>
          <el-tab-pane label="待团购" name="third">
              <div class="no_data" v-if="tableData4==''"><img src="../../assets/image/no_data.png"/></div>
              <div v-if="tableData4!=''" class="table">
                  <table style="width: 100%">
                      <tr>
                          <th>商品名称</th>
                          <th>开始时间</th>
                          <th>结束时间</th>
                          <th>销售量</th>
                          <th class="number">市场价</th>
                          <th class="number">团购价</th>
                      </tr>
                      <tr v-for="(v,k) in tableData4" :key="k">
                          <td class="overflow"><img :src="v.goodsIcon">{{v.goodsName}}</td>
                          <td>{{v.startTime}}</td>
                          <td>{{v.endTime}}</td>
                          <td class="number">{{v.sold}}</td>
                          <td class="number">{{(v.marketPrice/100).toFixed(2)}}</td>
                          <td class="number">{{(v.groupPrice/100).toFixed(2)}}</td>
                      </tr>
                  </table>
                  <el-pagination
                          @current-change="handleCurrentChange4"
                          :current-page.sync="currentPage4"
                          :page-size="10"
                          layout="prev, pager, next, jumper"
                          :total="totpage4">
                  </el-pagination>
              </div>
          </el-tab-pane>
          <el-tab-pane label="代理中" name="fifth">
              <div class="no_data" v-if="tableData5==''"><img src="../../assets/image/no_data.png"/></div>
              <div v-if="tableData5!=''" class="table">
                  <table style="width: 100%">
                      <tr>
                          <th>商品名称</th>
                          <th class="number">市场价</th>
                          <th class="number">零售价</th>
                          <th class="number" style="padding-right: 10px">已售数量</th>
                      </tr>
                      <tr v-for="(v,k) in tableData5" :key="k">
                          <td class="overflow"><img :src="v.goodsIcon">{{v.goodsName}}</td>
                          <td class="number">{{(v.marketPrice/100).toFixed(2)}}</td>
                          <td class="number">{{(v.retailPrice/100).toFixed(2)}}</td>
                          <td class="number" style="padding-right: 10px">{{v.soldAmount}}</td>
                      </tr>
                  </table>
                  <el-pagination
                          @current-change="handleCurrentChange5"
                          :current-page.sync="currentPage5"
                          :page-size="10"
                          layout="prev, pager, next, jumper"
                          :total="totpage5">
                  </el-pagination>
              </div>
          </el-tab-pane>
        <el-tab-pane label="已下架" name="fourth">
            <div class="no_data" v-if="tableData3==''"><img src="../../assets/image/no_data.png"/></div>
            <div v-if="tableData3!=''" class="table">
                <table style="width: 100%">
                    <tr>
                        <th>商品名称</th>
                        <th class="number">供货价</th>
                        <th class="number">销售数量</th>
                        <th>下架时间</th>
                        <th>下架原因</th>
                    </tr>
                    <tr v-for="(v,k) in tableData3" :key="k">
                        <td class="overflow"><img :src="v.goodsIcon">{{v.goodsName}}</td>
                        <td class="number">{{v.platformPrice}}</td>
                        <td class="number">{{v.soledNum}}</td>
                        <td>{{v.createTime}}</td>
                        <td style="text-align: left">{{v.reason}}</td>
                    </tr>
          </table>
                <el-pagination
            @current-change="handleCurrentChange3"
            :current-page.sync="currentPage3"
            :page-size="10"
            layout="prev, pager, next, jumper"
            :total="totpage3">
          </el-pagination>
            </div>
        </el-tab-pane>
      </el-tabs>

      <div class="info_main" v-if="in_shenghe == true">
          <div class="goback" @click="his_go"> <span class="back"></span>返回上一页</div>
          <div class="main">
              <div class="top_box">
                  <p><span class="titn">开始时间：</span><span>{{startTime}}</span></p>
                  <p><span class="titn">结束时间：</span><span>{{endTime}}</span></p>
                  <p><span class="titn">结算时间：</span><span>{{settlementTime}}</span></p>
                  <p><span class="titn">平台价(元)：</span><span>{{price}}</span></p>
                  <p><span class="titn">加钱购(元)：</span><span>{{addMoneyBuy}}</span></p>
                  <p>       
                    <span class="titn">拼团规则：</span>
                    <span style="display:inline-block;width:50%">
                      <el-row>
                        <el-col :span="24">
                          <el-row>
                            <el-col :span="10"><span class="rule_span">人数</span></el-col>
                            <el-col :span="4"><span class="rule_span">售价(元)</span></el-col>
                          </el-row>
                          <el-row v-for="item in groupsGoodsRuleExpands" :key="item.downNum">
                            <el-col :span="4"><span class="rule_span">{{item.downNum}}</span></el-col>
                            <el-col :span="2"><span class="rule_span">━━</span></el-col>
                            <el-col :span="4"><span class="rule_span">{{item.upNum}}</span></el-col>
                            <el-col :span="4"><span class="rule_span">{{item.salePrice}}</span></el-col>
                          </el-row>
                        </el-col>
                      </el-row>
                    </span>      
                  </p>
              </div>
          </div>
      </div>
      <el-dialog
      title="下架原因"
      :visible.sync="dialogVisible2"
      width="30%"
      >
      <textarea  class="input_box" v-model="input_txt2" placeholder="请输入下架理由"></textarea>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible2 = false">取 消</el-button>
        <el-button type="primary" @click="xiajia_sure">确 定</el-button>
      </span>
    </el-dialog>
      <el-dialog
      title="确定要取消该商品的拼团状态吗？"
      :visible.sync="dialogVisible3"
      width="30%"
      >
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible3 = false">取 消</el-button>
        <el-button type="primary" @click="quxiao_sure">确 定</el-button>
      </span>
    </el-dialog>

  </div>
</template>
<script>
import base from '../../basics/base.js';
import htmlHelper from '../../tools/html-helper';
import '../../tools/toast.css'
export default {
  name: 'mainleft',
  data() {
    return {
      state: 1,
      in_shenghe:false,
      activeName:'first',
      dialogImageUrl: '',
      dialogVisible: false,
      dialogVisible2:false,
      dialogVisible3:false,
      input_txt2:'',
      textarea:'',
      value1:'',
      value2:'',
      value3:'',
      value4:'',
      value5:'',
      currentPage1:1,
      currentPage2:1,
      currentPage3:1,
      currentPage4:1,
      currentPage5:1,
      totpage1:10,
      totpage2:10,
      totpage3:10,
      totpage4:10,
      totpage5:10,
      interval:'',
      tableData1: null,
      tableData2: null,
      tableData3:null,
      tableData4:null,
      tableData5:null,
      picallarr:null,
      picarr:[],
      pagenow1:1,
      pagenow2:1,
      pagenow3:1,
      pagenow4:1,
      pagenow5:1,
      getarr:[],
      jiagearr:[
      {txt1:'',txt2:'',txt3:''},
      {txt1:'',txt2:'',txt3:''},
      {txt1:'',txt2:'',txt3:''}],
      groupsGoodsExpand:{},
        startTime:"",
        endTime:"",
        settlementTime:"",
        price:"",
        addMoneyBuy:"",
      groupsGoodsRuleExpands:[],
      check_pintuan:"查看拼团"
    }
  },
   mounted(){
      this.getdata(1);
  },
  methods: {
      handleClick(tab, event){
        if(tab.index ==0){
            this.in_shenghe = false;
              this.getdata(this.pagenow1)
        }else if(tab.index ==1){
            this.in_shenghe = false;
              this.getptInfo(this.pagenow2)
        }else if(tab.index ==2){
              this.get_groupBuy()
        }else if(tab.index ==4){
            this.in_shenghe = false;
            this.getdownInfo(this.pagenow3)
        }else if(tab.index ==3){
            this.in_shenghe = false;
            this.get_replace_goods();
        }
      },
      get_groupBuy(){
        let data = {
            page_no:this.pagenow4,
            page_size:10

        };
        let _this = this;
        base.axios_post(data,'/api/1/goods/backQryEnterpriseGroupGoods',function (res) {
            if(res.code==0){
                if(res.data){
                    _this.totpage4 = res.data.pages*10;
                    _this.tableData4 = res.data.resultList
                    _this.tableData4.map((v,k)=>{
                        _this.tableData4[k].startTime = _this.getLocalTime(_this.tableData4[k].startTime);
                        _this.tableData4[k].endTime = _this.getLocalTime(_this.tableData4[k].endTime);
                    })
                }
            }
        });

      },
      getPrice(value){
          var f = Math.round(value*100)/100;
          var s = f.toString();
          var rs = s.indexOf('.');
          if (rs < 0) {
              rs = s.length;
              s += '.';
          }
          while (s.length <= rs + 2) {
              s += '0';
          }
          return s;
      },
      deletepic(i){
        this.picarr.splice(i,1);
      },
      getpic(){
        this.interval = setInterval(()=>{
              var aa =localStorage.getItem("msg_list");  
              var bb =JSON.parse(aa);
               var data = [];
               var obj = {};
              bb.map((v,k)=>{
                  obj.createdTime =v.uploadTime;
                  obj.fileName = '';
                  obj.fileSize =v.size;
                  obj.fileType =3;
                  obj.suffixName =v.mimeType;
                  obj.uploadTime =v.uploadTime;
                  obj.urlAddress = v.filename;
                  data.push(obj)
              })
               this.picallarr = data;
        },2000)
      },
     
      getdata(pagno){
        var me =this;
        var data = {
            goods_state:4,
            page_no:pagno,
            page_size:10
        }
         base.axios_post(data, '/api/1/goods/queryBackStockGoodsInfoList', function(res) {
             console.log(res.data);
              if(res.code ==0){
                  me.tableData1 =res.data.list;
                  me.totpage1 = res.data.pages*10;
                  me.tableData1.map((v,k)=>{
                      me.tableData1[k].validityTime = me.getLocalTime(me.tableData1[k].validityTime);
                      me.tableData1[k].marketPrice = me.getPrice(me.tableData1[k].marketPrice/100);
                      me.tableData1[k].supplyPrice = me.getPrice(me.tableData1[k].supplyPrice/100);
                  })
              }else{
                me.tableData1=[];
              }
         })
      },
      upload_img: function() {
      let _this = this;
      var option = {
        url: "/oss/uploadGoodsFile",
        type: "post",
        dataType: "json",        
        timeout: 10000,
        beforesend:function(){
           htmlHelper.showLoading();
        },
        success: function(data) {

          htmlHelper.hideLoading();
          console.log(data);
          let $ipt_file = document.getElementById("tea_cate_img").files[0];
          console.log(_this.img_type);
          if (_this.img_type == 0) {
            //头像上传
            _this.common_img_detail = {
              fileName: $ipt_file.name,
              fileSize: $ipt_file.size,
              fileType: 1,
              suffixName: $ipt_file.name.split(".")[1],
              urlAddress: data.data
            };
            console.log("头像上传");
            console.log( _this.common_img_detail);
           _this.picarr.push(_this.common_img_detail);
          }
          document.getElementById("tea_cate_img").value = "";
        }
      };
      jQuery("#uploadForm_default_tea").ajaxSubmit(option);
      return false;
    },
      getLocalTime(t) {     
        var d = new Date(t);
        var y = d.getFullYear();
        var m = d.getMonth() + 1;
        var dd = d.getDate();
        var h = d.getHours();
        var mm = d.getMinutes();
        var s = d.getSeconds();
        return y + '-' + e(m) + '-' + e(dd) + ' ' + e(h) + ':' + e(mm) + ':' + e(s);
        function e(t) {
          if (t < 10) {
            return t = '0' + t;
          } else {
            return t;
          }
        }
      }, 
      xiajia_sure(){
          var me = this;
          if(this.input_txt2==''){
              this.$message.error('下架原因不能为空!');
              return false
          }
          var data ={
            //offShelfReason:me.input_txt2,
            //goodsState:0,
            //offShelfTime:Date.parse(new Date()),
            goodsId: me.goodsId,
            reason: me.input_txt2
          }
         base.axios_post(data, '/api/1/goods/offGoodsShelf', function(res) {
            if(res.code == 0){
               me.$message({
                    message: '下架成功',
                    type: 'success'
                });
              me.dialogVisible2 =false;
              me.getdata(me.pagenow1);
            }
         })
       },
      getptInfo(pageno){
        var me = this;
        var data ={
          groupState:0,
          page_no:pageno,
          page_size:10
        }
          base.axios_post(data, '/api/1/goods/queryGroupsGoodsInfo', function(res) {
              if(res.code == 0){
                  me.tableData2 = res.data.list;   
                  me.totpage2 = res.data.pages*10;       
                  me.tableData2.map((v,k)=>{
                    me.tableData2[k].endTime = me.getLocalTime(me.tableData2[k].endTime);
                    me.tableData2[k].startTime = me.getLocalTime(me.tableData2[k].startTime);
                  })
              }else{
                 me.tableData2=[]
              }
         })
      },
      formatDate(now) {
        var year=now.getYear();
        var month=now.getMonth()+1;
        var date=now.getDate();
        var hour=now.getHours();
        var minute=now.getMinutes();
        var second=now.getSeconds();
        var y = String(year);
        //console.log(year-100);
        return "20"+(year-100)+"-"+month+"-"+date+" "+hour+":"+minute+":"+second;
      },
      getdownInfo(pageno){
        var me = this;
        var data ={
          goods_state:0,
          page_no:pageno,
          page_size:10
        }
          base.axios_post(data, '/api/1/goods/backHomeOffGoodsInfoQryList', function(res) {
              if(res.code == 0){
                  me.tableData3 = res.data.resultList;   
                  me.totpage3 = res.data.pages*10;       
                  me.tableData3.map((v,k)=>{                 
                      var time = new Date(me.tableData3[k].createTime);
                      me.tableData3[k].createTime = me.getLocalTime(time);
                      me.tableData3[k].platformPrice = me.getPrice(me.tableData3[k].platformPrice/100);
                  })
              } else {
                me.tableData3 = [];
              }
         })
      },
      deleteRow(index,tab){
          this.in_shenghe = true;
        var _this = this;
        var data = {
            goodsId:tab[index].goodsId
        };
        base.axios_post(data,"/api/1/goods/queryGoodsGroupsInfo",function (res) {
                console.log(res);
                if(res.code==0){
                    for(var i in res.data.groupsGoodsRuleExpands){
                        res.data.groupsGoodsRuleExpands[i].salePrice = _this.getPrice(res.data.groupsGoodsRuleExpands[i].salePrice/100);
                    }
                    _this.groupsGoodsRuleExpands = res.data.groupsGoodsRuleExpands;
                    //var start = new Date(res.data.groupsGoodsExpand.startTime);
                    //var end = new Date(res.data.groupsGoodsExpand.endTime);
                    _this.startTime = _this.getLocalTime(res.data.groupsGoodsExpand.startTime);
                    _this.endTime = _this.getLocalTime(res.data.groupsGoodsExpand.endTime);
                    _this.settlementTime = res.data.groupsGoodsExpand.settlementTime;
                    _this.price = _this.getPrice(res.data.groupsGoodsExpand.price/100);
                    _this.addMoneyBuy = _this.getPrice(res.data.groupsGoodsExpand.addMoneyBuy/100);

                }else{
                    _this.base.alerter(res.message);
                }
        });
      },
      deleteRow2(index,tab){
        this.goodsId = tab[index].goodsId;
        this.dialogVisible2= true;
      },
      deleteRow3(index,tab){
        this.goodsId = tab[index].goodsId;
        this.dialogVisible3= true;
      },
      get_replace_goods(){
          let data = {
              page_no:this.pagenow5,
              page_size:10,
          };
          let _this = this;
          base.axios_post(data,'/api/1/goods/backQryGoodsAgentingList',function (res) {
              if(res.code==0){
                if(res.data.resultList.length>0){
                    _this.totpage5 = res.data.pages*10;
                    _this.tableData5 = res.data.resultList
                }else{
                    _this.tableData5=[];
                }
              }else{
                _this.tableData5=[];
              }
          });
      },
      trans_methods: function(i) {
        this.img_type = i;
        var file = document.getElementById("tea_cate_img");
        file.click();
      },
      quxiao_sure(){
        var me = this;
          var data ={
            state:0,
            goodsId:me.goodsId
          }
         base.axios_post(data, '/api/1/goods/updateGroupsGoodsInfo', function(res) {
            if(res.code == 0){
               me.$message({
                    message: '操作成功',
                    type: 'success'
                });
              me.dialogVisible3 =false;
              me.getptInfo(me.pagenow2);
            }
         })

      },
       handleRemove(file, fileList) {
        console.log(file, fileList);
      },
      handlePictureCardPreview(file) {
        this.dialogImageUrl = file.url;
        this.dialogVisible = true;
      },
      his_go(){
         this.in_shenghe = false;
      },
      beforeAvatarUpload(file) {
        console.log(file);
        
        const isJPG = file.type.split('/')[0] === 'image';
        const isLt2M = file.size / 1024 / 1024 < 3;

        if (!isJPG) {
          this.$message.error('上传图片只能是图片格式!');
        }
        if (!isLt2M) {
          this.$message.error('上传图片大小不能超过 3MB!');
        }
        return isJPG && isLt2M;
      },
      handleSizeChange(index){ //分页
          this.pagenow1 = index;
          this.getdata(index)
      },
      handleCurrentChange2(index){
        this.pagenow2 = index;
        this.getptInfo(index)
      },
      handleCurrentChange3(index){
          this.pagenow3 =index;
          this.getdownInfo(index)
      },
      handleCurrentChange4(index){
          this.pagenow4 =index;
          this.get_groupBuy();
      },
      handleCurrentChange5(index){
          this.pagenow5 =index;
          this.get_replace_goods();
      },
      //赠送
      give:function (index,tab) {
          this.$prompt('请输入赠送数量', '', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              inputPattern:/^[0-9]*$/,
              inputErrorMessage: '请输入有效数字'
          }).then(({ value }) => {
              console.log(tab[index]+","+value);
              var data ={
                  goodsId :tab[index].goodsId,
                  giftNum:value,
              };

              base.axios_post(data, '/api/1/goods/updateGiftNumGoodsId', function(res) {
                  if(res.code == 0){
                      tab[index].giftNum = value;
                  }else{
                      this.$message({
                          type: 'success',
                          message: '您成功赠送的数量为: ' +value
                      });
                  }
              });
          }).catch(() => {});


      }
  }
}
</script>
<style type="text/css">
    .kucun{
        background: #fff!important;
    }
    .kucun .table{
        width: 96%;
        margin: 0 auto;
    }
    .kucun table tr img {
        width: 35px;
        height: 35px;
        border-radius: 50%;
        vertical-align: middle;
        margin-right: 3px;
    }
    .kucun table tr .number{
        text-align: right;
    }
    .kucun table{
        width: 100%;
        border-collapse: collapse;
        margin: 0 auto;
    }
    .kucun table tr{
        border-bottom: solid 1px #d7d7d7;
    }
    .kucun table tr td{
        padding: 5px 3px;
        font-size: 14px;
    }
    .kucun table tr:first-child{
    }
    .kucun table th{
        font-size: 14px;
        padding: 15px 0;
        color: #666666;
        font-weight:400;
    }
    .kucun .table .overflow{
        max-width: 150px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        text-align: left;
    }



.el-tabs__header{
      border-bottom: none;
    background-color: #fff;
    padding-bottom: 10px;
    padding-left: 30px;
    border-radius: 12px;
}
  .info_main{
  background-color: #fff;
}
  .content{
    margin-left: 10px;
    margin-right: 15px;
    margin-top: 20px;
    background-color: #fbfbfb;
  }
  .cell img{
      width: 40px!important;
      display: inline-block;
      margin-left: -90px;
      margin-right: 10px;
  }
  .el-table th>.cell{
    text-align: center;
  }
  .goback{
  border-bottom: #4f9bfe solid 3px;
  text-align: left;
  padding-left: 10px;
  height: 40px;
  line-height: 40px;
  font-size: 14px;
  cursor: pointer;
  width: 110px;
}
.back {
  width: 0;
    height: 0;
    display: inline-block;
    border-top: 5px solid transparent;
    border-right: 10px solid #20a0ff;
    border-bottom: 5px solid transparent;
    margin-right: 10px;
}
.main{
  position: relative;
}
.top_box{
  width: 100%;
  min-height: 200px;
    padding-left: 19%;
}
.top_box>p{
    text-align:left;
    font-size: 16px;
    margin: 20px 0!important;
}
.titn{
    margin-left: 15%;
    width: 120px;
    display: inline-block;
    letter-spacing: 2px;
    vertical-align: top;
}
.topleft_box,.midleft_box{
  width: 55%;
  height: 100%;
  position:relative;
  float: left;
}
.topright_box,.midright_box{
   width: 45%;
  height: 100%;
  position:relative;
  float: left;
}
.topleft_box p {
    padding-left: 120px;
    text-align: left;
    font-size: 15px;
}
.top_box p span{
    color: #4b4b4b;
}
.the_title{
   text-align: left;
   font-size: 20px!important;
    color: black !important;
    padding-left: 38px !important;
}
.rightbox{
  width:60%;
  float: right;
  padding-right:17%;
   margin-top: -33px;
}
.midleft_box p{
  text-align: left;
}
.midright_box p{
  text-align: left;
  padding-left: 45px;
  position: relative;
  font-size: 15px;
}

.input_box{
  width:90%;
  height:100px;
  border: #ccc solid 1px;
  border-radius: 5px;
  padding: 5px;
}
.el-dialog__body{
  padding: 10px 20px;
}

.txtbox{
  width: 45%;
  float: left;
}
.titall{
  display: inline-block;
  width: 87px;
  float: left;
}
.finalp{
  clear: both;
}
.finalspan{
      margin-top: 24px;
      display: inline-block;
  width: 87px;
  float: left;
}
.secondspan{
  margin-top:10px;
  display: inline-block;
  width: 87px;
  float: left;
}
.mid_boxa{
    position: relative;
    width: 100%;
    height: auto;
    overflow: hidden;
    margin-top: 20px;
}
.el-upload-list--picture-card .el-upload-list__item{
  width:100px;
  height: 100px;
}
.el-upload--picture-card{
  width: 100px;
  height: 100px;
  line-height: 100px;
}
.the_titless{
  width: 100px;
  display: inline-block;
  float: left;
  text-align: right;
  padding-right: 30px;
}
.uploadbox{
  width: 450px;
  height: 300px;
  text-align: left;
  overflow:hidden;
}
.bottom_box{
  width: 100%;
  min-height: 200px;
  text-align: left;
}
.title_box{
  width: 80%;
  height:20px;
  margin: 0 auto;
  margin-bottom: 20px;
}
.outer_box{
    width: 60%;
    /*margin: 0 auto;*/
    margin-left: 260px;
    text-align: left;
}
.span1,.span2,.span3{
    display: inline-block;
    width: 50px;
    height: 36px;
    line-height: 36px;
    text-align: center;
}
.rule_span{
  width: 100%;
  text-align: center;
  display: block;
  padding: 10px 0;
}
.span1{
    margin-left: -13px;
}
.span3{
    margin-left: 17px!important;
    line-height: 25px!important;
}
.pt_title{
  width:50%;
  height: 20px;
  float: left;
}
.pt_title>span{
    display: inline-block;
}
.pt1{
    width: 115px;
    text-align: center;
    display: inline-block;
}
.pt2{
    width: 110px;
    text-align: center;
    display: inline-block;
}
.the_titlen{
  width: 100%;
  padding-left: 38px;
  font-size: 20px!important;
}
.input_box1{
    width: 280px;
    overflow: hidden;
    padding-top: 10px;
    margin-left: 5%;
}
.st{
    display: inline-block;
    width: 100px;
    position: absolute;
    top: 20px;
    left: 160px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    text-align: left;
  }
.smalltitle_pintuan,.smalltitle_xiajia{
    display: inline-block;
    width: 100px;
    position: absolute;
    right: 0;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    text-align: left;
    top: 40%;

}

.firstbox span{
    color: #afaeae;
    float: left;
    padding-left: 3px;
    padding-right: 3px;
    line-height: 27px;
}
.picbox{
  width: 400px;
    height: auto;
    overflow: hidden;
}
.picbox .picbox_inner{
   width:100px;
  height:100px;
   float: left;
  margin-left: 20px;
  margin-top: 20px;
  position: relative;
}
.picbox img{
  width:100px;
  height:100px;
}
.select_icon{
      color: #fff;
    background-color: #409eff;
    border-color: #409eff;
    display: inline-block;
    line-height: 1;
    white-space: nowrap;
    cursor: pointer;  
    border: 1px solid #d8dce5;
    -webkit-appearance: none;
    text-align: center;
    box-sizing: border-box;
    outline: none;
    margin: 0;
    transition: .1s;
    font-weight: 500;
    -moz-user-select: none;
    -webkit-user-select: none;
    -ms-user-select: none;
    padding: 12px 20px;
    font-size: 14px;
    border-radius: 4px;
}
.delete_pic{
     display: block;
    background-color: #da4949;
    width: 16px;
    height: 16px;
    border-radius: 10px;
    line-height: 18px;
    color: #fff;
    text-align: center;
    position: absolute;
    right:-8px;
    top:-8px;
    cursor: pointer;
}
</style>

