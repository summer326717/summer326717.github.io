<template>
  <div class="content xiaoshou">
      <el-tabs v-model="activeName" @tab-click="handleClick">
      <el-tab-pane label="待发货" name="second">

        <div v-if="tableData1!=''&& !onshow " class="table">
            <table>
                <tr class="row">
                    <th>商品名称</th>
                    <th class="number">单价</th>
                    <th class="number">数量</th>
                    <th class="number">金额</th>
                    <th>下单时间</th>
                    <th>收货地址</th>
                    <th>收货人</th>
                </tr>
                <tr v-for="(v,k) in tableData1" :key="k">
                    <td class="overflow"><img :src="v.goods_icon">{{v.goods_name}}</td>
                    <td class="number">{{v.buy_price}}</td>
                    <td class="number">{{v.buy_count}}</td>
                    <td class="number">{{v.pay_amount}}</td>
                    <td >{{v.order_time}}</td>
                    <td style="text-align: left">{{v.addrall}}</td>
                    <td>{{v.receiver_name}}</td>
                </tr>
            </table>
            <el-pagination
                    @current-change="handleCurrentChange"
                    :current-page.sync="currentPage1"
                    :page-size="10"
                    layout="prev, pager, next, jumper"
                    :total="totpage1">
            </el-pagination>
        </div>
        <div class="no_data" v-if="tableData1==''"><img src="../../assets/image/no_data.png"/></div>
      </el-tab-pane>

      <el-tab-pane label="待收货" name="third">
          <div class="no_data" v-if="tableData2==''"><img src="../../assets/image/no_data.png"/></div>
          <div class="table" v-if="onshow == false && tableData2!=''">
              <table>
                  <tr class="row">
                      <th>商品名称</th>
                      <th>发货时间</th>
                      <th>收货人</th>
                      <th>联系电话</th>
                      <th>快递单号</th>
                      <th>物流信息</th>
                  </tr>
                  <tr v-for="(v,k) in tableData2" :key="k">
                      <td class="overflow"><img :src="v.goods_icon">{{v.goods_name}}</td>
                      <td>{{v.delivery_time}}</td>
                      <td>{{v.receiver_name}}</td>
                      <td>{{v.receiver_phone}}</td>
                      <td>{{v.expressNo}}</td>
                      <td>
                          <el-button size="small" @click.native.prevent="check_logistics(k,tableData2)" type="success">查看物流</el-button>
                      </td>
                  </tr>
              </table>
            <el-pagination
                @current-change="handleCurrentChange1"
                :current-page.sync="currentPage2"
                :page-size="10"
                layout="prev, pager, next, jumper"
                :total="totpage2">
            </el-pagination>
        </div>
      </el-tab-pane>

       <el-tab-pane label="已完成" name="four">
           <div class="no_data" v-if="tableData3==''"><img src="../../assets/image/no_data.png"/></div>
           <div v-if="tableData3!='' && !onshow " class="table">
            <table>
               <tr class="row">
                   <th>商品名称</th>
                   <th>收货时间</th>
                   <th>收货人</th>
                   <th>联系电话</th>
                   <th>快递单号</th>
                   <th>物流信息</th>
               </tr>
               <tr v-for="(v,k) in tableData3" :key="k">
                   <td class="overflow"><img :src="v.goods_icon">{{v.goods_name}}</td>
                   <td>{{v.finishtime}}</td>
                   <td>{{v.receiver_name}}</td>
                   <td>{{v.receiver_phone}}</td>
                   <td>{{v.expressNo}}</td>
                   <td>
                       <el-button size="small" @click.native.prevent="check_logistics(k,tableData3)" type="success">查看物流</el-button>
                   </td>
               </tr>
           </table>
            <el-pagination @current-change="handleCurrentChange2" :current-page.sync="currentPage3" :page-size="10" layout="prev, pager, next, jumper" :total="totpage3"></el-pagination>
           </div>
      </el-tab-pane>
    </el-tabs>
      <div class="info_main" v-if="onshow">
          <div class="goback" @click="his_go"> <span class="back"></span>返回上一页</div>
          <div class="info_item">
              <div class="info_top">
                  <div class="goodsInfo">
                      <div class="goodsPic">
                          <img :src="goodsIcon">
                      </div>
                      <div class="goodsTit">
                          <p>商品名：{{goodsName}}</p>
                          <p>快递单号：{{expressNo}}</p>
                      </div>
                  </div>
                  <div>
                      <img src="../../assets/image/jiantou.png">
                  </div>
                  <div class="userInfo">
                      <p>收货人信息</p>
                      <p>收&nbsp;&nbsp;&nbsp;货&nbsp;&nbsp;&nbsp;人&nbsp; ：{{userName}}</p>
                      <p>收货人地址 ：<span>{{userAddress}}</span></p>
                      <p>收货人电话 ：{{userPhone}}</p>
                  </div>
              </div>
              <div class="info_bottom">
                  <div class="step">
                      <div v-if="!logistics_Msg" style="color: #c6c6c6;font-size: 20px;">暂无物流信息...</div>
                      <div class="running" v-if="logistics_Msg">
                          <div class="el-icon-edit" style="color: #4db3ff"></div>
                          <div class="msg">
                              <p style="color: #4db3ff">{{time}}</p>
                              <p style="color: #4db3ff">{{address}}</p>
                          </div>
                      </div>
                      <div class="running" v-for="(v,k) in logisticsMsg" v-if="logistics_Msg">
                          <div class="el-icon-success icon"></div>
                          <div class="msg">
                              <p>{{v.accept_time}}</p>
                              <p>{{v.accept_station}}</p>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
</template>
<script>
import base from '../../basics/base.js';
export default {
  name: 'mainleft',
  data() {
    return {
      state: 1,
      activeName:'second',
      onshow:false,
      lanxianshow:false,
      tableData1: null,
      tableData2: null,
      tableData3: null,
      currentPage1:1,
      currentPage2:1,
      currentPage3:1,
      totpage1:10,
      totpage2:10,
      totpage3:10,
      arrivearr:[],
      no_data:false,
      expressNo:'',
      expressCode:'',//快递公司
      goodsName:'',
      goodsIcon:'',
      userName:'',
      userAddress:'',
      userPhone:'',
      logistics_Msg:true,
      logisticsMsg:[],
      time:'',
      address:''
    }
  },
   mounted(){
    this.getdata(1,3)
  },
  methods: {
      handleClick(tab, event){
        this.onshow = false;
        if(tab.index ==0){
           this. currentPage1 = 1;
            this.getdata(1,3)
        }else if(tab.index ==1){
            this.currentPage2 = 1;
            this.getdata(1,4)
        }else if(tab.index ==2){
            this.currentPage3 = 1;
            this.getdata(1,5)
        }
      },
      getdata(pageno,state){
        var data  ={
          state:state,
          page_no:pageno,
          page_size:10
        }
        var me =this;
        base.axios_post(data, '/api/1/orderCenter/backQryOrderInfoList', function(res) {
            if(res.code == 0&&res.data!=null){
                if(state ==3){
                    me.tableData1 =res.data.list;
                    me.totpage1 = res.data.pages*10;
                    me.tableData1.map((v,k)=>{
                        me.tableData1[k].addrall = me.tableData1[k].receiver_province+me.tableData1[k].receiver_city+me.tableData1[k].receiver_region+(me.tableData1[k].receive_address==null?'':me.tableData1[k].receive_address);
                        me.tableData1[k].order_time = me.getLocalTime(me.tableData1[k].order_time);
                        me.tableData1[k].buy_price =me.tableData1[k].buy_price/100
                        me.tableData1[k].pay_amount =me.tableData1[k].pay_amount/100
                    })
                }else if(state ==4){
                    me.tableData2 =res.data.list;
                    me.tableData2.map((v,k)=> {
                        if(me.tableData2[k].delivery_time){
                            me.tableData2[k].delivery_time = me.getLocalTime(me.tableData2[k].delivery_time);
                        }else if(!me.tableData2[k].delivery_time){
                            me.tableData2[k].delivery_time = '暂无';
                        }
                    });
                    me.totpage2 = res.data.pages*10;
                }else if(state ==5){
                    me.tableData3 =res.data.list;
                    me.tableData3.map((v,k)=> {
                        me.tableData3[k].finishtime = me.getLocalTime(me.tableData3[k].finishtime);
                    });
                    me.totpage3 = res.data.pages*10;
                }
            }else{
                me.tableData1 = [];
                me.tableData2 = [];
                me.tableData3 = [];
            }
        })
      },
      getheight(){
       
        var huixian = document.getElementById("huixian");
        var len =this.arrivearr.length -1;
        var thelen = len*55+'px';
        huixian.style.height = thelen;
       if(this.arrivearr.length>1){
          this.lanxianshow = true;
       }
      },
      check_logistics(i,list){
          this.logisticsMsg = [];
          this.onshow = true;
          this.loading = true;
          this.userName = list[i].receiver_name;
          this.goodsName = list[i].goods_name;
          this.goodsIcon = list[i].goods_icon;
          this.userAddress = list[i].receiver_province+list[i].receiver_city+list[i].receiver_region+list[i].receive_address;
          this.userPhone = list[i].receiver_phone;
          this.expressNo = list[i].expressNo;
          this.expressCode = list[i].expressCode;//快递id
          let data = {
              waybill_number:this.expressNo,
              express_id:this.expressCode
          };
          let _this = this;
          base.suyh_axios_post(data,'/10/findExpressLogistic',function (res) {
              if(res.mark=='0'){
                  if(res.obj.length===0){
                      _this.logistics_Msg = false;
                  }else{
                      _this.logistics_Msg = true;
                      _this.address = res.obj[0].accept_station;
                      _this.time = res.obj[0].accept_time;
                      for(let i in res.obj){
                          let obj = {};
                          obj.accept_station = res.obj[i].accept_station;
                          obj.accept_time = res.obj[i].accept_time;
                          if(i>=1){
                              _this.logisticsMsg.push(obj);
                          }
                      }
                  }
              }else{
                  base.alerter(res.tip);
                  _this.logisticsMsg = [];
              }
          });
      },
      getLocalTime(t) {
        var d = new Date(t);
        var y = d.getFullYear();
        var m = d.getMonth() + 1;
        var dd = d.getDate();
        var h = d.getHours();
        var mm = d.getMinutes();
        var s = d.getSeconds();
        return y + '-' + e(m) + '-' + e(dd) + ' ' + e(h) + ':' + e(mm) + ':' + e(s);
        function e(t) {
          if (t < 10) {
            return t = '0' + t;
          } else {
            return t;
          }
        }
      }, 
      his_go(){
          this.onshow =false;
          this.getdata(1,4);
      },
      handleCurrentChange(index){ //分页
          this.getdata(index,3)
      },
      handleCurrentChange1(index){
         this.getdata(index,4)
      },
      handleCurrentChange2(index){
         this.getdata(index,5)
      }


  }
}
</script>
<style type="text/css">
  .content{
    margin-left: 10px;
    margin-right: 15px;
    margin-top: 20px;
    background-color: #fff;
  }
  .xiaoshou .table{
      width: 96%;
      margin: 0 auto;
  }
  .xiaoshou .table table{
      width: 100%;
      border-collapse: collapse;
  }
  .xiaoshou .table table tr{
      border-bottom: solid 1px #d7d7d7;

  }
  .xiaoshou .table table .number{
      text-align: right;
  }
  .xiaoshou .table table th{
      font-size: 14px;
      padding: 15px 0;
      color: #666666;
      font-weight:400;
  }
  .xiaoshou .table table td{
      font-size: 14px;
      padding: 5px 0;
  }
  .xiaoshou .table img{
      width: 35px;
      height: 35px;
      border-radius: 50%;
      vertical-align: middle;
      margin-right: 4px;
  }
  .xiaoshou .table .overflow{
      max-width: 150px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      text-align: left;
  }
  .outer{
    margin-left: 10px;
    margin-right: 15px;
    margin-top: 20px;
    background-color: #f3f6fe;
}

.el-tabs__header {
    border-bottom: none;
    background-color: #fff;
    padding-bottom: 10px;
    padding-left: 30px;
    border-radius: 12px;
}
.el-tabs__content {
    overflow: hidden;
    position: relative;
    margin-top: 10px;
    background-color: #fff;
}
.el-table th>.cell{
  text-align: center;
}
.el-pagination{
  float: right;
  margin-top: 20px;
}
.cell img {
    height: 60px;
    display: inline-block;
}
  .smalltitle{
    display: inline-block;
    width: 100px;
    height: 40px;
    position: absolute;
    top: 34px;
  }
.rejected{
  padding-left: 10px;
  color:rgb(255, 73, 73)
}
.goback{
  text-align: left;
  padding-left: 20px;
  font-size: 14px;
  cursor: pointer;
  margin-bottom: 20px;
}
.back {
    width: 0;
    height: 0;
    display: inline-block;
    border-top: 5px solid transparent;
    border-right: 10px solid #20a0ff;
    border-bottom: 5px solid transparent;
    margin-right: 10px;
}

.title_info{
  clear: both;
  height: 40px;
  position: relative;
  color: #a5a5a5;
}
.timebox{
  width: 120px;
  height: 30px;
  float: left;
  font-size: 14px;

}
.tit_time{
  width: 100px;
  text-align: right;
  display: inline-block;
}
.tit_yuan{
  width: 14px;
  height: 14px;
  display: inline-block;
  background-color: #ccc;
  border-radius: 14px;
  left: 140px;
  position: absolute;
  top:10px;
  z-index: 10;
}
.tit_title{
  width: 50%;
  text-align: left;
  margin-left: 28%;
  padding-top: 7px;
}
.huixian{
    width: 2px;
    background-color: #ccc;
    position: absolute;
    top: 76px;
    left: 146px;
}
.lanxian{
   width: 2px;
    background-color:rgb(98,182,247);
    position: absolute;
    top: 76px;
    left: 146px;
    z-index:8;
    height: 30px;
}
.actives{
  background-color:rgb(98,182,247);
  border:#a5ceec solid 3px;
  top:8px;
  left:137px;
}
.activessd{
  color: rgb(98,182,247);
}

  .xiaoshou .info_main .info_item{
      padding: 20px 20px;
  }
  .xiaoshou .info_main .info_item .info_top,.info_bottom{
  }
  .xiaoshou .info_main .info_item .info_top{
      border-bottom: solid 1px #cfd6e0;
      display: flex;
      justify-content:space-between;
      align-items:center;
      padding-bottom:30px;
  }
  .xiaoshou .info_main .info_item .info_top .goodsInfo{
      overflow: hidden;
  }
  .xiaoshou .info_main .info_item .info_top .goodsInfo .goodsPic{
      float: left;
      width: 120px;
      height: 120px;
  }
  .xiaoshou .info_main .info_item .info_top .goodsInfo .goodsPic>img{
      width: 120px;
      height: 120px;
  }
  .xiaoshou .info_main .info_item .info_top .goodsInfo .goodsTit{
      float: left;
      margin-left: 10px;
      height: 120px;
      position: relative;
      font-size: 16px;
      text-align: left;
  }
  .xiaoshou .info_main .info_item .info_top .goodsInfo .goodsTit p:first-child{
      width: 240px;
      margin-top:15px;
  }
  .xiaoshou .info_main .info_item .info_top .goodsInfo .goodsTit p:last-child{
      position: absolute;
      bottom: 15px;
  }
  .xiaoshou .info_main .info_item .info_top .userInfo{
      height: 120px;
      width:40%;
  }
  .xiaoshou .info_main .info_item .info_top .userInfo p span{
      width:66%;
      word-wrap: break-word;
      display: inline-block;
      vertical-align: middle;
  }

  .xiaoshou .info_main .info_item .info_top .userInfo p{
      font-size: 14px;
      padding-left: 20px;
      margin-bottom: 7px;
      text-align: left;
  }
  .xiaoshou .info_main .info_item .info_top .userInfo p:first-child{
      font-size: 18px;
      padding-left: 0;
      margin-bottom: 10px;
      margin-top: 0;
  }
  .xiaoshou .info_main .info_item .info_bottom{
      margin: 50px 0;
  }

  .xiaoshou .info_main .info_item .info_bottom .step .running{
      margin-bottom:40px;
      padding-left: 30%;
      text-align: left;
  }

  .xiaoshou .info_main .info_item .info_bottom .step .running>div{
      display: inline-block;
      color: #c6c6c6;
      font-size: 26px;
  }
  .active{
      color: #1da0f6!important;
  }
  .xiaoshou .info_main .info_item .info_bottom .step .running>div:last-child{
      margin-left: 10px;
      vertical-align: top;
  }
  .xiaoshou .info_main .info_item .info_bottom .step .running p:first-child{
      color: #c6c6c6;
      font-size: 18px;
      margin: 0 0;
      text-align: left;
  }
  .xiaoshou .info_main .info_item .info_bottom .step .running p:last-child {
      color: #c6c6c6;
      font-size: 14px;
      text-align: left;
      margin: 0 0;
  }
</style>

