<template>
    <div class="content tuihuo">
        <el-tabs v-model="activeName" @tab-click="handleClick">
            <el-tab-pane label="退货申请" name="first">
                <div class="table" v-if="tableData1!=''">
                <table style="width: 100%">
                    <tr>
                        <th>订单编号</th>
                        <th>商品名称</th>
                        <th class="number">成交数量</th>
                        <th class="number">成交金额</th>
                        <th>退货时间</th>
                        <th>退货人</th>
                        <th>操作</th>
                    </tr>
                    <tr v-for="(v,k) in tableData1" :key="k">
                        <td>{{v.orderNo}}</td>
                        <td class="overflow"><img :src="v.goodsIcon">{{v.goodsName}}</td>
                        <td>{{v.orderNum}}</td>
                        <td>{{v.payMny}}</td>
                        <td>{{v.returnTime}}</td>
                        <td>{{v.buyersName}}</td>
                        <td>
                            <el-button
                                    @click.native.prevent="deleteRow1(k,tableData1)"
                                    type="text"
                                    size="small">
                                查看
                            </el-button>

                            <el-button
                                    @click.native.prevent="deleteRow2(k,tableData1)"
                                    type="text"
                                    size="small">
                                通过
                            </el-button>

                            <el-button
                                    @click.native.prevent="deleteRow3(k,tableData1)"
                                    type="text"
                                    size="small">
                                拒绝
                            </el-button>
                        </td>
                    </tr>
                </table>
                <el-pagination
                        @current-change="handleCurrentChange1"
                        :current-page.sync="currentPage1"
                        :page-size="10"
                        layout="prev, pager, next, jumper"
                        :total="allpage1">
                </el-pagination>
                </div>
                <div class="no_data" v-if="tableData1==''"><img src="../../assets/image/no_data.png"/></div>
            </el-tab-pane>
            <el-tab-pane label="已退货" name="second">
                <div class="no_data" v-if="tableData2==''"><img src="../../assets/image/no_data.png"/></div>
                <div v-if="tableData2!=''" class="table">
                <table  style="width: 100%">
                    <tr>
                        <th>订单编号</th>
                        <th>商品名称</th>
                        <th class="number">成交数量</th>
                        <th class="number">成交金额</th>
                        <th>退货时间</th>
                        <th>退货人</th>
                        <th>操作</th>
                    </tr>
                    <tr v-for="(v,k) in tableData2" :key="k">
                        <td>{{v.orderNo}}</td>
                        <td class="overflow"><img :src="v.goodsIcon">{{v.goodsName}}</td>
                        <td class="number">{{v.orderNum}}</td>
                        <td class="number">{{v.payMny}}</td>
                        <td>{{v.returnTime}}</td>
                        <td>{{v.buyersName}}</td>
                        <td>
                            <el-button type="text" size="small" @click.native.prevent="deleteRow1(k,tableData2)">
                                查看
                            </el-button>
                        </td>
                    </tr>
                </table>
                <el-pagination
                        @current-change="handleCurrentChange2"
                        :current-page.sync="currentPage2"
                        :page-size="10"
                        layout="prev, pager, next, jumper"
                        :total="allpage2">
                </el-pagination>
                </div>
            </el-tab-pane>

        </el-tabs>

        <el-dialog title="" :visible.sync="dongjie_show" width="30%">
            <span class="result" style="float: none">退货原因：{{result}}</span>
            <div class="result_picbox" v-for="item in picarr">
                <img :src="item" @mouseover="showpic(item)" @mouseout="hidepic()" >
            </div>
            <div class="take_pic" id="take_pic1">
                <img :src="nowpic">
            </div>
        </el-dialog>

        <el-dialog title="" :visible.sync="result_pass" width="30%">
            <span class="result">确定要同意{{title}}退货吗？</span>
            <el-button @click="result_pass = false">取 消</el-button>
            <el-button type="primary" @click="get_pass">确 定</el-button>
        </el-dialog>

        <el-dialog title="" :visible.sync="result_error" width="30%">
            <span class="result">确定要拒绝{{title}}退货吗？</span>
            <el-button @click="result_error = false">取 消</el-button>
            <el-button type="primary" @click="get_error">确 定</el-button>
        </el-dialog>
    </div>
</template>
<script>
    import base from '../../basics/base.js';
    export default {
        name: 'mainleft',
        data() {
            return {
                state: 1,
                activeName:'first',
                tableData1:null,
                tableData2:null,
                currentPage1:1,
                allpage1:10,
                currentPage2:1,
                allpage2:10,
                dongjie_show:false,
                dongjie_title:'',
                pagenow1:1,
                nowpic:'',
                pagenow2:1,
                picarr:null,
                result:'',
                result_pass:false,
                result_error:false,
                title:'',
                order_id:null
            }
        },
        created(){
            this.getdata(1)
        },
        mounted(){

        },
        methods: {
            handleClick(tab, event){
                if(tab.index ==0){
                    this.getdata(this.pagenow1);
                }else{
                    this.getdata2(this.pagenow2);
                }
            },
            getdata(pageno){
                var me =this;
                var data = {
                    page_no:pageno?pageno:1,
                    page_size:10
                }
                base.axios_post(data, '/api/1/orderCenter/backQryReturnGoodsList', function(res){

                    if(res.code == 0) {
                        if(res.data ==null){
                            me.tableData1=[];
                        }else{
                            me.tableData1 = res.data.resultList;
                            me.tableData1.map((v,k)=>{
                                me.tableData1[k].returnTime = me.getLocalTime(me.tableData1[k].returnTime);
                                me.tableData1[k].payMny =me.tableData1[k].payMny/100
                            })
                            me.allpage1 = res.data.pages*10;
                        }

                    }else{
                        me.tableData1 = [];
                        me.$message({
                            message: res.message,
                            type: 'warning'
                        });
                        return;
                    }
                })
            },
            getdata2(pageno){
                var me =this;
                var data = {
                    page_no:pageno?pageno:1,
                    page_size:10
                }
                base.axios_post(data, '/api/1/orderCenter/backQryHaveReturnGoodsList', function(res){
                    if(res.code == 0) {
                       if(res.data == null){
                           me.tableData2 =[];
                       }else{
                           me.tableData2 = res.data.resultList;
                           me.tableData2.map((v,k)=>{
                              me.tableData2[k].returnTime = me.getLocalTime(me.tableData2[k].returnTime);
                              me.tableData2[k].payMny =me.tableData2[k].payMny/100
                          })
                           me.allpage2 = res.data.pages*10;
                       }
                    }else{
                        me.$message({
                            message: '系统繁忙,请稍后再试',
                            type: 'warning'
                        });
                        return;
                    }
                })
            },
            showpic(picaddr){
                var e = window.event;
                var x = e.pageX;
                var y  =e.pageY;
                this.nowpic = picaddr;
                var picbox = document.getElementById('take_pic1');
                picbox.style.left=x+10+'px';
                picbox.style.top=y+10+'px';
                picbox.style.display="block";
            },
            hidepic(){
                this.nowpic = '';
                var picbox = document.getElementById('take_pic1');
                picbox.style.display="none";
            },
            have_back(){
                var me =this;
                var data = {
                    page_no:pageno?pageno:1,
                    page_size:10
                }
                base.axios_post(data, '/api/1/orderCenter/backQryHaveReturnGoodsList', function(res){
                    if(res.code == 0) {
                        me.tableData2 = res.obj;
                    }else{
                        me.$message({
                            message: '系统繁忙请稍后再试',
                            type: 'warning'
                        });
                        return;
                    }
                })
            },
            getLocalTime(t) {
              var d = new Date(t);
              var y = d.getFullYear();
              var m = d.getMonth() + 1;
              var dd = d.getDate();
              var h = d.getHours();
              var mm = d.getMinutes();
              var s = d.getSeconds();
              return y + '-' + e(m) + '-' + e(dd) + ' ' + e(h) + ':' + e(mm) + ':' + e(s);
              function e(t) {
                if (t < 10) {
                  return t = '0' + t;
                } else {
                  return t;
                }
              }
            },
            deleteRow1(index,data){
                var me =this;
                var order_id = data[index].orderId;
                this.order_id = order_id;
                var data={
                    order_id:order_id
                }
                base.axios_post(data, '/api/1/orderCenter/backReturnOrderReason', function(res){
                    if(res.code == 0){
                        var picarrary = [];
                        me.result = res.data.goodsReturn.reason;
                        res.data.goodsReturnImgList.map((v,k)=>{
                            picarrary.push(v.imgUrl);
                            console.log(v,k);
                        })
                        me.picarr =picarrary;
                    }else{
                        me.$message({
                            message: '系统繁忙请稍后再试',
                            type: 'warning'
                        });
                        return;
                    }
                })
                this.dongjie_show = true;

            },
            deleteRow2(index,data){
                this.order_id = data[index].orderId;
                this.title = data[index].goodsName;
                this.result_pass = true;
            },
            deleteRow3(index,data){
                this.order_id = data[index].orderId;
                this.title = data[index].goodsName;
                this.result_error = true;
            },
            get_pass(){
                var me =this;
                var data = {
                    order_id:this.order_id
                }
                base.axios_post(data, '/api/1/orderCenter/backApproveReturnOrder', function(res){
                    if(res.code == 0){
                        me.$message({
                            message: '通过退货申请成功',
                            type: 'success'
                        });
                        me.getdata(me.pagenow1);
                        me.result_pass =false;
                    }else{
                        me.$message({
                            message: '系统繁忙请稍后再试',
                            type: 'warning'
                        });
                        return;
                    }
                })
            },
            get_error(){
                var me =this;
                var data = {
                    order_id:this.order_id
                }
                base.axios_post(data, '/api/1/orderCenter/backRefuseReturnOrder', function(res){
                    if(res.code == 0){
                        me.$message({
                            message: '拒绝退货申请成功',
                            type: 'success'
                        });
                        me.getdata(me.pagenow2);
                        me.result_error = false;
                    }else{
                        me.$message({
                            message: '系统繁忙请稍后再试',
                            type: 'warning'
                        });
                        return;
                    }
                })
            },
            handleCurrentChange1(index){ //分页
                this.pagenow1 =index;
                this.currentPage1 =index;
                this.getdata(index)
            },
            handleCurrentChange2(index){ //分页
                this.pagenow2 = index;
                this.getdata2(index)
            },
            dongjie_sure(){//冻结接口


            }

        }
    }
</script>
<style type="text/css">
    .content{
        margin-left: 10px;
        margin-right: 15px;
        margin-top: 20px;
        background-color: #ffff;
    }
    .smalltitle22 {
        display: inline-block;
        width: 100px;
        height: 55px;
        /* position: absolute; */
        top: 40px;
        left: 108px;
        overflow: hidden;
        line-height: 55px;
    }
    .tuihuo .table{
        width: 96%;
        margin: 0 auto;
    }
   .tuihuo table tr img {
       width: 35px;
       height: 35px;
       border-radius: 50%;
       vertical-align: middle;
       margin-right: 3px;
    }
   .tuihuo table tr .number{
        text-align: right;
   }
    .tuihuo table{
        width: 100%;
        border-collapse: collapse;
        margin: 0 auto;
    }
    .tuihuo table tr{
        border-bottom: solid 1px #d7d7d7;
    }
    .tuihuo table tr td{
        padding: 5px 0;
        font-size: 14px;
    }
    .tuihuo table tr:first-child{
    }
    .tuihuo table th{
        font-size: 14px;
        padding: 15px 0;
        color: #666666;
        font-weight:400;
    }
    .tuihuo .table .overflow{
        max-width: 150px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        text-align: left;
    }



    .result{
        float: left;
        padding-bottom: 20px;
        display: inline-block;
        width: 100%;
        text-align: left;
    }
    .result_picbox{
        width: 100%;
        height:auto;
        padding-top: 20px;
        overflow: hidden;
    }
    .result_picbox img{
        width:100px;
        height:60px;
        display: inline;
        float: left;
        margin-right: 10px;
    }
    .take_pic{
        width:300px;
        height:auto;
        overflow: hidden;
        padding: 10px 20px;
        display: none;
        position: fixed;
        background-color: #fff;
        border-radius: 8px;
        z-index: 200;
        -moz-box-shadow:0px 0px 3px #333333; -webkit-box-shadow:0px 0px 3px #333333; box-shadow:0px 0px 3px #333333;
    }
    .take_pic img{
        width:300px;
        border-radius: 5px;
    }
    .picbox11{
        padding-top: 10px;
    }
</style>

