'use strict';


	import transition from './transition' ;
	import extend from 'extend';
	const ANIMATION_TIME = 3000;

const HTMLHelpers = (() => {

	/**
	 * ------------------------------------------------------------------------
	 * constants
	 * ------------------------------------------------------------------------
	 */
	const TOAST = {
		content: '',                            // toast内容
		showtime: 2500,                         // 展示的时间
		wrap: document.body,                    // toast容器，默认为document.body
		once: false,                            // 是否一次只允许弹出一个toast
		offset: {
			top: null,
			left: null,
			right: null,
			bottom: null
		},
		tmpl: '<div class="fixed-center-wraper"><div class="toast-content">%s</div></div>'
	};

	const Loading = {
		wrap: document.body,
		offset: {},
		tmpl: '<div class="fixed-center-wraper"><div class="app-loading"></div></div>'
	};

	// 状态保存所用
	let store = {};

	class HTMLHelpers {

		constructor() {
			throw Error('static class can\'t be initialize!');
		}

		/**
		 * ------------------------------------------------------------------------
		 * request and direct
		 * ------------------------------------------------------------------------
		 */

		// 解析跳转参数
		static toast(options) {

			if (Object.prototype.toString.call(options) === '[object String]') {
				options = extend(true, {}, TOAST, {content: options});
			} else {
				options = extend(true, {}, TOAST, options);
			}

			// 一次只允许一个toast
			if (options.once && store.onToast) return;
			store.onToast = true;

			let toastDocker = document.createElement('div');
			toastDocker.innerHTML = options.tmpl.replace('%s', options.content);

			let toast = toastDocker.childNodes[0];

			options.wrap.appendChild(toast);
			toast.offsetWidth;
			toast.classList.add('in');

			Object.keys(options.offset).forEach((offsetName) => {
				let val = options.offset[offsetName];

				if (val !== null) toast.querySelector('.toast-content').style[offsetName] = parseInt(val, 10) + 'px';
			});

			// option.showtime时间后隐藏
			setTimeout(() => {
				transition.transitionEnd(toast, () => {
					toast.parentNode.removeChild(toast);
				}, ANIMATION_TIME);

				toast.classList.remove('in');
				store.onToast = false;

			}, options.showtime);
		}

		static showLoading(options={}) {
			clearTimeout(store.loadingTimeId);

			// 延迟500ms显示
			store.loadingTimeId = setTimeout(() => {

				this.showLoadingNow(options);

			}, 200);

		}

		static showLoadingNow(options) {

			if (store.onLoading) return;

			if (Object.prototype.toString.call(options) === '[object String]') {
				options = extend(true, {}, Loading, {content: options});
			} else {
				options = extend(true, {}, Loading, options);
			}

			store.onLoading = true;

			let loadingDocker = document.createElement('div');
			loadingDocker.innerHTML = options.tmpl;

			let loader = loadingDocker.childNodes[0];

			store.loader = loader;

			options.wrap.appendChild(loader);
			loader.offsetWidth;
			loader.classList.add('in');

			Object.keys(options.offset).forEach((offsetName) => {
				let val = options.offset[offsetName];

				if (val !== null) loader.querySelector('.loader').style[offsetName] = parseInt(val, 10) + 'px';
			});

		}

		static showInfoWindow(tmpl, pos, type) {

			let win = document.getElementById('J_gbInfoWindow');

			if (!win) {
				win = document.createElement('div');
				win.id = 'J_gbInfoWindow';
				document.body.appendChild(win);
			}

			win.className = 'gb-info-window';
			type && win.classList.add(type);

			win.innerHTML = tmpl;
			win.style.left = `${pos.x + 20}px`;
			win.style.top = `${pos.y}px`;

			win.offsetWidth;
			win.classList.add('in');

			return win;
		}

		static hideInfoWindow(win) {
			win = win || document.getElementById('J_gbInfoWindow');
			win && win.classList.remove('in');
		}

		static hideLoading(options={}) {

			let loader = store.loader;
			clearTimeout(store.loadingTimeId);

			if (!loader) return;

			transition.transitionEnd(loader, () => {
				loader.parentNode && loader.parentNode.removeChild(loader);
				delete store.loader;
			}, 300);

			store.loader.classList.remove('in');

			store.onLoading = false;
		}

		static backdrop() {

		}
	}

	return HTMLHelpers;
})();
var htmlHelper = HTMLHelpers; 
export default  htmlHelper;
