'use strict';

class EventHelper {

	static create(eventName) {
		let event;

		if (document.createEvent) {
			event = document.createEvent('HTMLEvents');
			event.initEvent(eventName, true, true);
		} else {
			event = document.createEventObject();
			event.eventType = eventName;
		}

		return event;
	}

	static trigger(element, eventName) {

		let event = EventHelper.create(eventName);

		if (document.createEvent) {
			element && element.dispatchEvent(event);
		} else {
			element.fireEvent('on' + event.eventType, event);
		}
	}

	// 当callback触发一次之后，移除该event handler
	static one(event, element, callback) {

		let fn = () => {
			callback();
			element.removeEventListener(event, fn);
		};

		element.addEventListener(event, fn);
	}

	static on(event, element, callback) {

		let fn = () => {
			callback();
		};

		element._events_cached = element._events_cached || {};
		element._events_cached[event] = fn;

		element.addEventListener(event, fn);
	}

	static off(event, element) {
		element.removeEventListener(event, element._events_cached[event]);
	}
}
var eventHelpers =EventHelper;
export default eventHelpers;
