'use strict';

import eventHelpers from './event-helper.js';
const Transition = (() => {


	/**
	 * ------------------------------------------------------------------------
	 * Constants
	 * ------------------------------------------------------------------------
	 */

	const endEventNames = {
		transition: {
			transition: 'transitionend',
			OTransition: 'oTransitionEnd',
			MozTransition: 'transitionend',
			WebkitTransition: 'webkitTransitionEnd'
		},
		animation: {
			animation: 'animationend',
			OAnimation: 'oAnimationEnd',
			MozAnimation: 'animationend',
			WebkitAnimation: 'webkitAnimationEnd'
		}
	};

	let endEventName = {
		transition: '',
		animation: ''
	};

	let transitionEndEventName = '';
	let animationeEndEventName = '';

	let Transition = {};

	let callbacks = [];

	Transition.getEndEventName = (type='transition') => {

		if (endEventName[type]) return endEventName[type];

		let el = document.createElement('util');
		let possiableEventsNames = endEventNames[type];

		for (let name in possiableEventsNames) {
			if (el.style[name] !== undefined) {
				return possiableEventsNames[name];
			}
		}

		return false;

	};

	Transition.enmulateTransitionEnd = (el, duration) => {
		let endEventName = Transition.getEndEventName('transition');
		let called = false;

		eventHelpers.one(endEventName, el, () => {
			called = true;
		});

		return setTimeout(() => {
			!called && eventHelpers.trigger(el, endEventName);
		}, duration);
	};


	// 如果超过duration设定的时间, transitionEndEventName还没触发, 那就手动触发
	Transition.transitionEnd = (el, callback, duration, once=true) => {
		let endEventName = Transition.getEndEventName('transition');

		once ?
			eventHelpers.one(endEventName, el, callback) :
			eventHelpers.on(endEventName, el, callback);

		return Transition.enmulateTransitionEnd(el, duration);
	};

	Transition.animationEnd = (el, callback, duration, once=true) => {
		let animationeEndEventName = Transition.getEndEventName('animation');

		once ?
			eventHelpers.one(animationeEndEventName, el, callback) :
			eventHelpers.on(animationeEndEventName, el, callback);

		return Transition.enmulateTransitionEnd(el, duration);
	};

	return Transition;
})();

var transition = Transition;
export default transition;
