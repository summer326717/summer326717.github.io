<template>
  <div id="app">
  <div class="smallshop">
    <div class="left_box" v-if="haslogin ==true">
        <div class="logo_pic"><span class="logo"><img src="./assets/image/logo.png"></span></div>
        <el-row>
          <el-col  class="tac" :span="24" >
            <el-menu :class="{maxUl:maxUl}" :default-active="nowactive" :unique-opened="true" class="el-menu-vertical-demo"  background-color="#324157;" text-color="#fff" active-text-color="#ffd04b">

            <el-menu-item index="1"><img src="./assets/image/menu_01.png" class="index_icon"><router-link to="/index">首页&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</router-link></el-menu-item>
              <el-submenu index="2">
                <template slot="title"><i class="user_icon"></i>用户管理</template>
                <el-menu-item-group>
                  <el-menu-item index="2-1"><router-link to="/gys">供应商管理</router-link></el-menu-item>
                  <el-menu-item index="2-2"><router-link to="/maijia">买家管理</router-link></el-menu-item>
                </el-menu-item-group>           
              </el-submenu>
                    
               <el-submenu index="3">
                <template slot="title"><i class="shop_icon"></i>商品管理</template>
                <el-menu-item-group>            
                    <el-menu-item index="3-1"><router-link to="/huoyuan">货源管理</router-link></el-menu-item>
                    <el-menu-item index="3-2"><router-link to="/kuchun">库存管理</router-link></el-menu-item>
                    <el-menu-item index="3-3"><router-link to="/groupBuying">企业团购管理</router-link></el-menu-item>
                    <el-menu-item index="3-4"><router-link to="/pinjia">商品评价</router-link></el-menu-item>
                </el-menu-item-group>           
              </el-submenu>

              <el-submenu index="4">
                <template slot="title"><i class="el-icon-document"></i>订单管理</template>
                <el-menu-item-group>            
                    <el-menu-item index="4-1" ><router-link to="/xiaoshou">销售订单</router-link></el-menu-item>
                    <el-menu-item index="4-2" ><router-link to="/tuihuo">退货订单</router-link></el-menu-item>
                
                </el-menu-item-group>           
              </el-submenu>
              <el-submenu index="5">
                <template slot="title"><i class="el-icon-menu"></i>财务管理</template>
                <el-menu-item-group>
                    <el-menu-item index="5-1" ><router-link to="/audit">提现审核</router-link></el-menu-item>
                    <el-menu-item index="5-2" ><router-link to="/dispose">提现处理</router-link></el-menu-item>
                    <el-menu-item index="5-3" ><router-link to="/Myaccount">我的账户</router-link></el-menu-item>
                </el-menu-item-group>
              </el-submenu>
            <el-submenu index="6">
                <template slot="title"><i class="el-icon-setting"></i>系统设置</template>
                <el-menu-item-group>            
                    <el-menu-item index="6-1" ><router-link to="/fenlei">商品分类</router-link></el-menu-item>
                    <el-menu-item index="6-2" ><router-link to="/daili">代理保证金</router-link></el-menu-item>
                </el-menu-item-group>
              </el-submenu>
            </el-menu>
          </el-col>
        </el-row>
        <div class="topcont" v-if="haslogin ==true">
            <span class="backBtn" @click="go_out">退出</span>
        </div>

    </div>
       <login v-on:login_state="loginstate" v-if="haslogin == false"></login>
    </div>
      <div class="content_box" v-if="haslogin==true">
          <router-view></router-view>
      </div>
  </div>
</template>

<script>
import login from './login.vue';
import base from './basics/base.js';
export default {
  data () {
    return {
      input:'123',
      itemshow:'11',
      haslogin:true,
      nowactive:null,
      maxUl:true,
    }
  },
    components: {
      login
    },
    created(){
      this.inited();
      this.opendaohang();
    },
  methods: {
      inited(){
         var login = sessionStorage.getItem('key');
         if(!login){
          this.haslogin = false
         }
        },
      opendaohang(){
        var nowhref = window.location.href;
        var theindex = nowhref.split('#/')[1];
        if(theindex ==''||theindex=='index'){
            this.nowactive = '1';
        }else if(theindex == 'gys'||theindex == 'maijia'){
            this.nowactive = '2-1';
        }else if(theindex == 'huoyuan'||theindex == 'kuchun'||theindex =='pinjia'){
            this.nowactive = '3-1';
        }else if(theindex =='xiaoshou'||theindex=='tuihuo'){
            this.nowactive ='4-1'
        }
      },
      loginstate(data){
        this.haslogin = data;
        sessionStorage.setItem('key', 1);
        this.$router.push("/index");
        if(data){
          location.reload()
        }
        
      },
      changitem(k){
         this.itemshow = k;
      },
      go_out(){
          var _this = this;
        var data = {
            token:localStorage.getItem("token")
        };
        base.axios_post(data,"/api/1/admin/userCenter/adminExit",function (res) {
            if(res.code==0){
                sessionStorage.removeItem("key");
                localStorage.removeItem("token");
                _this.$router.push("/");
                _this.haslogin = false;
            }else{
                _this.base.alerter(res.message);
            }
        });
      }
  }
}
</script>

<style>
#app {
  font-family: Helvetica, sans-serif;
  text-align: center;
}
.backBtn{
    font-size: 16px;
    color: #ffffff;
    display: inline-block;
    width: 80px;
    height: 36px;
    line-height: 36px;
    cursor: pointer;
    border-radius: 8px;
    border: 1px solid #91c5ff;
}

.logo_pic{
  width: 100%;
  height: 100px;
}
.left_box{
    width: 16.666%;
    height: 100%;
    background-color: #394f6f;
    position: fixed;
    top: 0;
    left: 0;
}
.left_box .logo {
    width: 100%;
    padding: 20px 0;
    text-align: center;
    display: inline-block;
}
.left_box .logo img {
    display: inline-block;
    width: 100px;
}
.smallshop{
  position: relative;
}
.user_icon{
    display: inline-block;
    width: 20px;
    margin-top: -5px;
    height: 18px;
    margin-right: 5px;
    background: url(./assets/image/user.png);
    background-size: cover;
}
.index_icon{
    margin-right:5px;
}
.shop_icon{
    display: inline-block;
    width: 18px;
    margin-top: -5px;
    height: 18px;
    margin-right: 5px;
    background: url(./assets/image/shop.png);
    background-size: cover;
}
.topcont{
    bottom: 0;
    position: absolute;
    width: 100%;
    height: 50px;
    background-color: #394f6f
}
.content_box{
  width:83.333%;
  overflow: hidden;
  left: 16.666%;
  position: absolute;
  box-sizing: border-box;
  padding: 20px 20px;
  background: #F9F9F9;
}
.el-menu{
  background-color:#324157;
  width:100%;

}
.maxUl::-webkit-scrollbar {display:none}
.maxUl{
    overflow-y: auto ;
    height:500px;
}
.el-menu-vertical-demo li div{
   background-color: #324157 !important;
}
.el-menu-vertical-demo .is-active,.el-menu-item{
  background-color: #324157 !important;
}
.el-menu-item-group .el-menu-item{
  background-color: #1f2d3d !important;
}
.el-table__header-wrapper .cell{
  text-align: center;
}
.el-pagination{
  float: right;
  margin-top: 20px;
  margin-bottom: 50px;
}
.dongjie_title{
      text-align: left;
    display: inline-block;
    width: 100%;
    padding-left: 20px;
    font-size: 16px;
}
.el-submenu .el-menu-item{
      text-align: right;
    padding-right:34%;
}
 .el-submenu__title{
  color: #e2e2e2 !important;

}
.el-menu-item, .el-submenu__title{

}
.el-tabs__header {
    border-bottom: none;
    background-color: #fff;
    padding-bottom: 10px;
    padding-left: 30px;
    border-radius: 12px;
}
    .el-menu-item a{
        text-decoration: none;
        color: #fff;
    }
    .el-menu-item a:hover{
        text-decoration: none;
        color: rgb(129, 186, 255) !important;
    }
    .router-link-exact-active{
        color: rgb(48, 150, 248) !important;
    }
</style>
