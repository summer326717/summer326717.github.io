<template>
  <div class="main_content">


    <div class="main_title">
      <p class="title_pic"><img src="./assets/image/people.png"></p>
      <p class="explain">平台目前完成销售额<span>{{(saleTotalMny/100).toFixed(2)}}</span>元，在售商品有<span>{{kinds}}</span>种</p>
    </div>


    <div class="box" v-if="nameList">
      <div class="rankingLeft">
        <p class="title_firm" style="text-align: left">供应商排行榜</p>
        <div class="firmList">
          <p v-if="first"><img src="./assets/image/first.png">{{first}}</p>
          <p v-if="second"><img src="./assets/image/second.png">{{second}}</p>
          <p v-if="third"><img src="./assets/image/third.png">{{third}}</p>
          <p  style="padding-left: 55px" v-for="(v,k) in oneToTenCompany">{{v}}</p>
        </div>
      </div>
      <div class="rankingRight">
        <div id="content_bottom_left" class="content_bottom_left content_bottom"></div>
        <div id="content_bottom_right" class="content_bottom_right content_bottom"></div>
        <p v-if="isSecond" @click="back">返回</p>
      </div>
    </div>



    <div class="pic" v-if="!nameList">
      <img src="./assets/image/tuceng7.png">
      <p>啊哦~暂时还没有销售数据呢@^@</p>
    </div>

  </div>

</template>
<script>
    import axios from "axios";
    import echarts from "echarts";
    import base from './basics/base.js';
    export default {
    data() {
      return {
          sss:'点击饼块显示二级分类',
          isSecond:false,
          kinds:0,
          saleTotalMny:0,
          oneToTenCompany:[],
          first:'',
          second:'',
          third:'',
          month:[],
          saleMny:[],
          nameList:[],//商品类别
          nameList2:[],//商品类别
          goodsSaleMny:[],//各类商品销量
          goodsSaleMny2:[],//各类商品销量
          flag:1,//标记二级分类

      }
    },
    created() {
       this.getMessage();
    },
    methods: {
      getMessage(){
          let data = {};
          let _this = this;
          base.axios_post(data,'/api/1/orderCenter/backHomePageQry',function (res) {
              if(res.code==0){
                    _this.kinds = res.data.kinds;
                    _this.saleTotalMny = res.data.saleTotalMny;
                    let array = [];
                    for(let i in res.data.oneToTenCompany){
                        if(res.data.oneToTenCompany.length==0){
                            return;
                        }else if(res.data.oneToTenCompany.length==1){
                            _this.first = res.data.oneToTenCompany[0].companyName;
                        }else if(res.data.oneToTenCompany.length==2){
                            _this.first = res.data.oneToTenCompany[0].companyName;
                            _this.second = res.data.oneToTenCompany[1].companyName;
                        }else if(res.data.oneToTenCompany.length==3){
                            _this.first = res.data.oneToTenCompany[0].companyName;
                            _this.second = res.data.oneToTenCompany[1].companyName;
                            _this.third = res.data.oneToTenCompany[2].companyName;
                        }


                     if(i>=4){
                          array.push(res.data.oneToTenCompany[i].companyName)
                      }
                    }
                    _this.oneToTenCompany = array;



                    let mon = [];//临时存放月份
                    let saleMny = [];//临时存放月销售额
                    for(let j in res.data.MonSaleMny){
                        mon.push(res.data.MonSaleMny[j].mon+'月');
                        saleMny.push((res.data.MonSaleMny[j].saleMny/100).toFixed(2));
                    }
                    _this.month = mon;
                    _this.saleMny = saleMny;


                    let type = [],money=[],obj={};
                    for(let k in res.data.firstType){
                      type.push(res.data.firstType[k].firstName);
                      obj = {
                          value:res.data.firstType[k].goodsSaleMny,
                          name:res.data.firstType[k].firstName,
                          List:res.data.firstType[k].goodsSaleMnyExpands
                      };
                      money.push(obj);
                    }
                    _this.nameList = type;
                    _this.goodsSaleMny = money;
                    _this.nameList2 = type;
                    _this.goodsSaleMny2 = money;

                    _this.chert_left();
              }
          });
      },
      chert_left() {
         if(this.flag==-1){
             return false;
         }else if(this.flag==1){
             var _this = this;
             let echarts = require('echarts');
             // 基于准备好的dom，初始化echarts实例
             let myChart = echarts.init(document.getElementById('content_bottom_left'));
             let myPieChart = echarts.init(document.getElementById('content_bottom_right'));
             // 绘制图表
             myChart.setOption({
                 title: { text: '销售统计(元/月)' },
                 tooltip: {},
                 xAxis: {
                     data: _this.month
                 },
                 yAxis: {},
                 series: [{
                     name: '销量',
                     type: 'bar',
                     data: _this.saleMny
                 }]
             });
             myPieChart.setOption({
                 title: { text: '商品数据对比图' ,
                     subtext:_this.sss,
                     left:'center',
                     textStyle:{
                         color:'#000',
                         fontWeight:'bold',
                         fontSize:18
                     }
                 },
                 tooltip : {
                     trigger: 'item',
                     formatter: "{a} <br/>{b} : {c} ({d}%)"
                 },
                 color:['#18AB38','#46FFB1','green','yellow','#FFB879','#C2605C','#78C6FF','#FF4CF3'],
                 legend: {
                     orient : 'vertical',
                     x : '1%',
                     y:'10%',
                     data:_this.nameList
                 },
                 toolbox: {
                     show : true,
                     feature : {
                         mark : {show: true},
                         //dataView : {show: true, readOnly: false},
                         magicType : {
                             show: true,
                             type: ['pie', 'funnel'],
                             option: {
                                 funnel: {
                                     x: '72%',
                                     width: '50%',
                                     funnelAlign: 'left',
                                     max: 1000
                                 }
                             }
                         },
                         //restore : {show: true},
                         //saveAsImage : {show: true}
                     }
                 },
                 calculable : true,
                 series : [
                     {
                         name:'销售比例',
                         type:'pie',
                         radius : ['20%', '50%'],
                         itemStyle : {
                             normal : {
                                 label : {
                                     show : false
                                 },
                                 labelLine : {
                                     show : false
                                 }
                             },
                             emphasis : {
                                 label : {
                                     show : true,
                                     position : 'left',
                                     textStyle : {
                                         fontSize : '18',
                                         fontWeight : 'bold'
                                     }
                                 }
                             }
                         },
                         data:_this.goodsSaleMny
                     }
                 ],

             });
             myPieChart.on('click', (params) => {
                 if(_this.flag == 1){
                     _this.isSecond = true;
                     _this.sss = "二级分类菜单";
                     var goodsSaleMny = [],List = [],obj = {};
                     for(var n in params.data.List){
                         List.push(params.data.List[n].secondName);
                         obj = {
                             value:params.data.List[n].goodsSaleMny,
                             name:params.data.List[n].secondName
                         };
                         goodsSaleMny.push(obj);
                     }
                     _this.nameList = List;
                     _this.goodsSaleMny = goodsSaleMny;
                     _this.chert_left();
                     _this.flag = -1;
                 }
             });
         }
      },
      back(){
          this.flag = 1;
          this.sss='点击饼块显示二级分类';
          this.isSecond = false;
          this.getMessage();
      }
    },
  }
</script>
<style>
  .main_content{
    background: #F9F9F9;
    width: 98%;
    height: 100%;
    margin: 0 auto;
    border-radius: 8px;
  }
  .main_content .main_title{
    background: #fff;
    border-radius: 8px;
    width: 100%;
    overflow: hidden;
    margin-top: 10px;
    text-align: left;
    padding-left: 10px;
    box-sizing: border-box;
  }
  .main_content .main_title p{
    display: inline-block;
    vertical-align: middle;
    font-size: 18px;
  }
  .main_content .main_title p span{
    font-size: 24px;
    color: #008cff;
    margin: 0 3px;
  }
  .main_content .main_title .title_pic{
    width: 69px;
    height: 68px;
  }
  .main_content .main_title .title_pic img{
    width: 100%;
  }

  .main_content .box{
    background: #F9F9F9;
    border-radius: 8px;
    width: 100%;
    height: 100%;
    margin-top: 10px;
    box-sizing: border-box;
    text-align: center;
  }
  .main_content .box .rankingLeft{
    background: #fff;
    width: 25%;
    float: left;
    border-radius:16px;
    height: 775px;
  }
  .main_content .box .rankingLeft p{
    width: 85%;
    margin: 25px auto;
    text-align: left;
    font-size: 16px;
    padding-left: 15px;
  }
  .main_content .box .rankingLeft p img{
    width: 30px;
    vertical-align: middle;
    margin-right: 5px;
  }
  .main_content .box .rankingLeft>p{
    border-bottom: solid 3px #3cb8ff;
    border-radius:3px;
    padding: 5px 5px;
    width:120px;
    margin: 10px 0 25px 8px;
    font-size:18px;
  }
  .main_content .box .rankingRight{
    float: left;
    background: #fff;
    width: 74%;
    margin-left: 1%;
    border-radius: 16px;
  }
  .main_content .box .rankingRight>p{
    position: absolute;
    right: 15%;
    top:65%;
    z-index: 999999;
    width: 50px;
    height: 32px;
    line-height: 32px;
    border-radius: 4px;
    text-align: center;
    font-size: 14px;
    color: #666666;
    box-shadow: 1px 1px 2px 1px #cbcbcb;
    cursor: pointer;
  }
  .main_content .content_bottom{
    width:80%;
    height:320px;
    margin: 45px auto;
    box-shadow: 1px 1px 2px 1px #cbcbcb;
    transition: transform .5s;
    padding: 10px;
    box-sizing: border-box;
  }
  #content_bottom_right:hover{
     transform: scale(1.1);
   }
  #content_bottom_left:hover{
     transform: scale(1.1);
  }
</style>

