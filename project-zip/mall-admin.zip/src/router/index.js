import  Vue from 'vue'
import Router from 'vue-router'
import apps from '../secondview/mainleft/mainleft.vue';
import index from '../index.vue';
import gys from '../secondview/User/gongyingshang.vue'
import maijia from '../secondview/User/maijia.vue';
import huoyuan from '../secondview/merchandise/huoyuan.vue';
import kuchun from '../secondview/merchandise/kuchun.vue';
import login from '../login.vue';
import xiaoshou from '../secondview/order/xiaoshou.vue';
import tuihuo from '../secondview/order/tuihuo.vue';
import audit from '../secondview/deposit/audit.vue';
import dispose from '../secondview/deposit/dispose.vue';
import Myaccount from '../secondview/deposit/Myaccount.vue';
import pinjia from '../secondview/merchandise/pinjia.vue';
import groupBuying from '../secondview/merchandise/groupBuying.vue'
import fenlei from '../secondview/setting/fenlei.vue'
import daili from '../secondview/setting/daili.vue'
Vue.use(Router);
export default new Router({
    routes:[
        {
            path:'/',
            name:'apps',
            component:apps
        },
        /*{
        path:'/apps',
        name:'apps',
        component:apps
        },*/
        {
            path:'/index',
            name:'index',
            component:index
        },
        {
            path:'/gys',
            name:'gys',
            component:gys
        },
        {
            path:'/maijia',
            name:'maijia',
            component:maijia
        },
        {
            path:'/huoyuan',
            name:'huoyuan',
            component:huoyuan
        },
        {
            path:'/groupBuying',
            name:'groupBuying',
            component:groupBuying
        },

        {
            path:'/pinjia',
            name:'pinjia',
            component:pinjia
        },
        {
            path:'/kuchun',
            name:'kuchun',
            component:kuchun
        },
        {
            path:'/xiaoshou',
            name:'xiaoshou',
            component:xiaoshou
        },
        {
            path:'/tuihuo',
            name:'tuihuo',
            component:tuihuo
        },
        {
            path:'/audit',
            name:'audit',
            component:audit
        },
        {
            path:'/dispose',
            name:'dispose',
            component:dispose
        },
        {
            path:'/Myaccount',
            name:'Myaccount',
            component:Myaccount
        },{
          path:'/fenlei',
          name:'fenlei',
          component:fenlei
        },{
          path:'/daili',
          name:'daili',
          component:daili
        }]
})