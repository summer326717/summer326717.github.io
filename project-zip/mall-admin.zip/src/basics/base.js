import axios from 'axios';
import global from './config.vue';
import './base.css';
import '../tools/toast.css'
import htmlHelper from '../tools/html-helper';
var CryptoJS = require("crypto-js/core");
var AES = require("crypto-js/aes");
var hex_md5 = require("crypto-js/md5");
var ECB = require("crypto-js/mode-ecb");

var me = this;

function axios_post(data, url, completion) {
  var con_url = global.url;
  var time = Date.parse(new Date());
  var hash = hex_md5(time + "hotol");
  var token = localStorage.getItem('token');
  var _global = global;
  axios({
      method: 'post',
      url: con_url + url,
      dataType: "text",
      //data: Encrypt(_global.key, JSON.stringify(data)),
      data: data,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "version": "1",
        "client_type": "3",
        "Timestamp": time,
        "SignInfo": hash,
        "Content-Type": "application/json;charset=UTF-8",
        "token": token

      }
    })
    .then(function (res) {
      //res = JSON.parse(Decrypt(_global.key, res.data));
      htmlHelper.hideLoading();
      console.log(res.data);
      completion(res.data);
    })
    .catch(function (error) {
      htmlHelper.hideLoading();
      alerter('Status：' + error.response.status + ' —— Error：' + error.response.statusText);
    });
}

axios.interceptors.request.use(function (config) {
	htmlHelper.showLoading();console.log(config);
    return config;
  }, function (error) {
   console.log(error);
    return Promise.reject(error);
  });
function suyh_axios_post(data, url, completion) {
  console.log(data);
  var con_key = check_key();
  var con_url = check_suyh_ulr();
  var time = Date.parse(new Date());
  var hash = hex_md5(time + "hotol");
  if (data != "") {
    data = Encrypt(con_key, JSON.stringify(data));
  }
  time = Encrypt(con_key, time);
  hash = Encrypt(con_key, hash);
  axios({
      method: 'post',
      url: con_url + url,
      dataType: "text",
      data: data,
      headers: {
        "token": '',
        "version": "11",
        "Timestamp": time,
        "SignInfo": hash,
        "Access-Control-Allow-Origin": "*",
        "Content-Type": "application/json;charset=UTF-8"
      }
    })
    .then(function (res) {
      res = JSON.parse(Decrypt(con_key, res.data));
      console.log(res);
      htmlHelper.hideLoading();
      completion(res);
    })
    .catch(function (error) {
      console.log(error);
      htmlHelper.hideLoading();
      alerter(error);
    });
}

function check_key() {
  if (location.hostname.indexOf('localhost') == -1 && location.hostname.indexOf('test') == -1) {
    return 'hotolsuyh100emal'
  } else {
    return 'testtesttesttest'
  }
}

function check_suyh_ulr() {
  if (location.hostname.indexOf('localhost') != -1) {
    return '/suyh/app'
  } else if (location.hostname.indexOf('test') != -1) {
    return '/wechat/suyh/app'
  } else {
    return '/htwc/suyh/app'
  }
}
//加密
function Encrypt(key, word) {
  var key = CryptoJS.enc.Utf8.parse(key);
  var srcs = CryptoJS.enc.Utf8.parse(word);
  var encrypted = CryptoJS.AES.encrypt(srcs, key, {
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.Pkcs7
  });
  return encrypted.toString();
}
//解密
function Decrypt(key, word) {
  var key = CryptoJS.enc.Utf8.parse(key);
  var decrypt = CryptoJS.AES.decrypt(word, key, {
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.Pkcs7
  });
  return CryptoJS.enc.Utf8.stringify(decrypt).toString();
}

function alerter(msg) {
  var alerter = document.createElement("div");
  alert.id = "alerter";
  alerter.setAttribute("class", "alerter");
  var body = document.body;
  var html = "<span>" + msg + "</span>";
  alerter.innerHTML = html;
  body.appendChild(alerter);

  setTimeout(function () {
    alerter.remove();
  }, 3000);
}
export default {
  axios_post,
  alerter,suyh_axios_post
}