<script>
const url = '/api';
const key = 'testtesttesttest';

export default {
  url,key
}
</script>