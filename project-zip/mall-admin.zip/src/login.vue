<template>
  <div class="login_content">
    <img class="shop_login" src="./assets/image/shop_login.png"/>
    <el-card  class="login">
      <p class="tit111">登录</p>
      <p>
       <el-input class="user" v-model="input1" placeholder="请您输入账号" @keyup.enter.native="login"></el-input>
      </p>
      <p>
        <el-input class="user" type="password" placeholder="请输入密码" v-model="input2" @keyup.enter.native="login"></el-input>
      </p>
      <div class="remeber_password">
        <el-checkbox v-model="checked">记住密码</el-checkbox>
      </div>
      <p>
        <el-button class="login_btn" type="primary" @click='login'>登 录</el-button>
      </p>
    </el-card >
  </div>
</template>
<script>
import base from './basics/base.js';

export default {
  name: 'login',
  data() {
    return {
      input1:'',
      input2:'',
      checked:true
    }
  },
    mounted(){
      this.checkpassword()
    },
  methods: {
      checkpassword:function () {
         var oldad = localStorage.getItem('admin1');
          var oldpa = localStorage.getItem('admin2');
         if(oldad == null){
             this.input1 = oldad;
             this.input1 = oldpa;
         }
      },
    login: function() {
      var me = this;
      if (this.input1 == '') {
        base.alerter('请输入账号');
        return;
      }
      if (this.input2 == '') {
        base.alerter('请输入密码');
        return;
      }
      var data = { 
        admin_accounts:this.input1,
        admin_pass:this.input2
      }
      var _this = this;
      base.axios_post(data, '/api/1/userCenter/amdinLogin', function(res) {
        if(res.code == 0){
            localStorage.setItem('token',res.data.token);
            if(me.checked == true){
                localStorage.setItem('admin1',me.input1);
                localStorage.setItem('admin2',me.input2);
            }else{
                localStorage.setItem('admin1',null);
                localStorage.setItem('admin2',null);
            }
            me.$emit("login_state",true)
        }else if(res.code ==9||res.code ==10){
            base.alerter('账户名或密码错误')
        }else{
            base.alerter(res.message);
        }
      })
    }
  }
}
</script>
<style >
body,html{
height: 100%;
}
#app,.smallshop{
  height: 100%;
}
.login_content {
  height: 100%;
  text-align: center;
  background: #62B6F7;
}
.remeber_password{
  text-align: left;
}
.login {
  width: 400px;
  padding: 47px 50px 50px 50px;
  background: #ffffff;
  display: inline-block;
  position: relative;
  left: 27%;
  margin-top: 10%;
  border-radius: 8px;
}
.shop_login{
  width: 566px;
  position: absolute;
  left: 11%;
  top: 16%;
}
  input {
    padding-left: 15%;
    width: 85%;
    line-height: 80px;
    margin-top: 15px;
    background: #F7F3EB;

  }
  .el-input__inner{
    line-height: 50px;
    height: 50px;
    border-radius: 8px;
    font-size: 16px;
  }

  .login_btn{
    width: 100%;
    margin-top: 10px;
    padding: 20px 0;
    font-size: 18px;
    border-radius: 12px;
    box-shadow: 0 0 2px 2px #e2e2e2;
    background: #62B6F7;
  }
  .tit111 {
    text-align: center;  
    line-height: 52px;
    width: 100%;
    position: absolute;
    top: 0;
    left: 0;
    font-size: 20px;
    
  }
  :-moz-placeholder { /* Mozilla Firefox 4 to 18 */
    color: #999; opacity:1; 
}

::-moz-placeholder { /* Mozilla Firefox 19+ */
    color: #999;opacity:1;
}

input:-ms-input-placeholder{
    color: #999;opacity:1;
}

input::-webkit-input-placeholder{
    color: #b4bccc;opacity:1;
}
</style>