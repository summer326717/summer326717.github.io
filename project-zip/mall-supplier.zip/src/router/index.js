import Vue from 'vue'
import Router from 'vue-router'
import Home from '@/components/Home'
import Login from '@/components/Login'
import Register from '@/components/Register'
import Index from '@/components/Index'
import Error from '@/components/Error'
import Tostorage from '@/components/goods/Tostorage' //待入库
import Tocheck from '@/components/goods/Tocheck' //待审核
import Rejected from '@/components/goods/Rejected' //已驳回
import Recycle from '@/components/goods/Recycle' //回收站
import Instorage from '@/components/goods/Instorage' //已入库
import Comments from '@/components/goods/Comments' //商品评价
import preOrder from '@/components/orders/preOrder' //预订单
import Unprocessed from '@/components/orders/Unprocessed' //待收货
import Toreceived from '@/components/orders/Toreceived' //待收货
import Toreturned from '@/components/orders/Toreturned' //待退货
import Returned from '@/components/orders/Returned' //已退款
import Completed from '@/components/orders/Completed' //已完成
import pending from '@/components/message/pending' //待处理
import disposed from '@/components/message/disposed' //已处理
import being from '@/components/youhui/being' //正在使用
import stopped from '@/components/youhui/stopped' //已停用
import Servicer from '@/components/orders/Servicer' //客服信息
import Myaccount from '@/components/account/Myaccount' //我的账户
import Journal from '@/components/account/Journal' //资金流水
import Userinfo from '@/components/my/Userinfo' //用户信息
import Help from '@/components/my/Help' //帮助中心
import Advice from '@/components/my/Advice' //意见反馈
import About from '@/components/my/About' //关于我们
import addgood from '@/components/goods/addgood' //商品添加
import Editgood from '@/components/goods/Editgood' //编辑商品

Vue.use(Router);

export default new Router({
  routes: [
    {
      path: '*',
      redirect: {
        name: 'Error'
      }
    },
    {
      path: '/Error',
      name: 'Error',
      component: Error
    },
    {
      path: '/',
      name: 'Login',
      component: Login
    },
    {
      path: '/Home',
      name: 'Home',
      component: Home,
      children: [{
          path: '/',
          component: Index
        },
        {
          path: '/Index',
          name: 'Index',
          component: Index
        },
        {
          path: '/addgood',
          component: addgood
        },
        {
          path: '/Tostorage',
          component: Tostorage
        },
        {
          path: '/Tocheck',
          component: Tocheck
        },
        {
          path: '/Rejected',
          component: Rejected
        },
        {
          path: '/Recycle',
          component: Recycle
        },
        {
          path: '/Instorage',
          component: Instorage
        },
        {
          path: '/Comments',
          component: Comments
        },
        {
          path: '/preOrder',
          component: preOrder
        },
        {
          path: '/Unprocessed',
          component: Unprocessed
        },
        {
          path: '/Toreceived',
          component: Toreceived
        },
        {
          path: '/Toreturned',
          component: Toreturned
        },
        {
          path: '/Returned',
          component: Returned
        },
        {
          path: '/Completed',
          component: Completed
        },
        {
          path: '/pending',
          component: pending
        },
        {
          path: '/disposed',
          component: disposed
        },
        {
          path: '/being',
          component: being
        },
        {
          path: '/stopped',
          component: stopped
        },
        {
          path: '/Servicer',
          component: Servicer
        },
        {
          path: '/Myaccount',
          component: Myaccount
        },
        {
          path: '/Journal',
          component: Journal
        },
        {
          path: '/Userinfo',
          component: Userinfo
        },
        {
          path: '/Help',
          component: Help
        },
        {
          path: '/Advice',
          component: Advice
        },
        {
          path: '/About',
          component: About
        },
        {
          path: '/Editgood',
          component: Editgood
        }
      ]
    },
    {
      path: '/Login',
      name: 'Login',
      component: Login
    },
    {
      path: '/Register',
      name: 'Register',
      component: Register
    }
  ]
})
