<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: "app"
};
</script>
<style lang="less">
html,
body,
#app,
.main,
.login {
  height: 100%;
}

body,
p,
input,
button,
ul {
  margin: 0;
  padding: 0;
}

input,
button {
  outline: none;
  border: none;
}

body,
input,
button {
  color: #333333;
  font-size: 16px;
  font-family: "Microsoft YaHei";
  background: rgba(0, 0, 0, 0);
}

button {
  cursor: pointer;
}

a {
  text-decoration: none;
}

i {
  font-style: normal;
}

li {
  list-style-type: none;
}

.hide {
  display: none;
}

.tc {
  text-align: center;
  input{
    text-align: center;
  }
}
.tr {
  text-align: right;
}
.tl{
  text-align: left;
}
.pr {
  position: relative;
}

.fr {
  float: right;
}

.mtb5 {
  margin: 5px 0;
}

.login_close {
  cursor: pointer;
  position: absolute;
  top: 20px;
  right: -20px;
}
.loader {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 5000;
}

/*提示弹框*/

.alerter {
  z-index: 4000;
  position: fixed;
  top: 50%;
  left: 48%;
  color: #ffffff;
  border-radius: 5px;
  display: inline-block;
  padding: 10px 15px;
  background: rgba(0, 0, 0, 0.5);
}

.h {
  height: 100%;
}
::-webkit-scrollbar {
  display: none;
}
/*重置element样式*/
.el-menu {
  border: none;
}
/*标题及表格*/

.content {
  padding: 20px;
}

.content .tit {
  background: #ffffff;
  border-radius: 10px;
  padding: 17px 0;
  margin-bottom: 20px;
  cursor: pointer;
}

.content .tit span {
  color: #ffffff;
  width: 90px;
  line-height: 36px;
  font-size: 18px;
  margin-left: 40px;
  background: #62b6f7;
  border-radius: 10px;
  text-align: center;
  display: inline-block;
}

.content .table {
  background: #ffffff;
  border-radius: 10px;
  font-size: 14px;
  padding: 0 20px 20px 20px;
}
.content .table img{
  margin-right: 3px!important;
}
 .content .table .ell {
  width: 350px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  display: inline-block;
}

.content .table table {
  width: 100%;
  border-collapse: collapse;
}

.content .table th {
  color: #7f7f7f;
  font-size: 14px;
  line-height: 40px;
  font-weight: normal;
  padding: 5px;
}

.content .bor {
  box-shadow: #e1e1e1 0 1px 0;
}

.content .table td {
  color: #333333;
  border-bottom: 1px solid #eeeeee;
  //padding: 20px;
  //text-align: center;
}
/*查询无数据*/
.no_data {
  text-align: center;
  padding: 30px;
}
.content .add_info {
  color: #222222;
  font-size: 14px;
  background: #ffffff;
  border-radius: 10px;
}

.content .add_info .return {
  cursor: pointer;
  color: #808080;
  padding: 15px 0 15px 30px;
}

.content .add_info .info_item {
  padding: 30px 0;
}

.content .add_info .left_nav {
  text-align: center;
  line-height: 60px;
}

.content .add_info .left_nav .btn {
  cursor: pointer;
  font-size: 14px;
  color: #808080;
  text-align: center;
}

.content .add_info .left_nav .active {
  color: #ffffff;
  width: 90px;
  line-height: 30px;
  background: #62b6f7;
  border-radius: 10px;
}

.content .add_info .base_span {
  width: 120px;
  display: inline-block;
}

.content .add_info .l_ipt {
  width: 347px;
  display: inline-block;
}

.content .add_info .s_ipt {
  width: 167px;
  display: inline-block;
}

.content .add_info .right_con {
  line-height: 55px;
}

.content .add_info .right_con .detail {
  text-align: center;
}

.content .add_info .right_con .detail .li_span {
  width: 100px;
  text-align: left;
  margin-left: 20px;
  display: inline-block;
}

.table td {
  padding: 5px !important;
}
td img {
  width: 30px;
  height: 30px;
  border-radius: 50%;
  margin-right: 20px;
  vertical-align: middle;
}
.img_list img {
  width: 100px;
}
.img_list .img_list_item {
  position: relative;
  display: inline-block;
  .close {
    position: absolute;
    right: 0;
    top: 0;
    font-size: 30px;
    line-height: 30px;
    cursor: pointer;
  }
}
.tuihuo_img {
  padding: 20px 0;
  img {
    height: 100px;
    margin-right: 20px;
  }
}
/*logo及个人信息、退出按钮============================================================*/
.left_menu .top_header {
  background: #394f6f;
  position: absolute;
  width: 100%;
  left: 0;
  bottom: 0;
  padding: 20px 0;
}
.left_menu .logo {
  width: 100%;
  padding: 20px 0;
  text-align: center;
  display: inline-block;
}
.left_menu .logo img {
  display: inline-block;
  width: 100px;
}

.left_menu .top_header .right_info {
  color: #ffffff;
}
.left_menu {
  /*min-width: 200px;*/
  background: #394f6f;
  position: relative;
  overflow: hidden;
}
/*.left_menu .top_header .left_menu_se {
  height: calc(100% - 180px);
  overflow-y: scroll;
}*/
.left_menu .left_menu_se img {
  margin-right: 10px;
  vertical-align: middle;
}
.left_menu .left_menu_se .el-menu-item {
  margin: 0 5px;
}
.header_img {
  width: 50px;
  height: 50px;
  border-radius: 25px;
  vertical-align: middle;
  margin: 0 5px;
}
.header_nane {
  display: inline-block;
  vertical-align: middle;
  font-size: 14px;
}
.el-menu-vertical-demo{
  height: 500px;
  overflow-y: scroll;
}
.header_down {
  width: 20px;
  height: 20px;
  vertical-align: middle;
  padding: 5px 10px;
  border: 1px solid #62b6f7;
  border-radius: 5px;
  cursor: pointer;
  margin-left:10px;
}
.content .add_info .right_con_addgoods {
  padding-left: 10%;
}
</style>
