// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import App from './App'
import router from './router'
import base from './assets/base.js';
import echarts from 'echarts'
import Cookies from 'Cookies-js'
import axios from 'axios';
//import VuePreview from 'vue-preview'
Vue.config.productionTip = false;
Vue.prototype.base = base;
Vue.use(ElementUI);
//Vue.use(VuePreview)
Vue.prototype.$echarts = echarts;
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  template: '<App/>',
  components: { App },
  render: h => h(App)
});
