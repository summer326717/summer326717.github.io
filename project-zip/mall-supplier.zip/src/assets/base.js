import axios from 'axios';
import global from '../components/common/Global.vue';
var CryptoJS = require("crypto-js/core");
var AES = require("crypto-js/aes");
var hex_md5 = require("crypto-js/md5");
var ECB = require("crypto-js/mode-ecb");

function axios_post(data, url, completion) {
  console.log(data);
  msg.loader();
  var con_url = global.url;
  var Cookies = require('Cookies-js');
  var token = Cookies.get('token');
  var time = Date.parse(new Date());
  var hash = hex_md5(time + "hotol");
  axios({
    method: 'post',
    url: con_url + url,
    dataType: "text",
    data: JSON.stringify(data),
    headers: {
      "token": token,
      "Access-Control-Allow-Origin": "*",
      "Content-Type": "application/json;charset=UTF-8",
      "version": "1",
      "client_type": "3",
      "Timestamp": time,
      "SignInfo": hash,
    }
  })
    .then(function (res) {
      console.log(res.data);
      if (res.data.code == 100) {
        location.href='http://'+location.host+'/supplier/';
      }
      msg.hide();
      completion(res.data);
    })
    .catch(function (error) {
      msg.hide();
      alerter('Status：'+ error.response.status + ' —— Error：' + error.response.statusText);
    });
}
var msg = {
  loader: function () {
    var loader = document.createElement("div");
    loader.id = "loader";
    loader.setAttribute("class", "loader");
    var body = document.body;
    body.appendChild(loader);
  },
  hide: function () {
    var loader = document.getElementById('loader');
    loader.remove();
  }
}
function axios_postst(data, url, completion) {
  console.log(data);
  var con_url = '/api';
  var Cookies = require('Cookies-js');
  var token = Cookies.get('token');
  var time = Date.parse(new Date());
  var hash = hex_md5(time + "hotol");
  axios({
    method: 'post',
    url: con_url + url,
    dataType: "text",
    data: JSON.stringify(data),
    headers: {
      "token": token,
      "Access-Control-Allow-Origin": "*",
      "Content-Type": "application/json;charset=UTF-8",
      "version": "1",
      "client_type": "3",
      "Timestamp": time,
      "SignInfo": hash,
    }
  })
    .then(function (res) {
      console.log(res.data);
      completion(res.data);
    })
}
function suyh_axios_post(data, url, completion) {
  msg.loader();
  console.log(data);
  var con_key = check_key();
  var con_url = check_suyh_ulr();
  var time = Date.parse(new Date());
  var hash = hex_md5(time + "hotol");
  var Cookies = require('Cookies-js');
  var token = Cookies.get('token');
  if (token == undefined || token == '' || token == null) {
    token = '';
  }
  if (data != "") {
    data = Encrypt(con_key, JSON.stringify(data));
  }
  time = Encrypt(con_key, time);
  hash = Encrypt(con_key, hash);
  axios({
      method: 'post',
      url: con_url + url,
      dataType: "text",
      data: data,
      headers: {
        "token": '',
        "version": "11",
        "Timestamp": time,
        "SignInfo": hash,
        "Access-Control-Allow-Origin": "*",
        "Content-Type": "application/json;charset=UTF-8"
      }
    })
    .then(function (res) {
      res = JSON.parse(Decrypt(con_key, res.data));
      console.log(res);
      msg.hide();
      completion(res);
    })
    .catch(function (error) {console.log(error);
      msg.hide();
      alerter(error);
    });
}

function check_url() {
  if (location.hostname.indexOf('localhost') != -1) {
    return '/api/api/1'
  } else {
    return '/api/1'
  }
}

function check_key() {
  if (location.hostname.indexOf('localhost') == -1 && location.hostname.indexOf('test') == -1) {
    return 'hotolsuyh100emal'
  } else {
    return 'testtesttesttest'
  }
}

function check_suyh_ulr() {
  if (location.hostname.indexOf('localhost') != -1) {
    return '/suyh/app'
  } else if (location.hostname.indexOf('test') != -1) {
    return '/wechat/suyh/app'
  } else {
    return '/htwc/suyh/app'
  }
}
//加密
function Encrypt(key, word) {
  var key = CryptoJS.enc.Utf8.parse(key);
  var srcs = CryptoJS.enc.Utf8.parse(word);
  var encrypted = CryptoJS.AES.encrypt(srcs, key, { mode: CryptoJS.mode.ECB, padding: CryptoJS.pad.Pkcs7 });
  return encrypted.toString();
}
//解密
function Decrypt(key, word) {
  var key = CryptoJS.enc.Utf8.parse(key);
  var decrypt = CryptoJS.AES.decrypt(word, key, { mode: CryptoJS.mode.ECB, padding: CryptoJS.pad.Pkcs7 });
  return CryptoJS.enc.Utf8.stringify(decrypt).toString();
}
function alerter(msg) {
  var alerter = document.createElement("div");
  alert.id = "alerter";
  alerter.setAttribute("class", "alerter");
  var body = document.body;
  var html = "<span>" + msg + "</span>";
  alerter.innerHTML = html;
  body.appendChild(alerter);

  setTimeout(function () {
    alerter.remove();
  }, 1500);
}
//转换时间格式
function trans_time(t, type) {
  var d = new Date(t);
  var y = d.getFullYear();
  var m = d.getMonth() + 1;
  var dd = d.getDate();
  var h = d.getHours();
  var mm = d.getMinutes();
  var s = d.getSeconds();
  if (type == 2) {
    return y + '-' + e(m) + '-' + e(dd) + ' ' + e(h) + ':' + e(mm) + ':' + e(s);
  } else {
    return y + '-' + e(m) + '-' + e(dd);
  }
}
function e(t) {
  if (t < 10) {
    return t = '0' + t;
  } else {
    return t;
  }
}
function mul(a, b) {
  var c = 0,
      d = a.toString(),
      e = b.toString();
  try {
      c += d.split(".")[1].length;
  } catch (f) {}
  try {
      c += e.split(".")[1].length;
  } catch (f) {}
  return Number(d.replace(".", "")) * Number(e.replace(".", "")) / Math.pow(10, c);
}
export default {
  axios_post, alerter, axios_postst, trans_time, msg,suyh_axios_post,mul
}
