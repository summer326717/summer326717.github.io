<template>
  <div class="main">
    <el-row class="container">
      <vheader></vheader>
      <el-col :span="20" style="height:100%;overflow-y: scroll;">
        <router-view></router-view>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import vheader from "./common/vHeader";
export default {
  name: "hello",
  components: {
    vheader
  },
  methods: {
    handleOpen(key, keyPath) {
      console.log(key, keyPath);
    },
    handleClose(key, keyPath) {
      console.log(key, keyPath);
    },
  }
};
</script>

<style>
.el-submenu .el-menu-item{
  min-width: auto;
}

.main .container {
  height: 100%;
  background: #f4f5f9;
}
</style>
