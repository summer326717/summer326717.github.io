<template>
  <div class="content answer">
    <div class="add_info" >
      <p class="return bor">
        <span @click="back">
          <i class="el-icon-caret-left"></i>返回上一页</span>
      </p>
      <div class="info_item">
        <div class="dialogue_box" id="dialogue_box">
          <p @click="get_more" class="more" v-if="more">
            <img v-if="more_pic" :class="{more_pic:more_pic}" src="../../../assets/images/more.gif">
            <span>查看更多</span>
          </p>

          <div class="prettyUser" v-for="(v,k) in mes_list" :key="k">
            <p class="userName">{{v.buyers_name}}{{v.created_time}}</p>
            <p class="userMessage">
              <img :src="v.message_content" v-if="v.message_type==1">
              <span v-if="v.message_type==0">{{v.message_content}}</span>
            </p>
          </div>
        </div>
        <div class="message">
          <div class="mes" :class="{blue_border:blue_border}">
            <textarea  @keyup.13="submit_mes" v-model="message" @focus="G_border" @blur="N_border" placeholder="请输入回复内容"></textarea>
          </div>
          <el-button type="primary" @click="submit_mes">提交</el-button>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  export default {
    name: "answer",
    data() {
      return {
        more_pic:false,
        blue_border:false,//边框颜色
        message:"",//当前回复内容
        mes_list:[],
        page_no:1,
        more:true
      };
    },
    props: {
      goods_id: String,
      buyers_id:String,
      buyers_name:String,
      type:Number
    },
    created() {
      this.get_date(this.page_no);
    },
    methods: {
      back() {
        if(this.type==1){
          this.$emit("info_type",1);
        }else if(this.type==2){
          this.$emit("info_type",2);
        }
      },
      get_more(){
        this.page_no++;
        this.more_pic = true;
        this.get_date(this.page_no);
      },
      get_date(page_no) {
        let _this = this;
        let data = {
          buyers_id:this.buyers_id,
          goods_id:this.goods_id,
          page_size:10,
          page_no:page_no
        };
        this.base.axios_post(data, "/supplier/sms/supplierChatMessagePage", function(res) {
          if (res.code == 0) {
            _this.more_pic = false;
            if(res.data.items.length>0){
              _this.more = true;//显示查看更多
              for(var i in res.data.items){
                if(res.data.items[i].sender==1){
                  res.data.items[i].buyers_name = "用户："+_this.buyers_name;
                }else if(res.data.items[i].sender==2){
                  res.data.items[i].buyers_name = "客服：";
                }
                res.data.items[i].created_time =  _this.base.trans_time(res.data.items[i].created_time,2);
              }
              for(var j in res.data.items){
                let obj = {};
                obj.message_type = res.data.items[res.data.items.length-1-j].message_type;
                obj.buyers_name = res.data.items[res.data.items.length-1-j].buyers_name;
                obj.message_content = res.data.items[res.data.items.length-1-j].message_content;
                obj.created_time = res.data.items[res.data.items.length-1-j].created_time;
                _this.mes_list.unshift(obj);
              }
              console.log(_this.mes_list);

            }else{
              _this.more = false;
              _this.base.alerter('没有更多数据了');
            }
          }else{
            _this.base.alerter(res.message);
          }
        });
      },
      submit_mes(){
        if(this.message.replace(/(^\s*)|(\s*$)/g, "")==""){
          this.$message.error('请输入回复信息');
        }else{
          let _this = this;
          let data = {
            buyers_id:this.buyers_id,
            goods_id:this.goods_id,
            context:this.message,
            message_type:0 //0文字  1图片
          };
          this.base.axios_post(data,"/supplier/sms/replyChatMessage",function (res) {
            if(res.code==0){
              _this.message = "";
              _this.mes_list = [];
              _this.get_date(_this.page_no);
            }
          });
        }
      },
      G_border(){
        this.blue_border = true;
      },
      N_border(){
        this.blue_border = false;
      },
    },
    updated:function(){
      this.$nextTick(function(){
        document.getElementById('dialogue_box').scrollTop = document.getElementById('dialogue_box').scrollHeight;
      })
    }
  };
</script>

<style lang="less">
  .answer{
    .info_item{
      width: 95%;
      margin:0 auto;
      .dialogue_box{
        width: 100%;
        height: 550px;
        word-wrap: break-word;
        word-break: normal;
        overflow-y: auto;
        box-sizing: border-box;
        margin: 0 auto;
        padding: 5px 20px 10px 20px;
        border-top-left-radius: 16px;
        border-bottom-left-radius: 16px;
        border:  solid 1px #cfcfcf;
        .more{
          text-align: center;
          width: 90px;
          margin: 0 auto;
          margin-bottom: 30px;
          cursor: pointer;
          font-size: 14px;
          height: 17px;
          line-height: 17px;
          color: #4db3ff;
        }
        .more_pic{
          width: 17px;
          height:17px;
          margin-right: 3px;
          //animation:myfirst .2s infinite;
          vertical-align: top;
        }
        @keyframes myfirst {
          0%   {transform: rotate(0deg);}
          100% {transform: rotate(360deg);}
        }
        .prettyUser{
          margin-bottom: 25px;
          .userName{
            padding-left: 15px;
            font-size: 16px;
            color: #373737;
          }
          .userMessage{
            background: #ffffff;
            padding: 15px;
            font-size: 16px;
            margin-top: 5px;
            color: #666666;
            border-radius: 8px;
            margin-left: 35px;
            box-shadow: 1px 1px 1px 2px #dddddd;
            img{
              width: 100px;
            }
          }
        }
      }
      /*定义滚动条轨道*/
      .dialogue_box::-webkit-scrollbar-track {
        background-color: #F5F5F5;
        -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.22);
      }
      /*定义滚动条高宽及背景*/
      .dialogue_box::-webkit-scrollbar {
        display: block!important;
        width: 10px;
        background-color: rgba(0, 0, 0, 0.34);
      }
      /*定义滚动条*/
      .dialogue_box::-webkit-scrollbar-thumb {
        background-color: #394F6F;
        border-radius: 10px;
      }
      .message{

        padding-left:6%;
        margin-top: 30px;
        .mes{
          display: inline-block;
          margin-right: 35px;
          vertical-align: middle;
          width: 80%;
          height: 80px;
          border-radius: 16px;
          border: solid 1px #cfcfcf;
          padding: 15px;
          textarea{
            width: 100%!important;
            border: none;
            height: 100%;
            outline: none;
            font-size: 16px;
            resize : none;
          }
        }
        .blue_border{
          border-color: #3096f8;
        }
      }
    }
  }
</style>
