<template>
  <div class="content disposed">
    <div class="table"  v-if="info_type==2">
      <table>
        <tr class="bor">
          <th>用户</th>
          <th>商品名称</th>
          <th>消息时间</th>
          <th>消息内容</th>
          <th>操作</th>
        </tr>
        <tr v-for="(item,index) in data_list" :key="index">
          <td class="shopPic">{{item.buyers_name}}</td>
          <td class="shopPic">
            <img :src="item.goods_icon" >
            <span>{{item.goods_name}}</span></td>
          <td>{{item.created_time}}</td>
          <td class="shopPic">{{item.message_content}}</td>
          <td>
            <el-button type="text" size="small" @click.native.prevent="check(index,data_list)">
              查看
            </el-button>
          </td>
        </tr>
      </table>
      <div class="no_data" v-if="no_data"><img src="../../assets/images/no_data.png"/></div>
      <pagination v-if="data_list!=''&&total_pages>1" :cur='page_no' :all='total_pages' @get_page='turn_page'></pagination>
    </div>
    <answer v-if="info_type==0" :buyers_name="buyers_name" :buyers_id="buyers_id" :goods_id="goods_id" :type="2" @info_type="get_info"></answer>
  </div>
</template>
<script>
  import pagination from "../common/Pagination";
  import answer from "./common/answer.vue";
  export default {
    data() {
      return {
        page_no: 1,
        total_pages: 1,
        data_list: [],
        no_data: false,
        info_type:2,
        buyers_id:'',
        goods_id:'',
        buyers_name:'',
      };
    },
    components: {
      pagination,
      answer
    },
    created() {
      this.get_data();
    },
    methods: {
      turn_page: function(i) {
        this.page_no = i;
        this.get_data();
      },
      get_data() {
        var data = {
          state:2,//0待回复  1已回复
          page_no: this.page_no,
          page_size: 10
        };
        var _this = this;
        this.base.axios_post(data, "/supplier/sms/listChatMessageByPage", function(res) {
            if (res.code == 0) {
              if (res.data.list.length!=0) {
                for(var i in res.data.list){
                  res.data.list[i].created_time =  _this.base.trans_time(res.data.list[i].created_time,2);
                }
                _this.data_list = res.data.list;
                _this.total_pages = res.data.total_pages;
                _this.no_data = false;
              } else {
                _this.no_data = true;
              }
            } else {
              _this.no_data = true;
            }
          }
        );
      },
      check(index,data){
        this.buyers_id = data[index].buyers_id;
        this.goods_id = data[index].goods_id;
        this.buyers_name = data[index].buyers_name;
        this.info_type = 0;
      },
      get_info(i){
        this.info_type = i;
        this.get_data();
      }
    }
  };
</script>

<style>
  .content .re_info {
    color: #222222;
    font-size: 14px;
    background: #ffffff;
    border-radius: 10px;
  }

  .content .re_info .return {
    cursor: pointer;
    color: #808080;
    padding: 15px 0 15px 30px;
  }

  .content .bor {
    box-shadow: #e1e1e1 0 1px 0;
  }

  .content .info_item {
    padding: 55px;
  }

  .content .table .img {
    width: 35px;
    height: 35px;
    margin-right: 3px;
  }
  .disposed .table table tr th,td{
    text-align: center;
  }
  .disposed .table table tr .shopPic{
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    max-width: 150px;
    text-align: left;
  }
  .content .info_item .item_left,
  .content .info_item .item_center,
  .content .info_item .item_right {
    display: inline-block;
    vertical-align: top;
    line-height: 25px;
  }

  .content .info_item .item_right {
    padding-left: 200px;
    background: url("../../assets/images/img_01.png") no-repeat 100px 50%;
  }

  .content .info_item .item_right .pad {
    padding-left: 30px;
  }

  .content .info_wl {
    padding: 50px 0;
    color: #808080;
    font-size: 14px;
    line-height: 30px;
  }

  .content .info_wl .el-col {
    height: 80px;
  }

  .content .info_wl .time {
    padding-right: 80px;
    text-align: right;
    position: relative;
  }

  .content .info_wl .time::before {
    content: "";
    display: inline-block;
    width: 16px;
    height: 16px;
    border-radius: 50%;
    background: #bababa;
    position: absolute;
    right: 32px;
    top: 10%;
  }

  .content .info_wl .first {
    color: #222222;
  }

  .content .info_wl .first::before {
    right: 30px;
    background: #62b6f7;
    border: 3px solid #c6e4fc;
  }

  .content .info_wl .item {
    position: relative;
  }

  .content .info_wl .item::before {
    content: "";
    width: 1px;
    height: 50%;
    display: inline-block;
    background: #bababa;
    position: absolute;
    left: -40px;
    top: 30%;
  }

  .content .info_wl .a_first {
    color: #62b6f7;
  }

  .content .info_wl .a_first::before {
    background: #62b6f7;
  }

  .content .info_wl .item::after {
    content: "";
    width: 1px;
    height: 50%;
    display: inline-block;
    background: #bababa;
    position: absolute;
    left: -40px;
    top: 80%;
  }

  .content .info_wl .last::after {
    background: rgba(0, 0, 0, 0);
  }

  .content .info_wl .last::before {
    background: rgba(0, 0, 0, 0);
  }
</style>
