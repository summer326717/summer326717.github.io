<template>
  <div class="main">
    <div class="register">
      <div class="r_logo">Logo</div>
      <div class="reg_box">
        <div class="tit">注册
          <i class="login_close" @click="go_login">×</i>
        </div>
        <p>
          <span class="s_item">用户名：</span><input class="ipt" type="text" placeholder="请输入用户名" v-model="p_username"></p>
        <p>
          <span class="s_item">设置密码：</span><input class="ipt" type="password" placeholder="请输入密码" v-model="p_password"></p>
        <p>
          <span class="s_item">确认密码：</span><input class="ipt" type="password" placeholder="请重新输入密码" v-model="p_rpassword"></p>
        <p>
          <span class="s_item">商家名称：</span><input class="ipt" type="text" placeholder="请输入商家名称" v-model="p_name"></p>
        <p>
          <span class="s_item">联系人：</span><input class="ipt" type="text" placeholder="请输入联系人" v-model="p_contact"></p>
        <p>
          <span class="s_item">手机号码：</span><input class="ipt" type="text" placeholder="请输入手机号" v-model="p_phone"></p>
        <p class="pr">
          <span class="s_item">验证码：</span><input class="ipt" type="text" placeholder="请输入手机号验证码" v-model="p_code">
          <button v-if="!is_get_code" class="code" @click="get_code">获取验证码</button>
          <button v-if="is_get_code" class="code">{{num}}</button>
        </p>
        <p class="tc">
          <button class="reg_btn" @click="register">提交</button>
        </p>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      p_username: '',//用户名
      p_password:'',//密码
      p_rpassword:'',//确认密码
      p_name:'',//商家名称
      p_contact:'',//联系人
      p_phone:'',//手机号码
      p_code:'',//验证码
      p_r_code:'',//借口获得的验证码
      num:60,
      is_get_code:false,
    }
  },
  methods: {
    get_gray: function() {
      if (this.num == 0) {
        this.is_get_code = false;
        this.num = 60;
      } else {
        this.num--;
        var _this = this;
        setTimeout(_this.get_gray, 1000);
      }
    },
    go_login: function() {
      this.$router.push('/login');
    },
    //获取验证码
    get_code:function () {
    	if(this.p_phone==''){
    		this.base.alerter('请输入手机号！');
    		return;
      }
      var json={
        "phone": this.p_phone,
      };
      var _this = this;
      this.base.axios_post(json, '/userCenter/supplierSendRegistMsg', function(res) {
        if (res.code == 0) {
          _this.is_get_code = true;
          _this.get_gray();
        } else {
          _this.base.alerter(res.message);
        }
      })
    },
    //注册
    register: function() {
      if (this.p_username == '') {
        this.base.alerter('请输入用户名！');
        return;
      }
      if (this.p_password == '') {
        this.base.alerter('请输入密码！');
        return;
      }
      if (this.p_rpassword == '') {
        this.base.alerter('请输入确认密码！');
        return;
      }
      if (this.p_rpassword !== this.p_password) {
        this.base.alerter('密码和确认密码不一致！');
        return;
      }
      if (this.p_name == '') {
        this.base.alerter('请输入商家名称！');
        return;
      }
      if (this.p_contact == '') {
        this.base.alerter('请输入联系人！');
        return;
      }
      if (this.p_phone == '') {
        this.base.alerter('请输入手机号码！');
        return;
      }
      if (this.p_code == '') {
        this.base.alerter('验证码不能为空！');
        return;
      }
      var data = {
        "contacts": this.p_contact,     //联系人
        "phone": this.p_phone,	   //手机号
        "sup_name": this.p_name,    //商家名称
        "supplier_accounts": this.p_username,   //用户名
        "supplier_pass": this.p_password,     //密码
        "verification_code": this.p_code ,//验证码
      };
      var _this = this;
      this.base.axios_post(data, '/userCenter/supplierRegister', function(res) {
        if (res.code == 0) {
          _this.base.alerter(res.message);
          _this.$router.push('/login');
        } else {
          _this.base.alerter(res.message);
        }
      })
    }
  }
}
</script>
<style>
.r_logo {
  line-height: 88px;
  background: #62B6F7;
}

.register {
  min-height: calc(100% - 30px);
  padding-bottom: 30px;
  background: #F4F5F9;
}

.register .reg_box {
  width: 460px;
  margin: 0 auto;
  padding: 0 60px;
  margin-top: 30px;
  background: #ffffff;
  border-radius: 5px;
  box-shadow: rgba(0, 0, 0, 0.3) 0 0 5px;
}

.register .reg_box .tit {
  padding: 30px 0;
  font-size: 20px;
  text-align: center;
  position: relative;
}

.register .reg_box .s_item {
  width: 100px;
  text-align: right;
  display: inline-block;
}

.register .reg_box .ipt {
  width: 335px;
  padding-left: 15px;
  line-height: 46px;
  border-radius: 10px;
  margin-bottom: 17px;
  border: 2px solid #EAEAEA;
}

.register .reg_box .reg_btn {
  width: 400px;
  color: #ffffff;
  font-size: 18px;
  background: #62B6F7;
  line-height: 64px;
  border-radius: 5px;
  margin: 30px 0 40px 0;
  box-shadow: rgba(0, 0, 0, 0.3) 0 0 15px;
}

.register .reg_box .code {
  position: absolute;
  right: 6px;
  top: 0;
  width: 134px;
  line-height: 50px;
  background: #C0C0C0;
  border-radius: 0 10px 10px 0;
}
</style>
