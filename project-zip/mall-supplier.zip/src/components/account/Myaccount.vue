<template>
  <div class="content my_account myAccount">
    <div class="top">
      <div class="m_herder_list now">
        <p>可用余额</p>
        <p style="color: #FF850A">￥{{balance}}</p>
      </div>
      <div class="m_herder_list have">
        <p>
          <span>保证金:</span>
          <span style="color: #FF850A">￥{{baozhengjin}}</span>
        </p>
        <p>
          <span>总支出:</span>
          <span style="color: #FF850A">￥{{sum}}</span>
        </p>
      </div>
      <div class="m_herder_list total">
          <p>
            <span>营业额:</span>
            <span style="color: #FF850A">{{totalTurnover}}</span>
          </p>
          <p>
            <span>净利润:</span>
            <span style="color: #FF850A">{{totalIncome}}</span>
          </p>
      </div>
      <div class="m_herder_list m_herder_btn">
        <div>
          <button @click="top_full_money">充值</button>
          <button @click="top_ready_money">提现</button>
        </div>
      </div>
      <div class="classes">
        <div class="classes_title">分类</div>
        <div class="classes_content">
          <span :class="{activity:isActivity==1}" class="all_goods" @click="all_choose()">全部</span>
          <span :class="{activity:isActivity==2}" class="deal_goods" @click="deal_choose">商品交易</span>
          <span :class="{activity:isActivity==3}" class="fade_goods" @click="fade_choose">退货</span>
          <span :class="{activity:isActivity==4}" class=" ready_money" @click="ready_choose">提现</span>
          <span :class="{activity:isActivity==5}" class="full_money" @click="full_choose">充值</span>
        </div>
      </div>
      <div class="m_date">
        <div class="m_date_title">日期</div>
        <div class="m_date_content">
          <div class="bbbb">
            <el-date-picker v-model="value1" type="date" @change="getTime1" placeholder="开始日期">
            </el-date-picker>

            -

            <el-date-picker v-model="value2" type="date" @change="getTime2" placeholder="结束日期">
            </el-date-picker>
          </div>
          <el-button class="search" type="primary" icon="el-icon-search" @click="changes">搜 索</el-button>
        </div>
      </div>
    </div>
    <div class="bottom">
      <div  class="b_header">
        <span>&nbsp;交易记录&nbsp;</span>
      </div>
      <el-table
        :data="tableData" stripe style="width: 100%">
        <el-table-column prop="change_number" label="流水号" align="center"></el-table-column>
        <el-table-column prop="change_time" width="200" label="日期" align="center"></el-table-column>
        <el-table-column prop="change_mode" label="分类" align="center"></el-table-column>
        <el-table-column prop="change_amount" label="金额" align="right"></el-table-column>
        <el-table-column prop="transaction_detail" label="明细" align="center"></el-table-column>
        <el-table-column prop="change_state" label="状态" align="center"></el-table-column>
      </el-table>
      <!--分页容器-->
      <pagination v-if="tableData!=''&&total_pages>1" :cur='currentPage' :all='total_pages' @get_page='turn_page'></pagination>
    </div>
    <!--充值页面-->
    <el-dialog title="" :visible.sync="full_money_Visible" :show-close="false">
      <span style="position: absolute;
    left: 45%;
    top: 30px;
    font-size: 20px;
    color: #34a3eb;">充值</span>
      <el-form style="margin-top: 50px">
        <el-form-item class="cz" label="充值金额(元)" :label-width="formLabelWidth">
          <el-input class="czmoney" v-model="full_how_much" auto-complete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer" style="text-align: center;padding-left: 5%;margin-bottom: 20px">
        <el-button @click="full_money_Visible = false">取 消</el-button>
        <el-button type="primary" @click="sure_full_money">确 定</el-button>
      </div>
      <div id="cou_code"></div>
    </el-dialog>
    <!--提现页面-->
    <el-dialog class="tixian" title="" :visible.sync="showReady" center :show-close="false">
      <span style="position: absolute;
    left: 50%;
    top: 30px;
    font-size: 20px;
    color: #34a3eb;">提现</span>
      <el-form style="margin-top: 50px">
        <el-form-item label="可用余额：" :label-width="formLabelWidth">
          <span style="color:#CB110C;margin-left: 20px">{{resultfulMoney}}</span>
        </el-form-item>
        <el-form-item label="提现金额(元)：" :label-width="formLabelWidth">
          <el-input class="information" v-model="tixianMoney" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="支付宝账户：" :label-width="formLabelWidth">
          <span class="userAlipay" auto-complete="off">{{aliAccount}}</span>
        </el-form-item>
        <el-form-item label="手机号码：" :label-width="formLabelWidth">
          <span style="margin-left:10px">{{phoneNum}}</span>
          <el-button style="margin-left: 10px" v-if="btnCode" type="primary" @click="getCode">{{g_code}}</el-button>
          <el-button style="margin-left: 15px" v-if="!btnCode" :disabled="showCodeBtn" type="primary">{{num}}{{g_code}}</el-button>
        </el-form-item>
        <el-form-item  label="验证码：" :label-width="formLabelWidth">
          <el-input class="information" v-model="pnoneCode" auto-complete="off"></el-input>
        </el-form-item>
      </el-form>
      <div style="color:#CB110C;text-align: center;margin-left: 25%;margin-top: 0">申请预计三个工作日内到账</div>
      <div slot="footer" class="dialog-footer" style="text-align: center;padding-left: 10%;margin: 15px 0">
        <el-button type="primary" @click="readySave" class="_submit">提 交</el-button>
        <el-button @click="showReady = false" class="_back">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
  import axios from "axios";
  import pagination from '../common/Pagination';
  import base from "../../assets/base";
  export default {
    data() {
      return {
        isActivity:1,
        user_message:{},
        resultfulMoney:"",//可用余额
        baozhengjin:"0",//保证金
        sum:"",//总支出
        totalTurnover:0,  //营业额
        totalIncome:0,//净利润
        balance:"",//余额
        tr_show:true,
        currentPage:1,//当前页
        total_pages:0,//总页数
        pagesize:10,
        filterType:"商品交易 退货 提现 充值",
        startTime:'',
        endTime:'',
        start:'',
        end:'',
        tableData:[],
        value1:'',
        value2:'',
        showReady:false, //提现页面不显示
        formLabelWidth:'120px',
        tixianMoney:"",//提现金额
        aliAccount:"",//支付宝账户
        phoneNum:"",//手机号码
        pnoneCode:"",//手机验证码
        g_code:"获取验证码",
        showCodeBtn:false,
        full_how_much:"",//充值的金额
        full_money_Visible:false,//充值页面不显示
        num:60,
        btnCode:true,
        type:1
      }
    },
    components: {
      pagination
    },
    created(){
      this._getData();
      this.getMessage();
    },
    methods: {
      formatDate(now) {
        var year=now.getYear();
        var month=now.getMonth()+1;
        var date=now.getDate();
        var hour=now.getHours();
        var minute=now.getMinutes();
        var second=now.getSeconds();

        if(month<10){
          month = "0"+month;
        }
        if(date<10){
          date = "0"+date;
        }
        if(hour<10){
          hour = "0"+hour;
        }
        if(minute<10){
          minute = "0"+minute;
        }
        if(second<10){
          second = "0"+second;
        }

        return "20"+((year)-100)+"-"+month+"-"+date+" "+hour+":"+minute+":"+second
      },
      _getData(){
        var me = this;
        this.tableData = [];
        var Cookies = require("Cookies-js");
        var data = {
          type:this.type, //1全部 2商品交易 3退货 4提现 5充值
          startTime:this.startTime,
          endTime:this.endTime,
          pageNo:this.currentPage,//当前页号
          pageSize:10,
          token:Cookies.get("token")
        };
        me.base.axios_post(data,"/supplier/payCenter/supplierQryAccountDetails",function (res) {
            console.log(res);
            if(res.code==0){
              me.total_pages = res.data.pages;
              var money1 = res.data.userAccount.balance;
              var money2 = res.data.totalExpend;
              me.balance = me.turn_money(money1);
              me.sum = me.turn_money(money2);
              me.totalTurnover = (res.data.totalTurnover/100).toFixed(2);
              me.totalIncome = (res.data.totalIncome/100).toFixed(2);

              for(let i in res.data.resultList){
                res.data.resultList[i].change_time = me.formatDate(new Date(res.data.resultList[i].change_time));
                // 1提现申请 2充值 3订单完成  4商品退货  5 订单交易中 6订单取消
                if(res.data.resultList[i].change_mode == 1){
                  res.data.resultList[i].change_mode = "提现申请"
                }else if(res.data.resultList[i].change_mode == 2){
                  res.data.resultList[i].change_mode = "充值"
                }else if(res.data.resultList[i].change_mode == 3){
                  res.data.resultList[i].change_mode = "商品交易"
                }else if(res.data.resultList[i].change_mode == 4){
                  res.data.resultList[i].change_mode = "商品退货"
                }else if(res.data.resultList[i].change_mode == 5){
                  res.data.resultList[i].change_mode = "订单交易中"
                }else if(res.data.resultList[i].change_mode == 6){
                  res.data.resultList[i].change_mode = "订单取消"
                }

                if(res.data.resultList[i].pay_type == 1){
                  res.data.resultList[i].change_amount = "+"+me.turn_money(res.data.resultList[i].change_amount)
                }else if(res.data.resultList[i].pay_type == 2){
                  res.data.resultList[i].change_amount = "-"+me.turn_money(res.data.resultList[i].change_amount)
                }

                if(res.data.resultList[i].change_state == 1){
                  res.data.resultList[i].change_state = "申请中";
                }else if(res.data.resultList[i].change_state == 3){
                  res.data.resultList[i].change_state = "已支付";
                }else if(res.data.resultList[i].change_state == 2){
                  res.data.resultList[i].change_state = "待支付";
                }else if(res.data.resultList[i].change_state == 3){
                  res.data.resultList[i].change_state = "已支付";
                }else if(res.data.resultList[i].change_state == 0){
                  res.data.resultList[i].change_state = "失败";
                }else if(res.data.resultList[i].change_state == 4){
                  res.data.resultList[i].change_state = "已完成";
                }

              }
              me.tableData = res.data.resultList;
            }else{
              me.base.alerter(res.message);
            }
        });
      },
      getMessage(){
        var _this = this;
        var data = {};
        this.base.axios_post(data, "/supplier/userCenter/supplierWithdrawPage", function(res) {
            if(res.code==0){
              _this.user_message = res.data;
             _this.phoneNum = _this.user_message.phone;
              _this.resultfulMoney = _this.turn_money(_this.user_message.balance);
               _this.aliAccount = _this.user_message.aliAccount;
              var dataPhone = _this.phoneNum.split("");
              var dataAli = _this.aliAccount.split("");
              dataPhone.splice(3,4,"****");
              dataAli.splice(3,4,"****");
              _this.phoneNum = dataPhone.join("");
              _this.aliAccount = dataAli.join("");

            }else{
              _this.base.alerter(res.message);
            }
          });
      },
      //分类--选择全部
      all_choose(){
        this.isActivity = 1;
        this.type = 1;
        this.currentPage=1;
        this._getData();
      },
      deal_choose(){
        this.isActivity = 2;
        this.type = 2;
        this.currentPage=1;
        this._getData();
      },
      fade_choose(){
        this.isActivity = 3;
        this.type = 3;
        this.currentPage=1;
        this._getData();
      },
      ready_choose(){
        this.isActivity = 4;
        this.type = 4;
        this.currentPage=1;
        this._getData();
      },
      full_choose(){
        this.isActivity = 5;
        this.type = 5;
        this.currentPage=1;
        this._getData();
      },
      //转换为时间戳
      getTime1(value){
        this.start = new Date(value).getFullYear()+'-'+Number(new Date(value).getMonth()+1)+'-'+new Date(value).getDate();

        //this.start = value;
      },
      getTime2(value){
        //this.end = value;
        this.end = new Date(value).getFullYear()+'-'+Number(new Date(value).getMonth()+1)+'-'+new Date(value).getDate();
      },
      changes(){
        this.startTime = this.start;
        this.endTime = this.end;

        this._getData(1,this.currentPage,this.pagesize);
      },
      //充值
      top_full_money(){
        this.full_money_Visible = true;
      },
      //确定充值
      sure_full_money(){

        var Cookies = require("Cookies-js");
        if(!/^([1-9][0-9]*|0)(\.[0-9]+)*$/i.test(this.full_how_much)){
          this.$message({
            type: 'error',
            message: '请输入大于0的充值金额！'
          })
        }else{

          var data = {
            money:this.base.mul(this.full_how_much,100),
            pay_type:1,
            token:Cookies.get("token")
          };
          var _this = this;
          this.base.axios_post(data, "/supplier/payCenter/supplierRecharge", function(res) {
            if(res.code==0){
              console.log(res.data);
              document.getElementById('cou_code').innerHTML = res.data;
              document.forms['alipaysubmit'].submit();
            }else{
              _this.base.alerter(res.message);
            }
          });
        }
      },
      //倒计时
      countDown(){
        if (this.num == 0) {
          this.showCodeBtn = false;
          this.num = 60;
        } else {
          this.num--;
          var _this = this;
          setTimeout(_this.countDown, 1000);
        }
      },
      top_ready_money(){
        var Cookies = require("Cookies-js");
      if(Cookies.get("ali_atate")==0){
          this.$message({
            type: 'error',
            message: '请先绑定支付宝账号！'
          })
        }else{
        this.showReady=true;
      }

      },
      getCode(){
        var _this = this;
        var data = {
          phone:_this.user_message.phone
        };
        _this.showCodeBtn = true;
        _this.countDown();
        _this.btnCode = false;
        if(this.num == 60){
          _this.btnCode = true;
        }
        this.base.axios_post(data,"/supplier/userCenter/sendWithdrawMsg",function (res) {
          if(res.code==0){
            _this.g_code = "重新获取";
          }else{
            _this.base.alerter(res.message);
          }
          console.log(res);
        });
      },
      readySave(){

        if(Number(this.resultfulMoney)<Number(this.tixianMoney)){
          this.$message.error("提现金额不能大于可用金额！");
        }else if(Number(this.tixianMoney)%100<0){
          this.$message.error("提现金额最低为100！");
        }else{
          var data = {
            amount:this.base.mul(Number(this.tixianMoney),100),
            code:this.pnoneCode
          };
          var _this = this;
          this.base.axios_post(data,"/supplier/userCenter/supplierWithdraw",function (res) {
            console.log(res);
            if(res.code==0){
              _this.base.alerter('提现成功');
              _this.showReady=false;
            }else{
              _this.base.alerter(res.message);
            }
          });
        }
      },
      turn_page: function(i) {
        this.currentPage = i;
        this._getData();
      },
      //转换以金额“元”为单位
      turn_money(value){
        var f = Math.round(value*100)/10000;
        var s = f.toString();
        var rs = s.indexOf('.');
        if (rs < 0) {
          rs = s.length;
          s += '.';
        }
        while (s.length <= rs + 2) {
          s += '0';
        }
        return s;
      }
    }
  }
</script>

<style lang="less">
  .myAccount{
    .information{
      margin-left: 0!important;
      margin-top: 0!important;
    }
    .el-table_1_column_4{
      .cell{
        text-align: right!important;
        padding-right: 30%!important;
      }
    }
  .activity{
    color: #1c8de0;
    font-size: 20px;
  }
  .top{
    background-color: #fff;
    border-radius: 10px;
    padding: 20px 0;
    font-size: 0;
  }
  .bottom{
    background-color: #ffffff;
    min-height: 360px;
    margin-top: 20px;
    border-radius: 10px;
    padding-bottom: 20px;
  }
  .m_herder_list{
    display: inline-block!important;
   // border: 2px solid #919191;
   // border-bottom: solid 1px #666666;
    box-shadow: 2px 1px 3px 1px #cbcbcb;
    padding: 20px 0;
    width: 20%;
    height: 90px;
    vertical-align: middle;
    font-size: 20px;
    margin-left:3%;
    &:first-child{
      margin-left:11%;
    }
    div{
      display: inline-block;
      vertical-align: top;
      p{
        width: 100%;
        height: 40px;
        line-height: 40px;
      }
    }

  }
  .total{
    p{
      text-align: left;
      box-sizing: border-box;
      padding-left: 10%;
      height: 40px;
      line-height: 40px;
    }
  }
  .m_herder_btn{
    border: none!important;
    margin-left:0;
    box-shadow:none;
    div{
      width: 100%;
      margin-left: 10%;
      margin-top: 13%;
      button{
        float: left;
        width: 30%;
        height: 36px;
        background-color:#62B6F7 ;
        border-radius: 10px;
        margin-left: 10px;
        color: #fff;
      }
    }
  }
  .classes,.m_date{
    margin-top: 24px!important;
    margin-left: 11%;
  }
  .classes,.m_date{
    div{
      display: inline-block;
      font-size: 16px;
      text-align: center;
    }
    .classes_title,.m_date_title{
      padding: 0 10%;
      height: 40px;
      line-height: 40px;
      color: #03A9F4
    }
    .classes_content{
      padding: 0 40px;
      margin-left: -7%;
      span{
        padding: 0 40px;
        border-right: solid 1px #cbcaca;
        cursor: pointer;
        &:hover{
          color: #5f9be7;
        }
        &:last-child{
          border-right: none;
        }
      }
    }
    .m_date_content{
        width:600px;
      margin-left: -5%;
      .bbbb{
        .el-date-editor--date{
          width: 36%;
        }
        .el-input__icon{
          right: 50px!important;
        }
          .el-input__inner{
            width: 100%;
          }

      }
      .search{
      }
    }
  }
  .czmoney{
    width: 60%;
  }
  .cz{
    margin-left: -20px;
    .el-form-item__label{
      width: 112px!important;
    }
  }
  .now,.have{
    p{
      height: 40px;
      line-height: 40px;
      text-align: left;
      padding-left: 10%;
      box-sizing: border-box;
    }
  }
  .userAlipay{
    width: 64%;
    margin-left: 10px;
    height: 36px;
    line-height: 36px;
    display: inline-block;
  }
  .b_header{
    padding: 20px 0 15px 20px!important;
    font-size: 20px!important;
    color: #62B6F7!important;
    span{
      border-bottom:2px solid#62B6F7!important;
      padding: 5px 0!important;
    }
  }
  .el-pagination{
    text-align: right!important;
    padding-right: 30px!important;
    margin-top: 20px!important;
  }

    .el-input, .el-input__inner{
      width: 72%
    }
  .my_account .el-form-item{
    padding-left: 15%!important;
  }
  .el-form-item__label{
    text-align: left;
    margin-left: 20%;
  }
  .el-dialog__header{
    span{
      font-size: 20px!important;
      color: #63b1f3!important;
    }
  }
  .el-message-box__message{
    display: inline-block ;
    margin-right: 15px ;
    vertical-align: top;
    height: 36px;

  }
  .el-message-box__message p{
    line-height: 36px;
  }
  .el-message-box__input{
    display: inline-block ;
    width:210px ;
    padding: 0;
  }
  .el-dialog--small{
    width: 27%;
  }
  .tixian>div{
    width: 670px;
  }
  }
</style>
