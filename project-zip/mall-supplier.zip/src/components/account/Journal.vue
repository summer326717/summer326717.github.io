<template>
  <div class="content">
    <div class="table">
      <table>
        <tr class="bor">
          <th>商品名称</th>
          <th>市场价</th>
          <th>平台价</th>
          <th>已售数量</th>
          <th>提交时间</th>
          <th>下架时间</th>
          <th>操作</th>
        </tr>
        <tr>
          <td><img></td>
          <td>dsadsa</td>
          <td>dsadsa</td>
          <td>dsadsa</td>
          <td>dsadsa</td>
          <td>dsadsa</td>
          <td><button>交易明细</button></td>
        </tr>
      </table>
      <pagination :cur='page_no' :all='total_pages' @get_page='turn_page'></pagination>
    </div>
  </div>
</template>
<script>
import pagination from '../common/Pagination'
export default {
  data() {
    return {
      page_no: 1,
      total_pages: 2,
    }
  },
  components: {
    pagination
  },
  methods: {
    turn_page: function(i) {
      this.page_no = i;

    }
  }
}
</script>

<style>

</style>
