<template>
  <div class="pagelist" v-cloak>
    <a v-if="page_no>1" @click='left_page'>上一页</a>
    <a v-if="page_no==1">上一页</a>
    <a v-for="index in indexs" v-bind:class="{ 'active': page_no == index}" @click='turn_page(index)'>{{ index }}</a>
    <a v-if="page_no!=total_pages" @click='right_page'>下一页</a>
    <a v-if="page_no==total_pages">下一页</a>
    <input v-model="page_txt" type="text" />
    <a class="search_page" @click='search_page' href="javascript:;">确定</a>
  </div>
</template>
<script>
export default {
  name: "pagination",
  data() {
    return {
      page_txt: "",
      total_pages: 1,
      page_no: 1
    };
  },
  props: {
    all: Number,
    cur: Number
  },
  created() {
    this.total_pages = this.all;
    this.page_no = this.cur;
  },
  watch: {
    cur(val) {
      this.page_no = val;
    },
    all(val) {
      this.total_pages = val;
    }
  },
  methods: {
    left_page: function() {
      this.page_no--;
      this.$emit("get_page", this.page_no);
    },
    right_page: function() {
      this.page_no++;
      this.$emit("get_page", this.page_no);
    },
    turn_page: function(index) {
      this.page_no = index;
      this.$emit("get_page", this.page_no);
    },
    search_page: function() {
      if (this.page_txt == "") {
        this.base.alerter("请输入页码");
        return;
      }
      if (isNaN(this.page_txt)) {
        this.base.alerter("请输入正确的页码");
        return;
      }
      if (this.page_txt > this.total_pages) {
        this.base.alerter("输入页码数不能大于总页码数");
        return;
      }
      this.page_no = parseInt(this.page_txt);
      this.$emit("get_page", this.page_no);
      this.page_txt = "";
    }
  },
  computed: {
    indexs: function() {
      var left = 1;
      var right = this.total_pages;
      var ar = [];
      if (this.total_pages >= 5) {
        if (this.page_no > 3 && this.page_no < this.total_pages - 2) {
          left = this.page_no - 2;
          right = this.page_no + 2;
        } else {
          if (this.page_no <= 3) {
            left = 1;
            right = 5;
          } else {
            right = this.total_pages;
            left = this.total_pages - 4;
          }
        }
      }
      while (left <= right) {
        ar.push(left);
        left++;
      }
      return ar;
    }
  }
};
</script>
<style lang="less" scoped>
.pagelist {
  padding: 20px 0;
  font-size: 0;
  text-align: right;
  a {
    cursor: pointer;
    font-size: 14px;
    display: inline-block;
    color: #333333;
    line-height: 36px;
    padding: 0 15px;
    border: 1px solid #dcdcdc;
    margin-left: 12px;
    text-align: center;
    border-radius: 3px;

    &.active {
      color: #ffffff;
      background: #62b6f7;
      border: 1px solid #62b6f7;
    }
  }
  input {
    outline: none;
    width: 53px;
    line-height: 36px;
    margin-left: 12px;
    margin-right: -12px;
    vertical-align: top;
    text-align: center;
    border: 1px solid #dcdcdc;
    border-radius: 3px 0 0 3px;
  }
  .search_page {
    margin-right: 36px;
    padding: 0 8px;
    border-radius: 0 3px 3px 0;
  }
}
</style>