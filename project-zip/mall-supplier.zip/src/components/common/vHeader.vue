<template>
  <el-col :span="4" class="h left_menu">
    <span class="logo"><img src="../../assets/images/logo.png"></span>
    <div class="left_menu_se">
      <el-menu :default-active="onRoutes" class="el-menu-vertical-demo" theme="dark" unique-opened router background-color="#324157" text-color="#fff">
      <el-menu-item index="Index"><img src="../../assets/images/menu_01.png">首页</el-menu-item>
      <el-submenu index="1" v-if="state==2">
          <template slot="title"><img src="../../assets/images/menu_02.png">商品管理</template>
          <el-menu-item index="Tostorage">待入库</el-menu-item>
          <el-menu-item index="Tocheck">待审核</el-menu-item>
          <el-menu-item index="Instorage">已入库</el-menu-item>
          <el-menu-item index="Rejected">已驳回</el-menu-item>
          <el-menu-item index="Recycle">回收站</el-menu-item>
          <el-menu-item index="Comments">商品评价</el-menu-item>
      </el-submenu>
      <el-submenu index="2" v-if="state==2">
        <template slot="title"><img src="../../assets/images/menu_02.png">订单管理</template>
        <el-menu-item index="preOrder">预订单</el-menu-item>
        <el-menu-item index="Unprocessed">待发货</el-menu-item>
        <el-menu-item index="Toreceived">待收货</el-menu-item>
        <el-menu-item index="Toreturned">待退款</el-menu-item>
        <el-menu-item index="Returned">已退款</el-menu-item>
        <el-menu-item index="Completed">已完成</el-menu-item>
        <!--<el-menu-item index="Servicer">客服信息</el-menu-item>-->
      </el-submenu>
        <el-submenu index="3" v-if="state==2">
          <template slot="title"><img src="../../assets/images/menu_02.png">消息管理</template>
          <el-menu-item index="pending">待处理</el-menu-item>
          <el-menu-item index="disposed">已处理</el-menu-item>
        </el-submenu>
        <el-submenu index="4" v-if="state==2">
          <template slot="title"><img src="../../assets/images/menu_02.png">优惠设置</template>
          <el-menu-item index="being">使用中</el-menu-item>
          <el-menu-item index="stopped">已停用</el-menu-item>
        </el-submenu>
      <el-submenu index="5" v-if="state==2">
        <template slot="title"><img src="../../assets/images/menu_04.png">账户管理</template>
        <el-menu-item index="Myaccount">我的账户</el-menu-item>
       <!-- <el-menu-item index="Journal">资金流水</el-menu-item>-->
      </el-submenu>
      <el-submenu index="6">
        <template slot="title"><img src="../../assets/images/menu_05.png">个人中心</template>
        <el-menu-item index="Userinfo">用户信息</el-menu-item>
   <!--     <el-menu-item index="Help">帮助中心</el-menu-item>
        <el-menu-item index="Advice">意见反馈</el-menu-item>
        <el-menu-item index="About">关于我们</el-menu-item>-->
      </el-submenu>
    </el-menu>
    </div>
    <div class="top_header">
      <div class="right_info" style="../../assets/images/logo.png">
        <img class="header_img" v-if="!sup_icon" src="../../assets/images/head_icon.png">
        <img class="header_img" v-if="sup_icon" :src="sup_icon">
        <div class="header_nane">
          <p>{{sup_name}}</p>
          <p v-if="state==2">已认证</p>
          <p v-if="state==0">认证失败</p>
          <p v-if="state==3">未认证</p>
          <p v-if="state==1">审核中</p>
        </div>
        <span v-on:click="sign_out" class="header_down">退出</span>
      </div>
    </div>
  </el-col>
</template>
<script>
var Cookies = require("Cookies-js");
export default {
  name: "vHeader",
  data() {
    return {
      state: 2, //登陆后的用户状态
      sup_icon: "",
      sup_name: ""
    };
  },
  created() {
    let state = Cookies.get("state");
    if (state) {
      this.state = state;
    }
    let sup_icon = Cookies.get("sup_icon");
    if (sup_icon != "null") {
      this.sup_icon = sup_icon;
    }
    let sup_name = Cookies.get("sup_name");
    if (sup_name) {
      this.sup_name = sup_name;
    }
  },
  mounted() {
    this.state = Cookies.get("state");
  },
  methods: {
    sign_out: function() {
      let json = {
        token: Cookies.get("token")
      };
      let _this = this;
      this.base.axios_post(json, "/supplier/userCenter/supplierExit", function(
        res
      ) {
        if (res.code == 0) {
          _this.$router.push("/login");
        } else {
          _this.base.alerter(res.message);
        }
      });
    }
  },
  computed: {
    onRoutes() {
      return this.$route.path.replace("/", "");
    }
  }
};
</script>
