<template>
<div class="viewdetail">
  <span @click="dialogVisible=true">123465</span>
  <el-dialog title="提示" :visible.sync="dialogVisible" width="80%" :before-close="handleClose">
  <div class="">
    <div class="add_info">
      <div class="">
        <el-row>
          <el-col :span="6" class="left_nav">
            <p v-for="(item,i) in join_txt" :key="i">
              <button class="btn" :class="{active:join_type==(i+1)}" @click="tab_join_type(i+1)">{{item}}</button>
            </p>
          </el-col>
          <el-col :span="18" class="right_con" v-if="join_type==1">
            <p>
              <span class="base_span">商品名称</span>
              <span class="l_ipt">
                <el-button size="small" type="text">{{goods_base_info.goodsName}}</el-button>
              </span>
            </p>
            <p>
              <span class="base_span">分类</span>
              <el-button size="small" type="text">{{goods_base_info.goodsName}}</el-button>
            </p>
            <p>
              <span class="base_span">属性</span>
              <span class="l_ipt">
                <el-button size="small" type="text">{{goods_base_info.goodsAttribute}}</el-button>
              </span>
            </p>
            <p>
              <span class="base_span">商品品牌</span>
              <span class="l_ipt">
                <el-button size="small" type="text">{{goods_base_info.goodsBrand}}</el-button>
              </span>
            </p>
            <p>
              <span class="base_span">市场价（元）</span>
              <span class="s_ipt">
                <el-button size="small" type="text">{{goods_base_info.marketPrice}}</el-button>
              </span>
              <span class="base_span">平台价（元）</span>
              <span class="s_ipt">
                <el-button size="small" type="text">{{goods_base_info.supplyPrice}}</el-button>
              </span>
            </p>
            <p>
              <span class="base_span">商品介绍</span>
              <span class="l_ipt">
                <el-button size="small" type="text">{{goods_base_info.goodsIntroduce}}</el-button>
              </span>
            </p>
            <p>
              <span class="base_span">商品缩略图</span>
              <div class="img_list"><img :src="goods_base_info.goodsIcon"></div>
            </p>
          </el-col>
          <el-col :span="18" class="right_con" v-if="join_type==2">
            <ul class="detail">
              <li>
                <span class="li_span">规格</span>
                <span class="li_span">库存量</span>
              </li>
              <li v-for="(item,index) in good_detail_list" :key="index">
                <p >
                  <span class="li_span" >{{item.magnitude}}</span>
                  <span class="li_span" >{{item.stockAmount}}</span>
                  <el-button size="small" type="primary" v-on:click="del_detile(index)">删除</el-button>
                </p>
              </li>            
            </ul>
          </el-col>
          <el-col :span="18" class="right_con" v-if="join_type==3">
            <form enctype="multipart/form-data" style="display:none" id="uploadForm_default_tea">
              <input type="file" @change="upload_img" id="tea_cate_img" name="file" accept="image/png,image/gif,image/jpeg"/>
              <input type="hidden" name="goods" value="123456" />
            </form>
            <div class="img_list">
              <span class="img_list_item" v-for="(item,i) in img_list" :key="i">
                <img :src="item.thumbnailAddress">
                <span class="close" @click="delete_img(i)">×</span>
              </span>
            </div>
          </el-col>
          <el-col :span="18" class="right_con" v-if="join_type==4">
            <p>
              <span>发货时间</span>
              <span>
                <el-radio class="radio" v-model="deliverHour" label="1">24小时</el-radio>
                <el-radio class="radio" v-model="deliverHour" label="2">48小时</el-radio>
              </span>
            </p>
            <p>
              <span>7天无理由退款</span>
              <span>
                <el-radio class="radio" v-model="sevenDaysRefund" label="1">是</el-radio>
                <el-radio class="radio" v-model="sevenDaysRefund" label="2">否</el-radio>
              </span>
            </p>
          </el-col>
        </el-row>
      </div>
    </div>
  </div>
  <span slot="footer" class="dialog-footer">
    <el-button size="small" @click="dialogVisible = false">取 消</el-button>
    <el-button size="small" type="primary" @click="dialogVisible = false">确 定</el-button>
  </span>
</el-dialog>
</div>
</template>
<script>
export default {
  data() {
    return {
      dialogVisible: false,
      join_txt: ["基础信息", "轮播图片", "图文信息", "其他信息"],
      join_type: 1, //1.基础信息，2.详情信息，3.图片信息，4.其他信息
      //图片信息
      goods_base_info: {
        firstTypeName: "",
        goodsAttribute: "",
        goodsIcon: "",
        goodsName: "",
        marketPrice: "",
        secondTypeName: "",
        supplyPrice: "",
        goodsIntroduce: ""
      },
      goods_spec_list: [],
      goods_banner_list: [],
      get_pic_list: []
    };
  },
  props: {
    goodsId: String
  },
  created() {
    this.get_base_info();
  },
  methods: {
    handleClose() {},
    tab_join_type: function(i) {
      if (this.join_type == 2) {
        this.get_spec_list();
      }
      if (this.join_type == 3) {
        this.get_banner_list();
      }
      if (this.join_type == 4) {
        this.get_other_info();
      }
    },
    //查询商品规格信息
    get_spec_list: function() {
      let json = {
        goodsId: this.goodsId
      };
      let _this = this;
      this.base.axios_post(json, "/goods/queryGoodsSpecifications", function(
        res
      ) {
        if (res.code == 0) {
          _this.goods_spec_list = res.data;
        }
      });
    },
    //查询商品图片信息
    get_banner_list: function() {
      let json = {
        goodsId: this.goodsId
      };
      let _this = this;
      this.base.axios_post(json, "/goods/queryGoodsEnclosure", function(res) {
        if (res.code == 0) {
          if (res.data) {
            _this.goods_banner_list = res.data;
          }
        }
      });
    },
    //查询商品其他信息
    get_other_info: function() {
      let json = {
        goodsId: this.goodsId
      };
      let _this = this;
      this.base.axios_post(json, "/goods/queryGoodsAuxiliary", function(res) {
        if (res.code == 0) {
          if (res.data) {
            _this.deliverHour = res.data.deliverHour.toString();
            _this.sevenDaysRefund = res.data.sevenDaysRefund.toString();
          } else {
            _this.deliverHour = "1";
            _this.sevenDaysRefund = "1";
          }
        }
      });
    },
    get_base_info: function() {
      let json = {
        goodsId: this.goodsId
      };
      let _this = this;
      this.base.axios_post(json, "/goods/queryGoodsInfoByGoodsId", function(
        res
      ) {
        if (res.code == 0) {
          _this.goods_base_info = res.data;
          _this.goods_base_info.marketPrice =
            _this.goods_base_info.marketPrice / 100;
          _this.goods_base_info.supplyPrice =
            _this.goods_base_info.supplyPrice / 100;
        }
      });
    }
  }
};
</script>
<style lang="less">
.viewdetail .add_info .right_con{
  line-height: 40px;
}
</style>