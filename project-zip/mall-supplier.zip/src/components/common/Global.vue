<script>
const url = '/api/api/1';
const key = 'testtesttesttest';

export default {
  url, key
}
</script>
