<template>
  <div>
    <div class="oss_file">
      <input type="file" :id="id" :multiple="multiple" @change="doUpload"/>
     <!-- <input type="file" id="file" />-->
    </div>
  </div>
</template>

<script>
  export default{
    props:{
      multiple:{
        type: Boolean,
        twoWay:false
      },
      id:{
        type: String,
        twoWay:false
      },
      /*url:{
        type: Array,
        twoWay:true
      }*/
    },
    data(){
      return{
        region:'Your oss Region',
        bucket:'Bucket Name',
      };
    },
    methods:{
      doUpload(){
      	var _this=this;

        this.base.axios_postst('', "/oss/ossTest", function(res) {
          //var OSS = require('ali-oss');
          //var co = require('co');
          //res=JSON.parse(res);
          const client = new OSS.Wrapper({
            endpoint:"http://oss-cn-hangzhou.aliyuncs.com", /*res.data.region,*/
            accessKeyId: res.data.access_key_id,
            accessKeySecret: res.data.access_key_secret,
            stsToken: res.data.security_token,
            bucket: res.data.bucket,
          });
          console.log(client);
          const files = document.getElementById(_this.id);
          if (files.files) {
            const fileLen = document.getElementById(_this.id).files;
            const resultUpload = [];
           /* const file = fileLen;
            const storeAs = file.name;
            client.multipartUpload(storeAs, file).then(function (result) {
              console.log(result);
            }).catch(function (err) {
              console.log(err);
            });*/
            for (let i = 0; i < fileLen.length; i++) {
              const file = fileLen[i];
              const storeAs = file.name;
              client.multipartUpload(storeAs, file).then(function (result) {
                console.log(result);
              }).catch(function (err) {
                console.log(err);
              });
            }
            _this.url = resultUpload;
          }
        });

      }
    }
  };
</script>
<style type="text/css">
  .oss_file {
    height: 100px;
    width: 100%;

  }
  .oss_file  input {
    right: 0;
    top: 0;
    opacity: 100;
    filter: alpha(opacity=0);
    cursor: pointer;
    width: 100%;
    height: 100%;
  }

</style>

作者：Nix_____
链接：http://www.jianshu.com/p/645f63745abd
來源：简书
著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。
