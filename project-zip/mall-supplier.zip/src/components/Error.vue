<template>
  <div>
    <p class="h1">404，该页面没有找到</p>
  </div>
</template>
<style>
.h1 {
  font-size: 32px;
  font-weight: bold;
}
</style>
