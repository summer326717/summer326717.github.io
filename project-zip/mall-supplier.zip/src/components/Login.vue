<template>
  <div class="login">
    <img class="l_img" src="../assets/images/login_01.png">
    <div class="login_box" v-if="login_type==1">
      <p class="tit">登录</p>
      <p><input class="ipt" type="tel" placeholder="请输入用户名" v-model="l_username"></p>
      <p><input class="ipt" type="password" placeholder="请输入密码" v-model="l_password"   @keyup.13="_login"></p>
      <p><input type="checkbox" v-model="is_remember">
        <span>记住密码</span>
        <a class="f_pwd" @click="login_type=2" href="javascript:;">忘记密码？</a>
      </p>
      <p>
        <button class="l_btn" @click="l_login">登录</button>
      </p>
      <p>
        <a class="reg" href="javascript:;" @click="go_register">立即注册</a>
      </p>
    </div>
    <div class="login_box" v-if="login_type==2">
      <p class="tit">忘记密码
        <i class="login_close" @click="go_login">×</i>
      </p>
      <p><input class="ipt" type="tel" placeholder="请输入手机号" v-model="l_phone"></p>
      <p class="pr"><input class="ipt" type="number" placeholder="请输入手机号验证码" v-model="f_code">
        <button v-if="!is_get_code" class="code" @click="get_forget_code">获取验证码</button>
        <button v-if="is_get_code" class="code">{{num}}</button>
      </p>
      <p><input class="ipt" type="password" placeholder="请输入新密码" v-model="f_password" @keyup.13="_sure_login"></p>
      <p>
        <button class="l_btn" @click="f_update_pwd">确定</button>
      </p>
    </div>
  </div>
</template>
<script>
  import base from '../assets/base'
export default {
  data() {
    return {
      login_type: 1,//1是登录，2是忘记密码
      l_username: '',
      l_password: '',
      l_phone:'',//忘记密码输入的手机号码
      is_remember: false,
      f_username: '',
      f_password: '',
      f_code: '',
      num:60,
      is_get_code:false,
    }
  },
  methods: {
    get_gray: function() {
      if (this.num == 0) {
        this.is_get_code = false;
        this.num = 60;
      } else {
        this.num--;
        var _this = this;
        setTimeout(_this.get_gray, 1000);
      }
    },
    go_forget_pwd: function() {
    	if(this.l_username){
        this.login_type = 2;
      }else{
    		base.alerter('请输入用户名！');
      }
    },
    go_login: function() {
      this.login_type = 1;
    },
    go_register: function() {
      this.$router.push('/register');
    },
    l_login: function() {
      if (this.l_username == '') {
        this.base.alerter('请输入用户名');
        return;
      }
      if (this.l_password == '') {
        this.base.alerter('请输入密码');
        return;
      }
      var data = {
        'supplier_accounts': this.l_username,
        'supplier_pass': this.l_password,
      };
      var _this = this;
      var Cookies = require('Cookies-js');
      this.base.axios_post(data, '/userCenter/supplierLogin', function(res) {
        if (res.code == 0) {
        	localStorage.UserState=res.data.state;
        	Cookies.set('token',res.data.token,{expires:Infinity});
          Cookies.set('state',res.data.state,{expires:Infinity});
          Cookies.set('sup_icon',res.data.sup_icon,{expires:Infinity});
          Cookies.set('sup_name',res.data.sup_name,{expires:Infinity});
          _this.$router.push('/index');
          if (_this.is_remember) {

          } else {
            //密码
          }
        } else if(res.code==9){
        	base.alerter('密码错误！');
        }else if(res.code==10){
        	base.alerter('账号不存在！');
        }else if(res.code==11){
          base.alerter('账号已冻结！');
        }else if(res.code==13||res.code==14||res.code==17){
        	base.alerter(res.message);
        	localStorage.UserState=res.data.state;
        	Cookies.set('token',res.data.token,{expires:Infinity});
          Cookies.set('state',res.data.state,{expires:Infinity});//3未认证,1审核中，2已认证，0认证失败
          Cookies.set('sup_icon',res.data.sup_icon,{expires:Infinity});
          Cookies.set('sup_name',res.data.sup_name,{expires:Infinity});
          _this.$router.push('/Userinfo');
        }else{
        	base.alerter(res.message)
        }
      })
    },
    get_forget_code: function() {
      if (this.l_phone == '') {
        this.base.alerter('请输入用户名');
        return;
      }
      var data = {
        "phone": this.l_phone,
      };
      var _this = this;
      this.base.axios_post(data, '/userCenter/supplierSendForgetMsg', function(res) {
        if (res.code == 0) {
          _this.is_get_code = true;
          _this.get_gray();
        }
        _this.base.alerter(res.message);
      })
    },
    f_update_pwd: function(res) {
      if (this.l_phone == '') {
        this.base.alerter('请输入手机号');
        return;
      }
      if (this.f_password == '') {
        this.base.alerter('请输入密码');
        return;
      }
      if (this.f_code == '') {
        this.base.alerter('请输入验证码');
        return;
      }
      var data = {
        'phone': this.l_phone,
        'supplier_pass': this.f_password,
        'verification_code': this.f_code
      }
      var _this = this;
      this.base.axios_post(data, '/userCenter/supplierForgetMsg', function(res) {
        if (res.code == 0) {
          //成功
          _this.base.alerter(res.message);
          _this.login_type = 1;
        } else {
          _this.base.alerter(res.message);
        }
      })
    },
    _login(){
        this.l_login();
    },
    _sure_login(){
      this.f_update_pwd();
    }
  }
}
</script>

<style>
.login {
  background: #62B6F7;
}
.login .l_img{
  margin: 50px;
}

.login .login_box {
  width: 400px;
  height: 432px;
  background: #ffffff;
  position: absolute;
  right: 10%;
  top: 20%;
  padding: 0 40px;
  border-radius: 10px;
  box-shadow: rgba(0, 0, 0, 0.5) 0 0 2px;
}

.login .login_box .tit {
  padding: 30px 0;
  font-size: 20px;
  text-align: center;
  position: relative;
}

.login .login_box .ipt,
.login .login_box .l_btn {
  border-radius: 10px;
}

.login .login_box .ipt {
  width: 95%;
  padding-left: 5%;
  line-height: 52px;
  margin-bottom: 20px;
  border: 2px solid #EAEAEA;
}

.login .login_box .l_btn {
  width: 100%;
  font-size: 18px;
  line-height: 64px;
  color: #ffffff;
  background: #62B6F7;
  margin: 20px 0;
  box-shadow: rgba(0, 0, 0, 0.3) 0 0 10px;
}

.login .login_box .f_pwd {
  color: #EB701D;
  float: right;
  margin-bottom: 10px;
}

.login .login_box .reg {
  color: #62B6F7;
  float: right;
  margin-right: 20px;
}

.login .login_box .code {
  position: absolute;
  right: -4px;
  top: 0;
  border-radius: 0 10px 10px 0;
  width: 153px;
  line-height: 56px;
  background-color: #C0C0C0;
}
</style>
