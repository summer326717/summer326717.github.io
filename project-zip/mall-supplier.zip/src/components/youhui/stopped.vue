<template>
  <div class="content stopped">
     <div class="table">
        <table>
            <tr>
              <th style="text-align: left">优惠金额</th>
              <th class="overflow">限定商品</th>
              <th class="number">限制条件</th>
              <th>获取方式</th>
              <th class="number">剩余数量</th>
              <th>活动时间</th>
            </tr>
            <tr v-for="(v,k) in data_list" :key="k">
              <td style="text-align: left">{{v.money}}</td>
              <td class="overflow">{{v.rangeName}}</td>
              <td class="number">{{v.rangeCondition}}</td>
              <td>{{v.getWay}}</td>
              <td class="number">{{v.restNum}}</td>
              <td>{{v.startTime}} - {{v.endTime}}</td>
            </tr>
          </table>
        <div class="no_data" v-if="no_data"><img src="../../assets/images/no_data.png"/></div>
        <pagination :cur='page_no' v-if="data_list!=''&&total_pages>1" :all='total_pages' @get_page='turn_page'></pagination>
     </div>
  </div>
</template>
<script>
import pagination from "../common/Pagination";
export default {
  data(){
    return{
      page_no:1,
      total_pages:1,
      data_list:[],
      no_data:false,

    }
  },
  components: {
    pagination,
  },
  created(){
    this.get_data();
  },
  methods:{
    get_data(){
      var data = {
        state:0,// 1是启用0是停用
        page_no:this.page_no,//请求的页码
        page_size:10//每页显示的条数
      };
      var _this = this;
      this.base.axios_post(data,"/goods/queryCouponsActivityList",function (res) {
        if(res.code==0){
          if(res.data.resultList){
            for(var i in res.data.resultList){
              if(res.data.resultList[i].getWay=='1'){
                res.data.resultList[i].getWay = '领取';
              }else if(res.data.resultList[i].getWay=='2'){
                res.data.resultList[i].getWay = '赠送';
              }
              if(res.data.resultList[i].restNum==-1){
                res.data.resultList[i].restNum = '无上限';
              }
              if(res.data.resultList[i].rangeCondition=='0'){
                res.data.resultList[i].rangeCondition = "无";
              }else{
                res.data.resultList[i].rangeCondition = "满  "+res.data.resultList[i].rangeCondition;
              }
              if(res.data.resultList[i].discountMode === 2){
                res.data.resultList[i].money = res.data.resultList[i].discountFactor+' 折';
              }else if(res.data.resultList[i].discountMode === 1){
                res.data.resultList[i].money = '￥ '+res.data.resultList[i].discountAmount;
              }
            }
            _this.data_list = res.data.resultList;
            _this.total_pages = res.data.pages;

            _this.data_list.map(function(x, y) {
              x.startTime = _this.base.trans_time(x.startTime,1);
              x.endTime = _this.base.trans_time(x.endTime,1);
            });
            _this.no_data = false;
          }else{
            _this.no_data = true;
          }
        }else{
          _this.no_data = true;
        }
      });
    },
    turn_page(i){
      this.page_no = i;
      this.get_data();
    }
  },
}
</script>
<style>
  .stopped .table{
    width: 96%;
    margin: 0 auto;
  }
  .stopped table tr img {
    width: 35px;
    border-radius: 50%;
    vertical-align: middle;
    margin-right: 3px;
  }
  .stopped table{
    width: 100%;
    border-collapse: collapse;
    margin: 0 auto;
  }
  .stopped table tr{
    border-bottom: solid 1px #d7d7d7;
  }
  .stopped table tr td{
    padding: 5px 0;
    font-size: 14px;
    text-align: center;
  }
  .stopped table tr th{
    font-size: 14px;
    padding: 15px 0;
    color: #666666;
    font-weight:400;
    text-align: center;
  }
  .stopped .table .overflow{
    max-width: 150px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    text-align: left;
  }
  .stopped table tr .number{
    text-align: right;
  }
</style>
