<template>
  <div class="content being">
    <div class="box" v-if="tacket_type==1">
      <div class="top">
      <span @click="add_ticket">添加优惠券</span>
    </div>
      <div class="bottom">
        <div class="table" v-if="!no_data">
          <table>
            <tr>
              <th style="text-align: left">优惠金额</th>
              <th class="overflow">限定商品</th>
              <th class="number">限制条件</th>
              <th>获取方式</th>
              <th class="number">剩余数量</th>
              <th>活动时间</th>
              <th>操作</th>
          </tr>
            <tr v-for="(v,k) in data_list" :key="k">
              <td style="text-align: left">{{v.money}}</td>
              <td class="overflow">{{v.rangeName}}</td>
              <td class="number">{{v.rangeCondition}}</td>
              <td>{{v.getWay}}</td>
              <td class="number">{{v.restNum}}</td>
              <td>{{v.startTime}} - {{v.endTime}}</td>
              <td>
                <el-button size="small" type="primary" @click="set_ticket(k)">修改</el-button>
                <el-button size="small" type="danger" @click="stop_ticket(v.activityId)">停用</el-button>
              </td>
          </tr>
          </table>
          <pagination :cur='page_no' v-if="data_list!=''&&total_pages>1" :all='total_pages' @get_page='turn_page'></pagination>
        </div>
        <div class="no_data" v-if="no_data"><img src="../../assets/images/no_data.png"/></div>
      </div>
    </div>
    <ticket v-if="tacket_type==0" :dataList="List" :type="type" @tacket_type="get_being"></ticket>
  </div>
</template>
<script>
import pagination from "../common/Pagination";
import ticket from "./ticket.vue";
export default {
  data(){
    return{
      tacket_type:1,
      total_pages:1,//总页数
      page_no:1,//当前页
      no_data:false,
      data_list:[],
      id:"",
      type:0,
      dataList:[],
      List:{},
      index:-1,
    }
  },
  components: {
    pagination,
    ticket
  },
  created(){
    this.getData(1,10);
  },
  methods:{
    getData(page_no,size){
      var _this = this;
      var data = {
        state:1,//1是启用 0是停用
        page_no:page_no,//请求的页码
        page_size:size//每页显示的条数
      };
      this.base.axios_post(data,"/goods/queryCouponsActivityList",function (res) {
        if(res.code==0){
          if(res.data.resultList){
            _this.dataList = JSON.parse(JSON.stringify(res.data.resultList));
              for(var i in res.data.resultList){
                if(res.data.resultList[i].getWay=='1'){
                  res.data.resultList[i].getWay = '领取';
                }else if(res.data.resultList[i].getWay=='2'){
                  res.data.resultList[i].getWay = '赠送';
                }
                if(res.data.resultList[i].rangeCondition=='0'){
                  res.data.resultList[i].rangeCondition = "无";
                }else{
                  res.data.resultList[i].rangeCondition = "满  "+(res.data.resultList[i].rangeCondition)/100;
                }
                if(res.data.resultList[i].restNum==-1){
                  res.data.resultList[i].restNum = '无上限';
                }
                if(res.data.resultList[i].discountMode === 2){
                  res.data.resultList[i].money = res.data.resultList[i].discountFactor+' 折';
                }else if(res.data.resultList[i].discountMode === 1){
                  res.data.resultList[i].money = '￥ '+(res.data.resultList[i].discountAmount)/100;
                }
              }
              _this.data_list = res.data.resultList;
              _this.total_pages = res.data.pages;

              _this.data_list.map(function(x, y) {
                x.startTime = _this.base.trans_time(x.startTime,1);
                x.endTime = _this.base.trans_time(x.endTime,1);
              });
            _this.no_data = false;
          }else{
              _this.no_data = true;
          }
        }else{
          _this.no_data = true;
        }

      });
    },
    add_ticket(){
      this.type = 1;
      this.tacket_type = 0;
    },
    set_ticket(index){
      this.index = index;
      this.List = this.dataList[index];
      this.type = 2;
      this.tacket_type = 0;
    },
    stop_ticket(id){
      this.$confirm('确定停用该优惠券吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        showClose:false
      }).then(() => {
        var data = {
          activityId:id,
          state:0
        };
        var me = this;
        this.base.axios_post(data,"/goods/updateCouponsActivity",function (res) {
            if(res.code==0){
              me.$message({
                type: 'success',
                message: '已停用!'
              });
              me.getData(me.page_no,10)
            }
        });
      }).catch(() => {});

    },
    turn_page(i){
      this.page_no = i;
      this.getData(this.page_no,10)
    },
    get_being(i){
      this.tacket_type = i;
      this.getData(this.page_no,10);
    },
  }
}
</script>
<style>
.being .top,.bottom{
  border-radius: 10px;
  padding: 17px 0;
  margin-bottom: 20px;
  background: #fff;
}
.being .top span{
  color: #ffffff;
  width: 110px;
  line-height: 36px;
  font-size: 16px;
  margin-left: 40px;
  background: #62b6f7;
  border-radius: 10px;
  text-align: center;
  display: inline-block;
  cursor: pointer;
}
.being .table{
  width: 96%;
  margin: 0 auto;
}
.being table tr img {
  width: 35px;
  border-radius: 50%;
  vertical-align: middle;
  margin-right: 3px;
}
.being table{
  width: 100%;
  border-collapse: collapse;
  margin: 0 auto;
}
.being table tr{
  border-bottom: solid 1px #d7d7d7;
}
.being table tr td{
  padding: 5px 0;
  font-size: 14px;
  text-align: center;
}
.being table tr th{
  font-size: 14px;
  padding: 15px 0;
  color: #666666;
  font-weight:400;
  text-align: center;
}
.being .table .overflow{
  max-width: 150px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  text-align: left;
}
.being table tr .number{
  text-align: right;
}
</style>
