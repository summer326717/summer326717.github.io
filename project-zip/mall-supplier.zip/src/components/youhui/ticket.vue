<template>
  <div class="content ticket">
    <div class="add_info" >
      <p class="return bor">
        <span @click="back">
          <i class="el-icon-caret-left"></i>返回上一页</span>
      </p>
      <div class="ticket_box">
        <div class="ticket_item">
          <span>优惠券类型</span>
          <el-select v-model="ticket_type" @change="get_ticket_type" placeholder="请选择">
          <el-option
            v-for="(v,k) in table_list1"
            :key="k"
            :label="v.name"
            :value="v.name">
          </el-option>
        </el-select>
        </div>
        <div class="ticket_item" v-if="code==1">
          <span>优惠金额(元)</span>
          <el-input v-model="input1"></el-input>
          <i :class="{none:isNone1}">*优惠金额为0~999的整数</i>
        </div>
        <div class="ticket_item" v-if="code==2">
          <span>优惠金额(折)</span>
          <el-input v-model="input2" placeholder="0.0" ></el-input>
          <i :class="{none:isNone2}">*请输入0~9(允许保留一位小数)</i>
        </div>
        <div class="ticket_item">
          <span>数量(张)</span>
          <el-input v-model="input3" ></el-input>
          <i :class="{none:isNone3}">*若不需要限制，请输入-1</i>
        </div>
        <div class="ticket_item">
          <span>限制条件</span>
          <span class="r">满</span>
          <el-input v-model="input4" class="rule"></el-input>
          <span class="r">元</span>
          <i :class="{none:isNone4}">*若不需要限制，请输入0</i>
        </div>
        <div class="ticket_item date">
          <span>活动日期</span>
         <el-date-picker
          v-model="startTime"
          type="date"
          @change="get_start_time"
          placeholder="开始日期">
        </el-date-picker>
           -
          <el-date-picker
            v-model="endTime"
            type="date"
            @change="get_end_time"
            placeholder="结束日期">
          </el-date-picker>
        </div>
        <div class="ticket_item">
          <span>有效期(天)</span>
          <el-input v-model="input5" ></el-input>
          <i :class="{none:isNone5}">*若永久有效，请输入-1</i>
        </div>
        <div class="ticket_item">
          <span>限定商品</span>
          <span class="xianding">{{commodity}}</span>
          <el-button type="primary" @click="selectGoods">选择</el-button>
        </div>
        <div class="ticket_item">
          <span>获取方式</span>
          <el-select v-model="gain_type" @change="get_gain_type" placeholder="请选择">
            <el-option
              v-for="(v,k) in table_list2"
              :key="k"
              :label="v.name"
              :value="v.name">
            </el-option>
          </el-select>
        </div>
        <div class="ticket_item" style="text-align: center;margin-top: 50px">
          <el-button type="primary" @click="submit_ticket">提交</el-button>
        </div>
      </div>

      <el-dialog
        class="dialog"
        title="商品选择"
        :visible.sync="show_commodity">
        <el-radio-group v-model="radioGoods" @change="radio_goods" v-if="!no_data">
          <el-radio :label="-1" :class="{none2:isNone4}" style="color: #1d90e6">全部商品</el-radio>
          <el-radio :label="goods_list[k]" v-for="(v,k) in goods_list" :key="k">{{v.goodsName}}</el-radio>
        </el-radio-group>
        <pagination :cur='page_no' v-if="goods_list!=''&&total_pages>1" :all='total_pages' @get_page='turn_page'></pagination>
        <div class="no_data" v-if="no_data"><img src="../../assets/images/no_data.png"/></div>
      </el-dialog>
    </div>
  </div>
</template>
<script>
  import pagination from "../common/Pagination";
  export default {
    name:"ticket",
    data(){
      return{
        page_no:1,
        total_pages:1,
        ticket_type:"满减券",//优惠券类型
        table_list1:[],//优惠券类型
        input1:'',//优惠金额
        input2:'',//折扣
        input3:'',//优惠券数量
        input4:'',//限制条件
        startTime:'',
        endTime:'',
        isNone5:false,
        isNone1:false,
        isNone2:false,
        isNone3:false,
        isNone4:false,//单选全部商品按钮
        input5:'',//有效期
        commodity:'',//限定商品
        gain_type:"领取",//获取方式
        table_list2:[],//获取方式
        show_commodity:false,
        radioGoods:'',//单选的商品
        goods_list:[],//全部商品
        no_data:false,
        goodsId:"",
        code:1,
        code2:1
      }
    },
    props:{
      dataList:Object,
      type:Number
    },
    components: {
      pagination,
    },
    created(){
      this.get_goods_list(1);
      this.get_table_list("couponsType");//优惠券类型
      this.get_table_list("obtainType");//获取方式
    },
    mounted(){
      this.item();

    },
    methods:{
      back(){
        this.$emit("tacket_type",1);
      },
      item(){
        if(this.type==2){
          this.input1 = (this.dataList.discountAmount)/100;
          this.input2 = this.dataList.discountFactor;
          this.input3 = String(this.dataList.planNum);
          this.input4 = String(Number(this.dataList.rangeCondition)/100);
          this.input5 = this.dataList.termValidity;
          this.goodsId = this.dataList.goodsId;
          this.commodity = this.dataList.rangeName;
          this.startTime = this.dataList.startTime;
          this.endTime = this.dataList.endTime;
          if(this.dataList.discountMode==1){
            this.code = 1;
            this.ticket_type = '满减券'
          }else if(this.dataList.discountMode==2){
            this.code = 2;
            this.ticket_type = '折扣券'
          }
          if(this.dataList.getWay==1){
            this.code2 = 1;
            this.gain_type = '领取'
          }else if(this.dataList.getWay==2){
            this.code2 = 2;
            this.gain_type = '赠送'
          }
        }
      },
      get_table_list(type){
        var _this = this;
        var data = {
          dictionaryType:type
        };
        this.base.axios_post(data,"/centerConfig/queryCouponsActivity",function (res) {
          if(res.code===0 && res.data){
            if(type==="couponsType"){
                _this.table_list1 = res.data;
            }else if(type==="obtainType"){
              _this.table_list2 = res.data;
            }
          }
        });
      },
      get_goods_list(page_no){
        var me = this;
        var data = {
          goods_state: 4,
          page_no:page_no,
          page_size: 10
        };
        this.base.axios_post(data,"/goods/queryGoodsInfoList",function (res) {
          if (res.code == 0) {
            if (res.data) {
              me.total_pages = res.data.pages;
              me.goods_list = res.data.list;
              me.no_data = false;
            } else {
              me.no_data = true;
            }
          } else{
            if (me.page_no == 1) {
              me.goods_list = [];
            }
            me.no_data = true;
          }
        });
      },
      youhui1(){
        if(this.code==1){
          if(this.input1!=''){
            if(!/^([0-9]|([1-9][0-9])|([1-9][0-9][0-9]))$/.test(this.input1)){
              this.isNone1 = false;
              this.$message.error("请填写正确的优惠金额！");
              return false;
            }else{
              this.isNone1 = true;
              return true;
            }
          }else{
            this.isNone1 = false;
            this.$message.error("优惠金额不能为空！");
            return false;
          }
        }else{
          return true
        }
      },
      youhui2(){
        if(this.code==2){
          if(this.input2!=''){
            if(!/^[0-9](.[0-9])?$/.test(this.input2)){
              this.isNone2 = false;
              this.$message.error("请填写正确的优惠折扣！");
              return false;
            }else{
              this.isNone2 = true;
              return true
            }
          }else{
            this.isNone2 = false;
            this.$message.error('优惠折扣不能为空!');
            return false;
          }
        }else{
          return true
        }
      },
      number3(){
        if(this.input3!=''){
          if(this.input3==-1){
            this.isNone3 = true;
            return true;
          }else if(this.input3.length<=8){
            if(!/^\+?[0-9][0-9]*$/.test(this.input3)){
              this.isNone3 = false;
              this.$message.error("请输入正确的张数!");
              return false;
            }else{
              this.isNone3 = true;
              return true
            }
          }else{
            this.isNone3 = false;
            this.$message.error("请输入正确的张数!");
            return false
          }
        }else{
          this.isNone3 = false;
          this.$message.error("优惠券张数不能为空!");
          return false;
        }
      },
      number4(){
        if(this.input4!=''){
            if(this.input4.length<=8){
              if(!/^\+?[0-9][0-9]*$/.test(this.input4)){
              this.isNone4 = false;
              this.$message.error("请输入正确的限制条件!");
              return false;
              }else{
                this.isNone4 = true;
                return true;
              }
            }else{
              this.isNone4 = false;
              this.$message.error("请输入正确的限制条件!");
              return false;
            }
        }else{
          this.isNone4 = false;
          this.$message.error("限制条件不能为空!");
          return false;
        }
      },
      number5(){
        if(this.input5!=''){
          if(this.input5==-1){
            this.isNone5 = true;
            return true;
          }
          if(!/^([1-9][0-9]*)$/.test(this.input5)){
            this.isNone5 = false;
            this.$message.error('请输入正确的有效天数!');
            return false;
          }else{
            this.isNone5 = true;
            return true;
          }
        }else{
          this.isNone5 = false;
          this.$message.error('优惠券有效天数不能为空!');
          return false;
        }
      },
      get_start_time(value){
        //this.startTime = value;
        this.startTime = new Date(value).getFullYear()+'-'+Number(new Date(value).getMonth()+1)+'-'+new Date(value).getDate();
      },
      get_end_time(value){
        if(this.startTime){
          if(value < this.startTime){
            this.endTime = '';
            this.$message.error("结束时间不能小于开始时间！");
            return false;
          }else{
            //this.endTime = value;
            this.endTime = new Date(value).getFullYear()+'-'+Number(new Date(value).getMonth()+1)+'-'+new Date(value).getDate();
            return true
          }
        }else{
          return false;
        }

      },
      get_gain_type(value){
        if(value=='领取'){
          this.code2 = 1;
        }else if(value=='赠送'){
          this.code2 = 2;
        }
        this.gain_type = value;
      },
      get_ticket_type(value){
        if(!value.indexOf('满')){
          this.code = 1;
        }else if(!value.indexOf('折')){
          this.code = 2;
        }
        this.ticket_type = value;
      },
      selectGoods(){
        this.show_commodity = true
      },
      radio_goods(value){
        if(value==-1){
          this.commodity = '全部商品';
          this.goodsId = 0;
          this.show_commodity = false;
        }else{
          this.commodity = value.goodsName;
          this.goodsId = value.goodsId;
          this.show_commodity = false;
        }
      },
      submit_ticket(){
        console.log(this.input3);
          if(!this.ticket_type){
            this.$message.error("优惠券类型不能为空！");
          }else if(!this.gain_type){
            this.$message.error("优惠券获取方式不能为空！");
          }else if(!this.startTime){
            this.$message.error("开始日期不能为空！");
          }else if(!this.endTime){
            this.$message.error("结束日期不能为空！");
          }else if(!this.commodity){
            this.$message.error("请选择限定商品！");
          }else if(this.youhui1()&&this.youhui2()&&this.number3()&&this.number4()&&this.number5()&&this.get_end_time){
            if(this.type==1){
              this.sub_data();
            }else if(this.type==2){
              this.subData();
            }

          }
      },
      sub_data(){
        var data1 = {
          discountMode:this.code,// 1满减  2折扣
          rangeId:this.goodsId,//优惠商品id
          rangeName:this.commodity,
          rangeCondition:this.base.mul(Number(this.input4),100),//优惠限制条件
          getWay:this.code2,//获取方式
          planNum:Number(this.input3),//优惠券数量
          startTime:this.startTime,
          endTime:this.endTime,
          termValidity:this.input5,//有效期
          discountFactor:this.input2//折扣系数
        };
        var data2 = {
          discountMode:this.code,// 1满减  2折扣
          discountAmount:this.base.mul(Number(this.input1),100),//满减优惠金额
          rangeId:this.goodsId,//优惠商品id
          rangeName:this.commodity,
          rangeCondition:this.base.mul(Number(this.input4),100),//优惠限制条件
          getWay:this.code2,//获取方式
          planNum:Number(this.input3),//优惠券数量
          startTime:this.startTime,
          endTime:this.endTime,
          termValidity:this.input5,//有效期
        };
        var data = {};
        if(this.code==1){
           data = data2;
        }else if(this.code==2){
           data = data1;
        }
        var me = this;
        this.base.axios_post(data,"/goods/saveCouponsActivity",function (res) {
          if(res.code==0){
            me.$emit("tacket_type",1);
          }
        });
      },
      subData(){
        var data = {};
        var data1 = {
         activityId:this.dataList.activityId,//优惠活动id
         discountMode:this.code,//优惠类型
         discountAmount:this.base.mul(Number(this.input1),100),//满减优惠金额
         rangeId:this.goodsId,
         rangeName:this.commodity,
         rangeCondition:this.base.mul(Number(this.input4),100),
         getWay:this.code2,
         planNum:this.input3,
         startTime:this.startTime,
         endTime:this.endTime,
         termValidity:this.input5,
        };
        var data2 = {
          activityId:this.dataList.activityId,//优惠活动id
          discountMode:this.code,//优惠类型
          rangeId:this.goodsId,
          rangeName:this.commodity,
          rangeCondition:this.base.mul(Number(this.input4),100),
          getWay:this.code2,
          planNum:this.input3,
          startTime:this.startTime,
          endTime:this.endTime,
          termValidity:this.input5,
          discountFactor:this.input2
        };
        if(this.code==1){
          data = data1;
        }else if(this.code==2){
          data = data2;
        }
        var me = this;
        this.base.axios_post(data,"/goods/updateCouponsActivity",function (res) {
          if(res.code==0){
            me.$emit("tacket_type",1);
          }
        });
      },
      turn_page(i){
        if(i>1){
          this.isNone4 = true;
        }else if(i=1){
          this.isNone4 = false;
        }
        this.get_goods_list(i);
      },
    },
  }
</script>
<style>
.ticket .add_info .ticket_box{
  overflow: hidden;
  width: 90%;
  margin: 20px auto;
  padding-bottom: 20px;
}
.ticket .add_info .ticket_box .ticket_item{
  width: 64%;
  margin: 10px auto;
}
.ticket .add_info .ticket_box .ticket_item>span{
  display: inline-block;
  width: 100px;
  text-align: left;
}
.ticket .add_info .ticket_box .ticket_item>.xianding{
  width: 61%;
  padding-left: 5px;
  vertical-align: middle;
}
.ticket .add_info .ticket_box .ticket_item>.r{
  width: 25px;
  text-align: center;
}
.ticket .add_info .ticket_box .ticket_item>div{
  width: 40%;
}
.ticket .add_info .ticket_box .ticket_item>.rule{
  width: 28%;
}
.ticket .add_info .ticket_box .ticket_item>i{
  display: inline-block;
  color: #ff6d6d;
  margin-left:15px;
}
.ticket .add_info .ticket_box .ticket_item .none{
  display: none;
}
.ticket .add_info .ticket_box .date>div{
  width: 30%;
}
.ticket .el-dialog__footer,.el-dialog__header{
  text-align: center!important;
}
.ticket .el-radio-group{
  width: 100%;
  margin: 20px auto;
}
.ticket .el-radio-group>label{
  margin: 10px 0 10px 15px!important;
  display: block;
}

.ticket .el-radio-group>label:first-child{
  display: block;
}
.ticket .dialog>div{
  width:800px;
  height: 559px;
}
.ticket .dialog .el-dialog__body{
  height: 458px!important;
  position: relative;
}
.ticket .dialog .none2{
  display: none!important;
}
.ticket .pagelist{
  text-align: center!important;
  position: absolute;
  bottom: 10px;
  left: 20%;
}

</style>
