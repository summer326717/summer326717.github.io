<template>

  <div :class="{act:goodsMsg==''}" class="main_content" >
    <div class="main_title">
      <p class="title_pic"><img src="../assets/images/people.png"></p>
      <p class="explain">平台目前完成销售额<span> {{goodsMsg.saleTotalMny/100}} </span>元，在售商品有<span> {{goodsMsg.kinds}} </span>种</p>
    </div>


    <div class="box" style="background: #fff">
      <div id="content_bottom_left" class="content_bottom_left content_bottom" v-if="l_length!=0"></div>
      <div id="content_bottom_right" class="content_bottom_right content_bottom" v-if="l_length!=0"></div>
    </div>



    <div class="pic" v-if="l_length==0">
      <img src="../assets/images/tuceng7.png">
      <p>啊哦~暂时还没有销售数据呢@^@</p>
    </div>

  </div>

</template>
<script>
  import axios from "axios";
  import base from "../assets/base";
  export default {
    data() {
      return {
        goodsMsg:{},
        goodsName:[],//销售种类
        goodsSaleMny:[],//销售总量,
        goods:[],//商品种类与销量
        l_length:-1,
        MonSale:[],//各月份销售额
        Mouth:[],//各月份
      }
    },
    components: {
    },
    created() {
      this.get_goods_info();
    },
    methods: {
      get_goods_info(){
        var data = {};
        var _this = this;
        this.base.axios_post(data, "/orderCenter/supplierHomePageQry", function(res){
          if(res.code==0){

            if(res.data.MonSaleMny.length===0){
              _this.l_length = 0;
            }else if(res.data.MonSaleMny.length>0){
              _this.l_length = 1;
            }
            _this.goodsMsg = res.data;
            console.log(_this.goodsMsg);
            var array = [];
            for(var i in _this.goodsMsg.goodsSaleMnyOfYear){
              _this.goodsName.push(_this.goodsMsg.goodsSaleMnyOfYear[i].goodsName);
              _this.goodsSaleMny.push(_this.goodsMsg.goodsSaleMnyOfYear[i].goodsSaleMny/100);
              array.length = i;
              var obj = {};
              obj.value = _this.goodsMsg.goodsSaleMnyOfYear[i].goodsSaleMny/100;
              obj.name = _this.goodsMsg.goodsSaleMnyOfYear[i].goodsName;
              array.push(obj);
            }
            _this.goods = array;


            for(var j in res.data.MonSaleMny){
              _this.MonSale.push(_this.turn_money(res.data.MonSaleMny[j].saleMny));
              _this.Mouth.push(res.data.MonSaleMny[j].mon+"月");

            }

            console.log(_this.MonSale);



            _this.chert_left();
          }else{
            _this.base.alerter(res.message);
          }

        })
      },
      turn_money(value){
        var f = Math.round(value*100)/10000;
        var s = f.toString();
        var rs = s.indexOf('.');
        if (rs < 0) {
          rs = s.length;
          s += '.';
        }
        while (s.length <= rs + 2) {
          s += '0';
        }
        return s;
      },
      chert_left:function () {
        var echarts = require('echarts');
        // 基于准备好的dom，初始化echarts实例
        var myChart = this.$echarts.init(document.getElementById('content_bottom_left'));
        var myPieChart = this.$echarts.init(document.getElementById('content_bottom_right'));
        // 绘制图表
        var _this = this;
        myChart.setOption({
          title : {
            text: '商品每月销售额（元/月）',
            subtext: ''
          },
          tooltip : {
            trigger: 'axis'
          },
          legend: {

          },
          toolbox: {
            show : true,
            feature : {
              mark : {show: true},
              dataView : {show: true, readOnly: false},
              magicType : {show: true, type: ['line', 'bar']},
              restore : {show: false},
              saveAsImage : {show: false}
            }
          },
          calculable : true,
          xAxis : [
            {
              type : 'category',
              data : this.Mouth
            }
          ],
          yAxis : [
            {
              type : 'value'
            }
          ],
          series : [
            {
              name:'销售额',
              type:'bar',
              data:this.MonSale,
              markPoint : {
                data : [
                  {type : 'max', name: '最大值'},
                  {type : 'min', name: '最小值'}
                ]
              },
              markLine : {
                data : [
                  {type : 'average', name: '平均值'}
                ]
              }
            },
          ]
        });
        myPieChart.setOption({
          title: { text: '商品数据对比图' ,
            left:'center',
            textStyle:{
              color:'#000',
              fontWeight:'bold',
              fontSize:18
            }
          },
          tooltip : {
            trigger: 'item',
            formatter: "{a} <br/>{b} : {c} ({d}%)"
          },
          color:['#FFB879','#008f20','yellow','green','#C2605C'],
          legend: {
            orient : 'vertical',
            x : '73%',
            y:'80%',
            data:_this.goodsName
          },
          toolbox: {
            show : true,
            feature : {
              mark : {show: true},
              //dataView : {show: true, readOnly: false},
              magicType : {
                show: true,
                type: ['pie', 'funnel'],
                option: {
                  funnel: {
                    x: '25%',
                    width: '50%',
                    funnelAlign: 'center',
                    max: 1548
                  }
                }
              },
              //restore : {show: true},
              //saveAsImage : {show: true}
            }
          },
          calculable : true,
          series : [
            {
              name:'商品比例',
              type:'pie',
              radius : ['25%', '60%'],
              itemStyle : {
                normal : {
                  label : {
                    show : false
                  },
                  labelLine : {
                    show : false
                  }
                },
                emphasis : {
                  label : {
                    show : true,
                    position : 'center',
                    textStyle : {
                      fontSize : '22',
                      fontWeight : 'bold'
                    }
                  }
                }
              },
              data:_this.goods
            }
          ]
        });
      }
    },
  }
</script>

<style lang='less'>
  .pic{
    position: absolute;
    top: 20%;
    left: 32%;
    img{
      width: 400px;
    }
    p{
      text-align: center;
      font-size: 20px;
      color: #000;
    }
  }
  .center{
    text-align: center;
  }
  .act{
    background-color: #f2f2f2!important;
  }
.main_content{
  position: relative;
  width: 96%;
  height: 92%;
  padding-left: 20px;
  border-radius: 16px;
  margin-left: 0.6%;
  margin-top:1.3%;
  background: #f4f5f9;
  .main_title{
    background: #ffffff;

    padding: 20px 20px 10px 20px;
    border-radius: 16px;
    width: 100%;
    margin-bottom:15px;
    box-sizing: border-box;
    p{
      display: inline-block;
      span{
        color: #1d90e6;
        font-size: 24px;
      }
    }
    .title_pic{
      width: 69px;
      height: 68px;
      vertical-align: middle;
    }
    .explain{
      width: 70%;
      height: 30px;
      line-height: 30px;
      font-size: 20px;
      color: #000000;
    }
  }
  .box{
    width: 100%;
    height: 90%;
    //padding: 20px 20px;
    border-radius: 16px;
  }
  .content_top{
    height: 100px;
    min-width: 160px;
    max-width: 450px;
    //line-height: 100px;
    background-color: #dedede;
    display: inline-block;
    margin:  10px;
    padding: 0;
    vertical-align: middle;
    img{
      width: 80px;
      vertical-align: middle;
    }
    .p_text{
      display: inline-block;
      max-width: 320px;
      padding: 0 10px;
      line-height: 30px;
    }
  }
}
  .el-col{
    height: 100%;
  }
  .m_list{
    padding: 0 10px;
    li{
      height: 25px;
      line-height: 25px;
    }
  }
  .content_bottom{
    width: 41%;
    height: 60%;
    margin: 60px 10px 10px 10px;
    display: inline-block;
  }
  #content_bottom_right,#content_bottom_left{
    padding: 40px 20px;
    box-shadow: 1px 1px 2px 1px #cbcbcb;
    transform: scale(.9);
    transition: transform .5s;
  }
  #content_bottom_right{
    &:hover{
      transform: scale(1);
    }
  }
  #content_bottom_left{
    margin-left: 5%;
    &:hover{
      transform: scale(1.1);
    }
  }


</style>
