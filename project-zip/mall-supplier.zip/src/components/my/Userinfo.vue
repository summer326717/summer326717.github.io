<template>
  <div class="content userInfo">
    <!--初始页面-->
    <div v-if="register_type==0">
      <div class="person_top">
        <span class="name">
          <img v-if="!person_msg.sup_icon" src="../../assets/images/head_icon.png" />
          <img v-if="person_msg.sup_icon" v-bind:src="person_msg.sup_icon" >
        </span>
        <span class="name">商家名称：{{person_msg.sup_name}}</span>
        <span class="info" style="margin-right: 5%">信息完成度：
        <el-progress class="jdt" :show-text="false" :text-inside="true" :stroke-width="16" :percentage="70"></el-progress>完善70%</span>
      </div>
      <div class="person_bottom">
        <table>
          <tr>
            <td class="tit_pci" v-if="cookie_state!=2"><img src="../../assets/images/user_err.png"></td>
            <td class="tit_pci" v-if="cookie_state==2"><img src="../../assets/images/user_ok.png"></td>
            <td class="tit">商家认证</td>
            <td class="info">完成商家相关资格认证</td>
            <td v-on:click="update(1)" class="btn">修改</td>
            <td class="btn" v-if="cookie_state!=2" v-on:click="_showIdea">审核意见</td>
          </tr>
          <tr>
            <td class="tit_pci" v-if="fuwufei"><img src="../../assets/images/user_ok.png"></td>
            <td class="tit_pci" v-if="!fuwufei"><img src="../../assets/images/err.png"></td>
            <td class="tit">平台服务费(比率)</td>
            <td class="info">{{fuwufei}}</td>
            <td @click="check_fuwufei" class="btn">查看</td>
            <td></td>
          </tr>
          <tr>
            <td class="tit_pci" v-if="person_msg.aliAccountState==1"><img src="../../assets/images/user_ok.png"></td>
            <td class="tit_pci" v-if="person_msg.aliAccountState==0"><img src="../../assets/images/err.png"></td>
            <td class="tit">绑定支付宝</td>
            <td class="info">您绑定的支付宝：{{person_msg.ali_acount}}</td>
            <td @click="openAlipay" class="btn">修改</td>
            <td></td>
          </tr>
          <tr>
            <td class="tit_pci"><img src="../../assets/images/user_ok.png"></td>
            <td class="tit">登录密码</td>
            <td class="info">建议您定期更改密码以保护账户安全</td>
            <td @click="UpdatePassword" class="btn">修改</td>
            <td></td>
          </tr>
          <tr>
            <td class="tit_pci" v-if="phoneNumber"><img src="../../assets/images/user_ok.png"></td>
            <td class="tit_pci" v-if="!phoneNumber"><img src="../../assets/images/err.png"></td>
            <td class="tit">绑定手机</td>
            <td class="info">您绑定的手机：{{phoneNumber}}</td>
            <td @click="bindPhone" class="btn">修改</td>
            <td></td>
          </tr>
          <tr>
            <td class="tit_pci" v-if="person_msg.address"><img src="../../assets/images/user_ok.png"></td>
            <td class="tit_pci" v-if="!person_msg.address"><img src="../../assets/images/err.png"></td>
            <td class="tit">发货地址</td>
            <td class="info">您的发货地址：{{person_msg.province}}{{person_msg.city}}{{person_msg.region}}{{person_msg.address}}</td>
            <td @click="Address" class="btn">修改</td>
            <td></td>
          </tr>
        </table>
      </div>
    </div>
    <!--商家认证页面-->
    <div v-if="register_type==1"><!---->
        <div class="person_bottom" v-loading="loading" style="width: 100%">
          <p class="return bor">
        <span @click="back">
          <i class="el-icon-caret-left"></i>返回上一页</span>
          </p>
          <div class="certification">
            <div class="certification_lift">
              <div class="select_box">
                <img v-if="!person_msg.sup_icon" src="../../assets/images/head_icon.png" />
                <img v-if="person_msg.sup_icon" v-bind:src="person_msg.sup_icon">
                <form enctype="multipart/form-data"  id="uploadForm_default_tea" style="display:none">
                  <input type="file" @change="upload_img" class="input_update" id="tea_cate_img" name="file" accept="image/png,image/gif,image/jpeg"/>
                  <input type="hidden" name="goods" value="123456" />
                </form>
                <button class="select_icon" @click="trans_methods(0)">编辑</button>
              </div>
            </div>
            <div class="certification_right">
              <el-col :span="19" class="right_con" >
                <p>
                  <span class="base_span">商家名称</span>
                  <span class="l_ipt">
                  <el-input v-model="sup_name"></el-input>
                </span>
                </p>
                <p>
                  <span class="base_span">紧急联系人</span>
                  <span class="l_ipt">
                  <el-input v-model="urgent_contacts"></el-input>
                </span>
                </p>
                <p>
                  <span class="base_span">紧急联系人电话</span>
                  <span class="l_ipt">
                  <el-input v-model="urgent_phone"></el-input>
                </span>
                </p>
                <p>
                  <span class="base_span">是否三证合一</span>
                  <span>
                <el-radio class="radio" v-model="credentials_merge" label='1'>是</el-radio>
                <el-radio class="radio" v-model="credentials_merge" label='0'>否</el-radio>
              </span>
                </p>
                <p v-if="credentials_merge==1">
                  <span class="base_span" >社会统一信用代码</span>
                  <span class="l_ipt">
                  <el-input v-model="credit_code"></el-input>
                </span><el-button type="primary" @click="trans_methods(1)" style="margin-left:10px">选择文件</el-button>
                </p>
                <p v-if="credentials_merge==1" class="p_pick">
                  <span class="base_span"></span >
                  <span class="dis">
                  <img v-if="!credit_codeimg_detail.url_address" src="../../assets/images/image.png" />
                  <img v-if="credit_codeimg_detail.url_address" :src="credit_codeimg_detail.url_address" />
                </span>
                </p>
                <p v-if="credentials_merge==0">
                  <span class="base_span">营业执照号</span>
                  <span class="l_ipt">
                  <el-input v-model="business_licence"></el-input>
                </span><el-button type="primary" @click="trans_methods(2)" style="margin-left:10px">选择文件</el-button>
                </p>
                <p v-if="credentials_merge==0" class="p_pick">
                  <span class="base_span"></span>
                  <span class="dis">
                  <img v-if="!business_licence_img_detail.url_address" src="../../assets/images/image.png" />
                  <img v-if="business_licence_img_detail.url_address" :src="business_licence_img_detail.url_address" />
                    <!--<el-button type="primary" @click="trans_methods(2)">选择文件</el-button>-->
                </span>
                </p>
                <p v-if="credentials_merge==0">
                  <span class="base_span">组织机构代码</span>
                  <span class="l_ipt">
                  <el-input v-model="organization_code"></el-input>
                </span><el-button type="primary" @click="trans_methods(3)" style="margin-left:10px">选择文件</el-button>
                </p>
                <p v-if="credentials_merge==0" class="p_pick">
                  <span class="base_span"></span >
                  <span class="dis">
                  <img v-if="!organization_code_img_detail.url_address" src="../../assets/images/image.png" />
                  <img v-if="organization_code_img_detail.url_address" :src="organization_code_img_detail.url_address" />
                    <!--<el-button type="primary" @click="trans_methods(3)">选择文件</el-button>-->
                </span>
                </p>
                <p v-if="credentials_merge==0">
                  <span class="base_span">纳税人识别号</span>
                  <span class="l_ipt">
                  <el-input v-model="taxpayer_code"></el-input>
                </span><el-button type="primary" @click="trans_methods(4)" style="margin-left:10px">选择文件</el-button>
                </p>
                <p v-if="credentials_merge==0" class="p_pick">
                  <span class="base_span"></span >
                  <span class="dis">
                  <img v-if="!taxpayer_code_img_detail.url_address" src="../../assets/images/image.png" />
                  <img v-if="taxpayer_code_img_detail.url_address" :src="taxpayer_code_img_detail.url_address" />
                    <!--<el-button type="primary" @click="trans_methods(4)">选择文件</el-button>-->
                </span>
                </p>
                <p style="margin-left: 35%;margin-top: 6%">
                <span>
                  <el-button type="primary" v-on:click="sure">提交审核</el-button>
                </span>
                </p>
              </el-col>
            </div>
          </div>
        </div>

    </div>
    <!--绑定支付宝页面-->
    <el-dialog class="zfb" title="绑定支付宝" :visible.sync="centerDialogVisible" center>
      <el-form>
        <el-form-item label="手机号码" :label-width="formLabelWidth" style="margin-left: 17%">
          <span style="margin-left: 0.5%">{{phoneNumber}}</span>
          <el-button type="primary" @click="getCode" :disabled='codeShow' style="margin-left: 2.5%">{{get_code}}</el-button>
        </el-form-item>
        <el-form-item label="验证码" :label-width="formLabelWidth" style="margin-left: 17%">
          <el-input class="phoneCode" v-model="AlipayPhoneCode" auto-complete="off" style="width: 53%"></el-input>

        </el-form-item>
        <el-form-item label="支付宝" :label-width="formLabelWidth" style="margin-left: 17%">
          <el-input class="Alipay_information" v-model="alipayNum" auto-complete="off" style="width: 54%"></el-input>
        </el-form-item>
      </el-form>
      <div class="foot">
        <span slot="footer" class="dialog-footer">
          <el-button @click="centerDialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="alipaySave">保 存</el-button>
        </span>
      </div>
    </el-dialog>
    <!--登陆密码修改-->
    <el-dialog class="pws" title="修改登录密码" :visible.sync="showPassword" center>
      <el-form>
        <el-form-item label="手机号码" :label-width="formLabelWidth" style="margin-left: 17%">
          <span>{{phoneNumber}}</span>
          <el-button type="primary" @click="getCode_pws" :disabled='codeShow_pws' style="margin-left: 1.5%">{{get_code_pws}}</el-button>
        </el-form-item>
        <el-form-item label="验证码" :label-width="formLabelWidth" style="margin-left: 17%">
          <el-input class="phoneCode" v-model="pasPhoneCode" auto-complete="off" style="width: 52%"></el-input>
        </el-form-item>
        <el-form-item label="设置密码" :label-width="formLabelWidth" style="margin-left: 17%">
          <el-input class="set_pws_information" type="password" v-model="setPassword" auto-complete="off" style="width: 52%"></el-input>
        </el-form-item>
        <el-form-item label="确认密码" :label-width="formLabelWidth" style="margin-left: 17%">
          <el-input class="pws_information" type="password" v-model="password" auto-complete="off" style="width: 52%"></el-input>
        </el-form-item>
      </el-form>
      <div class="foot">
        <div slot="footer" class="dialog-footer">
          <el-button @click="showPassword = false">取 消</el-button>
          <el-button type="primary" @click="passwordSave">保 存</el-button>
        </div>
      </div>
    </el-dialog>
    <!--绑定手机修改-->
    <el-dialog class="pho" title="修改绑定手机号码" :visible.sync="showBindphone" center>
      <el-form>
        <el-form-item label="手机号码" :label-width="formLabelWidth"  style="margin-left:17%">
          <span>{{phoneNumber}}</span>
          <el-button type="primary" :disabled='codeShow_binding' @click="get_binding_phoneCode" style="margin-left: 1.5%">{{getBinding_btn}}</el-button>
        </el-form-item>
        <el-form-item label="验证码" :label-width="formLabelWidth"  style="margin-left: 17%">
          <el-input class="phoneCode" v-model="binding_phoneCode" auto-complete="off" style="width: 53%"></el-input>
        </el-form-item>
        <el-form-item label="新手机号码" :label-width="formLabelWidth" style="margin-left: 17%">
          <el-input class="phone_information" v-model="newPhone" placeholder="请输入新的手机号码" auto-complete="off" style="width: 53%"></el-input>
        </el-form-item>
      </el-form>
      <div class="foot">
        <div slot="footer" class="dialog-footer">
          <el-button @click="showBindphone = false">取 消</el-button>
          <el-button type="primary" @click="updatePhoneSave">保 存</el-button>
        </div>
      </div>
    </el-dialog>
    <!--发货地址修改-->
    <el-dialog class="address" title="修改发货地址" :visible.sync="showAddress" center>
    <div class="select_city">
      <span>新地址</span>
    <el-select v-model="province"  @change="change_province" clearable placeholder="省">
       <el-option v-for="(value,key) in province_options" :value="value.area_name" :key="key"></el-option>
    </el-select> -
    <el-select v-model="shouhuo_city" :disabled="showCity" @change="change_city" clearable placeholder="市">
       <el-option v-for="(value,key) in city_options" :value="value.area_name" :key="key"></el-option>
    </el-select> -
    <el-select v-model="county" :disabled="showCounty" @change="change_county" clearable placeholder="区">
       <el-option v-for="(value,key) in county_options" :value="value.area_name" :key="key"></el-option>
    </el-select>
    </div>
    <el-form style="margin-left: 25%" >
      <el-form-item label="    " :label-width="formLabelWidth">
        <el-input class="information" placeholder="请输入详细地址" v-model="detailedAddress" auto-complete="off"></el-input>
      </el-form-item>
    </el-form>
      <div class="foot">
        <div slot="footer" class="dialog-footer">
          <el-button @click="showAddress = false">取 消</el-button>
          <el-button type="primary" @click="shipAddressSave">保 存</el-button>
        </div>
      </div>
  </el-dialog>
    <!--查看服务费-->
    <el-dialog title="" :visible.sync="show_fuwufei">
      <div class="fuwufei">
        <p style="width: 58%;margin: 17px auto;text-align: left;color: #ff6150">
          *按照每笔订单实际成交金额，平台收取一定的服务费<br/>
          *服务费比例值在0-1之间(最多允许保留3位小数)<br/>
          *服务费 = 成交金额 * 服务费比例(四舍五入)
        </p>
      </div>
      <div class="foot">
        <div slot="footer" class="dialog-footer">
          <el-button @click="show_fuwufei = false">关 闭</el-button>
        </div>
      </div>
    </el-dialog>
    <!--审核意见-->
    <div class="idea">
      <el-dialog
        title="审核意见"
        :visible.sync="show_idea">
          <span style="font-size: 20px;font-weight: 400;margin-left: 30%">{{l_start}}</span>
          <span slot="footer" class="dialog-footer">
      <el-button type="primary" @click="show_idea = false">确 定</el-button></span>
      </el-dialog>
    </div>
  </div>
</template>

<script>
  var Cookies = require("Cookies-js");
import axios from "axios";
import base from "../../assets/base";
export default {
  data() {
    return {
      loading:false,
      l_start:'',
      show_idea:false,//审核意见
      cookie_state:-1,
      aliState:-1,
      province_options:[],
      province:"河南省",//省份
      shouhuo_city:"",//城市
      city_options:[],
      county:"",//区县
      county_options:[],
      showCity:true,
      showCounty:true,
      province_id:"",
      shouhuo_city_id:"",
      county_id:"",
      fuwufei:'',
      show_fuwufei:false,


      centerDialogVisible:false,
      showPassword:false,
      showBindphone:false,
      showAddress:false,
      formLabelWidth: '120px',
      AlipayPhoneCode:"",  //绑定支付宝页面的手机验证码
      codeShow:false,//获取验证码按钮是否可用
      get_code:"获取验证码",
      timeCode:"",//获取验证码倒计时
      alipayNum:"", //新支付宝账号,

      get_code_pws:"获取验证码",//修改登录密码页面的获取验证码按钮
      pasPhoneCode:"",//修改登录密码页面的手机验证码
      codeShow_pws:false,
      setPassword:"",
      password:"",

      binding_phoneCode:"", //修改绑定手机号页面的手机验证码
      codeShow_binding:false,
      newPhone:"",  //新手机号码
      getBinding_btn:"获取验证码",

      detailedAddress:"", //详细地址
      phoneNumber:"",//电话



      person_msg: {}, //个人信息
      register_type: 0, //修改状态 0本页面，1商家认证，2绑定支付宝，3支付宝密码，4登陆密码，5绑定手机，6发货地址
      options: [
        {
          value: 1,
          type: "是"
        },
        {
          value: 2,
          type: "否"
        }
      ],
      common_img_detail: {}, //供应商上传图片信息
      credit_codeimg_detail: {}, //统一社会信用代码的图片信息
      business_licence_img_detail: {}, //营业执照号的图片信息
      organization_code_img_detail: {}, //组织机构代码的图片信息
      taxpayer_code_img_detail: {}, //纳税人识别号的图片信息
      sup_name: "", //商家名称
      urgent_contacts: "", //紧急联系人
      urgent_phone: "", //紧急联系人电话
      credentials_merge: "2", //是否三证合一
      credit_code: "", //统一社会信用代码
      business_licence: "", //营业执照号
      organization_code: "", //组织机构代码
      taxpayer_code: "", //纳税人识别号
      img_type: 0 ,//
    };
  },
  created() {
    this.get_fuwufei();
    this.get_user_msg();
    this.get_up_msg();
    this.get_address_id();
    this.cookie_state = Cookies.get("state");
    if(Cookies.get("state")==1){
      this.l_start = '正在审核中......'
    }else if(Cookies.get("state")==0){
      this.l_start = '认证已拒接!'
    }else if(Cookies.get("state")==3){
      this.l_start = '未认证!'
    }
  },
  methods: {
    //审核意见
    _showIdea(){
      this.show_idea = true;
    },
    //返回
    back: function() {
      this.register_type = 0;
    },
    //获取商家信息
    get_user_msg: function() {
      var Cookies = require("Cookies-js");
      var data = {};
      var _this = this;
      this.base.axios_post(
        data,
        "/supplier/userCenter/supplierDetailMessage",
        function(res) {
          if (res.code == 0) {
            _this.person_msg = res.data;
            _this.sup_name = res.data.sup_name; //商家名称
            _this.phoneNumber = _this.person_msg.phone;
            var data = _this.phoneNumber.split("");
            data.splice(3,4,"****");
            _this.phoneNumber = data.join("");

            Cookies.set("ali_atate",_this.person_msg.aliAccountState);
          } else {
            _this.base.alerter(res.message);
          }
        }
      );
    },
    get_address_id(){
      //   /orderCenter/findAreaTree
      var _this = this;
      this.base.axios_post("", "/orderCenter/findAreaTree", function(res) {
        _this.province_options = res.data;
        for(var i in _this.province_options){
          _this.city_options = _this.province_options[i].area_list;
        }
      })
    },
    change_province(){
      for(var i in this.province_options){
        if(this.province_options[i].area_name==this.province){
          this.city_options = this.province_options[i].area_list;
          this.province_id = this.province_options[i].area_id;
        }
      }
      this.showCity=false;
    },
    change_city(){
      for(var i in this.city_options){
        if(this.city_options[i].area_name==this.shouhuo_city){
          this.county_options = this.city_options[i].area_list;
          this.shouhuo_city_id = this.city_options[i].area_id;
        }
      }
      this.showCounty=false;
    },
    change_county(){
      for(var i in this.county_options){
        if(this.county_options[i].area_name==this.county){
          this.county_id = this.county_options[i].area_id;
        }
      }
    },
    //获取已提交的审核信息
    get_up_msg: function() {
      var data = {};
      var _this = this;
      this.base.axios_post(
        data,
        "/supplier/userCenter/supplierAuditMessagePage",
        function(res) {
          if (res.code == 0) {
            if (res.data) {
              _this.urgent_contacts = res.data.urgent_contacts; //紧急联系人
              _this.urgent_phone = res.data.urgent_phone; //紧急联系人电话
              if (res.data.credentials_merge_img_url) {
                _this.credit_codeimg_detail =
                  res.data.credentials_merge_img_url; //统一社会信用代码的图片信息
              }
              if (res.data.business_licence_img_url) {
                _this.business_licence_img_detail =
                  res.data.business_licence_img_url; //营业执照号的图片信息
              }
              if (res.data.organization_code_img_url) {
                _this.organization_code_img_detail =
                  res.data.organization_code_img_url; //组织机构代码的图片信息
              }
              if (res.data.taxpayer_code_img_url) {
                _this.taxpayer_code_img_detail = res.data.taxpayer_code_img_url; //纳税人识别号的图片信息
              }
              if (res.data.sup_icon_url) {
                _this.common_img_detail = res.data.sup_icon_url;
              }
              _this.credentials_merge = res.data.credentials_merge.toString(); //是否三证合一
              _this.credit_code = res.data.credit_code; //统一社会信用代码
              _this.business_licence = res.data.business_licence; //营业执照号
              _this.organization_code = res.data.organization_code; //组织机构代码
              _this.taxpayer_code = res.data.taxpayer_code; //纳税人识别号
            }
          } else {
            _this.base.alerter(res.message);
          }
        }
      );
    },
    //修改信息（根据index的值）1修改商家认证 2修改帮定支付宝 3支付密码 4登陆密码 5绑定手机 6发货地址
    update: function(index) {
      this.register_type = index;
    },
    //点击添加图片
    select_img: function(data) {
      //该方法可跨域访问

    },
    //点击保存----商家认证页面
    sure: function() {
      var data = {
        sup_name: this.sup_name, //商家名称
        urgent_contacts: this.urgent_contacts, //紧急联系人
        urgent_phone: this.urgent_phone, //紧急联系人电话
        credentials_merge: this.credentials_merge, //是否三证合一 1是2不是
        credit_code: this.credit_code, //统一社会信用代码
        business_licence: this.business_licence, //营业执照号
        organization_code: this.organization_code, //组织机构代码
        taxpayer_code: this.taxpayer_code, //纳税人识别号
        //头像
        sup_icon: this.common_img_detail,
        //社会统一信用代码
        credentials_merge_img: this.credit_codeimg_detail,
        //营业执照图片
        business_licence_img: this.business_licence_img_detail,
        //组织机构代码图片
        organization_code_img: this.organization_code_img_detail,
        //纳税人识别图片
        taxpayer_code_img: this.taxpayer_code_img_detail
      };
      if (!this.sup_name) {
        base.alerter("商家名称不能为空！");
        return;
      }
      if (!this.urgent_contacts) {
        base.alerter("紧急联系人不能为空！");
        return;
      }
      if (!this.urgent_phone) {
        base.alerter("紧急联系人电话不能为空！");
        return;
      }
      if (JSON.stringify(data.sup_icon).length == 2) {
        base.alerter("请先上传头像！");
        return;
      }
      console.log(data);
      //判断是否三证合一 清除不该上传的信息
      if (data.credentials_merge == 1) {
        if (!data.credit_code) {
          base.alerter("社会统一信用代码不能为空！");
          return;
        }
        if (JSON.stringify(data.credentials_merge_img).length == 2) {
          base.alerter("社会统一信用代码图片不能为空！");
          return;
        }
        data.business_licence_img = {};
        data.organization_code_img = {};
        data.taxpayer_code_img = {};
        data.business_licence = "";
        data.organization_code = "";
        data.taxpayer_code = "";
      } else if (data.credentials_merge == 0) {
        if (!data.business_licence) {
          base.alerter("营业执照号不能为空！");
          return;
        }
        console.log(data.business_licence_img);
        if (JSON.stringify(data.business_licence_img).length == 2) {
          base.alerter("营业执照图片不能为空！");
          return;
        }
        if (!data.organization_code) {
          base.alerter("组织机构代码不能为空！");
          return;
        }
        if (JSON.stringify(data.organization_code_img).length == 2) {
          base.alerter("社组织机构代码图片不能为空！");
          return;
        }
        if (!data.taxpayer_code) {
          base.alerter("纳税人识别号不能为空！");
          return;
        }
        if (JSON.stringify(data.taxpayer_code_img).length == 2) {
          base.alerter("纳税人证件图片不能为空！");
          return;
        }
        data.credit_code = "";
        data.credentials_merge_img = {};
      }
      var _this = this;
      this.base.axios_post(
        data,
        "/supplier/userCenter/supplierUploadAuditMessage",
        function(res) {
          if (res.code == 0) {
            history.go(0);
            //Cookies.set("sup_icon",_this.person_msg.sup_icon);
            //_this.register_type = 0;
          } else {
            _this.base.alerter(res.message);
          }
        }
      );
    },
    upload_img: function() {
      this.loading = true;
      let _this = this;
      var option = {
        url: "/oss/uploadGoodsFile",
        type: "post",
        dataType: "json",
        timeout:50000,
        success: function(data) {
          let $ipt_file = document.getElementById("tea_cate_img").files[0];
          _this.loading = false;
          console.log(_this.img_type);
          if (_this.credentials_merge == 1) {
            if (_this.img_type == 0) {
              //头像上传
              _this.common_img_detail = {
                file_name: $ipt_file.name,
                file_size: $ipt_file.size,
                file_type: 1,
                suffix_name: $ipt_file.name.split(".")[1],
                thumbnail_address: data.data,
                url_address: data.data
              };
              console.log("头像上传");
              _this.person_msg.sup_icon = data.data;
            } else {
              //三证合一
              _this.credit_codeimg_detail = {
                file_name: $ipt_file.name,
                file_size: $ipt_file.size,
                file_type: 5,
                suffix_name: $ipt_file.name.split(".")[1],
                thumbnail_address: data.data,
                url_address: data.data
              };
              console.log("三证合一");
            }
          } else {
            if (_this.img_type == 0) {
              //头像上传
              _this.common_img_detail = {
                file_name: $ipt_file.name,
                file_size: $ipt_file.size,
                file_type: 1,
                suffix_name: $ipt_file.name.split(".")[1],
                thumbnail_address: data.data,
                url_address: data.data
              };
              console.log("头像上传");
              _this.person_msg.sup_icon = data.data;
              Cookies.set("sup_icon",  data.data);
            }
            if (_this.img_type == 2) {
              //营业执照
              _this.business_licence_img_detail = {
                file_name: $ipt_file.name,
                file_size: $ipt_file.size,
                file_type: 2,
                suffix_name: $ipt_file.name.split(".")[1],
                thumbnail_address: data.data,
                url_address: data.data
              };
              console.log("营业执照");
            }
            if (_this.img_type == 3) {
              //组织机构代码
              _this.organization_code_img_detail = {
                file_name: $ipt_file.name,
                file_size: $ipt_file.size,
                file_type: 3,
                suffix_name: $ipt_file.name.split(".")[1],
                thumbnail_address: data.data,
                url_address: data.data
              };
              console.log("组织机构代码");
            }
            if (_this.img_type == 4) {
              //纳税人识别码
              _this.taxpayer_code_img_detail = {
                file_name: $ipt_file.name,
                file_size: $ipt_file.size,
                file_type: 4,
                suffix_name: $ipt_file.name.split(".")[1],
                thumbnail_address: data.data,
                url_address: data.data
              };
              console.log("纳税人识别码");
            }
          }
          document.getElementById("tea_cate_img").value = "";
        }
      };
      jQuery("#uploadForm_default_tea").ajaxSubmit(option);
      return false;
    },
    trans_methods: function(i) {
      this.img_type = i;
      var file = document.getElementById("tea_cate_img");
      file.click();

    },

    //获取手机验证码
    getCode:function () {
      var _this = this;
      //获取手机验证码
      var data = {
        phone:this.person_msg.phone
      };
      this.base.axios_post(
        data,
        "/supplier/userCenter/sendSupplierBindAliPayMsg",
        function(res) {
          if(res.code == 0){
            _this.timeCode = 60;
            var code_t = setInterval(function () {
              _this.codeShow = true;
              _this.get_code = _this.timeCode+"重新获取";
              _this.timeCode--;
            },1000);
            setTimeout(function () {
              clearTimeout(code_t);
              _this.timeCode = "";
              _this.get_code = "重新获取";
              _this.codeShow = false;
            },60000);
          }else{
            _this.base.alerter(res.message);
          }
        }
      );
    },
    //打开绑定支付宝弹框
    openAlipay:function () {
      this.centerDialogVisible = true;
      //清空输入框内容
      this.alipayNum = "";  //支付宝
    },
    //点击保存----修改支付宝页面
    alipaySave:function () {
      if (!this.AlipayPhoneCode) {
        this.$message.error('请输入手机验证码');
        this.centerDialogVisible = true;
        return;
      }
      if (!this.alipayNum) {
        this.$message.error('请输入支付宝账号');
        this.centerDialogVisible = true;
        return;
      }
      var data = {
        aliPay:this.alipayNum,
        code:this.AlipayPhoneCode
      };
      var _this = this;
      this.base.axios_post(data, "/supplier/userCenter/bindAliPay", function(res) {
        if(res.code==0){
          var Cookies = require("Cookies-js");
          _this.person_msg.ali_acount = _this.alipayNum;
          _this.person_msg.aliAccountState=1;
          _this.$message.success('保存成功');
          _this.centerDialogVisible = false;
        }else{
          _this.base.alerter(res.message);
        }
      })
    },

    //打开设置密码弹框
    UpdatePassword:function () {
      this.showPassword = true;
      this.pasPhoneCode="";
      this.setPassword="";
      this.password="";
    },
    //获取修改登陆密码的短信验证码
    getCode_pws(){
      var data = {
        phone:this.person_msg.phone
      };
      var _this = this;
      this.base.axios_post(data, "/supplier/userCenter/sendUpdateSupplierLoginMsg", function(res) {
        if(res.code == 0){
          _this.timeCode = 60;
          var code_t = setInterval(function () {
            _this.codeShow_pws = true;
            _this.get_code_pws = _this.timeCode+"重新获取";
            _this.timeCode--;
          },1000);
          setTimeout(function () {
            clearTimeout(code_t);
            _this.timeCode = "";
            _this.get_code_pws = "重新获取";
            _this.codeShow_pws = false;
          },60000);
        }else{
          _this.base.alerter(res.message);
        }

      })
    },
    //点击保存----设置密码页面
    passwordSave:function () {
      if (!this.pasPhoneCode) {
        this.$message.error('请输入手机验证码');
        this.showPassword = true;
        return;
      }
      if (!this.setPassword) {
        this.$message.error('请输入密码');
        this.showPassword = true;
        return;
      }
      if (this.password != this.setPassword) {
        this.$message.error('两次输入的密码不一致，请确认');
        this.showPassword = true;
        return;
      }
      var data = {
        //phone:this.person_msg.phone
        code:this.pasPhoneCode,
        password:this.password
      };
      var _this = this;
      this.base.axios_post(data, "/supplier/userCenter/updateSupplierLoginPwd", function(res) {
        if(res.code==0){
          _this.$message.success('修改密码成功');
          _this.$router.push("/");
        }else{
          _this.base.alerter(res.message);
        }
      })
    },
    //打开绑定手机页面
    bindPhone:function () {
      this.showBindphone = true;
      this.phoneCode="";
      this.newPhone="";
    },
    //获取绑定手机验证码
    get_binding_phoneCode(){
      var _this = this;
      //获取手机验证码
      var data = {
        phone:this.person_msg.phone
      };
      this.base.axios_post(
        data,
        "/supplier/userCenter/sendBindPhoneMsg",
        function(res) {
          if(res.code == 0){
            _this.timeCode = 59;
            var code_t = setInterval(function () {
              _this.codeShow_binding = true;
              _this.getBinding_btn = _this.timeCode+"重新获取";
              _this.timeCode--;
            },1000);
            setTimeout(function () {
              clearTimeout(code_t);
              _this.timeCode = "";
              _this.getBinding_btn = "重新获取";
              _this.codeShow_binding = false;
            },59000);
          }else{
            _this.base.alerter(res.message);
            _this.get_code = "发送失败";
          }
        }
      );
    },
    //点击保存----更换绑定手机页面
    updatePhoneSave:function () {
      if (!this.binding_phoneCode) {
        this.$message.error('请输入手机验证码');
        this.showBindphone = true;
        return;
      }
      if (!this.newPhone) {
        this.$message.error('请输入新的手机号码');
        this.showBindphone = true;
        return;
      }
      if(!(/^1[3|4|5|8][0-9]\d{4,8}$/.test(this.newPhone))){
        this.$message.error('请输入正确的手机号码');
        this.showBindphone = true;
        return;
      }
      var data = {
        phone:this.newPhone,
        code:this.binding_phoneCode,
      };
      var _this = this;
      this.base.axios_post(data, "/supplier/userCenter/supplierBindPhone", function(res) {
        if(res.code==0){
          _this.person_msg.phone = _this.newPhone;
          _this.$message.success('保存成功');
          _this.showBindphone = false;
        }else{
          _this.base.alerter(res.message);
        }
      })
    },
    //打开发货信息页面
    Address:function () {
      this.showAddress = true;
      this.province = "";
      this.detailedAddress = "";

    },

    //查看服务费
    get_fuwufei(){
      var Cookies = require("Cookies-js");
      let data = {
        token:Cookies.get('token')
      };
      var _this = this;
      this.base.axios_post(data,"/supplier/userCenter/findProportion",function (res) {
          if(res.code==0){
            _this.fuwufei = (res.data.proportion)*100+'%';
          }
      });
    },
    //点击保存----发货地址页面
    shipAddressSave:function (k) {
      if (!this.province) {
        this.$message.error('请选择省分');
        this.showAddress = true;
        return;
      }
      if (!this.shouhuo_city) {
        this.$message.error('请选择市区');
        this.showAddress = true;
        return;
      }
      if (!this.county) {
        this.$message.error('请选择区县');
        this.showAddress = true;
        return;
      }
      if (!this.detailedAddress) {
        this.$message.error('请输入详细地址');
        this.showAddress = true;
        return;
      }
      var data = {
        shipping_province:this.province_id,
        shipping_city:this.shouhuo_city_id,
        shipping_region:this.county_id,
        shipping_address:this.detailedAddress
      };
      var _this = this;
      this.base.axios_post(data, "/supplier/userCenter/shippingAddress", function(res) {
        if(res.code==0){
          _this.person_msg.province=_this.province;
          _this.person_msg.city=_this.person_msg.shouhuo_city;
          _this.person_msg.region = _this.county;
          _this.person_msg.address = _this.detailedAddress;
          _this.$message.success('修改地址成功');
          _this.showAddress = false;
        }else{
          _this.base.alerter(res.message);
        }
      })

    },

    //查看平台服务费
    check_fuwufei(){
      this.show_fuwufei = true;
    }

  }
};
</script>
<style lang="less">
  .userInfo{
    .foot{
      text-align: center;
      margin-top: 60px;
    }
  }
.el-select .el-input {
  width: 130px;
}
.input-with-select .el-input-group__prepend {
  background-color: #fff;
}
  .address>div{
    width: 670px;
  }
  .pws>div,.zfb>div,.pho>div{
    width: 670px;
  }
.select_city{
  padding-left: 25%;
  position: relative;
  span{
    position: absolute;
    display: inline-block;
    width: 80px;
    line-height: 36px;
    height: 36px;
    left: 15%;
    top: 0;
    color: #6d6c6c;
    font-size: 16px;
  }
}
.idea{
  .el-dialog--small{
    width: 27%;
    padding: 20px 0;
  }
}
.content .person_bottom {
  color: #222222;
  background: #fff;
  border-radius: 10px;
  padding-bottom: 5%;
}
.phoneCode{
  width: 15%;
}
.information{
  width: 420px;
  margin-left: -120px;
  margin-top: 20px;
}
.Alipay_information{
  width: 30%;
}
.set_pws_information{
  width: 30%;
}
.pws_information{
  width: 30%;
}
.phone_information{
  width:30%;
}
.content .person_top {
  padding: 25px 0;
  margin-bottom: 16px;
}

.content .person_top img {
  width: 65px;
  height: 65px;
  margin-left: 25px;
  border-radius: 50%;
  border: 1px solid #f7f7f7;
}

.content .person_top .name {
  display: inline-block;
  vertical-align: middle;
}

.content .person_top .info {
  float: right;
}
.el-form-item__label{
  text-align: left;
  margin-left: 5%;
}
.content .person_top .jdt {
  display: inline-block;
  width: 190px;
  margin-right: 20px;
  vertical-align: middle;
}

.content .person_bottom {
  //margin-top: 20px;
}

.content .person_bottom table {
  width: 100%;
}

.content .person_bottom table td {
  line-height: 45px;
}

.content .person_bottom table .tit {
  padding-left:0;
}
.content .person_bottom table .tit_pci{
  padding-left: 50px;
  width: 40px!important;
  img{
    width: 20px;
    height: 20px;
  }
}
.content .person_bottom table .info {
  color: #808080;
  font-size: 14px;
}

.content .person_bottom table .btn {
  color: #62b6f7;
  font-size: 14px;
}
.return {
  cursor: pointer;
  color: #808080;
  padding: 15px 0 15px 30px;
}
.btn {
  cursor: pointer;
}
.el-dialog__close{
  display: none !important;
}
.el-form-item__label{
  //margin-left: 20% !important;
}
.el-dialog__title{
  font-size: 20px !important;
  color: #63b1f3 !important;
}
.certification_lift,
.certification_right {
  display: inline-block;
  vertical-align: top;
  padding: 1%;
  min-height: 420px;
  color: #6d6c6c;
  font-size: 14px;
}
.certification_lift {
  width: 25%;

  img {
    width: 100%;
  }
  .select_box {
    position: relative;
    width: 80px;
    height: 80px;
    border-radius: 80px;
    overflow: hidden;
    border: 1px solid #dedede;
    //选择头像的按钮
    .select_icon {
      color: #ffffff;
      width: 100%;
      padding: 5px 0;
      bottom: 0;
      left: 0;
      position: absolute;
      text-align: center;
      background: rgba(0, 0, 0, 0.5);
    }
  }
}
.certification_right {
  width: 70%;
}
.base_span {
  width: 180px;
  display: inline-block;
}
.l_ipt {
  width: 347px;
  display: inline-block;
}
.right_con {
  width: 90.2%;
  line-height: 45px;
  margin-left: -5%;
}
.iframe_display {
  display: inline-block;
  margin: 0;
  padding: 0;
  vertical-align: middle;
  width: 300px;
  z-index: 2;
  height: 60px;
}
.dis {
  display: inline-block;
  height: 62px;
  input {
    //width: 20px;
    display: inline-block;
  }
  img {
    width: 100px;
  }
}
</style>
