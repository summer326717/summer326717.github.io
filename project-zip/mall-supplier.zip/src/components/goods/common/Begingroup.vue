<template>
  <div class="content begroup">
    <div class="add_info" >
      <p class="return bor">
        <span @click="back">
          <i class="el-icon-caret-left"></i>返回上一页</span>
      </p>
      <div class="info_item">
        <el-row>
          <el-col :span="24" class="left_nav_addgoods">
            <el-form ref="form" label-width="200px">
              <el-form-item label="开始时间" style="margin-left: 13%">
                <el-col :span="12">
                  <el-date-picker v-model="startTime" :editable="false" type="datetime" placeholder="选择日期时间" value-format='yyyy-MM-dd HH:mm:ss' @change="dateStartChange" style="width: 110%;"></el-date-picker>
                </el-col>
              </el-form-item>
              <el-form-item label="结束时间"  style="margin-left: 13%">
                <el-col :span="12">
                  <el-date-picker v-model="endTime" :editable="false" type="datetime" placeholder="选择日期时间" @change="dateEndChange" value-format='yyyy-MM-dd HH:mm:ss' style="width: 110%;"></el-date-picker>
                </el-col>
              </el-form-item>
              <el-form-item label="结算时间"  style="margin-left: 13%">
                <el-col :span="12">

                  <el-time-picker
                    v-model="settlementTime"
                    placeholder="17:0:0"
                    :editable="false"
                    style="width: 110%;"
                    value-format='HH:mm:ss'
                    @change="timeChange">
                  </el-time-picker>

                </el-col>
              </el-form-item>
              <el-form-item label="平台价（元）"  style="margin-left: 13%">
                <el-col :span="2">
                  <span style="padding-left: 12px">{{price}}</span>
                </el-col>
              </el-form-item>
              <el-form-item label="加钱购（元）"  style="margin-left: 13%">
                <el-col :span="12">
                  <el-input style="width: 110%;" @blur="addMoney" size="small" v-model="addMoneyBuy"></el-input>
                </el-col>
              </el-form-item>
              <el-form-item label="拼团规则"  style="margin-left: 13%">
                <div style="display: block;overflow: hidden">
                  <el-col :span="6" class="tc">人数</el-col>
                  <el-col :span="4">&nbsp;</el-col>
                  <el-col :span="3" class="tc">售价（元）</el-col>
                </div>
                <div class="rule" style="overflow: hidden" v-for="(v,k) in rule_num">
                  <el-col :span="4">
                    <el-input size="small" @change="least(k)" @focus="show" class="number" :disabled="v.lea" v-model="v.downNum"></el-input>
                  </el-col>
                  <el-col :span="1" class="tc">-</el-col>
                  <el-col :span="4">
                    <el-input size="small" @blur="change_most(k)" @focus="show" class="number" v-model="v.upNum"></el-input>
                  </el-col>
                  <el-col :span="1">&nbsp;</el-col>
                  <el-col :span="4">
                    <el-input size="small" @blur="sell(k)" @focus="show" class="number" v-model="v.salePrice"></el-input>
                  </el-col>
                  <el-col :span="1">&nbsp;</el-col>

                  <el-col :span="2">
                    <el-button size="small" type="danger" @click="del_rule(k)">删除</el-button>
                  </el-col>
                  <el-col :span="4" v-if="k==rule_num.length-1">
                    <div style="margin-left: 10px" @click="add_rule"><el-button size="small" :disabled="add" type="success">添加</el-button></div>
                  </el-col>
                </div>
              </el-form-item>
              <el-form-item style="width: 88%;margin-top: 5%;text-align: center">
                <el-button type="primary" :disabled="fb_submit" @click="publish_goods">发布</el-button>
              </el-form-item>
            </el-form>
          </el-col>
        </el-row>
      </div>
    </div>
  </div>
</template>
<script>
import base from "../../../assets/base";
export default {
  name: "Begingroup",
  data() {
    return {
      s:"",
      startTime: "",
      endTime: "",
      settlementTime:'',
      time:"",
      price:this.supplyPrice,
      addMoneyBuy: "",
      addMon:"",
      soldAmount: "",
      groupsGoodsRuleExpands:[],
      rule_num:[{
        downNum:1,//最少人数
        upNum:"",//最多人数
        salePrice:"",//售价
        lea:false,//拼团最低人数是否禁用
      }],
      add:false,//添加按钮是否禁用
      fb_submit:false,//发布按钮是否禁用

      start:'',
      end:''
    };
  },
  props: {
    goodsId: String,
    supplyPrice: String,
    goodsIcon:String,
    marketPrice:String,
    stockAmount:Number
  },
  created(){
    if(!this.time){
      this.time = '17:00:00'
    }
      var f = Math.round(this.price*100)/100;
      var s = f.toString();
      var rs = s.indexOf('.');
      if (rs < 0) {
        rs = s.length;
        s += '.';
      }
      while (s.length <= rs + 2) {
        s += '0';
      }
    this.price = s;

  },
  methods: {
    dateStartChange(value){
      /*console.log(Date.parse(new Date(value)));
      var s = Date.parse(new Date(value));
      this.startTime = s;*/
      this.startTime = value;
      this.start = Date.parse(new Date(value));
    },
    dateEndChange(value){
      this.endTime = value;
      this.end = Date.parse(new Date(value));
    },
    timeChange(value){
      this.time = value;
    },
    back() {
      this.$emit("group_type", 1);
    },
    publish_goods() {
      var n=0;
      var _this = this;
      var index = this.rule_num.length-1;

      var p = [];
      for(var j in this.rule_num){
        p.push(this.rule_num[j].salePrice);
        if(this.least(j)&&this.most(j)&&this.sell(j)){
          n++;
        }
      }


      if(n == this.rule_num.length && this.addMoney()){
        var array = this.rule_num;
        for(var i in array){
          delete array[i].lea;
          array[i].salePrice = this.base.mul(Number(array[i].salePrice),100);
          array[i].upNum = Number(array[i].upNum);
        }
        var heheda = JSON.parse(JSON.stringify(array));
        for(var n in p){
          _this.rule_num[n].salePrice = p[n];
        }
        let json = {
          groupsGoods: {
            goodsId: this.goodsId,
            startTime: this.start,
            endTime: this.end,
            settlementTime: this.time,
            price: this.base.mul(this.supplyPrice,100),
            addMoneyBuy: this.base.mul(this.addMon,100),
            goodsIcon:this.goodsIcon,
            marketPrice:this.base.mul(Number(this.marketPrice),100),
            stockAmount:this.stockAmount
          },
          groupsGoodsRuleList: heheda
        };
        if(this.endTime!="" && this.startTime>this.endTime){
          this.$message.error('结束时间必须大于开始时间！');
        }else if(this.startTime==""){
          this.$message.error('开始时间不能为空！');
        }else if(this.time==""){
          this.$message.error('结算时间不能为空！');
        }else{
          this.$confirm('确定发布该商品的拼团规则吗?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            _this.base.axios_post(json, "/goods/releaseGoodsGroupInfo", function(res) {
              if (res.code == 0) {
                _this.$message({
                  type: 'success',
                  message: '发布成功!'
                });
                _this.$emit("group_type", 1);
              }else{
                _this.$message(res.message);
              }
            });
          }).catch(() => {

          });
        }
      }

    },
    add_rule(){
      var index = this.rule_num.length-1;
      var least_p = Number(this.rule_num[index].upNum)+1;
      if(this.least(index)&&this.most(index)&&this.sell(index)){
        if(index>=0) {
          this.rule_num.push({
            downNum: least_p,//最少人数
            upNum: "",//最多人数
            salePrice: ""//售价
          });
          this.rule_num[index+1].lea = true;
          return true
        }
      }else{
        return false;
      }
    },
    del_rule(index){

      this.rule_num.splice(index,1);
      if(this.rule_num.length==0){
        this.rule_num.push({
          downNum: 1,//最少人数
          upNum: "",//最多人数
          salePrice: ""//售价
        });
      }
      return true;
    },
    addMoney(){
      this.addMon = this.addMoneyBuy;
      this.addMon = Number(this.addMon);
      if(!/^[+]{0,1}(\d+)$|^[+]{0,1}(\d+\.\d+)$/.test(this.addMon)){
        this.$message.error('请输入正确的价格');
        this.show();
        return false;
      }else{
        var f = Math.round(this.addMoneyBuy*100)/100;
        var s = f.toString();
        var rs = s.indexOf('.');
        if (rs < 0) {
          rs = s.length;
          s += '.';
        }
        while (s.length <= rs + 2) {
          s += '0';
        }
        this.addMoneyBuy = s;
        this.show();
        return true;
      }

    },
    least(index){
      var num = Number(this.rule_num[index].downNum);
      if(! /^[1-9]\d*$/.test(num)){
        this.$message.error('请输入正确的拼团人数');
        this.hide();
        return false;
      }else{
        if(num < 1){
          this.$message.error('拼团人数最少为1人哦');
          this.hide();
          return false;
        }else if(num>99999){
          this.$message.error('拼团人数不能超过99999人哦');
          this.hide();
          return false;
        }else if(num%1<0){
          this.$message.error('请输入正确的拼团人数');
          this.hide();
          return false;
        }else{
          this.show();
          return true;
        }
      }

    },
    most(index){
      var num = Number(this.rule_num[index].upNum);//最多人数
      var num2 = Number(this.rule_num[index].downNum);//最少人数
      if(! /^[1-9]\d*$/.test(num)){
        this.$message.error('请输入正确的拼团人数');
        return false;
      }else{
        if(num < num2 || num>99999){
          this.$message.error('请输入正确的最多拼团人数');
          this.hide();
          return false;
        }else if(String(num)==""){
          this.$message.error('请输入最多拼团人数');
          this.hide();
          return false
        }else if(num%1<0){
          this.$message.error('请输入正确的拼团人数');
          this.hide();
          return false;
        }else{
          this.show();
          return true;
        }
      }

    },
    sell(index){
      var num = Number(this.rule_num[index].salePrice);
      if(!/^[+]{0,1}(\d+)$|^[+]{0,1}(\d+\.\d+)$/.test(num)){
        this.$message.error('请输入正确的销售价格');
        this.hide();
        return false;
      }else{
        if(num<=0 || String(num)==""){
          this.$message.error('请输入正确的销售价格');
          this.hide();
          return false;
        }else if(num>this.price){
          this.$message.error('拼团价必须小于等于平台价!');
          this.hide();
          return false;
        }else{
          var f = Math.round(num*100)/100;
          var s = f.toString();
          var rs = s.indexOf('.');
          if (rs < 0) {
            rs = s.length;
            s += '.';
          }
          while (s.length <= rs + 2) {
            s += '0';
          }
          this.rule_num[index].salePrice = s;
          this.show();
          return true;
        }
      }

    },
    hide(){
      this.add  = true;
      this.fb_submit  = true;
    },
    show(){
      //按钮恢复可用状态
      if(this.rule_num[0].downNum<1){
        this.$message.error('拼团人数最少为1人哦');
        this.hide();
      }else{
        this.add  = false;
        this.fb_submit  = false;
      }
    },
    change_most(index){
      if(index<this.rule_num.length-1){
        this.rule_num[index+1].downNum = Number(this.rule_num[index].upNum)+1;
      }
      this.most(index);
    }
  }
};
</script>
<style lang="less">
.begroup{
  .el-col-12{
   width: 33%!important;
  }

    /*.rule{
      overflow: hidden;
    }
    .rule>div{
      width: 90px;
    }
    .rule .tc{
      width: 30px;
    }
    .el-col-6{
      width: 23%!important;
    }
    .el-col-2{
      width: 5.2%!important;
    }
    .number{
      width: 90px;
    }
    .add{
      width: 45px;
      overflow: hidden;
      margin-left: 45%;
      margin-top: -3.2%;
    }
    .el-form-item__label{
      text-align: left;
      width: 100px!important;
      margin-left: 9%;
    }*/
}
</style>
