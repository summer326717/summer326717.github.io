<template>
  <div class="content look">
    <div class="add_info" >
      <p class="return bor">
        <span @click="back">
          <i class="el-icon-caret-left"></i>返回上一页</span>
      </p>
      <div class="info_item">
        <el-row>
          <el-col :span="24" class="left_nav_addgoods">
            <el-form ref="form" class="look_left_info" label-width="200px">
              <el-form-item label="开始时间">
                <el-col :span="12">
                  <el-button type="text">{{groupsGoodsExpand.startTime}}</el-button>
                </el-col>
              </el-form-item>
              <el-form-item label="结束时间">
                <el-col :span="12">
                  <el-button type="text">{{groupsGoodsExpand.endTime}}</el-button>
                </el-col>
              </el-form-item>
              <el-form-item label="结算时间">
                <el-col :span="12">
                  <el-button type="text">{{groupsGoodsExpand.settlementTime}}</el-button>
                </el-col>
              </el-form-item>
              <el-form-item label="平台价（元）">
                <el-col :span="12">
                  <el-button type="text">{{(groupsGoodsExpand.price/100).toFixed(2)}}</el-button>
                </el-col>
              </el-form-item>
              <el-form-item label="加钱购（元）">
                <el-col :span="12">
                  <el-button type="text" style="text-align: right">{{(groupsGoodsExpand.addMoneyBuy/100).toFixed(2)}}</el-button>
                </el-col>
              </el-form-item>

            </el-form>
            <div class="look_right_info">
              <p>拼团规则</p>
            <el-form >
              <div>
                <el-col :span="9" class="tc" style="margin-bottom: 10px">人数</el-col>
                <el-col :span="8" class="tc" style="margin-bottom: 10px">售价（元）</el-col>
                <el-col :span="7" class="tc" style="margin-bottom: 10px">优惠金额（元）</el-col>
              </div>
              <div v-for="(item,i) in groupsGoodsRuleExpands" :key="i">

                <el-col :span="4" class="tr">
                  <el-button type="text">{{item.downNum}}</el-button>
                </el-col>
                <el-col :span="1" class="tc">-</el-col>
                <el-col :span="4" class="tl">
                  <el-button type="text">{{item.upNum}}</el-button>
                </el-col>
                <el-col :span="2">&nbsp;</el-col>
                <el-col :span="4" class="tc sj">
                  <el-button type="text">{{(item.salePrice/100).toFixed(2)}}</el-button>
                </el-col>
                <el-col :span="2">&nbsp;</el-col>
                <el-col :span="7" class="tc je">
                  <el-button type="text">{{(item.discountPrice/100).toFixed(2)}}</el-button>
                </el-col>
              </div>
            </el-form>
            </div>
          </el-col>
        </el-row>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "Lookgroup",
  data() {
    return {
      goods_id: "",
      groupsGoodsExpand: "",
      groupsGoodsRuleExpands: ""
    };
  },
  props: {
    goodsId: String
  },
  created() {
    this.goods_id = this.goodsId;
    this.get_date();
  },
  methods: {
    back() {
      this.$emit("group_type", 1);
    },
    get_date() {
      let _this = this;
      let data = {
        goodsId: this.goods_id
      };
      this.base.axios_post(data, "/goods/queryGoodsGroupsInfo", function(res) {
        if (res.code == 0) {
          _this.groupsGoodsExpand = res.data.groupsGoodsExpand;
          _this.groupsGoodsRuleExpands = res.data.groupsGoodsRuleExpands;
          _this.groupsGoodsExpand.startTime = _this.base.trans_time(_this.groupsGoodsExpand.startTime, 2);
          _this.groupsGoodsExpand.endTime = _this.base.trans_time(_this.groupsGoodsExpand.endTime, 2);
          //_this.groupsGoodsExpand.settlementTime = _this.base.trans_time(_this.groupsGoodsExpand.settlementTime, 2);
        }
      });
    }
  }
};
</script>

<style lang="less">
  .look {
    .look_left_info, .look_right_info{
      width: 49.9%;
      overflow: hidden;
      float: left;
    }
    .look_left_info{
      border-right: solid 1px #a2a2a2;
      .el-col{
        text-align: right;
      }
    }
    .look_left_info .el-form-item__label{
        box-sizing: border-box;
        text-align: left;
        padding-left: 104px;
    }
    .look_right_info p{
      width:60px;
      height: 20px;
      line-height: 20px;
      margin: 0 auto;
      margin-bottom: 30px;
      padding-left: 30px;
    }
    .look_right_info{
      .sj,.je{
        padding-right: 11px;
        text-align: right;
      }
      .je{
        padding-right: 33px;
        text-align: right;
      }
    }
  }
</style>
