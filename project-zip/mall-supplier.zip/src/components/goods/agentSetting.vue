<template>
<div class="content look">
    <div class="add_info" >
      <p class="return bor">
        <span @click="back">
          <i class="el-icon-caret-left"></i>返回上一页</span>
      </p>
      <div class="info_item">
        <div class="agent" v-if="group_type==5">
        <el-row>
          <el-col :span="4">零售价（元）：</el-col>
          <el-col :span="6"><el-input size="small" placeholder="" v-model="retailPrice"></el-input></el-col>
        </el-row>
        <el-row>
          <el-col :span="4">佣金设置：</el-col>
          <el-col :span="20">
            <el-row>
              <el-col :span="8" class="tc">商品数量</el-col>
              <el-col :span="8" class="tc">佣金（%）</el-col>
              <el-col :span="8">&nbsp;</el-col>
            </el-row>
            <el-row v-for="(item,i) in data_list" :key="i">
              <el-col :span="8">
                <el-row>
                  <el-col :span="6" class="tc">满</el-col>
                  <el-col :span="12"><el-input size="small" placeholder="" v-model="item.agentRuleNumber"></el-input></el-col>
                  <el-col :span="6" class="tc">件</el-col>
                </el-row>
              </el-col>
              <el-col :span="8">
                <el-col :span="4">&nbsp;</el-col>
                <el-col :span="16">
                  <el-input size="small" placeholder="" v-model="item.brokerage"></el-input>
                </el-col>
                <el-col :span="4">&nbsp;</el-col>
              </el-col>
              <el-col :span="8" class="tc">
                <el-button v-if="data_list.length!=i+1" @click="deleteAddr(i)" type="primary" size="small">删除</el-button>
                <el-button v-else size="small" @click="addArr" type="danger">添加</el-button>
              </el-col>
            </el-row>
            <p class="tc info">佣金必须大于0，小于等于100</p>
          </el-col>
        </el-row>
        <p class="tc"><el-button @click="subAgent" type="primary">提交</el-button></p>
      </div>
      <div class="agent" v-if="group_type==6">
        <el-row>
          <el-col :span="4">零售价（元）：</el-col>
          <el-col :span="6">{{(retailPrice/100).toFixed(2)}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="4">佣金设置：</el-col>
          <el-col :span="20">
            <el-row>
              <el-col :span="8" class="tc b_bor">商品数量</el-col>
              <el-col :span="16" class="tc b_bor">佣金（%）</el-col>
            </el-row>
            <el-row v-for="(item,i) in data_list" :key="i">
              <el-col :span="8">
                <el-row class="b_bor">
                  <el-col :span="8" class="tc">满</el-col>
                  <el-col :span="8" class="tc">{{item.agentRuleNumber}}</el-col>
                  <el-col :span="8" class="tc">件</el-col>
                </el-row>
              </el-col>
              <el-col :span="16" class="b_bor">
                <el-col :span="8">&nbsp;</el-col>
                <el-col :span="8" class="tc">{{item.brokerage}}</el-col>
                <el-col :span="8">&nbsp;</el-col>
              </el-col>
            </el-row>
            <p class="tc info">佣金必须大于0，小于等于100</p>
          </el-col>
        </el-row>
      </div>
      </div>
    </div>
</div>
</template>
<script>
export default {
  props: {
    group_type: Number,
    goodsId: String
  },
  data() {
    return {
      retailPrice: "",
      data_list: [
        {
          agentRuleNumber: "",
          brokerage: ""
        },
        {
          agentRuleNumber: "",
          brokerage: ""
        }
      ]
    };
  },
  mounted() {
    if (this.group_type == 6) {
      this.getAgentInfo();
    }
  },
  methods: {
    back() {
      this.$emit("group_type", 1);
    },
    getAgentInfo() {
      let data = {
        goodsId: this.goodsId
      };
      let _this = this;
      this.base.axios_post(data, "/goods/queryAgentGoodsInfo", function(res) {
        if (res.code == 0) {
          _this.data_list = res.data.goodsAgentRules;
          _this.retailPrice = res.data.retailPrice;
        } else {
          _this.$message(res.message);
        }
      });
    },
    addArr() {
      for (let item of this.data_list) {
        if (!item.agentRuleNumber || !item.brokerage) {
          this.$message("请输入完整");
          return;
        }
      }
      this.data_list.push({ agentRuleNumber: "", brokerage: "" });
    },
    deleteAddr(i) {
      if (i == 0) {
        return;
      }
      this.data_list.splice(i, 1);
    },
    subAgent() {
      let sum = this.data_list.length;
      let arr = JSON.parse(JSON.stringify(this.data_list));
      if (!this.retailPrice) {
        this.$message("请输入零售价");
        return;
      }
      if (!parseFloat(this.retailPrice)) {
        this.$message("请输入正确零售价");
        return;
      }
      this.retailPrice = parseFloat(this.retailPrice).toFixed(2);
      for (let i = 0; i < sum; i++) {
        const e = arr[i];
        if (i < sum - 1) {
          if (!e.agentRuleNumber || !e.brokerage) {
            this.$message("请输入完整佣金设置");
            return;
          }
          if (!Number.isInteger(parseFloat(e.agentRuleNumber)) || parseFloat(e.agentRuleNumber) <= 0) {
            this.$message("第" + (i + 1) + "行，请输入正确商品数量");
            return;
          }
          if (isNaN(e.brokerage) || parseFloat(e.brokerage) <= 0 || parseFloat(e.brokerage) >= 100) {
            this.$message("第" + (i + 1) + "行，请输入正确佣金");
            return;
          }
          e.brokerage = parseFloat(e.brokerage).toFixed(2);
          this.data_list[i].brokerage = parseFloat(this.data_list[i].brokerage).toFixed(2);
        }
        if (i == sum - 1) {
          if (e.agentRuleNumber || e.brokerage) {
            if (!Number.isInteger(parseFloat(e.agentRuleNumber)) || parseFloat(e.agentRuleNumber) <= 0) {
              this.$message("第" + (i + 1) + "行，请输入正确商品数量");
              return;
            }
            if (isNaN(e.brokerage) || parseFloat(e.brokerage) <= 0 || parseFloat(e.brokerage) >= 100) {
              this.$message("第" + (i + 1) + "行，请输入正确佣金");
              return;
            }
            e.brokerage = parseFloat(e.brokerage).toFixed(2);
            this.data_list[i].brokerage = parseFloat(this.data_list[i].brokerage).toFixed(2);
          }
        }
        if (i != 0) {
          if (parseFloat(e.agentRuleNumber) <= parseFloat(arr[i - 1].agentRuleNumber)) {
            this.$message("第" + (i + 1) + "行，需大于上一行的商品数量");
            return;
          }
          if (parseFloat(e.brokerage) <= parseFloat(arr[i - 1].brokerage)) {
            this.$message("第" + (i + 1) + "行，需大于上一行的佣金");
            return;
          }
        }
        if (i == sum - 1) {
          if (!e.agentRuleNumber || !e.brokerage) {
            arr.pop();
          }
        }
      }
      console.log(arr);
      this.$confirm("确认允许该商品被代理吗?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          let data = {
            goodsId: this.goodsId,
            retailPrice: this.base.mul(this.retailPrice, 100),
            goodsAgentRules: arr
          };
          let _this = this;
          this.base.axios_post(data, "/goods/saveAgentGoodsInfo", function(
            res
          ) {
            if (res.code == 0) {
              _this.$emit("group_type", 1);
            } else {
              _this.$message(res.message);
            }
          });
        })
        .catch(() => {});
    }
  }
};
</script>
<style lang="less">
.agent {
  padding: 100px;
  line-height: 50px;
  .b_bor {
    border-bottom: 1px solid #eeeeee;
  }
  .info {
    color: #f56c6c;
    padding: 50px 0;
  }
}
</style>
