<template>
  <div class="content Comments">
    <div class="table" v-if="!is_comments_list">
      <table>
        <tr class="bor">
          <th>商品名称</th>
          <th>好评</th>
          <th>操作</th>
        </tr>
        <tr v-for="(item,i) in data_list" :key="i">
          <td style="text-align: left"><img :src="item.goodsIcon"><span class="ell">{{item.goodsName}}</span></td>
          <td style="text-align: center">{{item.goodDegree}}</td>
          <td style="text-align: center">
            <el-button size="small" type="primary" @click="detail(item.goodsId,item.goodDegree)">评价明细</el-button>
          </td>
        </tr>
      </table>
      <div class="no_data" v-if="data_list==''"><img src="../../assets/images/no_data.png"/></div>
      <pagination v-if="data_list!=''&&total_pages>1" :cur='page_no' :all='total_pages' @get_page='turn_page'></pagination>
    </div>
    <div class="add_info" v-if="is_comments_list">
      <p class="return bor">
        <span @click="back">
          <i class="el-icon-caret-left"></i>返回上一页</span>
      </p>
      <div class="info_item">
        <div class="rate">
          <div class="top"><el-button size="small" type="danger">全部评价（{{comments_list.length}}）</el-button><el-button size="small" type="danger">好评度{{goodDegree*100}}%</el-button></div>
          <ul>
            <li v-for="(item,i) in comments_list" :key="i">
              <p><el-rate v-model="item.goodsCommentH.matchScore" disabled text-color="#ff9900" score-template="{value}"></el-rate><span class="time">2017-10-10 11:20:11</span></p>
              <p class="des">{{item.goodsCommentH.goodsComment}}</p>
              <p><img class="preview-img" v-for="(m,j) in item.goodsCommentBList" :key="j" :src="m.imgUrl"></p>
            </li>
          </ul>
          <pagination v-if="comments_list!=''&&total_pages>1" :cur='page_no' :all='total_pages' @get_page='turn_page'></pagination>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import pagination from "../common/Pagination";
export default {
  data() {
    return {
      page_no: 1,
      total_pages: 1,
      no_data: false,
      data_list: [],
      goodDegree: 0,
      is_comments_list: false
    };
  },
  components: {
    pagination
  },
  created() {
    this.get_data();
  },
  methods: {
    back: function() {
      this.is_comments_list = false;
      this.page_no = 1;
      this.total_pages = 1;
    },
    turn_page: function(i) {
      this.page_no = i;
      if (!this.is_comments_list) {
        this.get_data();
      } else {
        this.detail();
      }
    },
    get_data: function() {
      var data = {
        page_no: this.page_no,
        page_size: 10
      };
      var _this = this;
      this.base.axios_post(
        data,
        "/orderCenter/supplierQueryGoodsCommentSum",
        function(res) {
          if (res.code == 0) {
            if (res.data) {
              _this.data_list = res.data.resultList;
              _this.total_pages = res.data.pages;
              _this.no_data = false;
            } else {
              _this.no_data = true;
            }
          } else {
            if (_this.page_no == 1) {
              _this.data_list = [];
            }
            _this.no_data = true;
          }
        }
      );
    },
    detail: function(goodsId, goodDegree) {
      if (!this.is_comments_list) {
        this.page_no = 1;
        this.total_pages = 0;
      }
      //评价明细
      var data = {
        goodsId: goodsId,
        page_no: this.page_no,
        page_size: 10
      };
      var _this = this;
      this.base.axios_post(
        data,
        "/orderCenter/supplierQueryGoodsCommentDetail",
        function(res) {
          if (res.code == 0) {
            if (res.data) {
              _this.comments_list = res.data.CommentList;
              _this.total_pages = res.data.pages;
              _this.goodDegree = goodDegree;
              _this.is_comments_list = true;
            }
          }
        }
      );
    }
  }
};
</script>

<style>
  .Comments .table .bor>th{
    text-align: center;
  }
.content .add_info {
  color: #222222;
  font-size: 14px;
  background: #ffffff;
  border-radius: 10px;
}

.content .add_info .return {
  cursor: pointer;
  color: #808080;
  padding: 15px 0 15px 30px;
}

.content .add_info .info_item {
  padding: 30px 0;
}
.content .add_info .rate .top {
  margin-left: 30px;
}
.content .add_info .rate ul li {
  margin: 15px 30px;
  padding: 15px 0;
  position: relative;
  border-bottom: 1px dashed #e1e1e1;
}
.content .add_info .rate .time {
  position: absolute;
  right: 30px;
  top: 0;
  color: #7d7b7b;
}
.content .add_info .rate .des {
  line-height: 25px;
  padding: 10px 0;
}
.content .add_info .rate img {
  height: 80px;
  margin-right: 20px;
}
.container .el-col,
.container .add_info {
  height: 100%;
}
.container .content {
  height: calc(100% - 40px);
}
.container .info_item {
  height: calc(100% - 110px);
  overflow-y: scroll;
}
.container .info_item::-webkit-scrollbar {
  display: none;
}
</style>
