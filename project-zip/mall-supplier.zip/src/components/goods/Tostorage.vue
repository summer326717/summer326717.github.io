<template>
  <div class="content Tostorage">
    <p class="tit">
      <span @click="join_goods">商品入库</span>
    </p>
    <div class="table">
      <table>
        <tr class="bor">
          <th>商品名称</th>
          <th>分类</th>
          <th>子分类</th>
          <th class="number">市场价（元）</th>
          <th class="number">平台价（元）</th>
          <th>操作</th>
        </tr>
        <tr v-for="item in data_list">
          <td style="text-align: left"><img v-if="item.goodsIcon" v-bind:src="item.goodsIcon"><span class="ell">{{item.goodsName}}</span></td>
          <td style="text-align: center">{{item.firstTypeName}}</td>
          <td style="text-align: center">{{item.secondTypeName}}</td>
          <td class="number">{{item.marketPrice}}</td>
          <td class="number">{{item.supplyPrice}}</td>
          <td  style="text-align: center">
            <el-button size="small" @click="upadate_goods(item.goodsId)" type="success">编辑</el-button>
            <el-button size="small" type="primary" @click="add_other_info(item.goodsId)">提交</el-button>
            <el-button size="small" type="warning" @click="delete_info(item.goodsId)">删除</el-button>
          </td>
        </tr>
      </table>
      <div class="no_data" v-if="no_data"><img src="../../assets/images/no_data.png"/></div>
      <pagination :cur='page_no' v-if="data_list!=''&&total_pages>1" :all='total_pages' @get_page='turn_page'></pagination>
    </div>
  </div>
</template>
<script>
import pagination from "../common/Pagination";
export default {
  data() {
    return {
      no_data: false,
      page_no: 1,
      total_pages: 1,
      data_list: [], //待入库列表数据
      second_menu_list: [],
      firstType: "", //一级类型
      secondType: "" //二级类型
    };
  },
  components: {
    pagination
  },
  created() {
    this.get_data();
  },
  methods: {
    turn_money(value){
      var f = Math.round(value*100)/10000;
      var s = f.toString();
      var rs = s.indexOf('.');
      if (rs < 0) {
        rs = s.length;
        s += '.';
      }
      while (s.length <= rs + 2) {
        s += '0';
      }
      return s;
    },
    join_goods: function() {
      this.$router.push({ path: "/addgood" });
    },
    turn_page: function(i) {
      this.page_no = i;
      this.get_data();
    },
    get_data: function() {
      //获取待入库商品列表
      let json = {
        goods_state: 1,
        page_no: this.page_no,
        page_size: 10
      };
      let _this = this;
      this.base.axios_post(json, "/goods/queryGoodsInfoList", function(res) {
        if (res.code == 0) {
          //_this.data_list = res.data.list;
          _this.total_pages = res.data.pages;
          for(var i in res.data.list){
            res.data.list[i].marketPrice = _this.turn_money(res.data.list[i].marketPrice);
            res.data.list[i].supplyPrice = _this.turn_money(res.data.list[i].supplyPrice);
          }
          _this.data_list = res.data.list;
          _this.no_data = false;
        } else {
          _this.no_data = true;
          if (_this.page_no == 1) {
            _this.data_list = [];
          }
        }
      });
    },
    get_category_list: function() {
      var json = {
        typeMode: 1
      };
      var _this = this;
      this.base.axios_post(json, "/centerConfig/queryGoodsTypeList", function(
        res
      ) {
        console.log("一级分类");
        if (res.code == 0) {
          _this.options = res.data;
          _this.menu_id = res.data[0].typeId;
          _this.get_right_menu();
        }
      });
    },
    get_right_menu: function() {
      //根据一级菜单显示二级菜单
      var _this = this;
      if (this.menu_id == 0) {
        return;
      }
      let json = {
        typeMode: 2,
        typeId: this.menu_id
      };
      this.base.axios_post(json, "/centerConfig/queryGoodsTypeList", function(
        res
      ) {
        console.log("二级分类");
        if (res.code == 0) {
          _this.second_menu_list = res.data;
        } else {
          _this.second_menu_list = [];
          _this.$toast(res.message);
        }
      });
    },
    delete_info: function(goodsId) {
      let _this = this;
      this.$confirm("确定删除该商品?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          let json = {
            goodsId: goodsId
          };
          _this.base.axios_post(json, "/goods/deleteGoodsInfo", function(res) {
            if (res.code == 0) {
              _this.page_no = 1;
              _this.get_data();
            }
            _this.$message({ message: res.message });
          });
        })
        .catch(() => {});
    },
    add_other_info: function(goodsId) {

      var _this = this;
      this.$confirm("确认提交审核吗?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          var json = {
            goodsId: goodsId
          };
          _this.base.axios_post(json, "/goods/supplierCommitGoods", function(
            res
          ) {
            _this.$message(res.message);
            if (res.code == 0) {
              _this.page_no = 1;
              _this.get_data();
            }
          });
        })
        .catch(() => {});
    },
    upadate_goods: function(id) {
      this.$router.push({ path: "/Editgood?id=" + id });
    }
  }
};
</script>
<style>
  .Tostorage .table .bor>th{
    text-align: center;
  }
  .Tostorage .table table .number{
    text-align: right;
  }
</style>
