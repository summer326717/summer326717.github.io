<template>
  <div class="content Recycle">
    <div class="table">
      <table>
        <tr class="bor">
          <th>商品名称</th>
          <th class="number">平台价</th>
          <th class="number">已售数量</th>
          <th>下架时间</th>
          <th>下架原因</th>
          <th>操作</th>
        </tr>
        <tr v-for="(item,index) in data_list" :key="index">
          <td style="text-align: left"><img :src="item.goodsIcon"><span class="ell">{{item.goodsName}}</span></td>
          <td class="number">{{item.platformPrice}}</td>
          <td class="number">{{item.soledNum}}</td>
          <td style="text-align: center">{{item.createTime}}</td>
          <td style="text-align: left;max-width:100px;overflow: hidden;text-overflow: ellipsis;white-space: nowrap" :title="item.reason">{{item.reason}}</td>
          <td style="text-align: center"><el-button v-if="item.state==1" type="primary" size="small" @click="reinstorage(item.goodsId)">重新入库</el-button></td>
        </tr>
      </table>
      <div class="no_data" v-if="no_data"><img src="../../assets/images/no_data.png"/></div>
      <pagination v-if="data_list!=''&&total_pages>1" :cur='page_no' :all='total_pages' @get_page='turn_page'></pagination>
    </div>
  </div>
</template>
<script>
import pagination from "../common/Pagination";
export default {
  data() {
    return {
      page_no: 1,
      total_pages: 1,
      data_list: [],
      no_data: true
    };
  },
  components: {
    pagination
  },
  created() {
    this.get_data();
  },
  methods: {
    turn_money(value){
      var f = Math.round(value*100)/10000;
      var s = f.toString();
      var rs = s.indexOf('.');
      if (rs < 0) {
        rs = s.length;
        s += '.';
      }
      while (s.length <= rs + 2) {
        s += '0';
      }
      return s;
    },
    turn_page: function(i) {
      this.page_no = i;
      this.get_data();
    },
    get_data: function() {
      var data = {
        goods_state: 0,
        page_no: this.page_no,
        page_size: 10
      };
      var _this = this;
      this.base.axios_post(data, "/goods/supplierOffGoodsInfoQryList", function(
        res
      ) {
        if (res.code == 0) {
          if (res.data) {
            for(var i in res.data.resultList){
              res.data.resultList[i].platformPrice = _this.turn_money(res.data.resultList[i].platformPrice);
            }
            _this.data_list = res.data.resultList;

            _this.total_pages = res.data.pages;
            _this.data_list.map(function(x, y) {
              x.createTime = _this.base.trans_time(x.createTime, 2);
            });



            _this.no_data = false;
          } else {
            _this.data_list = [];
            _this.no_data = true;
          }
        } else {
          if (_this.page_no == 1) {
            _this.data_list = [];
          }
          _this.no_data = true;
        }
      });
    },
    reinstorage: function(goodsId) {
      let _this = this;
      let json = {
        goodsId: goodsId
      };
      this.$confirm("确认该商品重新入库?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          _this.base.axios_post(
            json,
            "/goods/supplierGoodsToWaitingStock",
            function(res) {
              if (res.code == 0) {
                _this.page_no = 1;
                _this.get_data();
              }
              _this.$message(res.message);
            }
          );
        })
        .catch(() => {});
    }
  }
};
</script>

<style>
.Recycle .table .bor>th{
  text-align: center;
}
  .Recycle table .number{
    text-align: right!important;
  }
</style>
