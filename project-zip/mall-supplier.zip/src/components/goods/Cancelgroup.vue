<template>
  <div class="content">
    <div class="table" v-if="group_type==1">
      <table>
        <tr class="bor">
          <th style="width:410px">商品名称</th>
          <th>市场价</th>
          <th>平台价</th>
          <th>可售数量</th>
          <th>已售数量</th>
          <th>交易金额</th>
          <th>操作</th>
        </tr>
        <tr v-for="(item,index) in data_list" :key="index">
          <td style="text-align: left"><img :src="item.goodsIcon"><span class="ell">{{item.goodsName}}</span></td>
          <td>{{item.marketPrice/100}}</td>
          <td>{{item.supplyPrice/100}}</td>
          <td>{{item.stockAmount}}</td>
          <td>{{item.soldAmount}}</td>
          <td>{{item.totalMny/100}}</td>
          <td>
            <el-button type="primary" size="small" class="mb" v-if="item.groupState==1" v-on:click="go_to_goods(item.goodsId)">发起拼团</el-button>
            <el-button type="primary" size="small" class="mb" v-if="item.groupState==1" v-on:click="loook_goods(item.goodsId)">查看拼团</el-button>
            <el-button type="primary" size="small" v-if="item.groupState==1" v-on:click="cancel_goods(item.goodsId)">取消拼团</el-button>
            <el-button type="primary" size="small" v-on:click="out_goods(item.goodsId)">下架</el-button>
          </td>
        </tr>
      </table>
      <div class="no_data" v-if="no_data"><img src="../../assets/images/no_data.png"/></div>
      <pagination v-if="data_list!=''&&total_pages>1" :cur='page_no' :all='total_pages' @get_page='turn_page'></pagination>
    </div>
    <begingroup v-if="group_type==2" :goodsId='goods_id' @group_type="get_type"></begingroup>
    <lookgroup v-if="group_type==3" :goodsId='goods_id' @group_type="get_type"></lookgroup>
  </div>
</template>
<script>
import pagination from "../common/Pagination";
import begingroup from "./common/Begingroup";
import lookgroup from "./common/Lookgroup";
export default {
  data() {
    return {
      page_no: 1,
      total_pages: 1,
      data_list: [],
      no_data: false,
      goods_id: "",
      group_type: 1 //1.页面数据2.发起拼团3.查看拼团
    };
  },
  components: {
    pagination,
    begingroup,
    lookgroup
  },
  created() {
    this.get_data();
  },
  methods: {
    get_type: function(i) {
      this.group_type = i;
    },
    turn_page: function(i) {
      this.page_no = i;
      this.get_data();
    },
    get_data: function() {
      //查询列表
      var data = {
        goods_state: 4,
        page_no: this.page_no,
        page_size: 10
      };
      var _this = this;
      this.base.axios_post(data, "/goods/queryGoodsInfoList", function(res) {
        if (res.code == 0) {
          if (res.data) {
            _this.data_list = res.data.list;
            _this.total_pages = res.data.pages;
            _this.no_data = false;
          } else {
            _this.no_data = true;
          }
        } else {
          if (_this.page_no == 1) {
            _this.data_list = [];
          }
          _this.no_data = true;
        }
      });
    },
    out_goods: function(goodsId) {
      //下架商品
      var _this = this;
      this.$confirm("确认下架该商品?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          var data = {
            dr: 0,
            goodsId: goodsId
          };
          _this.base.axios_post(data, "/goods/updateGoodsInfo", function(res) {
            if (res.code == 0) {
              _this.page_no = 1;
              _this.get_data();
            }
            _this.$message(res.message);
          });
        })
        .catch(() => {});
    },
    go_to_goods: function(goodsId) {
      //发起拼团
      this.goods_id = goodsId;
      this.group_type = 2;
    },
    loook_goods: function(goodsId) {
      //查看拼团
      this.goods_id = goodsId;
      console.log(this.goods_id);
      this.group_type = 3;
    },
    cancel_goods: function(goodsId) {
      //取消拼团
      var _this = this;
      this.$confirm("确认取消该拼团?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          var data = {
            goodsId: goodsId
          };
          _this.base.axios_post(
            data,
            "/goods/supplierCancelGroupsGoodsInfo",
            function(res) {
              if (res.code == 0) {
                _this.page_no = 1;
                _this.get_data();
              }
              _this.$message(res.message);
            }
          );
        })
        .catch(() => {});
    }
  }
};
</script>
