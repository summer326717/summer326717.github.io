<template>
  <div class="content Tocheck">
    <div class="table">
      <table>
        <tr class="bor">
          <th>商品名称</th>
          <th>分类</th>
          <th>子分类</th>
          <th class="number">市场价（元）</th>
          <th class="number">平台价（元）</th>
          <th>提交时间</th>
          <th>操作</th>
        </tr>
        <tr v-for="(item,index) in data_list" :key="index">
          <td style="text-align: left"><img v-if="item.goodsIcon" v-bind:src="item.goodsIcon"><span class="ell">{{item.goodsName}}</span></td>
          <td style="text-align: center">{{item.firstTypeName}}</td>
          <td style="text-align: center">{{item.secondTypeName}}</td>
          <td class="number">{{item.marketPrice}}</td>
          <td class="number">{{item.supplyPrice}}</td>
          <td style="text-align: center">{{item.submitTime}}</td>
          <td style="text-align: center">
            <!--<el-button type="primary" v-on:click="out(item.goodsId)">下架</el-button>-->
            <el-button size="small" type="primary" v-on:click="cancel(item.goodsId)">撤回</el-button>
          </td>
        </tr>
      </table>
      <div class="no_data" v-if="no_data"><img src="../../assets/images/no_data.png"/></div>
      <pagination v-if="data_list!=''&&total_pages>1" :cur='page_no' :all='total_pages' @get_page='turn_page'></pagination>
    </div>
  </div>
</template>
<script>
import pagination from "../common/Pagination";
export default {
  data() {
    return {
      page_no: 1,
      total_pages: 1,
      data_list: [],
      no_data: false
    };
  },
  components: {
    pagination
  },
  created() {
    this.get_data();
  },
  methods: {
    turn_money(value){
      var f = Math.round(value*100)/10000;
      var s = f.toString();
      var rs = s.indexOf('.');
      if (rs < 0) {
        rs = s.length;
        s += '.';
      }
      while (s.length <= rs + 2) {
        s += '0';
      }
      return s;
    },
    turn_page: function(i) {
      this.page_no = i;
      this.get_data();
    },
    /*out: function(goodsId) {
      var _this = this;
      this.$confirm("确认下架该商品?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          var data = {
            goodsState: 0,
            goodsId: goodsId
          };
          _this.base.axios_post(data, "/goods/updateGoodsInfo", function(res) {
            if (res.code == 0) {
              _this.page_no = 1;
              _this.get_data();
            }
            _this.$message(res.message);
          });
        })
        .catch(() => {});
    },*/
    cancel: function(goodsId) {
      var _this = this;
      this.$confirm("确认撤回该商品?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          var data = {
            goodsId: goodsId
          };
          _this.base.axios_post(data, "/goods/supplierUnCommitGoods", function(
            res
          ) {
            if (res.code == 0) {
              _this.page_no = 1;
              _this.get_data();
            }
            _this.$message(res.message);
          });
        })
        .catch(() => {});
    },
    get_data: function() {
      var data = {
        goods_state: 2,
        page_no: this.page_no,
        page_size: 10
      };
      var _this = this;
      this.base.axios_post(data, "/goods/queryGoodsInfoList", function(res) {
        if (res.code == 0) {
          if (res.data) {
            _this.total_pages = res.data.pages;
            for(var i in res.data.list){
              res.data.list[i].marketPrice = _this.turn_money(res.data.list[i].marketPrice);
              res.data.list[i].supplyPrice = _this.turn_money(res.data.list[i].supplyPrice);
            }
            _this.data_list = res.data.list;
            _this.data_list.map(function(x, y) {
              x.submitTime = _this.base.trans_time(x.submitTime, 2);
            });
            _this.no_data = false;
          } else {
            _this.no_data = true;
          }
        } else {
          if (_this.page_no == 1) {
            _this.data_list = [];
          }
          _this.no_data = true;
        }
      });
    }
  }
};
</script>

<style>
  .Tocheck .table .bor>th{
    text-align: center;
  }
  .Tocheck .table table .number{
    text-align: right;
  }
</style>
