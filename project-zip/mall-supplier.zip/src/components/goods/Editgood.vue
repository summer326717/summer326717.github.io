<template>
  <div class="content qqqqq">
    <div class="add_info right_con_addgoods" >
      <p class="return bor">
        <span @click="back">
          <i class="el-icon-caret-left"></i>返回上一页</span>
      </p>
      <div class="info_item">
        <el-row style="padding-left: 20%">
          <el-col :span="24" class="left_nav_addgoods">
            <el-button type="text" size="medium" style="margin-right:3%">基础信息</el-button>
            <span>
              <el-button v-if="!is_spec" size="medium" @click="open_dialog_methods(2)">规格信息</el-button>
              <el-button type="primary" v-if="is_spec" size="medium" @click="open_dialog_methods(2)">规格信息</el-button>
              <el-button v-if="!is_banner" size="medium" @click="open_dialog_methods(3)">轮播图片</el-button>
              <el-button type="primary" v-if="is_banner" size="medium" @click="open_dialog_methods(3)">轮播图片</el-button>
              <el-button v-if="!is_pic_intro" size="medium" @click="open_dialog_methods(5)">图文介绍</el-button>
              <el-button type="primary" v-if="is_pic_intro" size="medium" @click="open_dialog_methods(5)">图文介绍</el-button>
              <el-button v-if="!is_other_info" size="medium" @click="open_dialog_methods(4)">其他信息</el-button>
              <el-button type="primary" v-if="is_other_info" size="medium" @click="open_dialog_methods(4)">其他信息</el-button>
            </span>
          </el-col>
          <el-col :span="24" class="right_con right_con_addgoods">
            <p>
              <span class="base_span">商品名称</span>
              <span class="l_ipt">
                <el-input size="small" v-model="goods_detail_obj.goodsName"></el-input>
              </span>
            </p>
            <p>
              <span class="base_span">分类</span>
              <el-select size="small" v-model="firstType">
                <el-option v-for="item in options" :key="item.typeChinese" :label="item.typeChinese" :value="item.typeId">
                </el-option>
              </el-select>
              <el-select size="small" v-model="secondType">
                <el-option v-for="item in second_menu_list" :key="item.typeChinese" :label="item.typeChinese" :value="item.typeId">
                </el-option>
              </el-select>
            </p>
            <p>
              <span class="base_span">属性</span>
              <el-select size="small" v-model="goods_detail_obj.goodsAttribute">
                <el-option v-for="item in good_attribute_list" :key="item.label" :label="item.label" :value="item.label">
                </el-option>
              </el-select>
            </p>
            <p>
              <span class="base_span">商品品牌</span>
              <span class="l_ipt">
                <el-input size="small" v-model="goods_detail_obj.goodsBrand"></el-input>
              </span>
            </p>
            <p>
              <span class="base_span">市场价（元）</span>
              <span class="s_ipt">
                <el-input size="small" v-model="goods_detail_obj.marketPrice"></el-input>
              </span>
              <span class="base_span" style="text-align: right">平台价（元）</span>
              <span class="s_ipt">
                <el-input size="small" v-model="goods_detail_obj.supplyPrice"></el-input>
              </span>
            </p>
            <p>
              <span class="base_span">商品介绍</span>
              <span class="l_ipt">
                <el-input type="textarea" :rows="2" placeholder="请输入商品介绍" v-model="goods_detail_obj.goodsIntroduce"></el-input>
              </span>
            </p>
            <p style="margin-top: 15px">
              <span class="base_span">缩略图</span>
              <span class="l_ipt">
                <img class="s_img" v-if="goods_detail_obj.goodsIcon" :src="goods_detail_obj.goodsIcon" />
                <form enctype="multipart/form-data" style="display:none" id="uploadForm_default_tea2">
                  <input type="file" @change="upload_img(1)" id="tea_cate_img2" name="file" accept="image/png,image/gif,image/jpeg"/>
                  <input type="hidden" name="goods" value="123456" />
                </form>
                <el-button @click="upload(1)" size="small" type="primary">选择文件</el-button>
              </span>
            </p>
            <p class="next_step">
              <el-button v-if="goodsId==''" v-on:click="save_good_foundation_msg()" size="big" type="primary">保存</el-button>
              <el-button v-else v-on:click="save_good_foundation_msg()" size="big" type="primary">修改</el-button>
            </p>
          </el-col>
        </el-row>
        <el-dialog class="ed" title="" :show-close="false" :visible.sync="open_dialog" width="645px">
        <el-row>
          <el-col :span="24" class="right_con" v-if="dialog_type==2">
            <span style="position: absolute;left: 41%;top:-47px;font-size: 20px;color: #4ba1f1;">规格信息</span>
            <ul style="margin-top: 28px" class="detail">
              <li>
                <el-row>
                  <el-col :span="9">规格</el-col>
                  <el-col :span="2">&nbsp;</el-col>
                  <el-col :span="9">库存量</el-col>
                </el-row>
              </li>
              <li v-for="(item,index) in good_detail_list" :key="index">
                <el-row>
                  <el-col :span="9">{{item.magnitude}}</el-col>
                  <el-col :span="2">&nbsp;</el-col>
                  <el-col :span="9">{{item.stockAmount}}</el-col>
                  <el-col :span="4"><el-button v-on:click="del_detile(index)" size="small" type="primary">删除</el-button></el-col>
                </el-row>
              </li>
              <li>
                <el-row>
                  <el-col style="margin-left: 7%" :span="6" class="tc"><el-input size="small" v-model="magnitude"></el-input></el-col>
                  <el-col :span="5">&nbsp;</el-col>
                  <el-col :span="6" class="tc"><el-input size="small" v-model="stockAmount"></el-input></el-col>
                  <span style="margin-left: 6%"><el-button v-on:click="add_detile" size="small" type="primary">添加</el-button></span>
                </el-row>
              </li>
            </ul>
          </el-col>
          <el-col :span="24" style="margin-left: 0" class="right_con" v-if="dialog_type==3">
            <span style="position: absolute;left: 41%;top: -48px;font-size: 20px;color: #4ba1f1;">轮播图片</span>
            <div style="margin-top: 10px" class="img_list">
              <span style="margin-left: 15px;margin-top: 15px" class="img_list_item" v-for="(item,i) in img_msg" :key="i">
                <img :src="item.urlAddress">
                <span class="close" @click="delete_img(i)">×</span>
              </span>
              <img v-if="max_pic1==1" style="margin-left: 15px;margin-top: 10px" @click="upload(2)" src="../../assets/images/image.png" /></div>
            <form enctype="multipart/form-data" style="display:none" id="uploadForm_default_tea">
              <input type="file" @change="upload_img(2)" id="tea_cate_img" name="file" accept="image/png,image/gif,image/jpeg"/>
              <input type="hidden" name="goods" value="123456" />
            </form>
            <el-row class="warning">
              <el-col :span="4">温馨提示：</el-col>
              <el-col :span="20">
                <p>1、请上传介绍商品详情的图片</p>
                <p>2、图片尺寸为不超过3m的800*800的png、jpg或jpeg格式</p>
              </el-col>
            </el-row>
          </el-col>
          <el-col :span="24"  style="margin-left: 0" class="right_con" v-if="dialog_type==5">
            <span style="position: absolute;left: 41%;top:-46px;font-size: 20px;color: #4ba1f1;">图文介绍</span>
            <div style="margin-top: 10px" class="img_list">
              <span style="margin-left: 15px;margin-top: 15px" class="img_list_item" v-for="(item,i) in pic_intro_list" :key="i">
                <img :src="item.urlAddress">
                <span class="close" @click="delete_intro_img(i)">×</span>
              </span>
              <img v-if="max_pic2==1" style="margin-left: 15px;margin-top: 10px" @click="upload(2)" src="../../assets/images/image.png" /></div>
            <form enctype="multipart/form-data" style="display:none" id="uploadForm_default_tea">
              <input type="file" @change="upload_img(3)" id="tea_cate_img" name="file" accept="image/png,image/gif,image/jpeg"/>
              <input type="hidden" name="goods" value="123456" />
            </form>
            <el-row class="warning">
              <el-col :span="4">温馨提示：</el-col>
              <el-col :span="20">
                <p>1、请上传介绍商品详情的图片</p>
                <p>2、图片尺寸为不超过10m的png、jpg或jpeg格式</p>
              </el-col>
            </el-row>
          </el-col>
          <el-col :span="12" style="margin-left:30%;" class="right_con" v-if="dialog_type==4">
            <span style="position: absolute;left: 41%;top: -30%;font-size: 20px;color: #4ba1f1;">其他信息</span>
            <p style="margin-top: 30px">
              <span>发货时间</span>
              <span>
                <el-radio class="radio" v-model="deliverHour" label='1'>24小时</el-radio>
                <el-radio class="radio" v-model="deliverHour" label='2'>48小时</el-radio>
              </span>
            </p>
            <p>
              <span>7天无理由退款</span>
              <span>
                <el-radio class="radio" v-model="sevenDaysRefund" label='1'>是</el-radio>
                <el-radio class="radio" v-model="sevenDaysRefund" label='2'>否</el-radio>
              </span>
            </p>
          </el-col>
        </el-row>
        <div slot="footer" class="dialog-footer" style="text-align: center">
          <el-button size="small" @click="open_dialog = false">取 消</el-button>
          <el-button size="small" type="primary" @click="save_info">确 定</el-button>
        </div>
      </el-dialog>
      </div>
    </div>
  </div>
</template>

<script>
import base from "../../assets/base";

export default {
  props: ["data_msg"],
  data() {
    return {
      max_pic1: 1,
      max_pic2: 1,
      options: [],
      value: "",
      good_attribute_list: [
        {
          label: "实体商品"
        },
        {
          label: "虚拟商品"
        }
      ],
      img_msg: [], //商品轮播图
      intro_list: [], //商品图文介绍
      firstType: "",
      secondType: "",
      goodsId: "", //商品唯一标识
      stockAmount: "", //商品数量
      soldAmount: 0, //已售数量
      magnitude: "", //尺寸
      good_detail_list: [],
      update_good_detail_list: [],
      deliverHour: "1", //发货时间
      sevenDaysRefund: "1", //是否七天退款
      freeShipping: 1, //是否包邮
      menu_id: 0,
      second_menu_list: [],
      open_dialog: false,
      dialog_type: 1, //1.基础信息，2.规格信息，3.轮播图片，4.其他信息，5.图文介绍
      pic_intro_list: [], //商品图文介绍
      goods_detail_obj: "",
      is_first_load: true,
      is_spec: false, //是否已经填写规则
      is_banner: false, //banner图是否上传
      is_pic_intro: false, //图文介绍是否上传
      is_other_info: false //其他信息是否已提交
    };
  },
  created() {
    this.goodsId = this.$route.query.id;
    this.get_update_basic_info();
    this.select_other_info();
    this.select_img_info();
    this.select_detail_info();
    this.select_intro_info();
  },
  methods: {
    save_info: function() {
      if (this.dialog_type == 2) {
        //规格信息
        this.save_detile();
      }
      if (this.dialog_type == 3) {
        //轮播图片
        this.add_img();
      }
      if (this.dialog_type == 4) {
        //其他信息
        this.add_other();
      }
      if (this.dialog_type == 5) {
        //图文介绍
        this.add_ins_img();
      }
    },
    //修改图文介绍
    add_ins_img: function() {
      if (this.pic_intro_list == "") {
        this.$message("请至少选择一张图");
        return;
      }
      let _this = this;
      this.base.axios_post(
        this.pic_intro_list,
        "/goods/saveImageTextList",
        function(res) {
          _this.$message(res.message);
          if (res.code == 0) {
            _this.open_dialog = false;
            _this.is_pic_intro = true;
          }
        }
      );
    },
    open_dialog_methods: function(type) {
      this.open_dialog = true;
      this.dialog_type = type;
    },
    get_category_list: function() {
      var json = {
        typeMode: 1
      };
      var _this = this;
      this.base.axios_post(json, "/centerConfig/queryGoodsTypeList", function(
        res
      ) {
        if (res.code == 0) {
          _this.options = res.data;
          _this.menu_id = res.data[0].typeId;
          _this.get_right_menu();
        }
      });
    },
    get_right_menu: function() {
      //根据一级菜单显示二级菜单
      var _this = this;
      if (this.menu_id == 0) {
        return;
      }
      let json = {
        typeMode: 2,
        typeId: this.menu_id
      };
      this.base.axios_post(json, "/centerConfig/queryGoodsTypeList", function(
        res
      ) {
        if (res.code == 0) {
          _this.second_menu_list = res.data;
        } else {
          _this.second_menu_list = [];
          _this.$message(res.message);
        }
      });
    },
    back: function() {
      if (this.$route.query.type == 0) {
        this.$router.push("/Instorage");
      } else {
        this.$router.push("/Tostorage");
      }
    },
    //修改基础信息
    save_good_foundation_msg: function() {
      this.goods_detail_obj.firstType = this.firstType;
      this.goods_detail_obj.secondType = this.secondType;
      if (this.goods_detail_obj.goodsName == "") {
        this.$message("商品名称不能为空！");
        return;
      }
      if (this.goods_detail_obj.firstType == "") {
        this.$message("商品第一分类不能为空！");
        return;
      }
      if (this.goods_detail_obj.secondType == "") {
        this.$message("商品第二分类不能为空！");
        return;
      }
      if (this.goods_detail_obj.goodsAttribute == "") {
        this.$message("商品属性不能为空！");
        return;
      }
      if (this.goods_detail_obj.goodsBrand == "") {
        this.$message("商品品牌不能为空！");
        return;
      }
      if (this.goods_detail_obj.marketPrice == "") {
        this.$message("商品市场价不能为空！");
        return;
      }
      if (!Number(this.goods_detail_obj.marketPrice)) {
        this.$message("请输入正确商品市场价格");
        return;
      }
      if (this.goods_detail_obj.supplyPrice == "") {
        this.$message("商品平台价不能为空！");
        return;
      }
      if (!Number(this.goods_detail_obj.supplyPrice)) {
        this.$message("请正确输入平台价！");
        return;
      }
      if (
        parseFloat(this.goods_detail_obj.supplyPrice) >
        parseFloat(this.goods_detail_obj.marketPrice)
      ) {
        this.$message("平台价不能高于市场价!");
        return;
      }
      if (this.goods_detail_obj.goodsIntroduce == "") {
        this.$message("商品介绍不能为空！");
        return;
      }
      if (this.goods_detail_obj.goodsIcon == "") {
        this.$message("商品缩略图不能为空！");
        return;
      }
      var json = this.goods_detail_obj;
      json.marketPrice = this.base.mul(this.goods_detail_obj.marketPrice, 100);
      json.supplyPrice = this.base.mul(this.goods_detail_obj.supplyPrice, 100);
      var _this = this;
      if (this.goodsId == "") {
        this.base.axios_post(json, "/goods/saveGoodsInfo", function(res) {
          if (res.code == 0) {
            _this.goods_detail_obj.goodsId = res.data;
            _this.goods_detail_obj.marketPrice = json.marketPrice / 100;
            _this.goods_detail_obj.supplyPrice = json.supplyPrice / 100;
            _this.goodsId = res.data;
            _this.dialog_type = 0;
            _this.$message("保存成功，请填写完善其他辅助信息");
          } else {
            _this.$message(res.message);
          }
        });
      } else {
        this.base.axios_post(json, "/goods/updateGoodsInfo", function(res) {
          _this.$message(res.message);
          if (res.code == 0) {
            _this.goods_detail_obj.marketPrice = json.marketPrice / 100;
            _this.goods_detail_obj.supplyPrice = json.supplyPrice / 100;
          }
        });
      }
    },
    //添加单挑商品规格信息
    add_detile: function() {
      if (this.stockAmount && this.magnitude) {
        this.good_detail_list.push({
          goodsId: this.goodsId,
          stockAmount: this.stockAmount, //商品数量
          soldAmount: 0, //已售数量
          colour: "",
          magnitude: this.magnitude, //尺寸
          dr: 0, //判断是否要删除0.删除1.不删除
          isnew: true //判断是否为新增的
        });
        this.magnitude = "";
        this.stockAmount = "";
      } else {
        this.$message("请完善信息后添加");
      }
    },
    //删除一条商品规格信息
    del_detile: function(data) {
      if (!this.good_detail_list[data].isnew) {
        this.good_detail_list[data].dr = 0;
        this.update_good_detail_list.push(this.good_detail_list[data]);
        this.good_detail_list.splice(data, 1);
        console.log(this.update_good_detail_list);
        console.log(this.good_detail_list);
      } else {
        this.good_detail_list.splice(data, 1);
      }
    },
    //修改商品规格信息
    save_detile: function() {
      var json = [];
      /*for (var i = 0; i < this.good_detail_list.length; i++) {
        if (this.good_detail_list[i].isnew) {
          json.push(this.good_detail_list[i]);
        }
      }*/
      json.push.apply(json, this.good_detail_list);
      if (this.stockAmount != "" && this.magnitude != "") {
        json.push({
          stockAmount: this.stockAmount,
          magnitude: this.magnitude,
          colour: "",
          dr: 0,
          goodsId: this.goodsId,
          isnew: true,
          soldAmount: 0
        });
      }
      if (json == "") {
        this.$message("请点击添加按钮！");
        return;
      } else {
        var _this = this;
        this.base.axios_post(json, "/goods/saveGoodsSpecifications", function(
          res
        ) {
          _this.$message(res.message);
          if (res.code == 0) {
            _this.open_dialog = false;
            _this.is_spec = true;
          }
        });
      }
    },
    //修改图片信息
    add_img: function() {
      if (this.img_msg == "") {
        this.$message("请至少选择一张图");
        return;
      }
      let _this = this;
      this.base.axios_post(this.img_msg, "/goods/saveGoodsEnclosure", function(
        res
      ) {
        _this.$message(res.message);
        if (res.code == 0) {
          _this.open_dialog = false;
          _this.is_banner = true;
        }
      });
    },
    //保存其它信息
    add_other: function() {
      var json = {
        actionType: 1,
        goodsId: this.goodsId,
        deliverHour: parseInt(this.deliverHour), //发货时间
        sevenDaysRefund: parseInt(this.sevenDaysRefund), //是否七天退款
        freeShipping: 1, //是否包邮
        freeProvince: "" //包邮城市  逗号分隔
      };
      var _this = this;
      this.base.axios_post(json, "/goods/updateGoodsAuxiliary", function(res) {
        _this.$message(res.message);
        if (res.code == 0) {
          _this.open_dialog = false;
          _this.is_other_info = true;
        }
      });
    },
    upload: function(type) {
      if (type == 1) {
        var file = document.getElementById("tea_cate_img2");
      } else {
        var file = document.getElementById("tea_cate_img");
      }
      file.click();
    },
    upload_img: function(type) {
      let _this = this;
      if (type == 1) {
        //基础信息的缩略图
        var $ipt_file = document.getElementById("tea_cate_img2").files[0];
        console.log($ipt_file);
      }
      if (type == 2) {
        //轮播图
        var $ipt_file = document.getElementById("tea_cate_img").files[0];
        console.log($ipt_file);
      }
      if (type == 3) {
        //商品介绍
        var $ipt_file = document.getElementById("tea_cate_img").files[0];
        console.log($ipt_file);
      }
      if ($ipt_file.size / 1024 > 10000) {
        this.$message("图片大小不能超过10M");
        return;
      }
      this.base.msg.loader();
      var option = {
        url: "/oss/uploadGoodsFile",
        type: "post",
        dataType: "json",
        success: function(data) {
          console.log(data);
          if (type == 1) {
            _this.goods_detail_obj.goodsIcon = data.data;
            console.log(_this.goods_detail_obj.goodsIcon);
            console.log("基础信息的商品缩略图上传");
            document.getElementById("tea_cate_img2").value = "";
          }
          if (type == 2) {
            let name_arr = $ipt_file.name.split(".");
            let obj = {
              fileName: $ipt_file.name,
              fileSize: $ipt_file.size,
              fileType: 3, //1小图标 2轮播图 3详情图片
              suffixName: name_arr[name_arr.length - 1],
              thumbnailAddress: data.data,
              urlAddress: data.data,
              goodsId: _this.goodsId
            };

            _this.img_msg.push(obj);
            if (_this.img_msg.length >= 15) {
              _this.max_pic1 = -1;
            }
            console.log("商品轮播图片");
            document.getElementById("tea_cate_img").value = "";
          }

          if (type == 3) {
            let name_arr = $ipt_file.name.split(".");
            let obj = {
              fileName: $ipt_file.name,
              fileSize: $ipt_file.size,
              fileType: 3, //1小图标 2轮播图 3详情图片
              suffixName: name_arr[name_arr.length - 1],
              urlAddress: data.data,
              goodsId: _this.goodsId
            };

            _this.pic_intro_list.push(obj);
            if (_this.pic_intro_list.length >= 15) {
              _this.max_pic1 = -1;
            }
            console.log("图文信息图片");
            document.getElementById("tea_cate_img").value = "";
          }
          _this.base.msg.hide();
        },
        error: function(err) {
          _this.base.msg.hide();
          _this.$message("图片上传失败");
        }
      };
      if (type == 1) {
        jQuery("#uploadForm_default_tea2").ajaxSubmit(option);
      } else {
        jQuery("#uploadForm_default_tea").ajaxSubmit(option);
      }
      return false;
    },
    //查询商品规格信息
    select_detail_info: function() {
      let json = {
        goodsId: this.goodsId
      };
      let _this = this;
      this.base.axios_post(json, "/goods/queryGoodsSpecifications", function(
        res
      ) {
        if (res.code == 0) {
          _this.good_detail_list = res.data;
          if (
            _this.good_detail_list != null &&
            _this.good_detail_list.length != 0
          ) {
            _this.is_spec = true;
          }
        } else {
          _this.good_detail_list = [];
        }
      });
    },
    //查询商品轮播图片信息
    select_img_info: function() {
      let json = {
        goodsId: this.goodsId
      };
      let _this = this;
      this.base.axios_post(json, "/goods/queryGoodsEnclosure", function(res) {
        if (res.code == 0 && res.data != null && res.data.length != 0) {
          _this.img_msg = res.data;
          _this.is_banner = true;
        } else {
          _this.img_msg = [];
        }
      });
    },
    //查询商品图文信息
    select_intro_info: function() {
      let json = {
        goodsId: this.goodsId
      };
      let _this = this;
      this.base.axios_post(json, "/goods/queryGoodsImgText", function(res) {
        if (res.code == 0 && res.data != null && res.data.length != 0) {
          _this.pic_intro_list = res.data;
          _this.is_pic_intro = true;
        } else {
          _this.pic_intro_list = [];
        }
      });
    },
    delete_img: function(i) {
      console.log(this.img_msg);
      this.img_msg.splice(i, 1);
      if (this.img_msg.length < 15) {
        this.max_pic1 = 1;
      } else if (this.img_msg.length >= 15) {
        this.max_pic1 = -1;
      }
      if (this.pic_intro_list.length < 15) {
        this.max_pic1 = 1;
      } else if (this.pic_intro_list.length >= 15) {
        this.max_pic1 = -1;
      }
    },
    delete_intro_img: function(i) {
      console.log(this.pic_intro_list);
      this.pic_intro_list.splice(i, 1);
    },
    //查询商品其他信息
    select_other_info: function() {
      let json = {
        goodsId: this.goodsId
      };
      let _this = this;
      this.base.axios_post(json, "/goods/queryGoodsAuxiliary", function(res) {
        if (res.code == 0 && res.data != null && res.data.length != 0) {
          _this.deliverHour = res.data.deliverHour.toString();
          _this.sevenDaysRefund = res.data.sevenDaysRefund.toString();
          _this.is_other_info = true;
        } else {
          _this.deliverHour = "1";
          _this.sevenDaysRefund = "1";
        }
      });
    },
    //查询商品的基础信息
    get_update_basic_info: function() {
      let json = {
        goodsId: this.goodsId
      };
      let _this = this;
      this.base.axios_post(json, "/goods/queryGoodsInfoByGoodsId", function(
        res
      ) {
        if (res.code == 0) {
          _this.goods_detail_obj = res.data;
          _this.firstType = res.data.firstType;
          _this.secondType = res.data.secondType;
          _this.goods_detail_obj.marketPrice =
            _this.goods_detail_obj.marketPrice / 100;
          _this.goods_detail_obj.supplyPrice =
            _this.goods_detail_obj.supplyPrice / 100;
          _this.get_category_list();
        }
      });
    }
  },
  watch: {
    firstType: function(value, old) {
      this.menu_id = this.firstType;
      if (!this.is_first_load) {
        this.secondType = "";
      } else {
        this.is_first_load = false;
      }
      this.get_right_menu();
    }
  }
};
</script>

<style lang="less">
.qqqqq {
  .warning {
    line-height: 25px;
    padding-top: 20px;
    color: #686868;
  }

  .content .add_info {
    color: #222222;
    font-size: 14px;
    background: #ffffff;
    border-radius: 10px;
  }

  .content .add_info .return {
    cursor: pointer;
    color: #808080;
    padding: 15px 0 15px 30px;
  }
  .content .ed .el-dialog--small {
    width: 640px;
  }
  .content .add_info .info_item {
    padding: 30px 0;
  }
  .content .add_info .right_con_addgoods {
    padding-left: 30%;
  }
  .content .add_info .left_nav_addgoods {
    text-align: center;
    padding-bottom: 20px;
  }

  .content .add_info .left_nav_addgoods .btn {
    cursor: pointer;
    font-size: 14px;
    color: #808080;
    text-align: center;
  }

  .content .add_info .left_nav_addgoods .active {
    color: #ffffff;
    width: 90px;
    line-height: 30px;
    background: #62b6f7;
    border-radius: 10px;
  }
  .content .add_info .base_span {
    width: 120px;
    display: inline-block;
  }

  .content .add_info .l_ipt {
    width: 347px;
    display: inline-block;
  }

  .content .add_info .s_ipt {
    width: 167px;
    display: inline-block;
  }

  .next_step {
    width: 100%;
    margin-top: 60px;
    padding-left: 30%;
  }
  .img_list img {
    vertical-align: middle;
    margin-right: 20px;
    width: 100px;
  }
  .img_list .img_list_item {
    width: 100px;
    height: 100px;
    overflow: hidden;
    vertical-align: middle;
  }
  .img_list .img_list_item img {
    width: 100%;
  }
  .s_img {
    width: 100px;
    vertical-align: middle;
  }
}
</style>
