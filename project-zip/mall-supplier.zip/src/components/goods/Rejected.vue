<template>
  <div class="content">
    <div v-if="goods_do_type==1" class="table">
      <table>
        <tr class="bor">
          <th>商品名称</th>
          <th>驳回意见</th>
          <th>驳回时间</th>
          <th>操作</th>
        </tr>
        <tr v-for="(item,index) in data_list" :key="index">
          <td style="text-align: left"><img v-if="item.goodsIcon" v-bind:src="item.goodsIcon"><span class="ell">{{item.goodsName}}</span></td>
          <td>{{item.finalRejection}}</td>
          <td>{{item.examineTime}}</td>
          <td>
            <el-button size="small" type="primary" v-on:click="del(item.goodsId)">删除</el-button>
            <el-button size="small" type="danger" v-on:click="reinstorage(item.goodsId)">重新入库</el-button>
          </td>
        </tr>
      </table>
      <div class="no_data" v-if="no_data"><img src="../../assets/images/no_data.png"/></div>
      <pagination v-if="data_list!=''&&total_pages>1" :cur='page_no' :all='total_pages' @get_page='turn_page'></pagination>
    </div>
    <updategood v-bind:data_msg="data_msg" v-on:get_type="get_type" v-if="goods_do_type==2"></updategood>
  </div>
</template>
<script>
import pagination from "../common/Pagination";
import updategood from "./addgood.vue";
import base from "../../assets/base";
export default {
  data() {
    return {
      page_no: 1,
      total_pages: 1,
      data_list: [],
      goods_do_type: 1,
      data_msg: [], //修改货物信息所传递的信息
      no_data: false
    };
  },
  components: {
    pagination,
    updategood
  },
  created() {
    this.get_data();
  },
  methods: {
    turn_page: function(i) {
      this.page_no = i;
      this.get_data();
    },
    get_type: function(data) {
      this.goods_do_type = data;
    },
    reinstorage: function(goodsId) {
      var _this = this;
      this.$confirm('确认重新入库该商品?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          var data = {
            goodsState: 1,
            goodsId: goodsId
          };
          _this.base.axios_post(data, "/goods/updateGoodsInfo", function(res) {
            if (res.code == 0) {
              base.alerter("重新入库成功");
              _this.page_no = 1;
              _this.get_data();
            } else {
              base.alerter(res.message);
            }
          });
        }).catch(() => {
        });
    },
    del: function(goodsId) {
      var _this = this;
      this.$confirm('确认删除该商品?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          var data = {
            dr: 0,
            goodsId: goodsId
          };
          _this.base.axios_post(data, "/goods/updateGoodsInfo", function(res) {
            if (res.code == 0) {
              base.alerter("删除成功");
              _this.page_no = 1;
              _this.get_data();
            } else {
              base.alerter(res.message);
            }
          });
        }).catch(() => {
        });
    },
    get_data: function() {
      var data = {
        goods_state: 3,
        page_no: this.page_no,
        page_size: 10
      };
      var _this = this;
      this.base.axios_post(data, "/goods/queryGoodsInfoList", function(res) {
        if (res.code == 0) {
          if (res.data) {
            _this.data_list = res.data.list;
            _this.total_pages = res.data.pages;
            _this.data_list.map(function(x, y) {
              x.examineTime = _this.base.trans_time(x.examineTime, 2);
            });
            _this.no_data = false;
          } else {
            _this.no_data = true;
          }
        } else {
          if (_this.page_no == 1) {
            _this.data_list = [];
          }
          _this.no_data = true;
        }
      });
    }
  }
};
</script>
