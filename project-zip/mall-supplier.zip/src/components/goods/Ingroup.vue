<template>
  <div class="table Ingroup">
    <table v-if="group_type==1">
      <tr class="bor">
        <th style="width:410px">商品名称</th>
        <th class="number">市场价</th>
        <th class="number">平台价</th>
        <th class="number">库存量</th>
        <th class="number">拼团人数</th>
        <th>操作</th>
      </tr>
      <tr v-for="(item,index) in data_list" :key="index">
        <td style="text-align: left;overflow: hidden;text-overflow: ellipsis;white-space: nowrap"><img :src="item.goodsIcon" style="margin-right: 3px;vertical-align: middle">{{item.goodsName}}</td>
        <td class="number">{{item.marketPrice}}</td>
        <td class="number">{{item.price}}</td>
        <td class="number">{{item.stockAmount}}</td>
        <td class="number">{{item.joinNum}}</td>
        <td style="text-align: center">
          <el-button type="success" size="small" class="mtb5" v-on:click="loook_goods(item.goodsId)">查看拼团</el-button>
          <el-button type="danger" size="small" class="mtb5" v-on:click="cancel_goods(item.goodsId)">取消拼团</el-button>
         <!-- <el-button type="danger" size="small" class="mtb5" v-on:click="out_goods(item.goodsId)">下架</el-button>   -->
        </td>
      </tr>
    </table>
    <div class="no_data" v-if="no_data"><img src="../../assets/images/no_data.png"/></div>
    <pagination v-if="data_list!=''&&total_pages>1&&group_type==1" :cur='page_no' :all='total_pages' @get_page='turn_page'></pagination>
    <begingroup v-if="group_type==2" :goodsId='goods_id' @group_type="get_type"></begingroup>
    <lookgroup v-if="group_type==3" :goodsId='goods_id' @group_type="get_type"></lookgroup>
  </div>
</template>
<script>
import pagination from "../common/Pagination";
import begingroup from "./common/Begingroup";
import lookgroup from "./common/Lookgroup";
export default {
  data() {
    return {
      page_no: 1,
      total_pages: 1,
      data_list: [],
      no_data: false,
      goods_id: "",
      group_type: 1 //1.页面数据2.发起拼团3.查看拼团
    };
  },
  components: {
    pagination,
    begingroup,
    lookgroup
  },
  created() {
    this.get_data();
  },
  methods: {
    turn_money(value){
      var f = Math.round(value*100)/10000;
      var s = f.toString();
      var rs = s.indexOf('.');
      if (rs < 0) {
        rs = s.length;
        s += '.';
      }
      while (s.length <= rs + 2) {
        s += '0';
      }
      return s;
    },
    get_type: function(i) {
      this.group_type = i;
    },
    turn_page: function(i) {
      this.page_no = i;
      this.get_data();
    },
    get_data: function() {
      //查询列表
      var data = {
        page_no: this.page_no,
        page_size: 10
      };
      var _this = this;
      this.base.axios_post(data, "/goods/supplierQryGroupsGoodsInfo", function(res) {
        if (res.code == 0) {
          if (res.data) {
            for(var i in res.data.list){
              res.data.list[i].marketPrice = _this.turn_money(res.data.list[i].marketPrice);
              res.data.list[i].price = _this.turn_money(res.data.list[i].price);
            }
            _this.data_list = res.data.list;
            _this.total_pages = res.data.pages;
            _this.no_data = false;
          } else {
            _this.no_data = true;
          }
        } else {
          if (_this.page_no == 1) {
            _this.data_list = [];
          }
          _this.no_data = true;
        }
      });
    },
    out_goods: function(goodsId) {
      //下架商品
      var _this = this;
      this.$prompt("请输入下架原因?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
      })
        .then(({ value }) => {
          var data = {
            goodsId: goodsId,
            reason: value
          };
          _this.base.axios_post(data, "/goods/offGoodsShelf", function(res) {
            if (res.code == 0) {
              _this.page_no = 1;
              _this.get_data();
            }
            _this.$message(res.message);
          });
        })
        .catch(() => {});
    },
    go_to_goods: function(goodsId) {
      //发起拼团
      this.goods_id = goodsId;
      this.group_type = 2;
    },
    loook_goods: function(goodsId) {
      //查看拼团
      this.goods_id = goodsId;
      console.log(this.goods_id);
      this.group_type = 3;
    },
    cancel_goods: function(goodsId) {
      //取消拼团
      var _this = this;
      this.$confirm("确认取消该拼团?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          var data = {
            goodsId: goodsId
          };
          _this.base.axios_post(
            data,
            "/goods/supplierCancelGroupsGoodsInfo",
            function(res) {
              if (res.code == 0) {
                _this.page_no = 1;
                _this.get_data();
              }
              _this.$message(res.message);
            }
          );
        })
        .catch(() => {});
    }
  }
};
</script>
<style>
  .Ingroup .bor>th{
    text-align: center;
  }
  .Ingroup table .number{
    text-align: right;
  }
</style>
