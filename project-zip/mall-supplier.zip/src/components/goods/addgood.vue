<template>
  <div class="content addgood">
    <div class="add_info" >
      <p class="return bor">
        <span @click="back">
          <i class="el-icon-caret-left"></i>返回上一页</span>
      </p>
      <div class="info_item">
        <el-row>
          <span class="left_nav_addgoods" style="color:#20a0ff;margin-left: 15%;float: left">基础信息</span>
          <el-col :span="18" class="left_nav_addgoods" style="margin-left: 10%;width: 46%">
            <span v-if="dialog_type!=1">
              <el-button v-if="!is_spec" size="medium" @click="open_dialog_methods(2)">规格信息</el-button>
              <el-button type="primary" v-if="is_spec" size="medium" @click="open_dialog_methods(2)">规格信息</el-button>
              <el-button v-if="!is_banner" size="medium" @click="open_dialog_methods(3)">轮播图片</el-button>
              <el-button type="primary" v-if="is_banner" size="medium" @click="open_dialog_methods(3)">轮播图片</el-button>
              <el-button v-if="!is_pic_intro" size="medium" @click="open_dialog_methods(5)">图文介绍</el-button>
              <el-button type="primary" v-if="is_pic_intro" size="medium" @click="open_dialog_methods(5)">图文介绍</el-button>
              <el-button v-if="!is_other_info" size="medium" @click="open_dialog_methods(4)">其他信息</el-button>
              <el-button type="primary" v-if="is_other_info" size="medium" @click="open_dialog_methods(4)">其他信息</el-button>
            </span>
          </el-col>
          <el-col :span="24" class="right_con right_con_addgoods" style="padding-left: 27%">
            <p>
              <span class="base_span">商品名称</span>
              <span class="l_ipt">
                <el-input size="small" v-model="good_foundation_msg.goodsName"></el-input>
              </span>
            </p>
            <p>
              <span class="base_span">分类</span>
              <el-select size="small" v-model="firstType" @change="first_menu_change">
                <el-option v-for="item in options" :key="item.typeChinese" :label="item.typeChinese" :value="item.typeId">
                </el-option>
              </el-select>
              <el-select size="small" v-model="secondType">
                <el-option v-for="item in second_menu_list" :key="item.typeChinese" :label="item.typeChinese" :value="item.typeId">
                </el-option>
              </el-select>
            </p>
            <p>
              <span class="base_span">属性</span>
              <el-select size="small" v-model="good_foundation_msg.goodsAttribute">
                <el-option v-for="item in good_attribute_list" :key="item.label" :label="item.label" :value="item.label">
                </el-option>
              </el-select>
            </p>
            <p>
              <span class="base_span">商品品牌</span>
              <span class="l_ipt">
                <el-input size="small" v-model="good_foundation_msg.goodsBrand"></el-input>
              </span>
            </p>
            <p>
              <span class="base_span">市场价（元）</span>
              <span class="s_ipt">
                <el-input size="small" v-model="good_foundation_msg.marketPrice"></el-input>
              </span>
              <span class="base_span">平台价（元）</span>
              <span class="s_ipt">
                <el-input size="small" v-model="good_foundation_msg.supplyPrice"></el-input>
              </span>
            </p>
            <p>
              <span class="base_span">商品介绍</span>
              <span class="l_ipt">
                <el-input type="textarea" :rows="2" placeholder="请输入商品介绍" v-model="good_foundation_msg.goodsIntroduce"></el-input>
              </span>
            </p>
            <p>
              <span class="base_span">缩略图</span>
              <span class="l_ipt">
                <img class="s_img" v-if="good_foundation_msg.goodsIcon" :src="good_foundation_msg.goodsIcon" />
                <form enctype="multipart/form-data" style="display:none" id="uploadForm_default_tea2">
                  <input type="file" @change="upload_img(1)" id="tea_cate_img2" name="file" accept="image/png,image/gif,image/jpeg"/>
                  <input type="hidden" name="goods" value="123456" />
                </form>
                <el-button @click="upload(1)" size="small" type="primary">选择文件</el-button>
              </span>
            </p>
            <p class="next_step tc">
              <el-button v-if="goodsId==''" v-on:click="save_good_foundation_msg()" size="big" type="primary">保存</el-button>
              <el-button v-else v-on:click="save_good_foundation_msg()" size="big" type="primary">修改</el-button>
            </p>
          </el-col>
        </el-row>
        <el-dialog title="" :visible.sync="open_dialog" center :show-close="false" width="665px">
          <el-row>
            <el-col :span="24" class="right_con" v-if="dialog_type==2" >
              <span style="position: absolute;left: 41%;top:-47px;font-size: 20px;color: #4ba1f1;margin: -13px 0">规格信息</span>
              <ul class="detail">
                <li>
                  <el-row>
                    <el-col :span="4">&nbsp;</el-col>
                    <el-col :span="7">规格</el-col>
                    <el-col :span="2">&nbsp;</el-col>
                    <el-col :span="7">库存量</el-col>
                  </el-row>
                </li>
                <li v-for="(item,index) in good_detail_list" :key="index">
                  <el-row>
                    <el-col :span="4">&nbsp;</el-col>
                    <el-col :span="7">{{item.magnitude}}</el-col>
                    <el-col :span="2">&nbsp;</el-col>
                    <el-col :span="2">{{item.stockAmount}}</el-col>
                    <el-col :span="4"><el-button v-on:click="del_detile(index)" size="small" type="primary">删除</el-button></el-col>
                  </el-row>
                </li>
                <li>
                  <el-row>
                    <el-col :span="4">&nbsp;</el-col>
                    <el-col :span="7" class="tc"><el-input size="small" v-model="magnitude"></el-input></el-col>
                    <el-col :span="2">&nbsp;</el-col>
                    <el-col :span="7" class="tc"><el-input size="small" v-model="stockAmount"></el-input></el-col>
                    <el-col :span="4"><el-button v-on:click="add_detile" size="small" type="primary">添加</el-button></el-col>
                  </el-row>
                </li>
              </ul>
            </el-col>
            <el-col :span="24" class="right_con" v-if="dialog_type==3">
              <span style="position: absolute;left: 41%;top: -48px;font-size: 20px;color: #4ba1f1;margin: -13px 0">轮播图片</span>
              <div class="img_list" style="margin-left: 20px">
                <span class="img_list_item" v-for="(item,i) in img_msg" :key="i">
                  <img :src="item.urlAddress">
                  <span class="close" @click="delete_img(i)">×</span>
                </span>
                <img @click="upload(2)" src="../../assets/images/image.png" />
              </div>
              <form enctype="multipart/form-data" style="display:none" id="uploadForm_default_tea">
                <input type="file" @change="upload_img(2)" id="tea_cate_img" name="file" accept="image/png,image/gif,image/jpeg"/>
                <input type="hidden" name="goods" value="123456" />
              </form>
              <el-row class="warning" style="margin-left: 25px">
                <el-col :span="4">温馨提示：</el-col>
                <el-col :span="20">
                  <p>1、请上传介绍商品详情的图片</p>
                  <p>2、图片尺寸为不超过3m的800*800的jpg或jpeg格式</p>
                </el-col>
              </el-row>
            </el-col>
            <el-col :span="24" class="right_con" v-if="dialog_type==5">
              <span style="position: absolute;left: 41%;top: -48px;font-size: 20px;color: #4ba1f1;margin: -13px 0">图文信息</span>
              <div class="img_list" style="margin-left: 20px">
              <span class="img_list_item" v-for="(item,i) in pic_intro_list" :key="i">
                <img :src="item.urlAddress">
                <span class="close" @click="delete_intro_img(i)">×</span>
              </span>
                <img @click="upload(2)" src="../../assets/images/image.png" /></div>
              <form enctype="multipart/form-data" style="display:none" id="uploadForm_default_tea">
                <input type="file" @change="upload_img(3)" id="tea_cate_img" name="file" accept="image/png,image/gif,image/jpeg"/>
                <input type="hidden" name="goods" value="123456" />
              </form>
              <el-row class="warning" style="margin-left: 25px">
                <el-col :span="4">温馨提示：</el-col>
                <el-col :span="20">
                  <p>1、请上传介绍商品详情的图片</p>
                  <p>2、图片尺寸为不超过10m的jpg或jpeg格式</p>
                </el-col>
              </el-row>
            </el-col>
            <el-col :span="24" class="right_con" v-if="dialog_type==4">
              <span style="position: absolute;left: 41%;top: -48px;font-size: 20px;color: #4ba1f1;margin: -13px 0">其他信息</span>
              <el-col :span="4">&nbsp;</el-col>
              <p>
                <span>发货时间</span>
                <el-col :span="2">&nbsp;</el-col>
                <span>
                <el-radio class="radio" v-model="deliverHour" label='1'>24小时</el-radio>
                <el-radio class="radio" v-model="deliverHour" label='2'>48小时</el-radio>
              </span>
              </p>
              <el-col :span="4">&nbsp;</el-col>
              <p>
                <span>7天无理由退款</span>
                <el-col :span="2">&nbsp;</el-col>
                <span>
                <el-radio class="radio" v-model="sevenDaysRefund" label='1'>是</el-radio>
                <el-radio class="radio" v-model="sevenDaysRefund" label='2'>否</el-radio>
              </span>
              </p>
              <!--<p>
                <span>配送地址</span>
                <span>
                  <el-checkbox :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">全选</el-checkbox>
                  <div style="margin: 15px 0;"></div>
                  <el-checkbox-group v-model="checkedCities" @change="handleCheckedCitiesChange">
                    <el-checkbox v-for="city in cities" :label="city" :key="city">{{city}}</el-checkbox>
                  </el-checkbox-group>
                </span>
              </p>-->
            </el-col>
          </el-row>
          <div slot="footer" class="dialog-footer">
            <el-button size="small" @click="open_dialog = false">取 消</el-button>
            <el-button size="small" type="primary" @click="save_info">确 定</el-button>
          </div>
        </el-dialog>
      </div>
    </div>
  </div>
</template>

<script>
  import base from "../../assets/base";

  export default {
    props: ["data_msg"],
    data() {
      return {
        options: [],
        value: "",
        checkAll: true,
        checkedCities: [],
        isIndeterminate: true,
        cities: ["上海", "北京", "广州", "深圳"], //配送地址
        good_attribute_list: [
          {
            label: "实体商品"
          },
          {
            label: "虚拟商品"
          }
        ],
        img_msg: [],
        good_foundation_msg_change: {},
        good_foundation_msg: {
          goodsName: "", //商品名称
          firstType: "", //分类
          secondType: "",
          goodsAttribute: "实体商品", //属性
          goodsBrand: "", //商品品牌
          goodsIcon: "", //商品缩略图
          marketPrice: "", //市场价
          supplyPrice: "", //供货价
          goodsIntroduce: "" //商品介绍
        },
        firstType: "",
        secondType: "",
        goodsId: "", //商品唯一标识
        stockAmount: "", //商品数量
        soldAmount: 0, //已售数量
        magnitude: "", //尺寸
        good_detail_list: [],
        update_good_detail_list: [],
        good_img: [], //图片数组
        img_list: [],
        deliverHour: "1", //发货时间
        sevenDaysRefund: "1", //是否七天退款
        freeShipping: 1, //是否包邮
        menu_id: 0,
        second_menu_list: [],
        open_dialog: false,
        dialog_type: 1, //1.基础信息，2.规格信息，3.轮播图片，4.其他信息，5.图文介绍
        pic_intro_list: [],
        is_spec: false, //是否已经填写规则
        is_banner: false, //banner图是否上传
        is_pic_intro: false, //图文介绍是否上传
        is_other_info: false, //其他信息是否已提交
      };
    },
    created() {
      this.get_category_list();
    },
    methods: {
      delete_img: function(i) {
        console.log(this.img_msg);
        this.img_msg.splice(i, 1);
      },
      delete_intro_img: function(i) {
        console.log(this.pic_intro_list);
        this.pic_intro_list.splice(i, 1);
      },
      save_info: function() {
        if (this.dialog_type == 2) {
          //规格信息
          this.save_detile();
        }
        if (this.dialog_type == 3) {
          //轮播图片
          this.add_img();
        }
        if (this.dialog_type == 4) {
          //其他信息
          this.add_other();
        }
        if (this.dialog_type == 5) {
          //图文介绍
          this.add_ins_img();
        }
      },
      add_ins_img: function() {
        //图文介绍
        if (this.pic_intro_list == "") {
          this.$message("请至少选择一张图");
          return;
        }
        let _this = this;
        this.base.axios_post(
          this.pic_intro_list,
          "/goods/saveImageTextList",
          function(res) {
            _this.$message(res.message);
            if (res.code == 0) {
              _this.open_dialog = false;
              _this.is_pic_intro = true;
            }
          }
        );
      },
      open_dialog_methods: function(type) {
        this.open_dialog = true;
        this.dialog_type = type;
      },
      get_category_list: function() {
        var json = {
          typeMode: 1
        };
        var _this = this;
        this.base.axios_post(json, "/centerConfig/queryGoodsTypeList", function(
          res
        ) {
          if (res.code == 0) {
            _this.options = res.data;
            _this.menu_id = res.data[0].typeId;
            _this.get_right_menu();
          }
        });
      },
      get_right_menu: function() {
        //根据一级菜单显示二级菜单
        var _this = this;
        if (this.menu_id == 0) {
          return;
        }
        let json = {
          typeMode: 2,
          typeId: this.menu_id
        };
        this.base.axios_post(json, "/centerConfig/queryGoodsTypeList", function(
          res
        ) {
          if (res.code == 0) {
            _this.second_menu_list = res.data;
          } else {
            _this.second_menu_list = [];
            _this.$message(res.message);
          }
        });
      },
      back: function() {
        this.$router.push("/Tostorage");
      },
      handleCheckAllChange(event) {
        this.checkedCities = event.target.checked ? this.cities : [];
        this.isIndeterminate = false;
      },
      handleCheckedCitiesChange(value) {
        let checkedCount = value.length;
        this.checkAll = checkedCount === this.cities.length;
        this.isIndeterminate =
          checkedCount > 0 && checkedCount < this.cities.length;
      }, //保存基础信息
      save_good_foundation_msg: function() {
        this.good_foundation_msg.firstType = this.firstType;
        this.good_foundation_msg.secondType = this.secondType;
        if (this.good_foundation_msg.goodsName == "") {
          this.$message("商品名称不能为空！");
          return;
        }
        if (this.good_foundation_msg.firstType == "") {
          this.$message("商品第一分类不能为空！");
          return;
        }
        if (this.good_foundation_msg.secondType == "") {
          this.$message("商品第二分类不能为空！");
          return;
        }
        if (this.good_foundation_msg.goodsAttribute == "") {
          this.$message("商品属性不能为空！");
          return;
        }
        if (this.good_foundation_msg.goodsBrand == "") {
          this.$message("商品品牌不能为空！");
          return;
        }
        if (this.good_foundation_msg.marketPrice == "") {
          this.$message("商品市场价不能为空！");
          return;
        }
        if (!Number(this.good_foundation_msg.marketPrice)) {
          this.$message("请输入正确商品市场价格");
          return;
        }
        if (this.good_foundation_msg.supplyPrice == "") {
          this.$message("商品平台价不能为空！");
          return;
        }
        if (!Number(this.good_foundation_msg.supplyPrice)) {
          this.$message("请正确输入商品平台价！");
          return;
        }
        if (parseFloat(this.good_foundation_msg.supplyPrice) > parseFloat(this.good_foundation_msg.marketPrice)) {
          this.$message("平台价不能高于市场价！");
          return;
        }
        if (this.good_foundation_msg.goodsIntroduce == "") {
          this.$message("商品介绍不能为空！");
          return;
        }
        if (this.good_foundation_msg.goodsIcon == "") {
          this.$message("商品缩略图不能为空！");
          return;
        }
        var json = this.good_foundation_msg;
        json.marketPrice = this.good_foundation_msg.marketPrice * 100;
        json.supplyPrice = this.good_foundation_msg.supplyPrice * 100;
        var _this = this;
        if (this.goodsId == "") {
          this.base.axios_post(json, "/goods/saveGoodsInfo", function(res) {
            if (res.code == 0) {
              _this.good_foundation_msg.goodsId = res.data;
              _this.good_foundation_msg.marketPrice = json.marketPrice / 100;
              _this.good_foundation_msg.supplyPrice = json.supplyPrice / 100;
              _this.goodsId = res.data;
              _this.dialog_type = 0;
              _this.$message("保存成功，请填写完善其他辅助信息");
            } else {
              _this.$message(res.message);
            }
          });
        } else {
          this.base.axios_post(json, "/goods/updateGoodsInfo", function(res) {
            _this.$message(res.message);
            if (res.code == 0) {
              _this.good_foundation_msg.marketPrice = json.marketPrice / 100;
              _this.good_foundation_msg.supplyPrice = json.supplyPrice / 100;
            }
          });
        }
      },
      //添加单挑商品规格信息
      add_detile: function() {
        if (this.stockAmount && this.magnitude) {
          this.good_detail_list.push({
            goodsId: this.goodsId,
            stockAmount: this.stockAmount, //商品数量
            soldAmount: 0, //已售数量
            colour: "",
            magnitude: this.magnitude, //尺寸
            dr: 1, //判断是否要删除0.删除1.不删除
            isnew: true //判断是否为新增的
          });
          this.magnitude = "";
          this.stockAmount = "";
        } else {
          this.$message("请完善信息后添加");
        }
      },
      //删除一条商品规格信息
      del_detile: function(data) {
        if (!this.good_detail_list[data].isnew) {
          this.good_detail_list[data].dr = 0;
          this.update_good_detail_list.push(this.good_detail_list[data]);
          this.good_detail_list.splice(data, 1);
          console.log(this.update_good_detail_list);
          console.log(this.good_detail_list);
        } else {
          this.good_detail_list.splice(data, 1);
        }
      },
      //保存商品规格信息
      save_detile: function() {
        var json = [];
        for (var i = 0; i < this.good_detail_list.length; i++) {
          if (this.good_detail_list[i].isnew) {
            json.push(this.good_detail_list[i]);
          }
        }
        json.push.apply(json, this.update_good_detail_list);
        if (this.stockAmount!=''&&this.magnitude!='') {
          json.push({stockAmount:this.stockAmount,magnitude:this.magnitude,colour:'',dr:0,goodsId:this.goodsId,isnew:true,soldAmount:0})
        }
        if (json == "") {
          this.$message("请点击添加按钮！");
          return;
        } else {
          var _this = this;
          this.base.axios_post(json, "/goods/saveGoodsSpecifications", function(
            res
          ) {
            _this.$message(res.message);
            if (res.code == 0) {
              _this.open_dialog = false;
              _this.is_spec = true;
            }
          });
        }
      },
      //保存图片信息
      add_img: function() {
        if (this.img_msg == "") {
          this.$message("请至少选择一张图");
          return;
        }
        let _this = this;
        this.base.axios_post(this.img_msg, "/goods/saveGoodsEnclosure", function(
          res
        ) {
          _this.$message(res.message);
          if (res.code == 0) {
            _this.open_dialog = false;
            _this.is_banner = true;
          }
        });
      },
      //保存其它信息
      add_other: function() {
        var json = {
          actionType: 1,
          goodsId: this.goodsId,
          deliverHour: parseInt(this.deliverHour), //发货时间
          sevenDaysRefund: parseInt(this.sevenDaysRefund), //是否七天退款
          freeShipping: 1, //是否包邮
          freeProvince: "" //包邮城市  逗号分隔
        };
        var _this = this;
        if (!this.is_other_info) {
          this.base.axios_post(json, "/goods/saveGoodsAuxiliary", function(res) {
            _this.$message(res.message);
            if (res.code == 0) {
              _this.is_other_info = true;
              _this.open_dialog = false;
            }
          });
        } else {
          this.base.axios_post(json, "/goods/updateGoodsAuxiliary", function(
            res
          ) {
            _this.$message(res.message);
            if (res.code == 0) {
              _this.open_dialog = false;
            }
          });
        }
      },
      upload: function(type) {
        if (type == 1) {
          var file = document.getElementById("tea_cate_img2");
        } else {
          var file = document.getElementById("tea_cate_img");
        }
        file.click();
      },
      upload_img: function(type) {
        let _this = this;
        if (type == 1) {
          //基础信息的缩略图
        }
        if (type == 2) {
          //轮播图
        }
        if (type == 3) {
          //商品介绍
        }
        this.base.msg.loader();
        var option = {
          url: "/oss/uploadGoodsFile",
          type: "post",
          dataType: "json",
          //timeout: 10000,
          success: function(data) {
            console.log(data);
            if (type == 1) {
              _this.good_foundation_msg.goodsIcon = data.data;
              console.log(_this.good_foundation_msg.goodsIcon);
              console.log("基础信息的商品缩略图上传");
              document.getElementById("tea_cate_img2").value = "";
            }
            if (type == 2) {
              let $ipt_file = document.getElementById("tea_cate_img").files[0];
              console.log($ipt_file);
              let name_arr = $ipt_file.name.split(".");
              let obj = {
                fileName: $ipt_file.name,
                fileSize: $ipt_file.size,
                fileType: 3, //1小图标 2轮播图 3详情图片
                suffixName: name_arr[name_arr.length-1],
                thumbnailAddress: data.data,
                urlAddress: data.data,
                goodsId: _this.goodsId
              };
              _this.img_msg.push(obj);
              console.log("商品详情图片");
              document.getElementById("tea_cate_img").value = "";
            }
            if (type == 3) {
              let $ipt_file = document.getElementById("tea_cate_img").files[0];
              console.log($ipt_file);
              let name_arr = $ipt_file.name.split(".");
              let obj = {
                fileName: $ipt_file.name,
                fileSize: $ipt_file.size,
                fileType: 3, //1小图标 2轮播图 3详情图片
                suffixName: name_arr[name_arr.length-1],
                urlAddress: data.data,
                goodsId: _this.goodsId
              };
              _this.pic_intro_list.push(obj);
              console.log("商品轮播图片");
              document.getElementById("tea_cate_img").value = "";
            }
            _this.base.msg.hide();
          },
          error: function(err){
            _this.base.msg.hide();
            _this.$message("图片上传失败");
          }
        };
        if (type == 1) {
          jQuery("#uploadForm_default_tea2").ajaxSubmit(option);
        } else {
          jQuery("#uploadForm_default_tea").ajaxSubmit(option);
        }
        return false;
      },
      first_menu_change:function(){
        this.secondType = '';
        this.menu_id = this.firstType;
        this.get_right_menu();
      }
    }
  };
</script>

<style lang="less">
  .addgood{
    .warning{
      color:#fb1313;
      line-height: 30px;
      padding-top: 30px;
    }
    .content .add_info {
      color: #222222;
      font-size: 14px;
      background: #ffffff;
      border-radius: 10px;
    }

    .content .add_info .return {
      cursor: pointer;
      color: #808080;
      padding: 15px 0 15px 30px;
    }

    .content .add_info .info_item {
      padding: 30px 0;
    }

    .content .add_info .left_nav_addgoods {
      text-align: right;
      padding-bottom: 20px;
    }

    .content .add_info .left_nav_addgoods .btn {
      cursor: pointer;
      font-size: 14px;
      color: #808080;
      text-align: center;
    }

    .content .add_info .left_nav_addgoods .active {
      color: #ffffff;
      width: 90px;
      line-height: 30px;
      background: #62b6f7;
      border-radius: 10px;
    }
    .content .add_info .base_span {
      width: 120px;
      display: inline-block;
    }

    .content .add_info .l_ipt {
      width: 347px;
      display: inline-block;
    }

    .content .add_info .s_ipt {
      width: 167px;
      display: inline-block;
    }
    /*table img {
      width: 40px;
      height: 40px;
      border-radius: 20px;
    }*/
    .next_step {
      width: 50%;
      margin-top: 40px;
      margin-left: 20px;
    }
    .img_list img {
      vertical-align: middle;
      margin-right: 20px;
      width: 100px;
    }
    .img_list .img_list_item {
      width: 100px;
      height: 100px;
      overflow: hidden;
      vertical-align: middle;
      margin: 8px;
    }
    .img_list .img_list_item img{
      width: 100%;
    }
    .s_img {
      width: 100px;
      vertical-align: middle;
    }
  }

</style>
