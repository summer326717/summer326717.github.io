<template xmlns="http://www.w3.org/1999/html">
  <div class="content groupBuying">
    <div class="add_info" >
      <p class="return bor">
        <span @click="back">
          <i class="el-icon-caret-left"></i>返回上一页</span>
      </p>
      <div class="info_item">
        <el-row>
          <el-col :span="24">
            <el-form ref="form" label-width="200px">
              <div class="box">
                <span style="font-size: 24px;color: #1d90e6;margin-left: -3%">企业超级团</span>杭城2000家企业共享优惠<br/><br/>
                1、微商城每周会挑选一款商品，面向速邮汇企业客户进行团购销售<br/>
                2、每周一、二预报名统计配送数量，周三用户购买后直接配送<br/>
                3、下午14:00前购买的用户当天配送，14:00之后购买的客户第二日配送
              </div>
              <el-form-item label="开始时间" style="margin-left: 23%">
                <el-col :span="12">
                  <el-date-picker v-model="startTime" :editable="false" type="date" placeholder="选择日期时间" value-format='yyyy-MM-dd' @change="dateStartChange" style="width:205px"></el-date-picker>
                </el-col>
              </el-form-item>
              <el-form-item label="结束时间"  style="margin-left: 23%">
                <el-col :span="12">
                  <el-date-picker v-model="endTime" :editable="false" type="date" placeholder="选择日期时间" @change="dateEndChange" value-format='yyyy-MM-dd' style="width: 205px"></el-date-picker>
                </el-col>
              </el-form-item>
              <el-form-item label="团购价（元）"  style="margin: 0 0 100px 23%">
                <el-col :span="12">
                  <el-input style="width: 205px;" @blur="addMoney" size="small" v-model="price"></el-input>
                </el-col>
              </el-form-item>
              <el-button @click="submit_activity" size="medium" type="primary" style="margin-left:48%">提交</el-button>
            </el-form>
          </el-col>
        </el-row>
      </div>
    </div>
  </div>
</template>
<script>
import base from "../../assets/base";
export default {
  name: "groupBuying",
  data() {
    return {
      startTime: "",
      endTime: "",
      price:'',//团购价
      start:'',
      end:'',
    };
  },
  props: {
    goodsId: String,
  },
  created(){
//alert(this.goodsId)
  },
  methods: {
    back() {
      this.$emit("group_type", 1);
    },
    dateStartChange(value){
      this.startTime = value;
      this.start = new Date(value).getTime();
    },
    dateEndChange(value){
      this.endTime = value;
      if(!value){
        this.end = ''
      }else{
        this.end = new Date(value).getTime();
      }
    },

    addMoney(){
      if(!this.price){
        this.price = '';
      }else{
        this.price = this.turnMoney(this.price);
      }
    },
    turnMoney(value){
      var f = Math.round(Number(value)*100)/100;
      var s = f.toString();
      var rs = s.indexOf('.');
      if (rs < 0) {
        rs = s.length;
        s += '.';
      }
      while (s.length <= rs + 2) {
        s += '0';
      }
      return s
    },
    submit_activity(){
      if(!this.start){
        this.$message.error('开始时间不能为空!')
      }else if(!/^[+]{0,1}(\d+)$|^[+]{0,1}(\d+\.\d+)$/.test(Number(this.price))){
        this.$message.error('请输入正确的价格');
      }else if(!this.price){
        this.$message.error('团购价格不能为空!');
      }else if(this.end){
        if(this.end<this.start){
          this.$message.error('结束时间不能早于开始时间!')
        }else{
          this.$confirm('确认参与企业团购活动吗？', '提示',{
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            showClose:false,
            type: 'warning',
          }).then(() => {
            this.sure();
          }).catch(() => {});
        }
      }else{
        this.$confirm('确认参与企业团购活动吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          showClose:false,
          type: 'warning',
        }).then(() => {
          this.sure();
        }).catch(() => {});
      }
    },
    sure(){
      let data = {
        startTime:this.start,
        endTime:this.end,
        goodsId:this.goodsId,
        description:'',
        groupPrice:this.base.mul(Number(this.price),100)
      };
      console.log(data);
      let _this = this;
      this.base.axios_post(data,'/goods/saveEnterpriseGroup',function (res) {
         if(res.code==0){
           _this.$message({type: 'success',message: '已成功参与企业团购!'});
           _this.$emit("group_type", 1);
         }else{
           _this.base.message(res.message);
         }
      })

    }

  }
};
</script>
<style lang="less">
.groupBuying{
  .el-col-12{
   width: 33%!important;
  }
  .box{
    margin-bottom: 60px;
    font-size: 16px;
    margin-left: 26%;
  }
}
</style>
