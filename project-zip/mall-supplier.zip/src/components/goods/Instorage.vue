<template>
  <div class="content Instorage">
    <el-tabs v-model="activeName" @tab-click="handleClick">
    <el-tab-pane label="库存商品" name="first">
      <div class="table" v-if="group_type==1">
      <table>
        <tr class="bor">
          <th style="width:390px">商品名称</th>
          <th class="number">市场价</th>
          <th class="number">平台价</th>
          <th class="number">库存量</th>
          <th class="number">已售数量</th>
          <th>操作</th>
        </tr>
        <tr v-for="(item,index) in data_list" :key="index">
          <td style="text-align: left"><img :src="item.goodsIcon"><span class="ell">{{item.goodsName}}</span></td>
          <td class="number">{{item.marketPrice}}</td>
          <td class="number">{{item.supplyPrice}}</td>
          <td class="number">{{item.stockAmount}}</td>
          <td class="number">{{item.soldAmount}}</td>
          <td style="text-align:right">
            <el-button type="warning" size="mini" class="mtb5" v-on:click="setInfo(item.goodsId )">修改</el-button>
            <el-button type="primary" size="mini" class="mtb5" v-if="item.groupState==0" v-on:click="go_to_goods(item.goodsId,item.supplyPrice,item.goodsIcon,item.marketPrice,item.stockAmount)">拼团</el-button>

            <el-button :class="{isLeft:isLeft}" v-if="item.enterpriseState==0" type="success" size="mini" class="mtb5" v-on:click="group_buying(item.goodsId)">团购</el-button>
            <el-button type="danger" size="mini" class="mtb5" v-on:click="out_goods(item.goodsId)">下架</el-button>
            <el-button type="warning" size="mini" class="mtb5" v-if="item.agentState==0" v-on:click="agentGoods(item.goodsId )">代理</el-button>
          </td>
        </tr>
      </table>
      <div class="no_data" v-if="no_data"><img src="../../assets/images/no_data.png"/></div>
      <pagination v-if="data_list!=''&&total_pages>1" :cur='page_no' :all='total_pages' @get_page='turn_page'></pagination>
    </div>
    </el-tab-pane>
    <el-tab-pane label="拼团中" name="second">
      <ingroup v-if="activeName=='second'"></ingroup>
    </el-tab-pane>
    <el-tab-pane label="企业团购" name="third">
      <div class="table" v-if="group_type!=2">
        <table>
          <tr class="bor">
            <th style="width:390px">商品名称</th>
            <th class="number">市场价</th>
            <th class="number">团购价</th>
            <th>有效时间</th>
            <th class="number">已售数量</th>
            <th>操作</th>
          </tr>
          <tr v-for="(v,k) in data_list2" :key="k">
            <td style="text-align: left"><img :src="v.goodsIcon"><span class="ell">{{v.goodsName}}</span></td>
            <td class="number">{{(v.marketPrice/100).toFixed(2)}}</td>
            <td class="number">{{(v.groupPrice/100).toFixed(2)}}</td>
            <td style="text-align: center">{{v.startTime}}~{{v.endTime}}</td>
            <td class="number">{{v.sold}}</td>
            <td style="text-align: center">
              <el-button @click='cancel_group(v.goodsId)' type="danger" size="mini" class="mtb5">取消团购</el-button>
            </td>
          </tr>
        </table>
        <div class="no_data" v-if="no_data2"><img src="../../assets/images/no_data.png"/></div>
        <pagination v-if="data_list2!=''&&total_pages2>1" :cur='page_no2' :all='total_pages2' @get_page='turn_page2'></pagination>
      </div>
    </el-tab-pane>
    <el-tab-pane label="代理中" name="four">
      <div class="table" v-if="group_type!=5&&group_type!=6">
        <table>
          <tr class="bor">
            <th style="width:390px">商品名称</th>
            <th class="number">市场价</th>
            <th class="number">零售价</th>
            <th class="number">已售数量</th>
            <th>操作</th>
          </tr>
          <tr v-for="(v,k) in data_list" :key="k">
            <td style="text-align: left"><img :src="v.goodsIcon"><span class="ell">{{v.goodsName}}</span></td>
            <td class="number">{{(v.marketPrice/100).toFixed(2)}}</td>
            <td class="number">{{(v.retailPrice/100).toFixed(2)}}</td>
            <td class="number">{{v.soldAmount}}</td>
            <td style="text-align: center">
              <el-button @click="viewAgent(v.goodsId)" type="primary" size="mini" class="mtb5">查看代理</el-button>
              <el-button @click='cancelAgent(v.goodsId)' type="danger" size="mini" class="mtb5">取消代理</el-button>
            </td>
          </tr>
        </table>
        <div class="no_data" v-if="data_list==''"><img src="../../assets/images/no_data.png"/></div>
        <pagination v-if="data_list!=''&&total_pages>1" :cur='page_no' :all='total_pages' @get_page='turn_page'></pagination>
      </div>
    </el-tab-pane>
  </el-tabs>
    <begingroup v-if="group_type==2" :goodsId='goods_id' :supplyPrice='price' :goodsIcon="goodsIcon"   :marketPrice="marketPrice" :stockAmount="stockAmount"  @group_type="get_type"></begingroup>
    <lookgroup v-if="group_type==3" :goodsId='goods_id' @group_type="get_type"></lookgroup>
    <!--<viewdetail goodsId="ac437fc9381144cdae83f72857bcb208"></viewdetail>-->
    <groupBuying v-if="group_type==4" :goodsId='goods_id' @group_type="get_type"></groupBuying>
    <agentSetting :goodsId='goods_id' v-if="group_type==5||group_type==6" :group_type='group_type' @group_type="get_type"></agentSetting>
  </div>
</template>
<script>
import pagination from "../common/Pagination";
import begingroup from "./common/Begingroup";
import groupBuying from "./groupBuying";
import lookgroup from "./common/Lookgroup";
import ingroup from "./Ingroup";
import viewdetail from "../../components/common/Viewdetail";
import agentSetting from './agentSetting'
export default {
  data() {
    return {
      page_no: 1,
      total_pages: 1,
      data_list: [],
      no_data: false,
      goods_id: "",
      price: "", //平台价
      group_type: 1, //1.页面数据2.发起拼团3.查看拼团4.企业拼团5.代理设置6.查看代理设置
      goodsIcon: "",
      marketPrice: "",
      stockAmount: "",
      activeName: "first",

      data_list2:[],
      no_data2:false,
      total_pages2:1,
      page_no2:1,
      isLeft:false

    };
  },
  components: {
    pagination,
    begingroup,
    lookgroup,
    groupBuying,
    viewdetail,
    ingroup,
    agentSetting
  },
  created() {
    this.get_data();
    //this.get_groupBuying_msg();
  },
  methods: {
    turn_money(value){
      var f = Math.round(value*100)/10000;
      var s = f.toString();
      var rs = s.indexOf('.');
      if (rs < 0) {
        rs = s.length;
        s += '.';
      }
      while (s.length <= rs + 2) {
        s += '0';
      }
      return s;
    },
    handleClick: function(i) {
      this.group_type = 1;
      this.page_no = 1;
      if(i.name=='first'){
        this.get_data();
      }else if(i.name=='third'){
        this.get_groupBuying_msg();
      } else if(i.name == 'four'){
        this.getAgentList();
      }
    },
    get_type: function(i) {
      this.group_type = i;
      //this.page_no = 1;
      if (this.activeName == 'four') {
        this.getAgentList();
      } else {
        this.get_data();
      }
    },
    turn_page: function(i) {
      this.page_no = i;
      if (this.activeName == 'four') {
        this.getAgentList();
      } else {
        this.get_data();
      }
    },
    turn_page2:function (i) {
      this.page_no2 = i;
      this.get_groupBuying_msg();
    },
    get_groupBuying_msg(){
      let data = {
        page_no:this.page_no2,
        page_size:10
      };
      let _this = this;
      this.base.axios_post(data,'/goods/queryEnterpriseGroupGoods',function (res) {
        if(res.code==0){
          if(res.data.resultList.length>0){
            _this.data_list2 = res.data.resultList;
            _this.data_list2.map(function(x, y) {
              x.startTime = _this.base.trans_time(x.startTime,1);
              x.endTime = _this.base.trans_time(x.endTime,1);
            });
            _this.total_pages2 = res.data.pages;
          }else{
            _this.no_data2 = true;
          }
        }else{
          _this.no_data2 = true;
        }
      });
    },
    get_data: function() {
      //查询列表
      var data = {
        goods_state: 4,
        page_no: this.page_no,
        page_size: 10
      };
      var _this = this;
      this.base.axios_post(data, "/goods/queryGoodsInfoList", function(res) {
        if (res.code == 0) {
          if (res.data) {
            _this.total_pages = res.data.pages;
            for(var i in res.data.list){
              res.data.list[i].marketPrice = _this.turn_money(res.data.list[i].marketPrice);
              res.data.list[i].supplyPrice = _this.turn_money(res.data.list[i].supplyPrice);
              if(res.data.list[i].groupState!=0 && res.data.list[i].enterpriseState==0){
                _this.isLeft = true;
              }
            }
            _this.data_list = res.data.list;
            _this.no_data = false;
          } else {
            _this.no_data = true;
          }
        } else {
          if (_this.page_no == 1) {
            _this.data_list = [];
          }
          _this.no_data = true;
        }
      });
    },
    out_goods: function(goodsId) {
      //下架商品
      var _this = this;
      this.$prompt("请输入下架原因?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
      })
        .then(({ value }) => {
          var data = {
            goodsId: goodsId,
            reason: value
          };
          _this.base.axios_post(data, "/goods/offGoodsShelf", function(res) {
            if (res.code == 0) {
              _this.page_no = 1;
              _this.get_data();
            }
            _this.$message(res.message);
          });
        })
        .catch(() => {});
    },
    getAgentList(){
      var data = {
        page_no: this.page_no,
        page_size: 10
      };
      let _this = this;
      this.base.axios_post(data, "/goods/supplierQryGoodsAgentingList", function(res) {
        if (res.code == 0) {
          _this.data_list = res.data.resultList;
          _this.total_pages = res.data.pages;
        } else if (res.code == 10){
          _this.data_list = [];
        } else {
          _this.$message(res.message);
        }
      });
    },
    agentGoods(goodsId){
      this.goods_id = goodsId;
      this.group_type = 5;
    },
    viewAgent(goodsId){
      this.goods_id = goodsId;
      this.group_type = 6;
    },
    cancelAgent(goodsId){
      var _this = this;
      this.$confirm("是否取消代理?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: 'warning'
      })
        .then(() => {
          var data = {
            goodsId: goodsId,
          };
          _this.base.axios_post(data, "/goods/cancelAgentGoodsInfo", function(res) {
            if (res.code == 0) {
              _this.page_no = 1;
              _this.getAgentList();
            }
            _this.$message(res.message);
          });
        })
        .catch(() => {});
    },
    group_buying(id){
    //允许团购，跳转到参与企业团购页面
      this.goods_id = id;
      this.group_type = 4;

    },
    cancel_group(id){
      //取消团购
      this.$confirm('是否取消企业团购?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        showClose:false,
      }).then(() => {
        let data = {
          goodsId:id
        };
        let _this = this;
        this.base.axios_post(data,'/goods/cancelEnterpriseGroup',function (res) {
          if(res.code==0){
            _this.get_groupBuying_msg();
            _this.$message({
              type: 'success',
              message: '已成功取消企业团购!'
            });
          }else{
            _this.alerter(res.message);
          }
        });

      }).catch(() => {

      });

    },
    check_group(){
      //查看团购
    },
    setInfo(id){
      this.$router.push({ path: "/Editgood?id=" + id+'&type=0' });
    },


    go_to_goods: function(goodsId, price, goodsIcon, marketPrice, stockAmount) {
      //发起拼团
      this.goods_id = goodsId;
      this.price = price;
      this.goodsIcon = goodsIcon;
      this.marketPrice = marketPrice;
      this.stockAmount = stockAmount;
      this.group_type = 2;
    },
    loook_goods: function(goodsId) {
      //查看拼团
      this.goods_id = goodsId;
      console.log(this.goods_id);
      this.group_type = 3;
    },
    cancel_goods: function(goodsId) {
      //取消拼团
      var _this = this;
      this.$confirm("确认取消该拼团?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          var data = {
            goodsId: goodsId
          };
          _this.base.axios_post(
            data,
            "/goods/supplierCancelGroupsGoodsInfo",
            function(res) {
              if (res.code == 0) {
                _this.page_no = 1;
                _this.get_data();
              }
              _this.$message(res.message);
            }
          );
        })
        .catch(() => {});
    },
  }
};
</script>
<style>
  .Instorage .table .bor>th{
    text-align: center;
  }
  .Instorage .table table .number{
    text-align: right;
  }
  .Instorage .table table img{
    vertical-align: bottom;
  }
  .Instorage .table .isLeft{
    margin-left: 10px;
  }

</style>
