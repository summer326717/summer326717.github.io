<template>
  <div class="content">
    <div class="left">
      <p class="h_title"><span>客服列表</span></p>
      <div class="s_content s_active">
        <img src="../../assets/images/head_icon.png"/>
        <span>帅帅的晓伟</span>
      </div>
      <div class="s_content">
        <img src="../../assets/images/head_icon.png"/>
        <span>帅帅的晓伟</span>
      </div>
      <div class="s_content">
        <img src="../../assets/images/head_icon.png"/>
        <span>帅帅的晓伟</span>
      </div>
    </div>
    <div class="right">
      <div class="s_talk">
        <div class="s_talk_list">
          <img src="../../assets/images/head_icon.png">
          <span>你好！小水为你服务。你好！小水为你服务。你好！小水为你服务。你好！小水为你服务。</span>
        </div>
        <div class="s_talk_list">
          <img src="../../assets/images/head_icon.png">
          <span>你好！小水为你服务。</span>
        </div>
        <div class="s_talk_list">
          <img style="float: right" src="../../assets/images/head_icon.png">
          <span style="float: right" >你好！小水为你服务。你好！小水为你服务。你好！小水为你服务。</span>
        </div>
        <div class="s_talk_list">
          <img src="../../assets/images/head_icon.png">
          <span>你好！小水为你服务。</span>
        </div>
      </div>
      <p class="s_sent">
        <textarea></textarea>
        <button>发送</button>
      </p>
    </div>
  </div>
</template>
<script>
  import pagination from '../common/Pagination'
  export default {
    data() {
      return {
        page_no: 1,
        total_pages: 2,
      }
    },
    components: {
      pagination
    },
    methods: {
      turn_page: function(i) {
        this.page_no = i;
      }
    }
  }
</script>

<style lang="less" scoped>
  //左边客服列表
  .content{
    margin: 0;
    padding: 0;
  }
  .left{
    margin: 2% 0 0 2%;
    display: inline-block;
    background-color: #ffffff;
    width: 30%;
    height: 520px;
    border-radius: 10px;
    padding: 0 20px;
    vertical-align: top;
  }
  .h_title{
    font-size: 24px;
    color: #62B6F7;
    padding: 20px 0;
    span{
      border-bottom: 3px solid#62B6F7;
    }
  }
  .s_content{
    padding: 20px 0;
    border-bottom: 2px solid#F4F5F9;
    img{
      width: 40px;
      height: 40px;
      vertical-align: middle;
      border-radius: 20px;
    }
  }
  .s_active{
    background-color: #F4F5F9!important;
    border-radius: 10px;
  }
  //右边聊天记录
  .right{
    border-radius: 10px;
    margin: 2% 0 0 2%;
    display: inline-block;
    width: 60%;
    background-color: #ffffff;
    height: 520px;
  }
  .s_talk{
    width: 70%;
    height: 350px;
    margin: 10% 0 0 15%;
    border: 2px solid#F4F5F9;
    border-radius: 10px;
    .s_talk_list{
      margin: 10px 0;
      min-height: 40px;
      display: inline-block;
      width: 100%;
      font-size: 14px;
      border-radius: 10px;
      img{
        width: 30px;
        height: 30px;
        border-radius: 15px;
        vertical-align: top;
        margin: 1px 20px;
      }
      span{
        width: 80%;
        vertical-align: top;
        background-color: #F4F5F9;
        display: inline-block;
        line-height: 30px;
        border-radius: 10px;
        min-height: 30px;
        padding: 2px 5px;
      }
    }
  }
  .s_sent{
    margin:1% 15%;
    width: 80% !important;
    textarea{
      width: 72%;
      border: 1px solid#ccc;
      border-radius: 10px;
      outline:none;
      font-size: 14px;
      vertical-align: top;
      padding: 5px 0 0 5px;
      height: 80px;
      resize:none;
    }
    textarea::-webkit-scrollbar{display:none}
    button{
      width: 68px;
      height: 32px;
      background-color:#62B6F7 ;
      border-radius: 10px;
    }
  }
</style>
