<template>
  <div class="content completed">
    <div class="table">
      <table>
        <tr class="bor">
          <th>商品名称</th>
          <th class="number">成交单价</th>
          <th class="number">成交数量</th>
          <th class="number">成交金额</th>
          <th>成交时间</th>
          <th>收货地址</th>
          <th>收货人</th>
          <th>订单号</th>
        </tr>
        <tr v-for="(item,index) in data_list" :key="index">
          <td class="overflow"><img :src="item.goods_icon" style="margin-right: 3px">{{item.goods_name}}</td>
          <td class="number">{{(item.buy_price/100).toFixed(2)}}</td>
          <td class="number">{{item.buy_count}}</td>
          <td class="number">{{(item.pay_amount/100).toFixed(2)}}</td>
          <td style="text-align: center">{{item.finishtime}}</td>
          <td style="max-width:180px!important;text-align: left;white-space: pre-wrap">{{item.receiver_province}}{{item.receiver_city}}{{item.receiver_region}}{{item.receive_address}}</td>
          <td style="text-align: center">{{item.receiver_name}}</td>
          <td style="text-align: center">{{item.order_no}}</td>
        </tr>
      </table>
      <div class="no_data" v-if="no_data"><img src="../../assets/images/no_data.png"/></div>
      <pagination v-if="data_list!=''&&total_pages>1" :cur='page_no' :all='total_pages' @get_page='turn_page'></pagination>
    </div>
  </div>
</template>
<script>
import pagination from "../common/Pagination";
export default {
  data() {
    return {
      page_no: 1,
      total_pages: 1,
      data_list: [],
      no_data: false
    };
  },
  components: {
    pagination
  },
  created() {
    this.get_data();
  },
  methods: {
    turn_page: function(i) {
      this.page_no = i;
      this.get_data();
    },
    get_data: function() {
      var data = {
        state: 5,
        page_no: this.page_no,
        page_size: 10
      };
      var _this = this;
      this.base.axios_post(
        data,
        "/orderCenter/supplierQueryOrderInfoList",
        function(res) {
          if (res.code == 0) {
            if (res.data) {
              _this.data_list = res.data.list;
              _this.total_pages = res.data.pages;
              _this.data_list.map(function(x, y) {
                x.finishtime = _this.base.trans_time(x.finishtime, 2);
              });
              _this.no_data = false;
            } else {
              _this.no_data = true;
            }
          } else {
            _this.no_data = true;
          }
        }
      );
    }
  }
};
</script>

<style>
.completed table .number{
  text-align: right!important;
}
.completed table .overflow{
  max-width:120px!important;
  text-align: left;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap
}
</style>
