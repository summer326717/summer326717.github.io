<template>
  <div class="content tor">
    <div class="table">
      <table>
        <tr class="bor">
          <th>订单编号</th>
          <th>商品名称</th>
          <th class="number">成交数量</th>
          <th class="number">成交金额</th>
          <th>退货时间</th>
          <th>退货人</th>
          <th>操作</th>
        </tr>
        <tr v-for="(item,i) in data_list" :key="i">
          <td style="text-align: center">{{item.orderNo}}</td>
          <td class="overflow"><img :src="item.goodsIcon" style="margin-right: 3px">{{item.goodsName}}</td>
          <td class="number">{{item.orderNum}}</td>
          <td class="number">{{(item.payMny/100).toFixed(2)}}</td>
          <td style="text-align: center">{{item.returnTime}}</td>
          <td style="text-align: left">{{item.buyersName}}</td>
          <td style="text-align: center">
            <el-button size="small" type="primary" @click="return_money(item.orderId)">退款</el-button>
            <el-button size="small" type="success" @click="view_reason(item.orderId)">查看</el-button>
          </td>
        </tr>
      </table>
      <div class="no_data" v-if="data_list==''"><img src="../../assets/images/no_data.png"/></div>
      <pagination v-if="data_list!=''&&total_pages>1" :cur='page_no' :all='total_pages' @get_page='turn_page'></pagination>
      <el-dialog title="信息提示" :visible.sync="dialogVisible" width="30%">
        <p><span v-if="goodsReturn!=''">退货原因：{{goodsReturn.goodsReturn.reason}}</span></p>
        <p class="tuihuo_img"><img v-for="(item,i) in goodsReturn.goodsReturnImgList" :key="i" :src="item.imgUrl"></p>
        <span slot="footer" class="dialog-footer">
          <el-button size="small" type="primary" @click="dialogVisible = false">确 定</el-button>
        </span>
      </el-dialog>
    </div>
  </div>
</template>
<script>
import pagination from "../common/Pagination";
export default {
  data() {
    return {
      page_no: 1,
      total_pages: 1,
      data_list: [],
      dialogVisible: false,
      goodsReturn: ""
    };
  },
  components: {
    pagination
  },
  created() {
    this.get_data();
  },
  methods: {
    turn_page: function(i) {
      this.page_no = i;
      this.get_data();
    },
    get_data: function() {
      var data = {
        page_no: this.page_no,
        page_size: 10
      };
      var _this = this;
      this.base.axios_post(
        data,
        "/orderCenter/supplierQryReturnGoodsList",
        function(res) {
          if (res.code == 0) {
            if (res.data) {
              _this.data_list = res.data.resultList;
              _this.total_pages = res.data.pages;
              _this.data_list.map(function(x, y) {
                x.returnTime = _this.base.trans_time(x.returnTime, 2);
              });
              _this.no_data = false;
            } else {
              _this.data_list = [];
              _this.no_data = true;
            }
          } else {
            _this.no_data = true;
          }
        }
      );
    },
    return_money: function(order_id) {
      //退款
      var _this = this;
      let json = {
        order_id: order_id
      };
      this.$confirm("确定退款?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(() => {
        _this.base.axios_post(json, "/supplier/payCenter/refund", function(res) {
          _this.$message({
            type: "success",
            message: res.message
          });
          _this.page_no = 1;
          _this.get_data();
        });
      }).catch(() => {

        });;
    },
    view_reason: function(order_id) {
      //查看退款原因
      let json = {
        order_id: order_id
      };
      let _this = this;
      this.base.axios_post(json, "/orderCenter/backReturnOrderReason", function(
        res
      ) {
        if (res.code == 0) {
          _this.goodsReturn = res.data;
          _this.dialogVisible = true;
        }
      });
    }
  }
};
</script>
<style>
  .tor .table table .number{
    text-align: right!important;
  }
  .tor .overflow{
    max-width:200px!important;
    text-align: left;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap
  }
</style>
