<template>
  <div class="content Tor">
    <div class="table" v-if="is_list && !logistics">
      <table>
        <tr class="bor">
          <th>商品名称</th>
          <th>订单号</th>
          <th>收货人</th>
          <th>联系电话</th>
          <th>快递单号</th>
          <th>物流信息</th>
        </tr>
        <tr v-for="(item,index) in data_list" :key="index">
          <td class="overflow"><img :src="item.goods_icon" style="margin-right: 3px">{{item.goods_name}}</td>
          <td>{{item.order_no}}</td>
          <td>{{item.receiver_name}}</td>
          <td>{{item.receiver_phone}}</td>
          <td>{{item.expressNo}}</td>
          <td>
            <el-button size="small" v-on:click="check_logistics(index)" type="success">查看物流</el-button>
          </td>
        </tr>
      </table>
      <div class="no_data" v-if="no_data"><img src="../../assets/images/no_data.png"/></div>
      <pagination v-if="data_list!=''&&total_pages>1" :cur='page_no' :all='total_pages' @get_page='turn_page'></pagination>
    </div>

    <div class="add_info" v-if="logistics">
      <p class="return bor">
        <span @click="back">
          <i class="el-icon-caret-left"></i>返回上一页</span>
      </p>
      <div class="info_item" >
        <div class="info_top">
          <div class="goodsInfo">
            <div class="goodsPic">
              <img :src="goodsIcon">
            </div>
            <div class="goodsTit">
              <p>商品名：{{goodsName}}</p>
              <p>快递单号：{{expressNo}}</p>
            </div>
          </div>
          <div>
            <img src="../../assets/images/jiantou.png">
          </div>
          <div class="userInfo">
            <p>收货人信息</p>
            <p>收&nbsp;&nbsp;&nbsp;货&nbsp;&nbsp;&nbsp;人&nbsp; ：{{userName}}</p>
            <p>收货人地址 ：<span>{{userAddress}}</span></p>
            <p>收货人电话 ：{{userPhone}}</p>
          </div>
        </div>
        <div class="info_bottom" v-loading="loading">
          <div class="step">
            <div v-if="!logistics_Msg" style="color: #c6c6c6;font-size: 20px;">暂无物流信息...</div>
            <div class="running" v-if="logistics_Msg">
              <div class="el-icon-edit icon active" style="color: #4db3ff"></div>
              <div class="msg">
                <p class="active" style="color: #4db3ff">{{time}}</p>
                <p class="active" style="color: #4db3ff">{{address}}</p>
              </div>
            </div>
            <div class="running" v-for="(v,k) in logisticsMsg" v-if="logistics_Msg">
              <div class="el-icon-success icon"></div>
              <div class="msg">
                <p>{{v.accept_time}}</p>
                <p>{{v.accept_station}}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import pagination from "../common/Pagination";
export default {
  data() {
    return {
      loading:false,
      page_no: 1,
      total_pages: 1,
      is_list: true, //切换列表及物流信息
      data_list: [],
      no_data: false,
      logistics:false,
      expressNo:'',
      goodsName:'',
      goodsIcon:'',
      userName:'',
      userAddress:'',
      userPhone:'',
      expressCode:'',
      logisticsMsg:[],
      logistics_Msg:true,
      time:'',
      address:'',
    };
  },
  components: {
    pagination
  },
  created() {
    this.get_data();

  },
  methods: {
    turn_page: function(i) {
      this.page_no = i;
      this.get_data();
    },
    get_data: function() {
      var data = {
        state: 4,
        page_no: this.page_no,
        page_size: 10
      };
      var _this = this;
      this.base.axios_post(
        data,
        "/orderCenter/supplierQueryOrderInfoList",
        function(res) {
          if (res.code == 0) {
            if (res.data) {
              _this.data_list = res.data.list;
              _this.total_pages = res.data.pages;
              _this.no_data = false;
            } else {
              _this.no_data = true;
            }
          } else {
            _this.no_data = true;
          }
        }
      );
    },
    back(){
      this.logistics = false;
    },
    check_logistics(i){
      this.logistics = true;
      this.loading = true;
      this.userName = this.data_list[i].receiver_name;
      this.goodsName = this.data_list[i].goods_name;
      this.goodsIcon = this.data_list[i].goods_icon;
      this.userAddress = this.data_list[i].receiver_province+this.data_list[i].receiver_city+this.data_list[i].receiver_region+this.data_list[i].receive_address;
      this.userPhone = this.data_list[i].receiver_phone;
      this.expressNo = this.data_list[i].expressNo;
      this.expressCode = this.data_list[i].expressCode;//快递id
      let data = {
        waybill_number:this.expressNo,
        express_id:this.expressCode
      };
      this.logisticsMsg = [];
      let _this = this;
      this.base.suyh_axios_post(data,'/10/findExpressLogistic',function (res) {
         _this.loading = false;
         if(res.mark=='0'){
           if(res.obj.length===0){
             _this.logistics_Msg = false;
           }else{
             _this.logistics_Msg = true;
             _this.address = res.obj[0].accept_station;
             _this.time = res.obj[0].accept_time;
             for(let i in res.obj){
               let obj = {};
               obj.accept_station = res.obj[i].accept_station;
               obj.accept_time = res.obj[i].accept_time;
               if(i>=1){
                 _this.logisticsMsg.push(obj);
               }
             }
           }
         }else{
           _this.base.alerter(res.tip);
           _this.logisticsMsg = [];
         }
      });
    }
  }
};
</script>

<style>
.content .re_info {
  color: #222222;
  font-size: 14px;
  background: #ffffff;
  border-radius: 10px;
}
.content .re_info .return {
  cursor: pointer;
  color: #808080;
  padding: 15px 0 15px 30px;
}
.content .bor {
  box-shadow: #e1e1e1 0 1px 0;
}
.content .info_item {
  padding: 55px;
}
.content .info_item .img {
  width: 88px;
  height: 88px;
  margin-right: 25px;
}
.Tor .table table tr th,td{
  text-align: center;
}
.Tor .table table tr .overflow{
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  text-align: left;
  max-width: 200px!important;
}
.content .info_item .item_left,
.content .info_item .item_center,
.content .info_item .item_right {
  display: inline-block;
  vertical-align: top;
  line-height: 25px;
}
.content .info_item .item_right {
  padding-left: 200px;
  background: url("../../assets/images/img_01.png") no-repeat 100px 50%;
}
.content .info_item .item_right .pad {
  padding-left: 30px;
}
.content .info_wl {
  padding: 50px 0;
  color: #808080;
  font-size: 14px;
  line-height: 30px;
}
.content .info_wl .el-col {
  height: 80px;
}
.content .info_wl .time {
  padding-right: 80px;
  text-align: right;
  position: relative;
}
.content .info_wl .time::before {
  content: "";
  display: inline-block;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background: #bababa;
  position: absolute;
  right: 32px;
  top: 10%;
}
.content .info_wl .first {
  color: #222222;
}
.content .info_wl .first::before {
  right: 30px;
  background: #62b6f7;
  border: 3px solid #c6e4fc;
}
.content .info_wl .item {
  position: relative;
}
.content .info_wl .item::before {
  content: "";
  width: 1px;
  height: 50%;
  display: inline-block;
  background: #bababa;
  position: absolute;
  left: -40px;
  top: 30%;
}
.content .info_wl .a_first {
  color: #62b6f7;
}
.content .info_wl .a_first::before {
  background: #62b6f7;
}
.content .info_wl .item::after {
  content: "";
  width: 1px;
  height: 50%;
  display: inline-block;
  background: #bababa;
  position: absolute;
  left: -40px;
  top: 80%;
}
.content .info_wl .last::after {
  background: rgba(0, 0, 0, 0);
}
.content .info_wl .last::before {
  background: rgba(0, 0, 0, 0);
}
.Tor .add_info .info_item{
  padding: 20px 20px;
}
.Tor .add_info .info_item .info_top,.info_bottom{
}
.Tor .add_info .info_item .info_top{
  border-bottom: solid 1px #cfd6e0;
  display: flex;
  justify-content:space-between;
  align-items:center;
  padding-bottom:30px;
}
.Tor .add_info .info_item .info_top .goodsInfo{
  overflow: hidden;
}
.Tor .add_info .info_item .info_top .goodsInfo .goodsPic{
  float: left;
  width: 120px;
  height: 120px;
}
.Tor .add_info .info_item .info_top .goodsInfo .goodsPic>img{
  width: 120px;
  height: 120px;
}
.Tor .add_info .info_item .info_top .goodsInfo .goodsTit{
  float: left;
  margin-left: 10px;
  height: 120px;
  position: relative;
  font-size: 16px;
}
.Tor .add_info .info_item .info_top .goodsInfo .goodsTit p:first-child{
  width: 240px;
  margin-top:15px;
}
.Tor .add_info .info_item .info_top .goodsInfo .goodsTit p:last-child{
  position: absolute;
  bottom: 20px;
}
.Tor .add_info .info_item .info_top .userInfo{
  height: 120px;
  width:40%;
}
.Tor .add_info .info_item .info_top .userInfo p span{
  width:66%;
  word-wrap: break-word;
  display: inline-block;
  vertical-align: middle;
}
.Tor .add_info .info_item .info_top .userInfo p{
  font-size: 14px;
  padding-left: 20px;
  margin-bottom: 7px;
}
.Tor .add_info .info_item .info_top .userInfo p:first-child{
  font-size: 18px;
  padding-left: 0;
  margin-bottom: 10px;
}
.Tor .add_info .info_item .info_bottom{
  padding-left: 33.333%;
  margin: 50px 0;
}

.Tor .add_info .info_item .info_bottom .step .running{
  margin-bottom:40px;
}

.Tor .add_info .info_item .info_bottom .step .running>div{
  display: inline-block;
  color: #c6c6c6;
  font-size: 26px;
}
.active{
  color: #1da0f6!important;
}
.Tor .add_info .info_item .info_bottom .step .running>div:last-child{
  margin-left: 10px;
  vertical-align: top;
}
.Tor .add_info .info_item .info_bottom .step .running p:first-child{
  color: #c6c6c6;
  font-size: 18px;

}
.Tor .add_info .info_item .info_bottom .step .running p:last-child{
  color: #c6c6c6;
  font-size: 14px;
}
</style>
