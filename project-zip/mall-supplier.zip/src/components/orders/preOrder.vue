<template>
  <div class="content order">
    <div class="table">
      <table>
        <tr class="bor">
          <th>商品名称</th>
          <th class="number">成交数量</th>
          <th>收货人</th>
          <th>联系电话</th>
          <th>收货地址</th>
          <th>支付状态</th>
        </tr>
        <tr v-for="(item,index) in data_list" :key="index">
          <td class="overflow"><img :src="item.goodsIcon" style="margin-right: 3px">{{item.goodsName}}</td>
          <td class="number">{{item.orderNum}}</td>
          <td style="text-align: center">{{item.receiveName}}</td>
          <td style="text-align: center">{{item.phoneNo}}</td>
          <td style="text-align: left;max-width: 350px;word-wrap:break-word">{{item.address}}</td>
          <td style="text-align: center">
            <el-button size="small" v-if="item.payState==2" type="primary">未支付</el-button>
            <el-button size="small" v-if="item.payState==3" type="primary">已支付</el-button>
          </td>
        </tr>
      </table>
      <div class="no_data" v-if="no_data"><img src="../../assets/images/no_data.png"/></div>
      <pagination v-if="data_list!=''&&total_pages>1" :cur='page_no' :all='total_pages' @get_page='turn_page'></pagination>
    </div>
  </div>
</template>
<script>
import pagination from "../common/Pagination";
import base from "../../assets/base";
export default {
  data() {
    return {
      page_no: 1,
      total_pages: 1,
      data_list: [],
      no_data: false,
      orderState:-1
    };
  },
  components: {
    pagination
  },
  created() {
    this.get_data();
  },
  methods: {
    turn_page: function(i) {
      this.page_no = i;
      this.get_data();
    },
    get_data: function() {
      var Cookies = require("Cookies-js");
      var data = {
        page_no: this.page_no,
        page_size: 10
      };
      var _this = this;
      this.base.axios_post(
        data,
        "/orderCenter/supplierPreOrder",
        function(res) {
          console.log(res.data);
          if (res.code == 0) {
            if (res.data) {
              _this.data_list = res.data.resultList;
              _this.total_pages = res.data.pages;

              _this.no_data = false;
            } else {
              _this.no_data = true;
            }
          } else {
            _this.data_list = [];
            _this.no_data = true;
          }
        }
      );
    },
  }
};
</script>

<style>
.order .table .bor>th{
  text-align: center;
}
  .order .table table .number{
    text-align: right!important;
  }
  .order .table table .overflow{
    max-width:200px!important;
    text-align: left;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap
  }
</style>
