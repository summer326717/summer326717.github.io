<template>
  <div class="content Unprocessed">
    <div class="table">
      <table v-if="!no_data">
        <tr class="bor">
          <th>商品名称</th>
          <th class="number">成交数量</th>
          <th>收货人</th>
          <th>联系电话</th>
          <th>收货地址</th>
          <th>操作</th>
        </tr>
        <tr v-for="(item,index) in data_list" :key="index">
          <td class="overflow"><img :src="item.goods_icon" style="margin-right: 3px">{{item.goods_name}}</td>
          <td class="number">{{item.buy_count}}</td>
          <td style="text-align: center">{{item.receiver_name}}</td>
          <td style="text-align: center">{{item.receiver_phone}}</td>
          <td style="text-align: left;max-width: 390px;word-wrap:break-word">{{item.receiver_province}}{{item.receiver_city}}{{item.receiver_region}}{{item.receive_address}}</td>
          <td style="text-align: center">
            <el-button size="small" v-on:click="send_good(item.order_id)" type="primary">一键发货</el-button>
          </td>
        </tr>
      </table>
      <div class="no_data" v-if="no_data"><img src="../../assets/images/no_data.png"/></div>
      <pagination v-if="data_list!=''&&total_pages>1" :cur='page_no' :all='total_pages' @get_page='turn_page'></pagination>
    </div>

    <el-dialog class="dialog" title="快递信息" :visible.sync="orderFormVisible" :show-close="false">
      <el-form >
        <div class="box">
          <el-form-item label="快递公司" :label-width="formLabelWidth">
            <el-select v-model="firm" placeholder="请选择"  v-on:change="getCode">
              <el-option v-for="(item,key) in firmList" :key="key" :label="item.expressCompany" :value="item.expressCode"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="订单编号" :label-width="formLabelWidth">
            <el-input v-model="orderNum" auto-complete="off"></el-input>
          </el-form-item>
        </div>
      </el-form>
      <div slot="footer" class="dialog-footer" style="text-align: center">
        <el-button @click="orderFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="deliverGoods()">确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>
<script>
  import pagination from "../common/Pagination";
  import base from "../../assets/base";
  export default {
    data() {
      return {
        page_no: 1,
        total_pages: 1,
        data_list: [],
        no_data: false,
        orderFormVisible:false,
        orderId:'',
        formLabelWidth:'120px',
        firm:'',//快递公司
        firmList:[],//公司列表
        orderNum:'',//订单编号
        code:'',
        expressName:''
      };
    },
    components: {
      pagination
    },
    created() {
      this.get_data();
      // this.send_good();
    },
    methods: {
      turn_page: function(i) {
        this.page_no = i;
        this.get_data();
      },
      get_data: function() {
        var data = {
          state: 3, //3.待发货4.待收货5.已完成6.待退款
          page_no: this.page_no,
          page_size: 10
        };
        var _this = this;
        this.base.axios_post(data, "/orderCenter/supplierQueryOrderInfoList",
          function(res) {
            if (res.code == 0) {
              if (res.data) {
                _this.data_list = res.data.list;
                _this.total_pages = res.data.pages;
                /*  _this.data_list.map(function(x, y) {
                    x.pay_time = _this.base.trans_time(x.pay_time, 2);
                  });*/
                _this.no_data = false;
              } else {
                _this.no_data = true;
              }
            } else {
              _this.data_list = [];
              _this.no_data = true;
            }
          },);
      },
      //一键发货按钮
      send_good: function(order_id) {
        var _this = this;
        this.orderFormVisible = true;
        this.orderId = order_id;
        var data = {
          order_id: order_id,
        };
        this.base.axios_post(data,'/centerConfig/queryExpressCompany',function (res) {
          if(res.code==0){
            _this.firmList = res.data;
            _this.get_data();
          }
        });

      },
      getCode(value){
        this.code = value;
      },
      //确定发货
      deliverGoods(){


        for(let i in this.firmList){
          if(this.firmList[i].expressCode==this.code){
            this.firm = this.firmList[i].expressCompany
          }
        }
        var _this = this;
        if(this.firm==''){
          this.$message.error('请选择快递公司');
        }else if(this.orderNum==''){
          this.$message.error('请输入订单编号');
        }else if(!/^[a-zA-Z0-9]{4,15}$/.test(this.orderNum)){
          this.$message.error('请输入正确的订单编号');
        }else{

          var data = {
            orderId: _this.orderId,
            expressCompany: _this.firm,
            expressNo:_this.orderNum,
            expressCode:_this.code,
          };
          _this.base.axios_post(data, "/orderCenter/supplierSendGoods", function(res){
            if(res.code == 0){
              base.alerter(res.message);
              _this.orderFormVisible = false;
              _this.page_no = 1;
              _this.get_data();
            }else{
              base.alerter(res.message);
            }
          });
        }
      }
    }
  };
</script>

<style>
  .Unprocessed .table .bor>th{
    text-align: center;
  }
  .Unprocessed .dialog>div{
    width: 640px!important;
  }
  .Unprocessed .dialog .box{
    width: 50%;
    margin-left:20%;
  }
  .Unprocessed .table table .number{
    text-align: right!important;
  }
  .Unprocessed .table table .overflow{
    max-width:200px!important;
    text-align: left;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap
  }
</style>
