﻿var gulp = require('gulp'),
    gulpSequence = require('gulp-sequence').use(gulp),
    less = require('gulp-less'),
    htmlmin = require('gulp-htmlmin'),
    imagemin = require('gulp-imagemin'),
    cssmin = require('gulp-minify-css'),
    clean = require('gulp-clean'),
    rev = require('gulp-rev-append'),
    uglify = require('gulp-uglify'),
    pump = require('pump'),
    babel = require("gulp-babel"),
    es2015 = require("babel-preset-es2015");

gulp.task('image', function () {
    gulp.src('newweb/images/*.{png,jpg,gif,ico}')
        .pipe(imagemin())
        .pipe(gulp.dest('src/images'));
});
gulp.task('css', function () {
    gulp.src('newweb/css/**/*.css')
        .pipe(cssmin())
        .pipe(gulp.dest('src/css/'));
});
gulp.task('index', function () {
    return gulp.src('newweb/config.json', { base: 'newweb' })
        .pipe(gulp.dest('src'));
});
gulp.task('copy', function (cb) {
    return gulp.src('newweb/js/common/*.js', { base: 'newweb' })
        .pipe(gulp.dest('src'));
});
gulp.task('es6', function () {
    gulp.src(['newweb/js/*.js'])
        .pipe(babel({ presets: [es2015] }))
        .pipe(uglify())
        .pipe(gulp.dest('src/js'));
});
gulp.task('html', function () {
    var options = {
        removeComments: true,//清除HTML注释
        collapseWhitespace: true,//压缩HTML
        minifyJS: true,//压缩页面JS
        minifyCSS: true//压缩页面CSS
    };
    gulp.src('newweb/**/*.html')
        .pipe(htmlmin(options))
        .pipe(rev(options))
        .pipe(gulp.dest('src/'));
});
gulp.task('clean', function () {
    return gulp.src('src', { read: false }).pipe(clean());
});

gulp.task('build', gulpSequence(['html', 'es6', 'index', 'copy', 'css', 'image']));