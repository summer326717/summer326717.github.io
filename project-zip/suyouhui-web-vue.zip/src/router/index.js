import Vue from 'vue'
import Router from 'vue-router'
import index from '@/components/index'
import agreement from '@/components/agreement'
import order from '@/components/order'
import join from '@/components/join'
import about from '@/components/about'
import send from '@/components/send'
import gheader from '@/components/header'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'gheader',
      component: gheader,
      children:[
        {
          path: '/',
          component: index
        },
        {
          path: '/index',
          name: 'index',
          component: index
        },
        {
          path: '/agreement',
          component: agreement
        },
        {
          path: '/send',
          component: send
        },
        {
          path: '/order',
          component: order
        },
        {
          path: '/about',
          component: about
        },
        {
          path: '/join',
          component: join
        },
      ]
    },

  ]
})
