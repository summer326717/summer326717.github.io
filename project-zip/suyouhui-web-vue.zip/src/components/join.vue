<template>
  <div class="join">
    <header>
      <img src="../assets/images/join.png">
    </header>
    <div class="content">
      <p>加入我们</p>
      <p></p>
      <div>
        <div>
          <p class="tit">电商运营</p>
          <div class="detail">
            <p class="title">岗位职责：</p>
            <p>1.负责公司店铺及相关产品在互联网的推广，能有效提升店铺及产品的访问量；</p>
            <p>2.使用淘宝各项营销工具(直通车/淘客/钻石展位等)进行商品推广，达到销售目标所需要的流量，进而提长销量；</p>
            <p>3.负责各项活动或者品牌的宣传推广方案的设计、讨论和实施；</p>
            <p>4.对店铺做出专业的数据分析，平时做好竞争对手店铺的数据的采集、评估与分析；</p>
            <p>5.店铺的日常维护及上级交代的其他事务。</p>
            <p class="title">任职要求：</p>
            <p>1、有天猫/淘宝平台店铺独立运营经验1年以上；</p>
            <p>2、具备一定的数据分析能力和总结能力；</p>
            <p>3、具有优秀的沟通能力、组织协调能力；</p>
            <p>4、能承受较强的工作压力，拥有强烈的责任感，具有良好的职业操守；</p>
          </div>
        </div>
        <div>
          <p class="tit">BD经理</p>
          <div class="detail">
            <p class="title">岗位职责：</p>
            <p>1.负责速邮汇平台异业商家合作洽谈。</p>
            <p>2.负责速邮汇平台大客户开发拓展与维护。</p>
            <p>3.负责速邮汇平台合作驿站的开发和维护。</p>
            <p class="title">任职要求：</p>
            <p>1年以上移动互联网渠道拓展工作经验；</p>
            <p>2、具有较强的商务拓展及沟通能力；具有良好的职业形象和职业素质；</p>
            <p>3、对客户端产品有出色理解力和洞察力，较好的活动策划功底；</p>
            <p>4、具备较强市场意识和关系基础，有渠道市场人脉关系优先；</p>
            <p>5、优秀的沟通协作和项目管理能力，能够在复杂环境下组织工作；</p>
            <p>6、追求卓越，不甘平庸，具备强烈的事业心和开拓创新精神；</p>
            <p>7、良好的职业操守、工作态度积极主动、学习能力强，能够承受较大工作压力。</p>
          </div>
        </div>
        <div>
          <p class="tit">新媒体运营</p>
          <div class="detail">
            <p class="title">岗位职责：</p>
            <p>1.微信营销项目方案的策划、创意、执行、运营； 提高公司经营产品信息的传播量，提高产品在目标客户群中的知名度；</p>
            <p>2.管理企业微信运营；分配人员负责日常内容的编辑、发布、维护、管理、互动等工作，提高影响力和关注度。</p>
            <p>3.建立有效运营手段提升订阅数和用户活跃度；抓住潜在客户，发展新客户,与微信的粉丝做好互动交流，归纳粉丝的问题反馈和批评建议，了解粉丝需求，对微信粉丝的需求行为进行分析与总结。</p>
            <p>4.挖掘和分析微信粉丝使用习惯、情感及体验感受，并做专题策划、编辑制作；</p>
            <p>5.负责日常微信以及其他新媒体渠道文案的撰写与发布；</p>
            <p class="title">任职要求：</p>
            <p>1、有2年以上相关工作经验；</p>
            <p>2、具有较强的新闻、热点敏感性，有较强的文案功底；</p>
            <p>3、有丰富的线上活动推广实战经验，了解知识性媒体特点，熟悉口碑营销的执行操作流程；</p>
            <p>4、网感好，创意优，执行力强，有良好的策略思考能力并能独立撰写方案，一定程度掌握图片处理软件；</p>
            <p>5、对微博和微信运营成功案例者优先；</p>
          </div>
        </div>
        <div class="address">
          <p>地址: 杭州市下城区华丰路333号3楼 </p>
          <p>邮箱: suyh@100emall.com </p>
          <p>电话: 400-114-1788</p>
          <p>传真: 0571-86724908</p>
        </div>
      </div>

      <p>等多职位请直接联系我们!</p>
    </div>
  </div>
</template>
<script></script>
<style scoped>
  .join{
    width: 100%;
  }
  .join header{
    width: 100%;
    background:rgb(86,201,166);
    padding-top: 30px;
  }
  .join header img{
    width: 1200px;
  }
  .join .content{
    width: 1200px;
    box-sizing: border-box;
    padding: 33px;
    box-shadow: 2px 2px 4px 3px #d6d6d6;
    background: #fcfcfc;
    margin:30px auto;
    border-radius: 12px;

  }
  .join .content>p{
    font-size: 20px;
  }
  .join .content>p:last-child{
    font-size: 14px;
    color: #9d9d9d;
    text-align: left;
    margin: 20px 10px;
  }
  .join .content>p:nth-child(2){
    height: 1px;
    width: 35px;
    background: #6fcea4;
    margin: 10px auto;
    margin-bottom: 80px;
  }
  .join .content>div{
    display: flex;
    justify-content:space-between;
  }
  .join .content div .tit{
    text-align: center;
  }
  .join .content div .detail{
    text-align: left;
    margin-top: 30px;
    border: solid 1px #b4b4b4;
    width: 240px;
    height: 350px;
    overflow-y: scroll;
    padding: 15px;
    font-size: 14px;
    color: #606060;
    border-radius: 4px;
  }
  .join .content div .detail p{
    line-height: 21px;
  }
  .join .content div .detail .title{
    font-size: 16px;
    color: #000;
    margin: 10px 0;
  }
  .join .content div .address{
    font-size: 14px;
    color: #7f7f7f;
    text-align: left;
    height: 100px;
    margin-top: 200px;
  }
</style>


















