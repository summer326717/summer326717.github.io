<template>
  <div class="about">
    <div class="header">
      <img src="../assets/images/us.png">
    </div>
    <div class="content">
      <div class="item">
        <div class="tit">关于速邮汇</div>
        <div></div>
        <div class="detail">
          <div class="textPic">速邮汇</div>
          <div class="deCon">
            <p>速邮汇是杭州厚通网络科技有限公司旗下的网站，面向快递信息提供一站式的管理服务。旨在解决当前快递行业出现的效率低，管理紊乱等问题。运用科学管理方法，更有针对性地完善快递在运输过程中落单、跑单的现象，提高快递运输的效率。</p>
            <p>同时支持在线手机查询，有独立的手机客户端随时随地查快递。与多家快递公司合作，给予用户全面、便捷的快递查询服务，告别快递信息复杂、难找的困扰，为用户构建一个全新的快递管理平台。 </p>
          </div>
        </div>
      </div>
      <div class="item">
        <div class="tit">新闻中心</div>
        <div></div>
        <div class="detail">
          <div>
            <p class="title">杭州年内建800个自助快递取货点</p>
            <p class="time">2014-02-17 09:34</p>
            <p class="con">“最后一公里”配送是快递业发力的重点。日前，杭州市政府有关负责人在政府工作报告中表示，今年杭州将在主城区建立800个“E邮柜”公共服务站点，力图解决快递“最后一公里”配送。</p>
            <p>
              <img src="../assets/images/about.png">
            </p>
          </div>
          <div>
            <p class="title">快递行业将制定指导价</p>
            <p class="time">2014-01-20 07:34</p>
            <p class="con">“夺命快递”案引起了社会对物流快递行业安全监管的高度关注，市人大代表、国家邮政局副局长刘君表示，国家邮政局正在研究出台快递费用指导价。如何对这些快递实行有效监管，是目前需要进一步解决的问题。</p>
            <p>
              <img src="../assets/images/and.png">
            </p>
          </div>
          <div>
            <p class="title">国家邮政局：快递业需借力互联网</p>
            <p class="time">2014-03-05 08:55</p>
            <p class="con">电子商务 网络购物等新型服务业态的迅猛发展使快递服务日益大众化。国家邮政局局长马军胜表示，拥抱互联网，快递企业才会走得更远。在业内人士看来，互联网技术将有利于企业降低成本，更好地为消费者服务。</p>
            <p>
              <img src="../assets/images/me.png">
            </p>
          </div>
        </div>
      </div>
      <div class="item">
        <div class="tit">合作伙伴</div>
        <div></div>
        <div class="detail">
          <div>
            <img src="../assets/images/SF.png">
          </div>
          <div>
            <img src="../assets/images/TTKD.png">
          </div>
          <div>
            <img src="../assets/images/JD.png">
          </div>
          <div>
            <img src="../assets/images/debang.png">
          </div>
          <div>
            <img src="../assets/images/sto.png">
          </div>
        </div>
      </div>

    </div>
  </div>
</template>
<script></script>
<style scoped>
  .about{
    width: 100%;
    overflow: hidden;
  }
  .about .header{
    width: 100%;
    background:rgb(86,201,166);
  }
  .about .header img{
    width: 1000px;
    margin-top: 40px;
  }
  .about .content{
    width: 1200px;
    margin: 30px auto;
    border: solid 1px #e1e1e1;
    border-radius: 12px;
    box-shadow: 2px 2px 4px 2px #afafaf;
    background: #fcfcfc;
    margin-bottom: 10px;
  }
  .about .content .item{
    margin-top: 30px;
    padding-bottom:50px;
  }
  .about .content .item .tit{
    font-size: 20px;
    padding-bottom: 15px;
    margin: 0 auto;
  }
  .about .content .item>div:nth-child(2){
    background:rgb(86,201,166) ;
    height: 1px;
    width: 30px;
    margin: 0 auto;
  }
  .about .content .item .detail{
    overflow: hidden;
    margin-top: 45px;
  }
  .about .content .item .detail>div{
    float: left;
  }
  .about .content .item .detail .textPic{
    width: 120px;
    height: 120px;
    line-height: 120px;
    background: #56C9A6;
    color: #fff;
    text-align: center;
    margin-left: 1%;
    font-size: 18px;
  }
  .about .content .item .detail .deCon{
    width: 89%;
    text-align: left;
    font-size: 16px;
    padding: 0 10px;
    box-sizing: border-box;
  }
  .about .content .item .detail .deCon p{
    line-height: 24px;
    margin-top: 6px;
    font-size: 15px;
  }
  .about .content .item:nth-child(2) .detail{
    display: flex;
    justify-content:space-between;
    box-sizing: border-box;
    padding: 0 30px;
  }
  .about .content .item:nth-child(2) .detail>div{
    width: 340px;
    height:450px;
    box-sizing: border-box;
    padding: 35px 15px 0 15px;
    margin: 10px;
    transition: transform .8s;
    color: #949494;
    text-align: left;
    position: relative;
  }
  .about .content .item:nth-child(2) .detail>div img{
    width: 310px;
    position: absolute;
    bottom: 0;
  }
  .about .content .item:nth-child(2) .detail>div:hover{
    box-shadow: 2px 1px 4px 2px #c4c4c4;
    transform: scale(1.03);
    background: #fff;
  }
  .about .content .item:nth-child(2) .detail>div .title{
    color: #000;
    margin-bottom: 17px;
  }
  .about .content .item:nth-child(2) .detail>div .time{
    margin-bottom: 25px;
  }
  .about .content .item:nth-child(2) .detail>div .con{
    font-size: 14px;
    line-height: 22px;
  }
  .about .content .item:nth-child(3) .detail{
    display: flex;
    justify-content:space-between;
    box-sizing: border-box;
    padding: 0 30px;
  }
</style>















