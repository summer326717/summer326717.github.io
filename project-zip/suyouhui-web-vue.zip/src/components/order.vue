<template>
  <div class="order">
    <div class="content">
      <div class="orderTop">
        <p class="title">订单查询</p>
        <div class="con">
          <div class="item">
            <span>订单状态：</span>
            <p>
              <button @click="lanJian()" :class="{activity:state==1}">待揽件</button>
              <button @click="fulfill()" :class="{activity:state==2}" class="margin">已完成</button>
            </p>
          </div>
          <div class="item">
            <span>下单时间：</span>
            <p>
              <el-date-picker
                v-model="start_time"
                :editable="false"
                type="date"
                id="start"
                value-format="yyyy-MM-dd"
                @change="selectStartTime"
                placeholder="选择日期">
              </el-date-picker>
              -
              <el-date-picker
                v-model="end_time"
                :editable="false"
                type="date"
                id="end"
                value-format="yyyy-MM-dd"
                @change="selectEndTime"
                placeholder="选择日期">
              </el-date-picker>
            </p>
          </div>
          <div class="item">
            <span>批量订单号：</span>
            <p>
              <input v-model="order_num" class="orderNum" type="text" placeholder="请输入订单编号">
              <button @click="selectOrder()">查询</button>
              <button @click="exportList()" class="margin">导出</button>
            </p>
          </div>
        </div>
      </div>
      <div class="orderBottom">
        <table class="myTable">
          <tr>
            <th style="text-align: left">
              <input v-model="all_check" type="checkbox" name="name">全选
            </th>
            <th>编号</th>
            <th>批量订单号</th>
            <th>下单时间</th>
            <th class="number">数量</th>
            <th>操作</th>
          </tr>
          <tr v-for="(v,k) in orderList" :key="k">
            <td style="text-align: left">
              <input v-model="checkBox[k]" type="checkbox" name="name">
            </td>
            <td>{{k+1}}</td>
            <td>{{v.exp_ord_number}}</td>
            <td>{{v.exp_ord_time}}</td>
            <td class="number">{{v.exp_ord_size}}</td>
            <td>
              <button @click="check_order(k,orderList)" style="color: #a5a8a8">查看</button>
              <button @click="out_order(k,orderList)" style="color: #56C9A6">导出</button>
              <button @click="del_order(k,orderList)" style="color: #c97b74">删除</button>
            </td>
          </tr>
        </table>
        <el-pagination
          v-if="orderList.length>0"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="currentPage"
          :page-size="10"
          layout="prev, pager, next, jumper"
          :total="totals">
        </el-pagination>
        <div v-if="orderList==''" class="no_data"><img src="../assets/images/no_data.png"></div>
      </div>
      <el-dialog
        title="订单详情"
        :visible.sync="dialogVisible"
        width="1000px"
        center>
        <table class="myTable">
          <tr>
            <th>编号</th>
            <th>快递单号</th>
            <th>厚通编号</th>
            <th>收件人</th>
            <th>收件地址</th>
            <th>手机号</th>
            <th>快递公司</th>
          </tr>
          <tr v-for="(v,k) in orderDetailList" :key="k">
            <td>{{k+1}}</td>
            <td>{{v.express_number}}</td>
            <td>{{v.ht_number}}</td>
            <td>{{v.add_name}}</td>
            <td>{{v.add_address}}</td>
            <td>{{v.add_phone}}</td>
            <td>{{v.express_name}}</td>
          </tr>
        </table>
        <el-pagination
          v-if="orderDetailList.length>1"
          @size-change="handleSizeChange2"
          @current-change="handleCurrentChange2"
          :current-page.sync="currentPage2"
          :page-size="10"
          layout="prev, pager, next, jumper"
          :total="totals2">
        </el-pagination>
      </el-dialog>

    </div>
  </div>
</template>
<script>
  const Cookie = require('js-Cookie');
  const hex_md5 = require("crypto-js/md5");
  import base from '../assets/base';
export default {
  data(){
    return{
      orderList:[],
      start_time:'2017-09-17',
      end_time:'2018-02-03',
      state:1,//1待揽件，2是已完成
      currentPage:1,
      totals:1,
      checkBox:[],
      all_check:false,
      order_num:'',//订单编号
      ord_id_list:[],

      currentPage2:1,
      dialogVisible:false,
      orderDetailList:[],
      totals2:1
    }
  },
  created(){
    let token = Cookie.get('g_token');
    if(token==null||token==undefined||token==""){
      this.$router.push("/");
    }
    this.get_data('','');
    this.start_time = new Date().getFullYear() + "-" + (new Date().getMonth()+1) + "-" + new Date().getDate();
    this.end_time = new Date().getFullYear() + "-" + (new Date().getMonth()+1) + "-" + new Date().getDate();
  },
  methods:{
    //查看
    check_order(index,data){
      this.dialogVisible = true;
      let _this = this;
      let json = {
        exp_ord_id:data[index].exp_ord_id,
        page_size:10,
        page_no:this.currentPage2
      };
      base.axios_post(json,'/9/token/findBigOrderDetails',function (res) {
        if(res.mark==0){
          _this.orderDetailList = res.obj.items;
        }else if(res.mark==100 || res.mark==101){
          _this.go_back(res.tip);
        }else{
          base.alerter(res.tip);
        }
      });
    },

    //删除
    del_order(index,data){
      let _this = this;
      let _data = {
        'exp_ord_id': data[index].exp_ord_id
      };
      base.axios_post(_data,'/9/token/cancelBigOrder',function (res) {
        if(res.mark==0){
          base.alerter(res.tip);
          _this.get_data();
        }else if(res.mark==100 || res.mark==101){
          _this.go_back(res.tip);
        }else{
          base.alerter(res.tip);
        }
      })
    },

    //单个导出
    out_order(index,data){
      let order_id = data[index].exp_ord_id;
      this._export(order_id)
    },

    //待揽件
    lanJian(){
      this.state = 1;
      this.get_data(this.start_time,this.end_time);
    },

    //已完成
    fulfill(){
      this.state = 2;
      this.get_data(this.start_time,this.end_time);
    },

    selectStartTime(value){
      this.start_time = value;
    },
    selectEndTime(value){
      this.end_time = value;
    },

    //查询
    selectOrder(){
      this.get_data(this.start_time,this.end_time);
    },

    //多个导出
    exportList(){
      let _this = this;
      this.checkBox.map(function (x,y) {
        if(x){
          _this.ord_id_list.push(_this.orderList[y].exp_ord_id);
        }
      });
      let ord_id = this.ord_id_list.toString();
      this._export(ord_id);
    },

    //获取订单列表
    get_data(start,end){
      let _this = this;

      let json = {
        state:this.state,
        page_size:10,
        page_no:this.currentPage,
        exp_ord_number:this.order_num,
        start:start,
        end:end,
      };
      base.axios_post(json,'/9/token/findBigOrderByCondition',function (res) {
          if(res.mark==0){
            if(res.obj.items.length>0){
              _this.totals = res.obj.total_pages;
              _this.orderList = res.obj.items;
              _this.orderList.map(function (x,y) {
                x.exp_ord_time = base.trans_time(x.exp_ord_time,2)
              });
            }
          }else if(res.mark==100 || res.mark==101){
            _this.go_back(res.tip);
          }else{
            base.alerter(res.tip);
          }
      });
    },

    handleSizeChange(i){
      this.currentPage = i;
      this.get_data(this.start_time,this.end_time);
    },
    handleCurrentChange(i){
      this.currentPage = i;
      this.get_data(this.start_time,this.end_time);
    },

    handleSizeChange2(i){
      this.currentPage2 = i;
      this.check_order()
    },
    handleCurrentChange2(i){
      this.currentPage2 = i;
      this.check_order()
    },

    _export(id){
      let token = Cookie.get('g_token');
      let time = Date.parse(new Date());
      let hash = hex_md5(time + "hotol");
      time = base.Encrypt(base.check_key(), time);
      hash = base.Encrypt(base.check_key(), hash);
      time = encodeURIComponent(time);
      hash = encodeURIComponent(hash);
      window.location.href = '/hthome/suyh/app/9/fileToken/exportBigOrderByIds?exp_ord_ids=' + id + '&version=9&client_type=4&Timestamp=' + time + '&SignInfo=' + hash + '&token=' + token;
    },

    //返回首页
    go_back(mes){
        this.orderList = [];
        base.back();
        this.$router.push("/");
    },
  },
  watch:{
    deep:true,
    all_check:function (curVal,oldVal) {
      if(curVal){
        for(let i in this.orderList){
          this.checkBox[i] = true;
        }
      }else{
        for(let i in this.orderList){
          this.checkBox[i] = false;
        }
      }
    }
  }
}
</script>
<style  scoped>
.order{
  width: 100%;
}
.order .content{
  width: 1200px;
  margin: 30px auto;
  border-radius: 8px;
  box-shadow: 2px 2px 2px 2px #d8d8d8;
  position: relative;
  background: #fcfcfc;
}
.order .content>div{
  padding: 30px;
  box-sizing: border-box;
  width: 100%;
}
.order .content .orderTop{
  background: #ededed;
}
.order .content .orderTop .title{
  font-size: 22px;
  margin-top: -10px;
  color: #666666;
  margin-bottom: 20px;
}
.order .content table tr .number{
  text-align: right;
  padding-right: 30px;
}
.order .content table{
  width: 100%;
  border-collapse: collapse;
  margin: 0 auto;
  margin-top:-20px;
  margin-bottom: 20px;
}
.order .content table tr{
  border-bottom: solid 1px #d7d7d7;
}
.order .content table tr td{
  padding: 5px 3px;
  font-size: 14px;
  text-align: center;
}
.order .content table th{
  font-size: 16px;
  padding: 15px 0;
  color: #666666;
  font-weight:500;
  text-align: center;
}
.order .content table tr td>button{
  padding: 3px 7px;
  font-size: 12px;
  border-radius: 3px;
}
.order .content table tr td>button:hover{
  background: #56C9A6;
  color: #fff!important;
  border-color: #56C9A6;
}
.order .content table .overflow{
  max-width: 240px;
  text-align: left;
}
.order .content .orderTop .con{
  box-sizing: border-box;
  padding-left: 3%;
}
.order .content .orderTop .con>.item{
  margin: 10px 0;
  overflow: hidden;
}
.order .content .orderTop .con>.item>span{
  float: left;
  font-size: 18px;
  height: 40px;
  line-height: 40px;
  display: inline-block;
  width: 150px;
  text-align: left;
}
.order .content .orderTop .con>.item>p{
  float: left;
  height: 40px;
  line-height: 40px;
  width: 85%;
  text-align: left;
}
.order .content .orderTop .con>.item:first-child>p button{
  height:34px;
  line-height:34px;
  padding: 0 15px;
  border-radius: 5px;
  margin-top: 3px;
  font-size: 14px;
  background: #fff;
  border: solid 1px #bbbbbb;
}
.order .content .activity{
  background: #56C9A6!important;
  border: solid 1px #56C9A6;
  color: #fff;
}

.order .content .orderTop .con>.item:last-child>p button{
  background: #56C9A6;
  height: 34px;
  line-height: 34px;
  color: #fff;
  border-radius: 5px;
  padding: 0 25px;
  font-size: 14px;
}
.order .content .orderTop .con>.item:last-child>p>.orderNum{
  width: 452px;
  line-height: 40px;
  height: 40px;
  border:solid 1px #dfdfdf;
  font-size: 14px;
  border-radius: 5px;
  margin-right: 130px;
  padding-left: 10px;
  box-sizing: border-box;
  background: #fff;
}
::-webkit-input-placeholder{
  color: #babfcb;
}
.order .content .orderTop .con>.item:last-child>p>.orderNum:focus{
  border:solid 1px #56C9A6;
}
.margin{
  margin-left: 20px;
}
.order .content .el-pagination{
  text-align: right;
}
.order .content .el-pagination>button,.el-pagination>ul li{
  background: #fcfcfc !important;
}





















</style>
