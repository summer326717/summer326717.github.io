<template>
  <div class="Content">
    <div class="hea">
      <header>
      <span>
        <img src="../assets/images/logo.png">
      </span>
        <ul>
          <li @click="index()">首页</li>
          <li @click="send()">大客户寄件</li>
          <li @click="order()">订单查询</li>
          <li @click="about()">关于我们</li>
          <li @click="join_in">加入我们</li>
          <li v-if="login_state==0" @click="log_in()">登录</li>
          <li v-if="login_state==0">
            <button @click="g_register()" class="reg">注册</button>
          </li>
          <li v-if="login_state==1" style="font-size: 16px">{{accountNum}}<span @click="back()">【退出】</span></li>
        </ul>
      </header>
      <el-dialog
        class="loginBox"
        title=""
        :visible.sync="login_Visible"
        width="400px"
        center>
        <span  v-if="!showCode&&!registerBtn" class="title">登 录</span>
        <span  v-if="showCode" class="title m">忘记密码</span>
        <span  v-if="registerBtn" class="title">注 册</span>
        <div class="dialogContent">
          <span class="errorMsg" v-if="errorMsg">{{errorMsg}}</span>
          <input v-model="accountNum" placeholder="请输入手机号"/>
          <div class="phoneCode" v-if="showCode">
            <input v-model="phoneCode" placeholder="请输入验证码"/>
            <span v-if="!again" @click="getCode(1)">获取验证码</span>
            <span v-if="again">{{num}}</span>
          </div>
          <div class="phoneCode" v-if="!showCode&&registerBtn">
            <input v-model="phoneCode" placeholder="请输入验证码"/>
            <span v-if="!again" @click="getCode(2)">获取验证码</span>
            <span v-if="again">{{num}}</span>
          </div>
          <div class="bbb">
            <input @keyup.13="sure_submit" v-if="registerBtn" :type="inputType" v-model="passWord" placeholder="请输入密码"/>
            <input  @keyup.13="login" v-if="!showCode&&!registerBtn" :type="inputType" v-model="passWord" placeholder="请输入密码"/>
            <input @keyup.13="sure_login" v-if="showCode" :type="inputType" v-model="newPassWord" placeholder="请输入新密码"/>
            <i v-if="inputType=='text'"><img src="../assets/images/ck.png" @click="inputType = 'password'"></i>
            <i v-if="inputType=='password'"><img src="../assets/images/close.png"  @click="inputType = 'text'"></i>
          </div>
          <span  v-if="!showCode&&!registerBtn" @click="register()" class="zhuC">立即注册</span>
          <span  v-if="!showCode&&!registerBtn" @click="forgetPws">忘记密码?</span>
        </div>
        <div slot="footer" class="dialog-footer">
          <el-button v-if="!showCode && !registerBtn" class="loginBtn" type="primary" @click="login">登 录</el-button>
          <el-button v-if="showCode" class="loginBtn" type="primary" @click="sure_login">确 定</el-button>
          <el-button v-if="registerBtn" class="loginBtn" type="primary" @click="sure_submit">提 交</el-button>
          <div v-if="registerBtn" class="box_checkbox">
            <span @click="agree()" class="sign"><i v-if="agreeSign" class="el-icon-check"></i></span>
            <span class="checkbox">我已阅读并同意</span>
            <span @click="turn_agree">《用户使用协议》</span>
          </div>
        </div>
      </el-dialog>
      <el-dialog
        class="loginBox"
        title=""
        :visible.sync="reg_Visible"
        width="400px"
        center>
        <span class="title">注 册</span>
        <div class="dialogContent">
          <span class="errorMsg">{{errorMsg}}</span>
          <input v-model="accountNum" placeholder="请输入手机号"/>
          <div class="phoneCode">
            <input v-model="phoneCode" placeholder="请输入验证码"/>
            <span v-if="!again" @click="getCode(2)">获取验证码</span>
            <span v-if="again">{{num}}</span>
          </div>
          <div class="bbb">
            <input @keyup.13="sure_submit" :type="inputType" v-model="passWord" placeholder="请输入密码"/>
            <i v-if="inputType=='text'"><img src="../assets/images/ck.png" @click="inputType = 'password'"></i>
            <i v-if="inputType=='password'"><img src="../assets/images/close.png"  @click="inputType = 'text'"></i>
          </div>
        </div>
        <div slot="footer" class="dialog-footer">
          <el-button class="loginBtn" type="primary" @click="sure_submit">提 交</el-button>
          <div class="box_checkbox">
            <span @click="agree()" class="sign"><i v-if="agreeSign" class="el-icon-check"></i></span>
            <span class="checkbox">我已阅读并同意</span>
            <span @click="turn_agree">《用户使用协议》</span>
          </div>
        </div>
      </el-dialog>
    </div>
    <router-view></router-view>
    <div class="footer">
      <p>Copyright ©2013 厚通网络 浙ICP备14024016号-1</p>
      <span style="display: inline-block;width:50px"></span>
      <p>服务热线：400-114-1788 服务邮箱：suyh@100emall.com</p>
    </div>
  </div>

</template>
<script>
  const Cookie = require('js-Cookie');
  import base from '../assets/base'
  export default {
    name: 'gheader',
    data () {
      return {
        login_Visible:false,//登录弹框
        reg_Visible:false,//注册弹框
        accountNum:'',//账号
        passWord:'',//密码
        inputType:'password',
        errorMsg:'',
        num:60,
        phoneCode:'',//手机验证码
        showCode:false,//show验证码
        registerBtn:false,//立即注册
        again:false,//注册验证码
        newPassWord:'',
        agreeSign:false,//阅读协议
        login_state:0,//1是已登录 ，0是未登录
        turnPage:0,//判断登录之前用户点击的是哪个页面，登录后跳转。0是首页，1是大客户，2是订单查询
      }
    },
    created(){
      let state = Cookie.get('g_token');
      if(state){
        this.login_state = 1;
        this.accountNum = Cookie.get('memb_tel');
      }else{
        this.login_state = 0;
      }
    },
    methods:{
      index(){
        this.turnPage = 0;
        this.$router.push("/");
      },
      //大客户寄件
      send(){
        this.turnPage = 1;
        if( Cookie.get('g_token')){
          this.$router.push("/send");
        }else{
          this.login_Visible = true;
        }
      },
      //订单查询
      order(){
        this.turnPage = 2;
        if( Cookie.get('g_token')){
          this.$router.push("/order");
        }else{
          this.login_Visible = true;
        }
      },
      //关于我们
      about(){
        this.$router.push("/about");
      },
      //加入我们
      join_in(){
        this.$router.push("/join");
      },
      //导航栏注册、
      g_register(){
        this.reg_Visible = true;
      },
      //导航栏登录
      log_in(){
        this.login_Visible = true;
      },
      //登录
      login(){
        if(this.accountNum==''){
          base.alerter('请输入账号')
        }else if(this.passWord==''){
          base.alerter('请输入密码')
        }else if(!/^1[3|4|5|7|8][0-9]{9}$/.test(this.accountNum)){
          this.errorMsg = '请输入正确的手机号码!'
        }else if(!/^[a-zA-Z0-9]{6,20}$/.test(this.passWord)){
          this.errorMsg = '密码格式为6~20位大小写字母或数字'
        }else{
          let json = {
            memb_phone: this.accountNum,
            memb_password: this.passWord,
            push_token: '',
            device_number: ''
          };
          let _this = this;
          base.axios_post(json,'/5/webLogin',function (res) {
            if(res){
              if(res.mark=='0'){
                Cookie.set('g_token', res.obj.token, { expires: Infinity });
                Cookie.set('memb_role', res.obj.memb_role, { expires: Infinity });
                Cookie.set('memb_discount', res.obj.memb_discount, { expires: Infinity })
                Cookie.set('memb_tel', _this.accountNum, { expires: Infinity });
                _this.login_state = 1;
                _this.login_Visible = false;
                if(_this.turnPage===0){
                  _this.$router.push("/");
                }else if(_this.turnPage===1){
                  _this.$router.push("/send");
                }else if(_this.turnPage===2){
                  _this.$router.push("/order");
                }
              }else{
                base.alerter(res.tip);
              }
            }else{
              base.alerter('未知错误')
            }
          })
        }

      },
      //忘记密码
      forgetPws(){
        this.showCode = true;
      },
      //立即注册
      register(){
        this.registerBtn = true;
      },
      get_gray(){
        if (this.num == 0) {
          this.again = false;
          this.num = 60;
        } else {
          this.again = true;
          this.num--;
          let _this = this;
          setTimeout(_this.get_gray, 1000);
        }
      },
      //获取验证码
      getCode(index){
        if(this.accountNum==''){
          base.alerter('请输入手机号码')
        }else if(!/^1[3|4|5|7|8][0-9]{9}$/.test(this.accountNum)){
          this.errorMsg = '请输入正确的手机号码!'
        }else{
          let data = {
            'phoneno': this.accountNum
          };
          let _this = this;
          if(index==2){//index=2是注册时的验证码
            base.axios_post(data,'/3/sendRegValidateCode',function (res) {
              if(res.mark=='0'){
                _this.get_gray();
              }else if(res.mark=='1'){
                _this.login_Visible = true;
                _this.showCode = false;
                _this.registerBtn = false;
                _this.reg_Visible = false;
                base.alerter(res.tip);
              }else{
                base.alerter(res.tip);
              }
            });
          }else if(index==1){
            base.axios_post(data,'/3/sendForgetPassValidateCode',function (res) {
              if(res.mark=='0'){
                _this.get_gray();
              }
            });
          }
        }

      },
      //忘记密码-确定
      sure_login(){
        if(this.phoneCode==''){
          this.errorMsg = '验证码不能为空'
        }else if(this.newPassWord==''){
          this.errorMsg = '新密码不能为空'
        }else if(!/^[a-zA-Z0-9]{6,20}$/.test(this.newPassWord)){
          this.errorMsg = '密码格式为6~20位大小写字母或数字'
        }else{
          let data = {
            memb_phone: this.accountNum,
            memb_password: this.newPassWord,
            verification_code: this.phoneCode,
          };
          let _this = this;
          base.axios_post(data,'/3/forgetPwd',function (res) {
            if(res.mark=='0'){
              base.alerter('重置密码成功，请重新登录');
              _this.passWord = _this.newPassWord;
              _this.showCode = false;
              _this.registerBtn = false;
            }else{
              base.alerter(res.tip);
            }
          });
        }
      },
      //注册
      sure_submit(){
        if(this.phoneCode==''){
          this.errorMsg = '验证码不能为空'
        }else if(this.passWord==''){
          this.errorMsg = '密码不能为空'
        }else if(!/^[a-zA-Z0-9]{6,20}$/.test(this.passWord)){
          this.errorMsg = '密码格式为6~20位大小写字母或数字'
        }else if(!this.agreeSign){
          this.errorMsg = '请仔细阅读用并同意户使用协议'
        }else{
          let data = {
            memb_phone: this.accountNum,
            memb_password: this.passWord,
            verification_code: this.phoneCode,
            push_token: '',
            promote_code: '',
            memb_register_longitude: 0,
            memb_register_latitude: 0,
            memb_register_region: 0,
          };
          let _this = this;
          base.axios_post(data,'/3/register',function (res) {
            if(res.mark=='0'){
              _this.showCode = false;
              _this.registerBtn = false;
              base.alerter('注册成功，请重新登录');
            }else if(res.mark=='1'){
              _this.showCode = false;
              _this.registerBtn = false;
              base.alerter(res.tip);
            }else{
              base.alerter(res.tip)
            }
          })
        }
      },
      //同意协议
      agree(){
        if(this.agreeSign){
          this.agreeSign = false;
        }else{
          this.agreeSign = true;
        }
      },
      turn_agree(){
        this.login_Visible = false;
        this.reg_Visible = false;
        this.$router.push("/agreement");
      },
      back(){
        this.login_state = 0;
        Cookie.remove('g_token');
        Cookie.remove('memb_role');
        Cookie.remove('memb_discount');
        Cookie.remove('memb_tel');
        this.$router.push("/");
      },
    },
    watch:{
      deep:true,
      errorMsg(curVal,oldVal){
        clearTimeout(timer);
        let _this = this;
        let timer = setTimeout(function () {
          _this.errorMsg = ''
        },3000)
      },
      login_Visible(curVal,oldVal){
        this.showCode = false;
        this.registerBtn = false;
        this.agreeSign = false;
        this.passWord = '';
        this.newPassWord='';
        this.phoneCode='';
        this.errorMsg = '';
      },
      '$route' (to, from) {
        let state = Cookie.get('g_token');
        if(state){
          this.login_state = 1;
          this.accountNum = Cookie.get('memb_tel');
        }else{
          this.login_state = 0;
        }
      }
    }

  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
  .Content{
    width: 100%;
    position: relative;
  }
  .hea{
    width: 100%;
    background: rgb(86,201,166);
    overflow: hidden;
    padding: 30px 0;
  }
  .hea header{
    width: 1200px;
    margin: 0 auto;
    display: flex;
    align-items:center;
    justify-content:space-between;
    box-sizing: border-box;
    padding: 0 20px;
  }
  .hea header ul{
    overflow: hidden;
  }
  .hea header ul li{
    float: left;
    margin: 0 17px;
    font-size: 18px;
    color: #fff;
    vertical-align: bottom;
    height: 42px;
    line-height: 42px;
    cursor: pointer;
    overflow: hidden;
  }
  .hea header ul li>button{
    color: #fff;
    background:none;
    border: solid 1px #fff;
    border-radius: 5px;
    padding: 5px 15px;
    margin-right: 2px;
  }
  .hea header ul li>button:hover{
    box-shadow: 1px 1px 1px 1px #f2f2f2;
    background: #fff;
    color: #56C9A6;
  }
  .hea .loginBtn{
    background: #56C9A6;
    border-color: #56C9A6;
    width: 90%;
    margin: 0 auto;
    margin-bottom: 20px;
    font-size: 16px;
    text-align: center;
  }
  .hea .loginBtn>span{
    font-size: 16px;
    float: none!important;
    margin: 0!important;
    color: #fff!important;
  }
  .hea .loginBox div{
    overflow: hidden;
    margin: 0 auto;
    width: 100%;
    box-sizing: border-box;
  }
  .hea .loginBox .dialogContent{
    margin-top: 20px;
  }
  .hea .loginBox .dialogContent>input{
    width: 96%;
    margin-left: 1%;
  }
  .hea .loginBox div .bbb{
    position: relative;
    width: 98%;
  }
  .hea .loginBox div .errorMsg{
    color: #ca3a1c;
    font-size: 14px;
    display: inline-block;
    width: 100%;
    text-align: center;
    margin-bottom: 10px;
  }
  .hea .loginBox div input{
    border: solid 1px #bfbfbf;
    border-radius: 6px;
    padding: 8px 15px;
    box-sizing: border-box;
    width: 98%;
    margin-bottom: 20px;
  }
  .hea .loginBox div input:focus{
    border: solid 1px #56C9A6;
  }
  .hea .loginBox div .phoneCode{
    width: 98%;
    position: relative;
  }
  .hea .loginBox div .phoneCode>span{
    position: absolute;
    right: -3%;
    display: inline-block;
    padding:8px 15px;
    background: #666666;
    border-bottom-right-radius: 6px;
    border-top-right-radius: 6px;
    font-size: 14px!important;
    color: #fff!important;
  }
  .hea .loginBox div .zhuC{
    color:#56C9A6;
    float: left;
    margin-left:5%;
    font-size: 17px;
    cursor: pointer;
  }
  .hea .loginBox div span:last-child{
    color: #d73a15;
    float: right;
    margin-right: 5%;
    font-size: 17px;
    cursor: pointer;
  }
  .hea .loginBox div i img{
    position: absolute;
    width: 19px;
    height: 13px;
    left: 87%;
    top: 23.3%;
  }
  .hea .loginBox .title{
    position: absolute;
    left: 46%;
    top: 6%;
    font-size: 20px;
  }
  .hea .loginBox .m{
    left: 40%;
  }
  .hea .box_checkbox{
    font-size: 14px!important;
    margin-top: -4%;
    padding-left: 7%;
  }
  .hea .box_checkbox span{
    vertical-align: middle;
  }
  .hea .box_checkbox span:last-child{
    display: inline-block;
    color: #56C9A6!important;
    float: none!important;
  }
  .hea .box_checkbox .sign{
    display: inline-block;
    border: solid 1px #56C9A6;
    width: 14px;
    height: 14px;
    text-align: center;
    line-height: 14px;
    vertical-align: middle;
  }
  .footer{
    height:100px;
    line-height:100px;
    box-sizing: border-box;
    text-align: center;
    width: 100%;
    overflow: hidden;
    white-space: nowrap;
  }
  .footer p{
    display: inline-block;
    font-size: 12px;
    color: #7f7f7f;
    white-space: nowrap;
  }
  input::-ms-clear {
    display: none;
  }
  /*ie文本输入框眼睛*/
  input::-ms-reveal {
    display: none;
  }
</style>
