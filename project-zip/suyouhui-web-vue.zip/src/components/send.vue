<template>
  <div class="send">
    <div class="content">
      <div class="tit">寄件信息</div>
      <div class="info">
        <span>姓名</span>
        <div>
          <el-select v-if="senderList.length>0"
                     v-model="senderInfo"
                     allow-create
                     filterable
                     @change="senderName"
                     placeholder="请选择或者输入寄件人姓名">
            <el-option
              v-for="(v,k) in senderList"
              :key="k"
              :label="v.add_name+v.add_mobile_phone+v.add_telephone+v.province + v.city + v.region + v.add_detail_address+' '+v.add_is_default"
              :value="k">
            </el-option>
          </el-select>
          <el-input v-if="senderList.length==0" v-model="senderInfo" placeholder="请输入寄件人姓名"></el-input>
        </div>
      </div>
      <div class="info">
        <span>电话号码</span>
        <div>
          <el-input v-model="senderPhone" placeholder="请输入联系电话"></el-input>
        </div>
      </div>
      <div class="info">
        <span>发件地址</span>
        <div class="sendAddress">
          <input @click='selectAddress' v-model="senderAddress.province+senderAddress.city+senderAddress.region"  :readOnly="true" placeholder="请选择所在地区">
          <div class="addressBox" v-if="showSite" >
            <p><span @click="chooseProvince">{{province}}</span><span @click="chooseCity">{{city}}</span><span @click="chooseRegion">{{region}}</span></p>
            <div>
              <span v-if="addressState==1" v-for="(v,k) in addressList" @click="selectSite(k,addressList)">{{v.province_name}}</span>
              <span v-if="addressState==2" v-for="(v,k) in addressList" @click="selectSite(k,addressList)">{{v.city_name}}</span>
              <span v-if="addressState==3" v-for="(v,k) in addressList" @click="selectSite(k,addressList)">{{v.area_name}}</span>
            </div>
          </div>
        </div>
      </div>
      <div class="info">
        <span> </span>
        <div>
          <el-input v-model="senderAddress.detail" placeholder="请输入详细地址"></el-input>
        </div>
      </div>
      <div class="info">
        <span>选择快递</span>
        <div>
          <el-select v-model="express"
                     allow-create
                     filterable
                     @change="expressDetail"
                     :no-data-text="noExpress_hint"
                     placeholder="请选择快递公司">
            <el-option
              v-for="(v,k) in expressList"
              :key="k"
              :label="v.code_name"
              :value="k">
            </el-option>
          </el-select>
        </div>
      </div>
      <div class="info file">
        <span> </span>
        <p class="downText">如需批量上传收件信息，请先<span @click="downLoad">下载示例文件</span>（文件大小不能大于2M）</p>
        <form id="uploadFile" action = "/hthome/suyh/app/5/token/uploadExpFile" method="post" enctype="multipart/form-data" >
          <input @change='uploadFile' type="file" name="file" id="file"/>
        </form>
        <el-button type="warning" size="small" plain style="float: right">批量上传收件信息</el-button>
      </div>
      <table id="myTable">
        <tr>
          <th>编号</th>
          <th>订单编号</th>
          <th>姓名</th>
          <th>手机号</th>
          <th>地址</th>
          <th>重量（kg）</th>
          <th>货物名称</th>
          <th>操作</th>
        </tr>
        <tr v-for="(v,k) in receiverInfo" :key="k">
          <td>{{k+1}}</td>
          <td>{{v.ht_number}}</td>
          <td>{{v.add_name}}</td>
          <td>{{v.add_mobile_phone}}</td>
          <td class="overflow">{{v.add_province_name}}{{v.add_city_name}}{{v.add_region_name}}{{v.add_detail_address}}</td>
          <td class="number">{{v.exp_ord_clt_height}}</td>
          <td>{{v.exp_ord_category}}</td>
          <td>
            <el-button @click="set_receiver(k,receiverInfo)" type="warning" icon="el-icon-edit" size="mini"></el-button>
            <el-button @click="del_receiver(k)" type="danger" icon="el-icon-delete" size="mini"></el-button>
          </td>
        </tr>
      </table>
      <div class="addInfo">
        <el-button type="success" size="small" @click="addSenderInfo()">添加收件信息</el-button>
      </div>
      <el-button type="success" @click="submitSender()">提 交</el-button>

      <el-dialog
        title="收件人信息"
        :visible.sync="consigneeVisible"
        width="700px"
        center>
        <div class="info consignee">
          <span>姓名</span>
          <div>
            <el-input v-model=" consigneeName" placeholder="请输入收件人姓名"></el-input>
          </div>
        </div>
        <div class="info consignee">
          <span>电话号码</span>
          <div>
            <el-input v-model="consigneePhone" placeholder="请输入收件人手机号码"></el-input>
          </div>
        </div>
        <div class="info consignee">
          <span>收件地址</span>
          <div class="sendAddress">
            <input @click='selectAddress(0)' v-model="consigneeAddress.province+consigneeAddress.city+consigneeAddress.region"  :readOnly="true" placeholder="请选择所在地区">
            <div class="addressBox addressBox2" v-if="showAddress" >
              <p><span @click="chooseProvince">{{province}}</span><span @click="chooseCity">{{city}}</span><span @click="chooseRegion">{{region}}</span></p>
              <div>
                <span v-if="addressState==1" v-for="(v,k) in addressList" @click="selectSite(k,addressList)">{{v.province_name}}</span>
                <span v-if="addressState==2" v-for="(v,k) in addressList" @click="selectSite(k,addressList)">{{v.city_name}}</span>
                <span v-if="addressState==3" v-for="(v,k) in addressList" @click="selectSite(k,addressList)">{{v.area_name}}</span>
              </div>
            </div>
          </div>
        </div>
        <div class="info consignee">
          <span> </span>
          <div>
            <el-input v-model="consigneeAddress.detail" placeholder="请输入详细地址"></el-input>
          </div>
        </div>
        <div class="info consignee">
          <span>订单编号</span>
          <div>
            <el-input v-model="orderNum" placeholder="请输入订单编号"></el-input>
          </div>
        </div>
        <div class="info consignee weight">
          <span>重量</span>
          <div class="weightShop">
            <el-input v-model="Weight" placeholder="物品重量"></el-input>
          </div>
          <span style="width: 0;margin-left:5px">Kg</span>
        </div>
        <div class="info consignee weight">
          <span>物品类型</span>
          <div>
            <el-input v-model="goods_name" placeholder="如：衣服"></el-input>
          </div>
        </div>
        <span slot="footer" class="dialog-footer">
          <el-button @click="consigneeVisible = false;consigneeVisible2 = false">取 消</el-button>
          <el-button type="primary" @click="addConsigneeInfo">确 定</el-button>
        </span>
      </el-dialog>
    </div>
  </div>
</template>
<script>
  const Cookie = require('js-Cookie');
  const hex_md5 = require("crypto-js/md5");
  import base from '../assets/base';
  export default {
    data(){
      return {
        senderInfo: '',//寄件人姓名
        senderList: [],
        add_id:'',
        senderPhone: '',
        senderAddress:{
          province:'',
          city:'',
          region:'',
          detail:'',
          provinceCode:'',
          cityCode:'',
          regionCode:''
        },
        showSite:false,
        province:'省份/直辖市',
        city:'请选择',
        region:'请选择',
        addressList:[],
        express:'',
        expressId:'',
        expressList:[],
        noExpress_hint:'请先选择发件地址',
        receiverInfo:[],
        receiverIndex:0,
        addressState:1,
        addressIndex:1,
        addressIndex2:1,

        consigneeVisible:false,
        consigneeVisible2:false,
        consigneeName:'',//收货人姓名
        consigneePhone:'',//收货人电话
        showAddress:false,//收件人选择地址
        consigneeAddress:{
          province:'',
          city:'',
          region:'',
          detail:'',
          provinceCode:'',
          cityCode:'',
          regionCode:''
        },
        orderNum:'',
        Weight:'',
        goods_name:'',
      }
    },
    created(){
      let token = Cookie.get('g_token');
      if(token==null||token==undefined||token==""){
        this.$router.push("/");
      }
      this.getSendInfo();
      let address = JSON.parse(sessionStorage.getItem('rec_address'));
      if(address){
        this.receiverInfo = address;
      }
    },
    methods:{
      selectSite(index,data){
        if(this.addressState===1) {
          this.addressState = 2;
          this.addressIndex = index;
          this.getAddress(index);
          this.province = data[index].province_name;
        }else if(this.addressState===2){
          this.addressState = 3;
          this.addressIndex2 = index;
          this.getAddress(index);
          this.city = data[index].city_name;
        }else if(this.addressState===3){
          this.addressState = 3;
          this.region = data[index].area_name;
          if(this.showAddress){
            this.consigneeAddress.province = this.province;
            this.consigneeAddress.city = this.city;
            this.consigneeAddress.region = this.region;
            this.consigneeAddress.provinceCode = data[index].dict_id;
            this.consigneeAddress.cityCode = data[index].dict_id;
            this.consigneeAddress.regionCode = data[index].dict_id;
            this.showAddress = false;
            console.log(this.consigneeAddress)
          }else{
            this.senderAddress.province = this.province;
            this.senderAddress.city = this.city;
            this.senderAddress.region = this.region;
            this.senderAddress.provinceCode = data[index].dict_id;
            this.senderAddress.cityCode = data[index].dict_id;
            this.senderAddress.regionCode = data[index].dict_id;
            this.showSite = false;
            this.getExpressList();
          }
        }



      },
      chooseProvince(){
        this.addressState=1;
        this.getAddress();
      },
      chooseCity(){
        this.addressState=2;
        this.getAddress(this.addressIndex);
      },
      chooseRegion(){
        this.addressState=3;
        this.getAddress(this.addressIndex2);
      },
      getSendInfo(){
        let _this = this;
        base.axios_post('','/5/token/findAllSendAddress',function (res) {
            if(res.mark==0){
              for(let i in res.obj){
                if(res.obj[i].add_is_default==0){
                  res.obj[i].add_is_default= '【默认】';
                  _this.senderInfo = res.obj[i].add_name;
                  _this.senderPhone = res.obj[i].add_mobile_phone;
                  _this.senderAddress.province = res.obj[i].province;
                  _this.senderAddress.city = res.obj[i].city;
                  _this.senderAddress.region = res.obj[i].region;
                  _this.senderAddress.detail = res.obj[i].add_detail_address;
                  _this.senderAddress.provinceCode = res.obj[i].add_province;
                  _this.senderAddress.cityCode = res.obj[i].add_city;
                  _this.senderAddress.regionCode = res.obj[i].add_region;
                  _this.add_id = res.obj[i].add_id;
                }else{
                  res.obj[i].add_is_default= '';
                }
              }
              _this.getExpressList();
              _this.senderList = res.obj;
            }else if(res.mark==100 || res.mark==101){
                base.back();
                _this.$router.push("/");
            }else{
              base.alerter(res.tip);
            }
        });
      },
      //获取省市区
      getAddress(index){
        let _this = this;
        this.addressList = [];
        base.axios_post('','/3/token/findProvincialCity',function (res) {
          if(res.mark==0){
            if(_this.addressState==1){
              _this.addressList = res.obj;
            }
            if(_this.addressState==2){
                for(let j in res.obj[index].city_list){
                  _this.addressList.push(res.obj[index].city_list[j])
                }
            }
            if(_this.addressState==3){
                for(let i in res.obj[_this.addressIndex].city_list[index].area_list){
                  _this.addressList.push(res.obj[_this.addressIndex].city_list[index].area_list[i]);
                }
            }
          }else if(res.mark==100 || res.mark==101){
            base.back();
            _this.$router.push("/");
          }else{
            base.alerter(res.tip);
          }
        });
      },

      //获取快递公司
      getExpressList(){
        let json = {
          region_id: this.senderAddress.regionCode
        };
        let _this = this;
        base.axios_post(json,'/3/token/findExpressCompany',function (res) {
            if(res.mark==0){
                _this.expressList = res.obj;
            }else{
              _this.noExpress_hint = res.tip;
            }
        });
      },

      //姓名下拉框
      senderName(value){
          this.senderInfo = this.senderList[value].add_name;
          this.senderPhone = this.senderList[value].add_mobile_phone;
          this.senderAddress.province = this.senderList[value].province;
          this.senderAddress.city = this.senderList[value].city;
          this.senderAddress.region = this.senderList[value].region;
          this.senderAddress.detail = this.senderList[value].add_detail_address;
          this.senderAddress.provinceCode = this.senderList[value].add_province;
          this.senderAddress.cityCode = this.senderList[value].add_city;
          this.senderAddress.regionCode = this.senderList[value].add_region;
          this.add_id = this.senderList[value].add_id;
      },

      //选择快递公司
      expressDetail(index){
        this.expressId = this.expressList[index].dict_id;
      },

      //选择地址
      selectAddress(value){
        this.addressState = 1;
        this.province = '省份/直辖市';
        this.city = this.region = '请选择';
        if(value===0){
          if(this.showAddress){
            this.showAddress = false;
          }else{
            this.showAddress = true;
            if(this.addressState === 1){
              this.getAddress();
            }
          }
        }else {
          if(this.showSite){
            this.showSite = false;
          }else{
            this.showSite = true;
            if(this.addressState === 1){
              this.getAddress();
            }
          }
        }

      },

      //添加收件人信息按钮
      addSenderInfo(){
        this.consigneeName = '';
        this.consigneePhone = '';
        this.consigneeAddress = {
          province:'',
          city:'',
          region:'',
          detail:'',
          provinceCode:'',
          cityCode:'',
          regionCode:''
        };
        this.orderNum = '';
        this.Weight = '';
        this.goods_name = '';
        this.consigneeVisible = true;
      },

      //确认添加收件人信息
      addConsigneeInfo(){
        if(!this.consigneeName){
          base.alerter('请输入收件人姓名');
          return;
        }
        if(this.consigneePhone==''){
          base.alerter('请输入收件人电话');
          return;
        }
        if(!this.consigneeAddress.region){
          base.alerter('请选择收件人地址');
          return;
        }
        if(!this.consigneeAddress.detail){
          base.alerter('请输入收件人详细地址');
          return;
        }
        if(!this.orderNum){
          base.alerter('请输入订单编号');
          return;
        }
        if(!/^[0-9]\d*$/.test(this.orderNum)){
          base.alerter('订单编号不正确');
          return;
        }
        if(!this.Weight){
          base.alerter('请输入物品重量');
          return;
        }
        if(!/\d*\.?\d{1,2}/.test(this.Weight)){
          base.alerter('物品重量不正确');
          return;
        }
        if(!this.goods_name){
          base.alerter('请输入物品类型');
          return;
        }
        let data = {
          ht_number:this.orderNum,
          add_name:this.consigneeName,
          add_mobile_phone:this.consigneePhone,
          add_province_name:this.consigneeAddress.province,
          add_city_name:this.consigneeAddress.city,
          add_region_name:this.consigneeAddress.region,
          add_province:this.consigneeAddress.provinceCode,
          add_city:this.consigneeAddress.cityCode,
          add_region:this.consigneeAddress.regionCode,
          add_detail_address:this.consigneeAddress.detail,
          exp_ord_clt_height:this.Weight,
          exp_ord_category:this.goods_name
        };
        if(!this.consigneeVisible2){//添加
          this.receiverInfo.push(data);

        }else{//修改
          this.receiverInfo[this.receiverIndex].ht_number = this.orderNum;
          this.receiverInfo[this.receiverIndex].add_name = this.consigneeName;
          this.receiverInfo[this.receiverIndex].add_mobile_phone = this.consigneePhone;
          this.receiverInfo[this.receiverIndex].add_province_name = this.consigneeAddress.province;
          this.receiverInfo[this.receiverIndex].add_city_name = this.consigneeAddress.city;
          this.receiverInfo[this.receiverIndex].add_region_name = this.consigneeAddress.region;
          this.receiverInfo[this.receiverIndex].add_province = this.consigneeAddress.provinceCode;
          this.receiverInfo[this.receiverIndex].add_city = this.consigneeAddress.cityCode;
          this.receiverInfo[this.receiverIndex].add_region = this.consigneeAddress.regionCode;
          this.receiverInfo[this.receiverIndex].add_detail_address = this.consigneeAddress.detail;
          this.receiverInfo[this.receiverIndex].exp_ord_clt_height = this.Weight;
          this.receiverInfo[this.receiverIndex].exp_ord_category = this.goods_name;
        }
        sessionStorage.setItem('rec_address',JSON.stringify(this.receiverInfo));
        this.consigneeVisible = false;
      },

      //提交
      submitSender(){
        if(!this.senderInfo){
          base.alerter('寄件人姓名不能为空');
          return;
        }
        if(this.senderPhone==''){
          base.alerter('请输入寄件人电话');
          return;
        }
        if(!this.senderAddress.region){
          base.alerter('请选择寄件地址');
          return;
        }
        if(!this.senderAddress.detail){
          base.alerter('请输入寄件人详细地址');
          return;
        }
        if(!this.expressId){
          base.alerter('请选择快递公司');
          return;
        }
        if(this.receiverInfo.length===0){
          base.alerter('请上传或添加收件信息')
        }else{
          let _this = this;
          let sender = {
            add_name:this.senderInfo,
            add_mobile_phone:this.senderPhone,
            add_province:this.senderAddress.provinceCode,
            add_city:this.senderAddress.cityCode,
            add_region:this.senderAddress.regionCode,
            add_detail_address:this.senderAddress.detail,
            express_id:this.expressId,
            add_id:this.add_id?this.add_id:0,
            add_longitude:0.00,
            add_latitude:0.00,
          };
          let json = {
            express_order: sender,
            express_order_collects: this.receiverInfo,
          };
          base.axios_post(json,'/5/token/bigClientsSendExp',function (res) {
              if(res.mark==0){
                _this.receiverInfo = [];
                sessionStorage.removeItem('rec_address');
              }else if(res.mark==100 || res.mark==101){
                base.back();
                _this.$router.push("/");
              }else{
                base.alerter(res.tip);
              }
          });
        }
      },

      //修改收件人信息
      set_receiver(index,data){
        this.receiverIndex = index;
        this.consigneeName = data[index].add_name;
        this.consigneePhone = data[index].add_mobile_phone;
        this.consigneeAddress = {
          province:data[index].add_province_name,
          city:data[index].add_city_name,
          region:data[index].add_region_name,
          detail:data[index].add_detail_address,
          provinceCode:data[index].add_province,
          cityCode:data[index].add_city,
          regionCode:data[index].add_region
        };
        this.orderNum = data[index].ht_number;
        this.Weight = data[index].exp_ord_clt_height;
        this.goods_name =data[index].exp_ord_category;
        this.consigneeVisible2 = true;
        this.consigneeVisible = true;
      },

      //删除收件人信息
      del_receiver(index){
        this.receiverInfo.splice(index,1);
        sessionStorage.setItem('rec_address',JSON.stringify(this.receiverInfo));
      },

      //选择文件
      uploadFile(){
        let fileSize = document.getElementById('file').files[0];
        let reg = /(.xlsx|.xls)$/;
        let size = fileSize / 1024;
        if (size > 2000) {
          base.alerter("文件不能大于2M");
          return false;
        }
        if (!reg.test(fileSize.name)) {
          base.alerter("请上传Excel文件");
          return false;
        }else{
          let _this = this;
          let token = Cookie.get('g_token');
          let time = Date.parse(new Date());
          let hash = hex_md5(time + "hotol");
          time = base.Encrypt(base.check_key(), time);
          hash = base.Encrypt(base.check_key(), hash);
          let form = $("#uploadFile");
          let options  = {
            headers:{
              "token": token,
              "version": "9",
              "client_type": "4",
              "Timestamp": time,
              "SignInfo": hash,
              "Access-Control-Allow-Origin": "*"
            },
            dataType:'text',
            success:function(data){
              let res = JSON.parse(base.Decrypt(base.check_key(),data));
              if(res.mark==0){
                base.alerter('上传成功');
                for(let i in res.obj){
                  let data = {};
                  data = {
                    ht_number:res.obj[i].ht_number,
                    add_name:res.obj[i].add_name,
                    add_mobile_phone:res.obj[i].add_mobile_phone,
                    add_province_name:res.obj[i].add_province_name,
                    add_city_name:res.obj[i].add_city_name,
                    add_region_name:res.obj[i].add_region_name,
                    add_province:res.obj[i].add_province,
                    add_city:res.obj[i].add_city,
                    add_region:res.obj[i].add_region,
                    add_detail_address:res.obj[i].add_detail_name,
                    exp_ord_clt_height:res.obj[i].exp_ord_clt_height,
                    exp_ord_category:res.obj[i].exp_ord_category
                  };

                  _this.receiverInfo.push(data);
                }
                sessionStorage.setItem('rec_address',JSON.stringify(_this.receiverInfo));
              }else{
                base.alerter(res.tip)
              }
              console.log(res);

            },
            error:function(data){
              console.log(data);
              base.alerter('未知错误');
            }
          };
          form.ajaxForm(options).submit();
        }
      },

      //下载示例文件
      downLoad(){
        location.href = 'http://hotol.oss-cn-hangzhou.aliyuncs.com/app/data/config/%E6%89%B9%E9%87%8F%E4%B8%8B%E5%8D%95%E7%A4%BA%E4%BE%8B%E6%96%87%E4%BB%B6.xls'
      },
    }
  }
</script>
<style>
  .send{
    width: 100%;
  }
  .send .content{
    width: 1200px;
    margin: 30px auto;
    padding: 30px;
    border-radius: 8px;
    box-shadow: 2px 2px 2px 2px #d8d8d8;
    box-sizing: border-box;
    position: relative;
    background: #fcfcfc;
  }
  .send .content .tit{
    font-size: 20px;
    margin-bottom: 40px;
  }
  .send .content .info{
    overflow: hidden;
    padding: 0 200px;
    margin: 30px 0;
  }
  .send .content .consignee{
    padding: 0 30px!important;
  }
  .send .content .consignee>div{
    width: 82.5%!important;
  }
  .send .content .weight{
    display: inline-block;
    width: 40%;
    margin: 0!important;
  }
  .send .content .weight>div{
    width: 60%!important;
  }
  .send .content .weight>.weightShop{
    width: 40%!important;
  }
  .send .content .file{
    position: relative;
  }
  .send .content .info>div{
    float: left;
    width: 86%;
  }
  .send .content .info>span{
    float: left;
    width: 100px;
    height: 40px;
    line-height: 40px;
    text-align: left;
  }
  .send .content .info>div .el-select,.info>div .el-input,.info>div input{
    width: 100%;
  }
  .send .content .info .sendAddress>input{
    border: 1px solid #dcdfe6;
    border-radius: 4px;
    height: 40px;
    line-height: 1;
    padding: 0 15px;
    color: #494a4d;
    font-size: 14px;
    box-sizing: border-box;
    background-color:#FFF;
  }
  .send .content .info .sendAddress>input:focus{
    border: solid 1px #92b8f7;
  }
  ::-webkit-input-placeholder{
    color: #babfcb;
  }
  .send .content .info .sendAddress .addressBox {
    height: 270px;
    overflow-y: scroll;
    padding-top: 20px;
    padding-bottom: 20px;
    border: solid 1px #d5d5d5;
    border-top: none;
    position: absolute;
    width: 52.9%;
    left: 27.5%;
    z-index: 99;
    background: #fff;
  }
  .send .content .info .sendAddress .addressBox2 {
    left: 0;
    width: 100%!important;
    border: none!important;
    height: 300px!important;
    padding-top: 0;
    margin-top: 22px;
    padding-left: 12%;
    box-sizing: border-box;
  }
  .send .content .info .sendAddress .addressBox p{
    text-align: left;
    padding: 10px 0;
    border-bottom: solid 1px #cfcfcf;
    width: 80%;
    margin: 0 auto;
  }
  .send .content .info .sendAddress .addressBox p span{
    margin-left: 25px;
    font-size: 16px;
    color: #a3a3a3;
    cursor: pointer;
  }
  .send .content .info .sendAddress .addressBox div{
    text-align: left;
    padding: 20px 0;
  }
  .send .content .info .sendAddress .addressBox div span{
    color: #a3a3a3;
    font-size: 16px;
    display: inline-block;
    height:  36px;
    line-height: 36px;
    min-width: 128px;
    padding: 0 10px;
    margin: 5px 0 5px 40px;
    cursor: pointer;
    border-radius: 4px;
    text-align: center;
  }
  .send .content .info .sendAddress .addressBox div span:hover{
    background: #52C19F;
    color: #fff;
    border-radius: 4px;
  }
  .send .content .info .downText{
    float: left;
    font-size: 14px;
    color: #e6a23e;
    height: 32px;
    line-height: 32px;
  }
  .send .content .info .downText>span{
    color: #56D2A6;
    cursor: pointer;
  }
  .send .content table tr .number{
    text-align: right;
    padding-right: 30px;
  }
  .send .content table{
    width: 100%;
    border-collapse: collapse;
    margin: 0 auto;
    margin-top: 50px;
    margin-bottom: 20px;
  }
  .send .content table tr{
    border-bottom: solid 1px #d7d7d7;
  }
  .send .content table tr td{
    padding: 5px 3px;
    font-size: 14px;
  }
  .send .content table th{
    font-size: 14px;
    padding: 15px 0;
    color: #666666;
    font-weight:400;
  }
  .send .content table .overflow{
    max-width: 240px;
    text-align: left;
  }
  .send .content .addInfo{
    overflow:hidden;
    width: 100%;
  }
  .send .content .addInfo>button{
    float: right;
    background: none;
    border: solid 1px #9c9c9c;
    color: #666666;
  }
  .send .content .addInfo>button:hover{
    background: #56C9A6;
    border-color: #56C9A6;
    color: #fff;
  }
  #uploadFile{
    position: absolute;
    left: 71%;
    top: 6%;
    opacity:0;
    width: 133px;
  }
  .send .content>.el-button{
    width: 10%;
    background: #56C9A6!important;
    border-color: #56C9A6!important;
  }
  .send .content>.el-button:hover{
    background: #56C9A6;
    border-color: #56C9A6;
  }
  .el-dialog__footer{
    margin-top: 20px;
  }
  .el-dialog__footer .el-button{
    background: #56C9A6!important;
    border-color: #56C9A6!important;
  }
  .el-dialog__footer .el-button:first-child{
    background: #fff;
    border:1px solid #e8e8e8;
  }
  .el-dialog__footer .el-button:first-child:hover span{
    color: #535656;
  }
  .el-dialog__footer .el-button:first-child span{
    color: #535656;
  }
  .send .content .dialog-footer button:first-child>span{
    color: #fff;
  }
</style>
