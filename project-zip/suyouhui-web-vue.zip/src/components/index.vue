<template>
  <div class="index">
    <div class="con">
      <div class="details">
        <div class="content_pic">
          <img src="../assets/images/banner.png">
          <a href="https://itunes.apple.com/us/app/%E9%80%9F%E9%82%AE%E6%B1%87/id1057483757?l=zh&ls=1&mt=8" class="iphone"></a>
          <a href="http://a.app.qq.com/o/simple.jsp?pkgname=com.hotol.suyh" class="android"></a>
        </div>
      </div>
    </div>
  </div>
</template>
<script></script>
<style scoped>
  .index{
    width: 100%;
    height: 770px;
    background: rgb(86,201,166);
  }
  .con{
    height: 100%;
  }
  .con .details{
    width: 100%;
    height: 100%;
    overflow: hidden;
    position: relative;
  }
  .con .details .content_pic{
    height: auto;
    width: 100%;
    position: absolute;
    transform: translate(0,8%)
  }
  .con .details .content_pic img{
    width: 1450px;
  }
  .con .details .content_pic a{
    display: inline-block;
    width: 194px;
    height: 69px;
    position: absolute;
    cursor: pointer;
  }
  .con .details .content_pic .iphone{
    left: 51%;
    top: 72.5%;
  }
  .con .details .content_pic .android{
    left:65%;
    top: 72.5%;
  }
</style>












