import axios from 'axios'
var CryptoJS = require("crypto-js/core");
var AES = require("crypto-js/aes");
var hex_md5 = require("crypto-js/md5");
var ECB = require("crypto-js/mode-ecb");
function alerter(msg) {
  var alerter = document.createElement("div");
  alert.id = "alerter";
  alerter.setAttribute("class", "alerter");
  var body = document.body;
  var html = "<span>" + msg + "</span>";
  alerter.innerHTML = html;
  body.appendChild(alerter);

  setTimeout(function () {
    alerter.remove();
  }, 1500);
}
function trans_time(t, type) {
  var d = new Date(t);
  var y = d.getFullYear();
  var m = d.getMonth() + 1;
  var dd = d.getDate();
  var h = d.getHours();
  var mm = d.getMinutes();
  var s = d.getSeconds();
  if (type == 2) {
    return y + '-' + e(m) + '-' + e(dd) + ' ' + e(h) + ':' + e(mm) + ':' + e(s);
  } else {
    return y + '-' + e(m) + '-' + e(dd);
  }
}
function e(t) {
  if (t < 10) {
    return t = '0' + t;
  } else {
    return t;
  }
}

function axios_post(data, url, completion) {
  console.log(data);
  var con_key = check_key();
  var con_url = check_suyh_ulr();
  var time = Date.parse(new Date());
  var hash = hex_md5(time + "hotol");
  var Cookies = require('js-Cookie');
  var token = Cookies.get('g_token');
  if (token == undefined || token == '' || token == null) {
    token = '';
  }
  if (data != "") {
    data = Encrypt(con_key, JSON.stringify(data));
  }
  time = Encrypt(con_key, time);
  hash = Encrypt(con_key, hash);
  axios({
    method: 'post',
    url: con_url + url,
    //url:url,
    dataType: "text",
    data: data,
    headers: {
      "token":token,
      "version": "11",
      "Timestamp": time,
      "SignInfo": hash,
      "Access-Control-Allow-Origin": "*",
      "Content-Type": "application/json;charset=UTF-8"
    }
  })
    .then(function (res) {
      res = JSON.parse(Decrypt(con_key, res.data));
      console.log(res);
      //msg.hide();
      completion(res);
    })
    .catch(function (error) {console.log(error);
      //msg.hide();
      alerter(error);
    });
}
function check_url() {
  if (location.hostname.indexOf('localhost') != -1) {
    return '/api/api/1'
  } else {
    return '/api/1'
  }
}
var msg = {
  loader: function () {
    var loader = document.createElement("div");
    loader.id = "loader";
    loader.setAttribute("class", "loader");
    var body = document.body;
    body.appendChild(loader);
  },
  hide: function () {
    var loader = document.getElementById('loader');
    loader.remove();
  }
}
function check_key() {
  if (location.hostname.indexOf('localhost') == -1 && location.hostname.indexOf('test') == -1) {
    return 'hotolsuyh100emal'
  } else {
    return 'testtesttesttest'
  }
}

function check_suyh_ulr() {
  if (location.hostname.indexOf('localhost') != -1) {
    return '/suyh/app'
  }else {
    return '/hthome/suyh/app'
  }
}
//加密
function Encrypt(key, word) {
  var key = CryptoJS.enc.Utf8.parse(key);
  var srcs = CryptoJS.enc.Utf8.parse(word);
  var encrypted = CryptoJS.AES.encrypt(srcs, key, { mode: CryptoJS.mode.ECB, padding: CryptoJS.pad.Pkcs7 });
  return encrypted.toString();
}
//解密
function Decrypt(key, word) {
  var key = CryptoJS.enc.Utf8.parse(key);
  var decrypt = CryptoJS.AES.decrypt(word, key, { mode: CryptoJS.mode.ECB, padding: CryptoJS.pad.Pkcs7 });
  return CryptoJS.enc.Utf8.stringify(decrypt).toString();
}
var Cookie = require('js-Cookie');
function back(){
  Cookie.remove('g_token');
  Cookie.remove('memb_role');
  Cookie.remove('memb_discount');
  Cookie.remove('memb_tel');
  //this.$router.push("/");
}
export default {
  alerter,trans_time,axios_post,msg,back,Encrypt,Decrypt,check_key
}

