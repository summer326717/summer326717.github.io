<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'App',
}
</script>

<style>
  input,
  button {
    outline: none;
    border: none;
  }
  input,
  button {
    color: #333333;
    font-size: 16px;
    font-family: "Microsoft YaHei";
    background: rgba(0, 0, 0, 0);
  }

  button {
    cursor: pointer;
  }

  a {
    text-decoration: none;
  }

  i {
    font-style: normal;
  }

  li {
    list-style-type: none;
  }
  body,html,div,ul,p,input,button{
    margin: 0;
    padding: 0;
  }

  #app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #424242;
  /*background: rgb(86,201,166);*/
  overflow:hidden;
}
  ::-webkit-scrollbar {
    display: none;
  }
  html{
  overflow-x:hidden;
  }
  .alerter{
    display: inline-block;
    padding: 10px 15px;
    color: #fff;
    background: rgba(0, 0, 0, 0.7);
    position: absolute;
    left: 46%;
    top: 20%;
    font-size: 16px;
    border-radius: 5px;
    z-index: 99999;
  }
</style>
