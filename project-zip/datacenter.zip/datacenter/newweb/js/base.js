﻿function axios_post(data, url, completion) {
    axios.get('config.json')
        .then(function (res) {
            var con_url = res.data.con_url;
            var time = Date.parse(new Date());
            var hash = hex_md5(time + "hotol");
            console.log(data);
            axios({
                method: 'post',
                url: con_url + url,
                dataType: "text",
                data: data,
                headers: {
                    "token": '',
                    "client_type": "4",
                    "Timestamp": time,
                    "SignInfo": hash,
                    "Access-Control-Allow-Origin": "*",
                    'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8'
                }
            })
                .then(function (res) {
                    console.log(res.data);
                    if (res.data.mark == 0) {
                        completion(res.data);
                    } else {
                        completion(res.data);
                    }
                })
                .catch(function (error) {
                    alerter(error.response.status + '&nbsp;' + error.response.statusText);
                });
        });
}
function axios_post_o(data, url, completion) {
    axios.get('../config.json')
        .then(function (res) {
            var con_url = res.data.con_url;
            var time = Date.parse(new Date());
            var hash = hex_md5(time + "hotol");
            if (localStorage.getItem('token') != null) {
                var token = localStorage.getItem('token');
            }
            if (sessionStorage.getItem('token') != null) {
                var token = sessionStorage.getItem('token');
            }
            if (token == undefined || token == '' || token == null) {
                token = '';
            }
            console.log(data);
            axios({
                method: 'post',
                url: con_url + url,
                dataType: "text",
                data: data,
                headers: {
                    "token": token,
                    "client_type": "4",
                    "Timestamp": time,
                    "SignInfo": hash,
                    "Access-Control-Allow-Origin": "*",
                }
            })
                .then(function (res) {
                    console.log(res.data);
                    if (res.data.mark == 0) {
                        completion(res.data);
                    } else if (res.data.mark == 100 || res.data.mark == 101) {
                        location.href = '../index.html';
                    } else {
                        completion(res.data);
                    }
                })
                .catch(function (error) {
                    alerter(error.response.status + '&nbsp;' + error.response.statusText);
                });
        });
}
function axios_post_c(data, url, completion) {
    axios.get('../../config.json')
        .then(function (res) {
            var con_url = res.data.con_url;
            var time = Date.parse(new Date());
            var hash = hex_md5(time + "hotol");
            if (localStorage.getItem('token') != null) {
                var token = localStorage.getItem('token');
            }
            if (sessionStorage.getItem('token') != null) {
                var token = sessionStorage.getItem('token');
            }
            if (token == undefined || token == '' || token == null) {
                token = '';
            }
            console.log(data);
            axios({
                method: 'post',
                url: con_url + url,
                dataType: "text",
                data: data,
                headers: {
                    "token": token,
                    "client_type": "4",
                    "Timestamp": time,
                    "SignInfo": hash,
                    "Access-Control-Allow-Origin": "*",
                }
            })
                .then(function (res) {
                    console.log(res.data);
                    if (res.data.mark == 0) {
                        completion(res.data);
                    } else if (res.data.mark == 100 || res.data.mark == 101) {
                        location.href = '../../index.html';
                    } else {
                        completion(res.data);
                    }
                })
                .catch(function (error) {
                    alerter(error.response.status + '&nbsp;' + error.response.statusText);
                });
        });
}
//加密
function Encrypt(key, word) {
    var key = CryptoJS.enc.Utf8.parse(key);
    var srcs = CryptoJS.enc.Utf8.parse(word);
    var encrypted = CryptoJS.AES.encrypt(srcs, key, { mode: CryptoJS.mode.ECB, padding: CryptoJS.pad.Pkcs7 });
    return encrypted.toString();
}
//解密
function Decrypt(key, word) {
    var key = CryptoJS.enc.Utf8.parse(key);
    var decrypt = CryptoJS.AES.decrypt(word, key, { mode: CryptoJS.mode.ECB, padding: CryptoJS.pad.Pkcs7 });
    return CryptoJS.enc.Utf8.stringify(decrypt).toString();
}
/*===============================================================================退出登录 */
function sign_out() {
    axios_post_o('', '/admin/exitLogin', function (res) {
        location.href = "../index.html";
    })
}
function mar_sign_out() {
    axios_post_c('', '/admin/exitLogin', function (res) {
        location.href = "../../index.html";
    })
}
//弹框
var alerter = function (msg) {
    var alerter = document.createElement("div");
    alert.id = "alerter";
    alerter.setAttribute("class", "alerter");
    var body = document.body;
    var html = "<span>" + msg + "</span>";
    alerter.innerHTML = html;
    body.appendChild(alerter);

    setTimeout(function () {
        alerter.remove();
    }, 3000);
}
/*=================================================================================分页 */
var computed = {
    indexs: function () {
        var left = 1;
        var right = this.all;
        var ar = [];
        if (this.all >= 5) {
            if (this.cur > 3 && this.cur < this.all - 2) {
                left = this.cur - 2
                right = this.cur + 2
            } else {
                if (this.cur <= 3) {
                    left = 1
                    right = 5
                } else {
                    right = this.all
                    left = this.all - 4
                }
            }
        }
        while (left <= right) {
            ar.push(left)
            left++
        }
        return ar
    },
    indexs2: function () {
        var left = 1;
        var right = this.all2;
        var ar = [];
        if (this.all2 >= 5) {
            if (this.cur2 > 3 && this.cur2 < this.all2 - 2) {
                left = this.cur2 - 2
                right = this.cur2 + 2
            } else {
                if (this.cur2 <= 3) {
                    left = 1
                    right = 5
                } else {
                    right = this.all2
                    left = this.all2 - 4
                }
            }
        }
        while (left <= right) {
            ar.push(left)
            left++
        }
        return ar
    },
};
/*=================================================================================推广组列表*/
function get_group_list(completion) {
    axios_post_c('', '/group/searchAllGroup', function (res) {
        if (res.mark == 0) {
            //生成成功或者生成列表
            var group_list = res.obj;
            completion(group_list);
        }
    })
}
/*=======================================================================================登录*/
var login_methods = {
    login: function (event) {
        if (this.username == '' || this.username == null || this.username == undefined) {
            alerter("请输入用户名");
            return;
        }
        if (this.password == '' || this.password == null || this.password == undefined) {
            alerter("请输入密码");
            return;
        }
        var data = "user_name=" + this.username + "&user_pass=" + hex_md5(this.password);
        var _this = this;
        axios_post(data, '/admin/login/login', function (res) {
            if (res.mark == 0) {
                localStorage.setItem('token', res.obj);
                localStorage.setItem('username', _this.username);
                if (_this.checked) {
                    localStorage.setItem('token', res.obj);
                    localStorage.setItem('username', _this.username);
                } else {
                    sessionStorage.setItem('username', _this.username);
                    sessionStorage.setItem('token', res.obj);
                }
                location.href = "views/home.html";
            } else {
                alerter(res.tip);
            }
        });
    }
}
/*=================================================================================今天的方法*/
var today_methods = {
    drop: function () {
        if (this.hide) {
            this.hide = false;
        } else {
            this.hide = true;
        }
    },
    sign_out: function () {
        sign_out();
    },
    get_data: function () {
        var _this = this;
        axios_post_o('', '/liveData', function (res) {
            if (res.mark == 0) {
                var response = res.obj;
                _this.today_add_num = response.today_add_num;
                _this.today_order_num = response.today_order_num;
                _this.today_send_num = response.today_send_num;
                _this.today_note = response.today_note;
                _this.today_jiedan = response.today_jiedan;
                _this.today_qiandao = response.today_qiandao;
                _this.today_enterprise_orders = response.today_enterprise_orders;
            } else {
                alerter(res.tip);
            }
            _this.is_loading = false;
        });
    }
}

/*=================================总览的方法================================================*/

var index_methods = {
    drop: function () {
        if (this.hide) {
            this.hide = false;
        } else {
            this.hide = true;
        }
    },
    sign_out: function () {
        sign_out();
    },
    get_data: function () {
        var _this = this;
        axios_post_o('', '/generalSearch', function (res) {
            if (res.mark == 0) {
                res = res.obj;
                _this.today_add = res.today_add;
                _this.week_add = res.week_add;
                _this.month_add = res.month_add;
                _this.yest_order = res.yest_order;
                _this.week_order = res.week_order;
                _this.month_order = res.month_order;
                _this.user_num = res.user_num;
                _this.agent_num = res.agent_num;
                _this.yes_enterprise_orders = res.yes_enterprise_orders;
                _this.week_enterprise_orders = res.week_enterprise_orders;
                _this.month_enterprise_orders = res.month_enterprise_orders;
            } else {
                alerter(res.tip);
            }
            _this.is_loading = false;
        });
    }
}
/*侧边导航*/
window.onload = function () {
    var $ul = document.getElementById('ul');
    $ul.onclick = function (ev) {
        var ev = ev || window.event;
        var target = ev.target || ev.srcElement;
        if (target.nodeName.toLowerCase() == 'a') {
            var $childul = target.nextElementSibling;
            if ($childul != null) {
                var $childlinum = $childul.children.length;
                var $navstyle = window.getComputedStyle($childul, null);
                if ($navstyle.height == '0px') {
                    $childul.style.cssText = 'height:' + $childlinum * 50 + 'px;transition: 0.2s height ease-in;';
                } else {
                    $childul.style.cssText = 'height:0px;transition: 0.2s height ease-in;';
                }
            }
        }
    }
}