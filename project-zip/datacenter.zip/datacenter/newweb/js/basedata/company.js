﻿var start_time = default_start(), end_time = laydate.now(), start_time2 = '', end_time2 = '';
function e(e) {
    return e > 9 ? e : '0' + e;
}
function default_start() {
    var d_now = new Date();
    var num = d_now.getDay() - 1;
    d_now.setDate(d_now.getDate() - num);
    return d_now.getFullYear() + '-' + e(d_now.getMonth() + 1) + '-' + e(d_now.getDate());
}

var start = {
    elem: '#start',
    format: 'YYYY-MM-DD',
    min: '2000-01-01', //设定最小日期为当前日期
    max: laydate.now(), //最大日期
    istime: false,
    isclear: false,
    istoday: false,
    choose: function (datas) {
        end.min = datas; //开始日选好后，重置结束日的最小日期
        end.start = datas //将结束日的初始值设定为开始日
        start_time = datas;
    }
};
var end = {
    elem: '#end',
    format: 'YYYY-MM-DD',
    min: '2000-01-01',
    max: laydate.now(),
    istime: false,
    isclear: false,
    istoday: false,
    choose: function (datas) {
        start.max = datas; //结束日选好后，重置开始日的最大日期
        end_time = datas;
    }
};
var start2 = {
    elem: '#start2',
    format: 'YYYY-MM-DD',
    min: '2000-01-01', //设定最小日期为当前日期
    max: laydate.now(), //最大日期
    istime: false,
    isclear: false,
    istoday: false,
    choose: function (datas) {
        end2.min = datas; //开始日选好后，重置结束日的最小日期
        end2.start = datas //将结束日的初始值设定为开始日
        start_time2 = datas;
    }
};
var end2 = {
    elem: '#end2',
    format: 'YYYY-MM-DD',
    min: '2000-01-01',
    max: laydate.now(),
    istime: false,
    isclear: false,
    istoday: false,
    choose: function (datas) {
        start2.max = datas; //结束日选好后，重置开始日的最大日期
        end_time2 = datas;
    }
};
var methods = {
    drop: function () {
        if (this.hide) {
            this.hide = false;
        } else {
            this.hide = true;
        }
    },
    sign_out: function () {
        mar_sign_out();
    },
    start_time: function () {//用户选择开始时间
        laydate(start);
    },
    end_time: function () {//用户选择结束时间
        laydate(end);
    },
    start_time2: function () {//用户选择开始时间
        laydate(start2);
    },
    end_time2: function () {//用户选择结束时间
        laydate(end2);
    },
    get_data: function () {
        this.is_loading = true;
        this.default_end = end_time;
        this.default_start = start_time;
        var data = "startDate=" + start_time + "&endDate=" + end_time + "&page_no=" + this.cur + "&enterpriseId=" + this.company_id + '&page_size=' + this.page_size;
        var _this = this;
        axios_post_c(data, '/queryEnterpriseDataTotal', function (response) {
            if (response.mark == 0) {
                var response = response.obj;
                _this.orders_num = response.orders_num;
                _this.pay_amount = response.pay_amount;
                _this.total_amount = response.total_amount;
                _this.all = response.total_pages;
                _this.items = response.resultList;
            } else {
                _this.orders_num = 0;
                _this.pay_amount = 0;
                _this.total_amount = 0;
                _this.items = [];
            }
            _this.is_loading = false;
        });
    },
    search: function () {//点击查询
        this.cur = 1;
        this.get_data();
    },
    get_time: function () {//获取默认时间
        this.search();
    },
    show_list: function (id) {
        this.detail_company_id = id;
        start_time2 = start_time;
        end_time2 = end_time;
        this.cur2 = 1;
        this.get_detail();
        this.is_show = true;
    },
    com_search: function () {
        this.cur2 = 1;
        this.get_detail();
    },
    get_detail: function () {
        var data = "startDate=" + start_time2 + "&endDate=" + end_time2 + "&page_no=" + this.cur2 + "&enterpriseId=" + this.detail_company_id + '&page_size=' + this.page_size;
        var _this = this;
        console.log(data);
        axios_post_c(data, '/queryEnterpriseDataDetail', function (response) {
            if (response.mark == 0) {
                _this.order_detail = response.obj.resultList;
                _this.all2 = response.obj.total_pages;
            } else {
                _this.order_detail = [];
            }
            _this.is_loading = false;
        });
    },
    close_detail: function () {
        start_time2 = '';
        end_time2 = '';
        this.is_show = false;
    },
    btnClick: function (data) {//上一页、下一页点击事件
        if (data != this.cur) {
            this.cur = data
            this.get_data();
        }
    },
    pageClick: function () {//页码点击事件
        this.get_data();
    },
    page_search: function () {
        //分页搜索
        if (this.page_txt == null) {
            alerter("请输入页码");
            return;
        }
        if (this.page_txt > this.all) {
            alerter("请输入页码数不超过总页码数");
            return;
        }
        if (isNaN(this.page_txt)) {
            alerter("请输入正确页码数");
            return;
        }
        this.cur = parseInt(this.page_txt);
        this.get_data();
    },
    btnClick2: function (data) {//上一页、下一页点击事件
        if (data != this.cur2) {
            this.cur2 = data
            this.get_detail();
        }
    },
    pageClick2: function () {//页码点击事件
        this.get_detail();
    },
    page_search2: function () {
        //分页搜索
        if (this.page_txt2 == null) {
            alerter("请输入页码");
            return;
        }
        if (this.page_txt2 > this.all2) {
            alerter("请输入页码数不超过总页码数");
            return;
        }
        if (isNaN(this.page_txt2)) {
            alerter("请输入正确页码数");
            return;
        }
        this.cur2 = parseInt(this.page_txt2);
        this.get_detail();
    },
};