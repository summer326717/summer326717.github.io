﻿var start_time = "";
var end_time = "";
var o_start_time = "";
var o_end_time = "";
var max_time = new Date(),
    max_y = max_time.getFullYear(),
    max_m = max_time.getMonth() + 1,
    max_d = max_time.getDate();
max_time = max_y + '-' + e(max_m) + '-' + e(max_d);//用户选的最大时间为今天

//时间不大于10加‘0’字符
function e(e) {
    if (e < 10) {
        return e = "0" + e;
    } else {
        return e;
    }
}

var start = {
    elem: '#d_start',
    format: 'YYYY-MM-DD',
    min: '2000-01-01', //设定最小日期为当前日期
    max: max_time, //最大日期
    istime: false,
    isclear: false,
    istoday: false,
    choose: function (datas) {
        end.min = datas; //开始日选好后，重置结束日的最小日期
        end.start = datas //将结束日的初始值设定为开始日
        start_time = datas;
    }
};
var end = {
    elem: '#d_end',
    format: 'YYYY-MM-DD',
    min: '2000-01-01',
    max: max_time,
    istime: false,
    isclear: false,
    istoday: false,
    choose: function (datas) {
        start.max = datas; //结束日选好后，重置开始日的最大日期
        end_time = datas;
    }
};
var o_start = {
    elem: '#o_start',
    format: 'YYYY-MM-DD',
    min: '2000-01-01', //设定最小日期为当前日期
    max: max_time, //最大日期
    istime: false,
    isclear: false,
    istoday: false,
    choose: function (datas) {
        o_end.min = datas; //开始日选好后，重置结束日的最小日期
        o_end.start = datas //将结束日的初始值设定为开始日
        o_start_time = datas;
    }
};
var o_end = {
    elem: '#o_end',
    format: 'YYYY-MM-DD',
    min: '2000-01-01',
    max: max_time,
    istime: false,
    isclear: false,
    istoday: false,
    choose: function (datas) {
        o_start.max = datas; //结束日选好后，重置开始日的最大日期
        o_end_time = datas;
    }
};
/*==================================推广码管理===============================================*/

var code_methods = {
    drop: function () {
        if (this.hide) {
            this.hide = false;
        } else {
            this.hide = true;
        }
    },
    sign_out: function () {
        mar_sign_out();
    },
    get_data: function () {
        console.log('aa');
    },
    build_code: function () {
        if (this.num_type) {
            var data = "number=0&promote_descri=" + this.promote_descri;
        } else {
            if (this.promote_code_num == null || this.promote_code_num.trim() == '') {
                alerter('请输入推广码数量')
                return;
            }
            var data = "number=1&promote_code_num=" + this.promote_code_num;
        }
        var _this = this;
        axios_post_c(data, '/popularize/build', function (res) {
            if (res.mark == 0) {
                //生成成功或者生成列表
                if (res.obj.length > 0) {
                    _this.b_promote_id_list = res.obj;

                } else {
                    _this.b_promote_id = res.obj.promote_id;
                }
            } else {
                alerter(res.data.tip);
            }
            _this.is_loading = false;
        });
    },
    check_tel: function () {
        if (isNaN(this.promoter)) {
            this.promoter = '';
        }
    },
    bind_code: function () {
        if (this.promoter == null || this.promoter.trim() == '') {
            alerter('请输入手机号');
            return;
        }
        if (!(/^1(3|4|5|7|8)\d{9}$/.test(this.promoter))) {
            alerter('请输入正确手机号');
            return;
        }
        if (this.promote_id == null || this.promote_id.trim() == '') {
            alerter('请输入推广码');
            return;
        }
        if (this.user_bind == 1) {
            var role_type = 0;
        }
        if (this.user_bind == 2) {
            var role_type = 1;
        }
        if (this.user_bind == 3) {
            var role_type = 2;
        }
        var data = "role_type=" + role_type + "&telephone=" + this.promoter + "&promote_id=" + this.promote_id;
        var data2 = "promoter=" + this.promoter + "&promote_id=" + this.promote_id;
        var _this = this;
        axios_post_c(data2, '/popularize/searchMemb', function (res) {
            console.log(res);
            if (res.mark == 0) {
                if (res.obj.agent_name == null && role_type == 1) {
                    alerter('该代理人不存在');
                    return;
                }
                if (res.obj.promoterMeb == null && role_type == 0) {
                    alerter('该用户不存在');
                    return;
                }
                if (res.obj.staff_name == null && role_type == 2) {
                    alerter('该员工不存在');
                    return;
                }
                if (res.obj.state == 2) {
                    alerter('该手机号已绑定');
                    return;
                }
                var data2 = "promote_id=" + _this.promote_id;
                axios_post_c(data2, '/popularize/searchPromoter', function (res) {
                    if (res.mark == 0) {
                        if (res.obj == null) {
                            alerter('该推广码不存在');
                            return;
                        }
                        if (res.obj.state == 2) {
                            alerter('该推广码已绑定');
                            return;
                        }
                        axios_post_c(data, '/popularize/binding', function (res) {
                            if (res.mark == 0) {
                                alerter('绑定成功');
                            } else {
                                alerter(res.tip);
                            }
                            _this.is_loading = false;
                        });
                    } else {
                        alerter(res.data.tip);
                    }
                })

            }
        })
    },
    update_code: function () {
        if (this.u_promote_id == null || this.u_promote_id.trim() == '') {
            alerter('请输入推广码');
            return;
        }
        if (this.u_promote_descri == null || this.u_promote_descri.trim() == '') {
            alerter('请输入推广码描述');
            return;
        }
        var data = "promote_id=" + this.u_promote_id + "&promote_descri=" + this.u_promote_descri;
        var _this = this;
        axios_post_c(data, '/popularize/update', function (res) {
            if (res.mark == 0) {
                alerter('更新成功');
            } else {
                alerter(res.tip);
            }
            _this.is_loading = false;
        });
    },
    search_code: function () {
        var data = "promotion_code=" + this.promotion_code + "&page_no=" + this.cur + "&status=" + this.picked;
        var _this = this;
        axios_post_c(data, '/popularize/search', function (response) {
            if (response.mark == 0) {
                if (response.obj.list[0] == null) {
                    _this.s_promote_list = null;
                } else {
                    _this.s_promote_list = response.obj.list;
                    _this.all = response.obj.total_pages;
                }
            } else {
                _this.s_promote_list = null;
            }
            _this.is_loading = false;
        });
    },
    edit_show: function (state, id, name, des) {
        this.promote_state = state
        this.is_edit = true;
        this.e_promote_id = id;
        this.e_promote = name;
        this.e_promote_descri = des;
    },
    edit_code: function () {
        if (this.e_promote == null || this.e_promote.trim() == '') {
            alerter('请输入推广手机号');
            return;
        }
        if (this.e_promote_descri == null || this.e_promote_descri.trim() == '') {
            alerter('请输入推广描述');
            return;
        }
        var data = "promote_id=" + this.e_promote_id + "&promoter=" + this.e_promote + "&promote_descri=" + this.e_promote_descri;
        var data2 = "promoter=" + this.e_promote + "&promote_id=" + this.e_promote_id;
        var _this = this;
        axios_post_c(data2, '/popularize/searchMemb', function (res) {
            if (res.mark == 0) {
                if (res.obj.agent_name == null && res.obj.promoterMeb == null && res.obj.staff_name == null) {
                    alerter('该手机号不存在');
                    return;
                } else if (res.obj.promote_state == 2) {
                    alerter('该手机号已绑定');
                    return;
                } else if (res.obj.state == 2) {
                    alerter('该手机号已绑定');
                    return;
                } else {
                    axios_post_c(data, '/popularize/edit', function (res) {
                        if (res.mark == 0) {
                            alerter('修改成功');
                            _this.search_code();
                            _this.is_edit = false;
                        } else {
                            alerter(res.tip);
                        }
                        _this.is_loading = false;
                    });
                }
            } else {
                alerter(res.tip);
            }
            _this.is_loading = false;
        });
    },
    //修改已绑定的推广码描述
    edit_binded_code: function () {
        if (this.e_promote_descri == null || this.e_promote_descri.trim() == '') {
            alerter('请输入推广描述');
            return;
        }
        var data = "promote_id=" + this.e_promote_id + "&promoter=" + this.e_promote + "&promote_descri=" + this.e_promote_descri;
        var _this = this;
        axios_post_c(data, '/popularize/edit', function (res) {
            if (res.mark == 0) {
                alerter('修改成功');
                _this.search_code();
                _this.is_edit = false;
            } else {
                alerter(res.tip);
            }
            _this.is_loading = false;
        })
    },
    pageClick: function () {
        this.search_code();
    },
    btnClick: function (data) {
        if (data != this.cur) {
            this.cur = data
            this.search_code();
        }
    },
    page_search: function () {
        if (this.page_txt == null) {
            alerter("请输入页码");
            return;
        }
        if (this.page_txt > this.all) {
            alerter("请输入页码数不超过总页码数");
            return;
        }
        if (isNaN(this.page_txt)) {
            alerter("请输入正确页码数");
            return;
        }
        this.cur = parseInt(this.page_txt);
        this.search_code();
    },
    check_has_bind: function (type) {
        if (type == 1) {
            if (!this.is_bind) {
                this.is_bind = true;
                this.is_binded = false;
                this.is_binded1 = false;
                this.picked = 0;
            } else {
                this.is_bind = false;
                this.picked = '';
            }
            this.search_code();
        }
        if (type == 2) {
            if (!this.is_binded) {
                this.is_binded = true;
                this.is_bind = false;
                this.picked = 1;
                this.is_bind1 = false;
            } else {
                this.is_binded = false;
                this.picked = '';
            }
            this.search_code();
        }
    }
}

/*==================================推广组管理===============================================*/
var group_methods = {
    drop: function () {
        if (this.hide) {
            this.hide = false;
        } else {
            this.hide = true;
        }
    },
    sign_out: function () {
        mar_sign_out();
    },
    group_build: function () {
        if (this.group_name == null || this.group_name.trim() == '') {
            alerter('请输入推广组名称');
            return;
        }
        if (this.group_descri == null || this.group_descri.trim() == '') {
            alerter('请输入推广描述');
            return;
        }
        var data = "group_name=" + this.group_name + "&group_descri=" + this.group_descri;
        var _this = this;
        axios_post_c(data, '/group/build', function (res) {
            if (res.mark == 0) {
                alerter('生成成功');
                _this.group_id = res.obj.group_id;
                get_group_list(function (res) {
                    _this.group_list = res;
                });
            } else {
                alerter(res.tip);
            }
            _this.is_loading = false;
        });
    },
    group_update: function () {
        if (this.u_group_id == null || this.u_group_id.trim() == '') {
            alerter('请输入推广组');
            return;
        }
        if (this.u_group_descri == null || this.u_group_descri.trim() == '') {
            alerter('请输入推广组描述');
            return;
        }
        var data = "group_name=" + this.u_group_id + "&group_descri=" + this.u_group_descri;
        var data2 = "group_name=" + this.u_group_id;
        var _this = this;
        axios_post_c(data2, '/group/searchName', function (res) {
            if (res.group_name == null) {
                alerter('该推广组不存在');
                return;
            }
            axios_post_c(data, '/group/update', function (res) {
                if (res.mark == 0) {
                    alerter('更新成功');
                } else {
                    alerter(res.tip);
                }
                _this.is_loading = false;
            })
        })
    },
    group_search: function () {
        if (this.s_group_id == null || this.s_group_id == '') {
            alerter('请选择查询推广组');
            return;
        }
        var data = "group_id=" + this.s_group_id + "&page_no=" + this.cur;
        var _this = this;
        axios_post_c(data, '/group/search', function (res) {
            if (res.mark == 0) {
                _this.s_group_list = res.obj.list;
                _this.all = res.obj.total_pages;
            } else {
                alerter(res.tip);
                _this.s_group_list = [];
            }
            _this.is_loading = false;
        });
    },
    add_group: function () {
        if ((this.group_id == null || this.group_id == undefined) && (this.s_group_id == null || this.s_group_id == '')) {
            alerter('无推广组id');
            return;
        }
        if (this.a_promote_id == null || this.a_promote_id.trim() == '') {
            alerter('请输入码');
            return;
        }
        if (isNaN(this.a_promote_id)) {
            alerter('请输入正确码');
            return;
        }
        if (this.a_promote_id.length > 10) {
            alerter('码超过长度');
            return;
        }
        if (this.add_type == 0) {
            var data = "promote_id=" + this.a_promote_id + "&group_id=" + this.group_id;
        } else {
            var data = "promote_id=" + this.a_promote_id + "&group_id=" + this.s_group_id;
        }
        var _this = this;
        var data2 = "promote_id=" + this.a_promote_id;
        axios_post_c(data2, '/popularize/searchPromoter', function (res) {
            if (res.mark == 0) {
                if (res.obj == null) {
                    alerter('该推广码不存在');
                    return;
                }
                axios_post_c(data2, '/group/addPopularize', function (res) {
                    if (res.mark == 0) {
                        alerter('添加成功');
                        if (_this.add_type == 0) {
                            _this.member_list.push(_this.a_promote_id);
                        }
                        _this.a_promote_id = '';
                        _this.is_add = false;
                    } else {
                        alerter(res.tip);
                    }
                    _this.is_loading = false;
                })
            } else {
                alerter(res.tip);
            }
        })
    },
    group_delete: function (promote_id) {
        var data = "promote_id=" + promote_id + "&group_id=" + this.s_group_id;
        var _this = this;
        axios_post_c(data, '/popularize/delete', function (res) {
            if (res.mark == 0) {
                alerter('删除成功');
            } else {
                alerter(res.tip);
            }
            _this.group_search();
            _this.is_loading = false;
        });
    },
    pageClick: function () {
        this.group_search();
    },
    btnClick: function (data) {
        if (data != this.cur) {
            this.cur = data
            this.group_search();
        }
    },
    page_search: function () {
        if (this.page_txt == null) {
            alerter("请输入页码");
            return;
        }
        if (this.page_txt > this.all) {
            alerter("请输入页码数不超过总页码数");
            return;
        }
        if (isNaN(this.page_txt)) {
            alerter("请输入正确页码数");
            return;
        }
        this.cur = parseInt(this.page_txt);
        this.group_search();
    },
    select_group_id: function (group_id, name) {
        this.s_group_id = group_id;
        this.s_group_name = name;
        this.is_drop = false;
    },
    open_add_dialog: function () {
        if ((this.group_id == '' || this.group_id == null) && (this.s_group_id == '' || this.s_group_id == null)) {
            alerter('请选择推广组');
            return;
        }
        if (this.add_type == 0) {
            if (this.group_id == '' || this.group_id == null) {
                alerter('生成时才能添加成员');
                return;
            }
            this.add_name = this.group_name;
        }
        if (this.add_type == 1) {
            if (this.s_group_id == 0) {
                alerter('请选择推广组');
                return;
            }
            this.add_name = this.s_group_name;
        }
        this.is_add = true
    }
}

/*=====================================================推广数据查询====================================================*/

var datasearch_methods = {
    start_way: function () {
        laydate(start);
    },
    end_way: function () {
        laydate(end);
    },
    search_data: function () {
        var data = "promote_code=" + this.promotion_code + "&group_id=" + this.group_id + "&start_time=" + start_time + "&end_time=" + end_time + "&page_no=" + this.cur;
        var _this = this;
        axios_post_c(data, '/generalized/data/query', function (res) {
            if (res.mark == 0) {
                _this.data_list = res.obj.list;
                _this.all = res.obj.total_pages;
                _this.data_num = res.obj.count;
            } else {
                _this.data_list = [];
            }
            _this.is_loading = false;
        })
    },
    pageClick: function () {
        this.search_data();
    },
    btnClick: function (data) {
        if (data != this.cur) {
            this.cur = data
            this.search_data();
        }
    },
    drop: function () {
        if (this.hide) {
            this.hide = false;
        } else {
            this.hide = true;
        }
    },
    change_valid_data: function () {
        if (this.checked == false) {
            this.checked = true;
        }
    },
    page_search: function () {
        if (this.page_txt == null) {
            alerter("请输入页码");
            return;
        }
        if (this.page_txt > this.all) {
            alerter("请输入页码数不超过总页码数");
            return;
        }
        if (isNaN(this.page_txt)) {
            alerter("请输入正确页码数");
            return;
        }
        this.cur = parseInt(this.page_txt);
        this.search_data();
    },
    sign_out: function () {
        mar_sign_out();
    },
    select_group_id: function (group_id, name) {
        this.group_id = group_id;
        this.group_name = name;
        this.is_drop = false;
    }
}

/*=====================================================推广转化统计====================================================*/

var protransform_methods = {
    start_way: function () {
        laydate(start);
    },
    end_way: function () {
        laydate(end);
    },
    drop: function () {
        if (this.hide) {
            this.hide = false;
        } else {
            this.hide = true;
        }
    },
    search_data: function () {
        if (!this.is_first) {
            if (this.promotion_code == '' && (start_time == '' || end_time == '')) {
                alerter('请选择开始时间、结束时间');
                return;
            }
            if (this.group_id == '' && (start_time == '' || end_time == '')) {
                alerter('请选择开始时间、结束时间');
                return;
            }
        }
        var data = "promote_code=" + this.promotion_code + "&group_id=" + this.group_id + "&start_time=" + start_time + "&end_time=" + end_time + "&page_no=" + this.cur;
        var _this = this;
        axios_post_c(data, '/generalized/conversion/statistics', function (res) {
            if (res.mark == 0) {
                _this.data_list = res.obj.list;
                _this.all = res.obj.total_pages;
                _this.data_num = res.obj.count;
            } else {
                _this.data_list = [];
                alerter(res.tip);
            }
            if (_this.is_first) {
                _this.is_first = false;
            }
            _this.is_loading = false;
        });
    },
    pageClick: function () {
        this.search_data();
    },
    btnClick: function (data) {
        if (data != this.cur) {
            this.cur = data
            this.search_data();
        }
    },
    page_search: function () {
        if (this.page_txt == null) {
            alerter("请输入页码");
            return;
        }
        if (this.page_txt > this.all) {
            alerter("请输入页码数不超过总页码数");
            return;
        }
        if (isNaN(this.page_txt)) {
            alerter("请输入正确页码数");
            return;
        }
        this.cur = parseInt(this.page_txt);
        this.search_data();
    },
    sign_out: function () {
        mar_sign_out();
    },
    select_group_id: function (group_id, name) {
        this.group_id = group_id;
        this.group_name = name;
        this.is_drop = false;
    }
}

/*=====================================================推广转化订单详情====================================================*/

var proorder_methods = {
    start_way: function () {
        laydate(start);
    },
    end_way: function () {
        laydate(end);
    },
    o_start_way: function () {
        laydate(o_start);
    },
    o_end_way: function () {
        laydate(o_end);
    },
    drop: function () {
        if (this.hide) {
            this.hide = false;
        } else {
            this.hide = true;
        }
    },
    search_data: function () {
        var data = "promote_code=" + this.promotion_code + "&group_id=" + this.group_id + "&register_start_time=" + start_time + "&register_end_time=" + end_time + "&order_start_time=" + o_start_time + "&order_end_time=" + o_end_time + "&page_no=" + this.cur;
        var _this = this;
        axios_post_c(data, '/generalized/conversion/search', function (res) {
            if (res.mark == 0) {
                _this.data_list = res.obj.list;
                _this.all = res.obj.total_pages;
            } else {
                _this.data_list = [];
                //alerter(res.tip);
            }
            _this.is_loading = false;
        });
    },
    detail_data: function (id) {
        this.detail_item = [];
        var _this = this;
        var data = "exp_ord_id=" + id;
        axios_post_c(data, '/generalized/conversion/searchByOrderID', function (res) {
            if (res.mark == 0) {
                _this.is_detail = true;
                _this.detail_item = res.obj;
            } else {
                alerter(res.tip);
            }
            _this.is_loading = false;
        })
    },
    pageClick: function () {
        this.search_data();
    },
    btnClick: function (data) {
        if (data != this.cur) {
            this.cur = data
            this.search_data();
        }
    },
    page_search: function () {
        if (this.page_txt == null) {
            alerter("请输入页码");
            return;
        }
        if (this.page_txt > this.all) {
            alerter("请输入页码数不超过总页码数");
            return;
        }
        if (isNaN(this.page_txt)) {
            alerter("请输入正确页码数");
            return;
        }
        this.cur = parseInt(this.page_txt);
        this.search_data();
    },
    sign_out: function () {
        mar_sign_out();
    },
    select_group_id: function (group_id, name) {
        this.group_id = group_id;
        this.group_name = name;
        this.is_drop = false;
    }
}

/*=====================================================订单转化统计详情====================================================*/

var procount_methods = {
    start_way: function () {
        laydate(start);
    },
    end_way: function () {
        laydate(end);
    },
    o_start_way: function () {
        laydate(o_start);
    },
    o_end_way: function () {
        laydate(o_end);
    },
    drop: function () {
        if (this.hide) {
            this.hide = false;
        } else {
            this.hide = true;
        }
    },
    search_data: function () {
        var data = "promote_code=" + this.promotion_code + "&register_start_time=" + start_time + "&register_end_time=" + end_time + "&order_start_time=" + o_start_time + "&order_end_time=" + o_end_time + "&page_no=" + this.cur;
        var _this = this;
        axios_post_c(data, '/order/convertion/search', function (res) {
            if (res.mark == 0) {
                _this.data_list = res.obj.list;
                _this.all = res.obj.total_pages;
            } else {
                _this.data_list = [];
                _this.all = 1;
                //alerter(res.tip);
            }
            _this.is_loading = false;
        })
    },
    detail_data: function (id) {
        var _this = this;
        var data = "exp_ord_id=" + id;
        axios_post_c(data, '/order/convertion/detail', function (res) {
            if (res.mark == 0) {
                _this.is_detail = true;
                _this.detail_item = res.obj;
            } else {
                _this.detail_item = [];
                alerter(res.tip);
            }
            _this.is_loading = false;
        })
    },
    pageClick: function () {
        this.search_data();
    },
    btnClick: function (data) {
        if (data != this.cur) {
            this.cur = data
            this.search_data();
        }
    },
    page_search: function () {
        if (this.page_txt == null) {
            alerter("请输入页码");
            return;
        }
        if (this.page_txt > this.all) {
            alerter("请输入页码数不超过总页码数");
            return;
        }
        if (isNaN(this.page_txt)) {
            alerter("请输入正确页码数");
            return;
        }
        this.cur = parseInt(this.page_txt);
        this.search_data();
    },
    sign_out: function () {
        mar_sign_out();
    }
}