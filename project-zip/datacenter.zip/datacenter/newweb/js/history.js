﻿//==================时间空间配置
var start_time = null;
var end_time = null;
var max_time = new Date(),
    max_y = max_time.getFullYear(),
    max_m = max_time.getMonth() + 1,
    max_d = max_time.getDate();
max_time = max_y + '-' + e(max_m) + '-' + e(max_d);//用户选的最大时间为今天
//时间不大于10加‘0’字符
function e(e) {
    if (e < 10) {
        return e = "0" + e;
    } else {
        return e;
    }
}
//是否闰年
function isLeapYear(year) { return (year % 4 == 0) && (year % 100 != 0 || year % 400 == 0); }
//间隔的天数
function day_interval(startDate, endDate) {
    var startTime = new Date(Date.parse(startDate.replace(/-/g, "/"))).getTime();
    var endTime = new Date(Date.parse(endDate.replace(/-/g, "/"))).getTime();
    var dates = Math.abs((startTime - endTime)) / (1000 * 60 * 60 * 24);
    return dates;
}
var start = {
    elem: '#start',
    format: 'YYYY-MM-DD',
    min: '2000-01-01', //设定最小日期为当前日期
    max: max_time, //最大日期
    istime: false,
    isclear: false,
    istoday: false,
    choose: function (datas) {
        end.min = datas; //开始日选好后，重置结束日的最小日期
        end.start = datas //将结束日的初始值设定为开始日
        start_time = datas;
    }
};
var end = {
    elem: '#end',
    format: 'YYYY-MM-DD',
    min: '2000-01-01',
    max: max_time,
    istime: false,
    isclear: false,
    istoday: false,
    choose: function (datas) {
        start.max = datas; //结束日选好后，重置开始日的最大日期
        end_time = datas;
    }
};
var methods = {
    getChecked: function () {
        return this.table_data.filter(item => item.checked).map(item => item.value);
    },
    drop: function () {
        if (this.hide) {
            this.hide = false;
        } else {
            this.hide = true;
        }
    },
    sign_out: function () {
        _sign_out();
    },
    transf_chart: function (completion) {
        if (this.is_hide) {
            this.is_hide = false;
            this.is_block = true;
            this.btn_txt = '表格分析';
            this.search();
        } else {
            this.is_hide = true;
            this.is_block = false;
            this.btn_txt = '图形分析';
            this.search();
        }
    },
    btnClick: function (data) {//上一页、下一页点击事件
        if (data != this.cur) {
            this.cur = data
            this.get_data();
        }
    },
    pageClick: function () {//页码点击事件
        this.get_data();
    },
    chart_data_arr: function (d_time, series, name) {
        //===================折线图配置
        var option = {
            title: {
                text: name
            },
            tooltip: {
                trigger: 'axis'
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: d_time
            },
            yAxis: {
                type: 'value'
            },
            series: {
                name: name,
                type: 'line',
                stack: '总量',
                data: series
            }
        }
        return option;
    },
    chart_data: function () {
        var arr = ["new_users", "new_storage", "pur_users", "order_total", "tot_comp_order", "tot_comp_account", "pay_account", "per_cus_trans", "tot_parcel", "unit_price", "can_orders", "over_can_orders", "tot_coup_use", "acount_coup", "ref_orders", "ref_account", "fir_qua", "everyday", "total_finish_enterprise_order"];
        arr = JSON.stringify(arr);
        if (start_time == null && end_time != null) {
            var data = "start_time=" + this.default_end + "&end_time=" + end_time + "&time_status=" + this.select_time + "&page_no=0&name=" + arr;
        }
        if (end_time == null && start_time != null) {
            var data = "start_time=" + start_time + "&end_time=" + this.default_start + "&time_status=" + this.select_time + "&page_no=0&name=" + arr;
        }
        if (start_time == null && end_time == null) {
            var data = "start_time=" + this.default_end + "&end_time=" + this.default_start + "&time_status=" + this.select_time + "&page_no=0&name=" + arr;
        }
        if (start_time != null && end_time != null) {
            var data = "start_time=" + start_time + "&end_time=" + end_time + "&name=" + arr + "&time_status=" + this.select_time + "&page_no=0";
        }
        var _this = this;
        axios_post_o(data, '/searchDataByTime', function (response) {
            console.log(response);
            _this.chart_item = [];
            if (response.mark == 0) {
                var response = response.obj;
                if (_this.select_time == 2 || _this.select_time == 3) {
                    _this.chart_item = response.list;
                } else {
                    _this.chart_item = response.list[0]
                }
                _this.chart_data_save();
            } else {
                alerter(response.tip);
            }
            _this.is_loading = false;
        });
    },
    chart_data_save() {
        var d_time = [], acount_coup = [], can_orders = [], fir_qua = [], new_storage = [],
            new_users = [], order_total = [], over_can_orders = [], pay_account = [], per_cus_trans = [],
            pur_users = [], ref_account = [], ref_orders = [], tot_comp_account = [], tot_comp_order = [],
            tot_coup_use = [], tot_parcel = [], unit_price = [], everyday = [];
        for (var index = 0; index < this.chart_item.length; index++) {
            var element = this.chart_item[index];
            if (element != null) {
                if (element.everyday != undefined) {
                    d_time.push(element.everyday);
                }
                if (element.end != undefined) {
                    d_time.push(element.end);
                }
                if (element.date != undefined) {
                    d_time.push(element.date);
                }
                acount_coup.push(element.acount_coup);
                can_orders.push(element.can_orders);
                fir_qua.push(element.fir_qua);
                new_storage.push(element.new_storage);
                new_users.push(element.new_users);
                order_total.push(element.order_total);
                over_can_orders.push(element.over_can_orders);
                pay_account.push(element.pay_account);
                per_cus_trans.push(element.per_cus_trans);
                pur_users.push(element.pur_users);
                ref_account.push(element.ref_account);
                ref_orders.push(element.ref_orders);
                tot_comp_account.push(element.tot_comp_account);
                tot_comp_order.push(element.tot_comp_order);
                tot_coup_use.push(element.tot_coup_use);
                tot_parcel.push(element.tot_parcel);
                unit_price.push(element.unit_price);
            }
        }
        if (new_users[0] != undefined) {
            var myChart = echarts.init(document.getElementById('main2'));
            myChart.setOption(this.chart_data_arr(d_time, new_users, '新增用户数统计(个)'));
        }
        if (new_storage[0] != undefined) {
            var myChart = echarts.init(document.getElementById('main3'));
            myChart.setOption(this.chart_data_arr(d_time, new_storage, '新客量统计(个)'));
        }
        if (pur_users[0] != undefined) {
            var myChart = echarts.init(document.getElementById('main4'));
            myChart.setOption(this.chart_data_arr(d_time, pur_users, '复购用户数统计(个)'));
        }
        if (order_total[0] != undefined) {
            var myChart = echarts.init(document.getElementById('main5'));
            myChart.setOption(this.chart_data_arr(d_time, order_total, '订单总数统计(单)'));
        }
        if (tot_comp_order[0] != undefined) {
            var myChart = echarts.init(document.getElementById('main6'));
            myChart.setOption(this.chart_data_arr(d_time, tot_comp_order, '完成订单总数统计(单)'));
        }
        if (tot_comp_account[0] != undefined) {
            var myChart = echarts.init(document.getElementById('main7'));
            myChart.setOption(this.chart_data_arr(d_time, tot_comp_account, '完成订单金额统计(元)'));
        }
        if (pay_account[0] != undefined) {
            var myChart = echarts.init(document.getElementById('main8'));
            myChart.setOption(this.chart_data_arr(d_time, pay_account, '支付金额统计(元)'));
        }
        if (per_cus_trans[0] != undefined) {
            var myChart = echarts.init(document.getElementById('main9'));
            myChart.setOption(this.chart_data_arr(d_time, per_cus_trans, '客单价统计(元)'));
        }
        if (tot_parcel[0] != undefined) {
            var myChart = echarts.init(document.getElementById('main10'));
            myChart.setOption(this.chart_data_arr(d_time, tot_parcel, '完成订单包裹总数统计(单)'));
        }
        if (unit_price[0] != undefined) {
            var myChart = echarts.init(document.getElementById('main11'));
            myChart.setOption(this.chart_data_arr(d_time, unit_price, '件单价统计(元)'));
        }
        if (can_orders[0] != undefined) {
            var myChart = echarts.init(document.getElementById('main12'));
            myChart.setOption(this.chart_data_arr(d_time, can_orders, '取消订单统计(单)'));
        }
        if (over_can_orders[0] != undefined) {
            var myChart = echarts.init(document.getElementById('main13'));
            myChart.setOption(this.chart_data_arr(d_time, over_can_orders, '过期取消订单统计(单)'));
        }
        if (tot_coup_use[0] != undefined) {
            var myChart = echarts.init(document.getElementById('main14'));
            myChart.setOption(this.chart_data_arr(d_time, tot_coup_use, '优惠券使用总数统计(个)'));
        }
        if (acount_coup[0] != undefined) {
            var myChart = echarts.init(document.getElementById('main15'));
            myChart.setOption(this.chart_data_arr(d_time, acount_coup, '优惠券使用金额统计(元)'));
        }
        if (ref_orders[0] != undefined) {
            var myChart = echarts.init(document.getElementById('main16'));
            myChart.setOption(this.chart_data_arr(d_time, ref_orders, '退款单数统计(单)'));
        }
        if (ref_account[0] != undefined) {
            var myChart = echarts.init(document.getElementById('main17'));
            myChart.setOption(this.chart_data_arr(d_time, ref_account, '退款总金额统计(元)'));
        }
        if (fir_qua[0] != undefined) {
            var myChart = echarts.init(document.getElementById('main18'));
            myChart.setOption(this.chart_data_arr(d_time, fir_qua, '首重计件量统计(件)'));
        }
        if (fir_qua[0] != undefined) {
            var myChart = echarts.init(document.getElementById('main19'));
            myChart.setOption(this.chart_data_arr(d_time, fir_qua, '完成企业件统计(件)'));
        }
        this.is_loading = false;
    },
    start_time: function () {//用户选择开始时间
        laydate(start);
    },
    end_time: function () {//用户选择结束时间
        laydate(end);
    },
    get_data: function () {//判断传什么参数给后台
        var arr = ["new_users", "new_storage", "pur_users", "order_total", "tot_comp_order", "tot_comp_account", "pay_account", "per_cus_trans", "tot_parcel", "unit_price", "can_orders", "over_can_orders", "tot_coup_use", "acount_coup", "ref_orders", "ref_account", "fir_qua", "everyday", "total_finish_enterprise_order"];
        arr = JSON.stringify(arr);
        if (start_time == null && end_time != null) {
            var data = "start_time=" + this.default_end + "&end_time=" + end_time + "&time_status=" + this.select_time + "&page_no=" + this.cur + "&name=" + arr;
        }
        if (end_time == null && start_time != null) {
            var data = "start_time=" + start_time + "&end_time=" + this.default_start + "&time_status=" + this.select_time + "&page_no=" + this.cur + "&name=" + arr;
        }
        if (start_time == null && end_time == null) {
            var data = "start_time=" + this.default_end + "&end_time=" + this.default_start + "&time_status=" + this.select_time + "&page_no=" + this.cur + "&name=" + arr;
        }
        if (start_time != null && end_time != null) {
            var data = "start_time=" + start_time + "&end_time=" + end_time + "&time_status=" + this.select_time + "&page_no=" + this.cur + "&name=" + arr;
        }
        this.handle_data(data);
    },
    handle_data: function (data) {//ajax请求得到数据
        console.log(data);
        var _this = this;
        axios_post_o(data, '/searchDataByTime', function (response) {
            if (response.mark == 0) {
                _this.items = [];
                var response = response.obj;
                if (_this.select_time == 2 || _this.select_time == 3) {
                    for (var i = 0; i < response.list.length; i++) {
                        _this.items.unshift(response.list[i]);
                    }
                } else {
                    for (var i = 0; i < response.list[0].length; i++) {
                        _this.items.push(response.list[0][i]);
                    }
                }
                _this.all = response.total_pages;
            } else {
                alerter(response.tip);
            }
            _this.is_loading = false;
        });
    },
    change_time: function (e) {//用户选择日、周、月，默认为日
        if (e == 1) {
            this.select_time = 1;
            if (this.isActive) {
                this.isActive = false;
            } else {
                this.isActive = true;
                this.isActive2 = false;
                this.isActive3 = false;
            }
        }
        if (e == 2) {
            this.select_time = 2;
            if (this.isActive2) {
                this.isActive2 = false;
                this.select_time = 1;
            } else {
                this.isActive2 = true;
                this.isActive = false;
                this.isActive3 = false;
            }
        }
        if (e == 3) {
            this.select_time = 3;
            if (this.isActive3) {
                this.isActive3 = false;
                this.select_time = 1;
            } else {
                this.isActive3 = true;
                this.isActive2 = false;
                this.isActive = false;
            }
        }
    },
    search: function () {//点击查询
        this.is_loading = true;
        if (start_time != null) {
            this.default_end = start_time;
            var another_date2 = start_time;
        } else {
            var another_date2 = this.default_end;
        }
        if (end_time != null) {
            this.default_start = end_time;
            var another_date = end_time;

        } else {
            var another_date = this.default_start;
        }
        this.cur = 1;
        if (this.is_hide == false) {

            if (this.select_time == 1) {
                var e_t2 = new Date(another_date2);
                var e_t = new Date(another_date);
                e_t = e_t.setDate(e_t.getDate() - 30);
                e_t = new Date(e_t);
                if (e_t > e_t2) {
                    alerter('时间段不能超过三十天');
                    return;
                }
            }
            if (this.select_time == 2) {
                var e_t2 = new Date(another_date2);
                var e_t = new Date(another_date);
                e_t = e_t.setDate(e_t.getDate() - 30 * 7);
                e_t = new Date(e_t);
                if (e_t > e_t2) {
                    alerter('时间段不能超过三十周');
                    return;
                }
            }
            if (this.select_time == 3) {
                var e_t2 = new Date(another_date2);
                var e_t = new Date(another_date);
                e_t = e_t.setMonth(e_t.getMonth() - 30);
                e_t = new Date(e_t);
                if (e_t > e_t2) {
                    alerter('时间段不能超过三十月');
                    return;
                }
            }
            this.chart_data();
        } else {
            this.get_data();
        }
    },
    get_time: function () {//获取默认时间
        var now = new Date();
        var day = now.getDate();
        var year = now.getFullYear();
        var month = now.getMonth() + 1;
        var defore_m = month - 1;
        if (day >= 10) {
            var end_day = day - 9;
            this.default_start = year + '-' + e(month) + '-' + e(day);
            this.default_end = year + '-' + e(month) + '-' + e(end_day);
        } else {
            if (defore_m == 1 || defore_m == 3 || defore_m == 5 || defore_m == 7 || defore_m == 8 || defore_m == 10 || defore_m == 12) {
                var end_day = 31 - (10 - day);
                this.default_start = year + '-' + e(month) + '-' + e(day);
                this.default_end = year + '-' + e(defore_m) + '-' + e(end_day);
            }
            if (defore_m == 4 || defore_m == 6 || defore_m == 9 || defore_m == 11) {
                var end_day = 30 - (10 - day);
                this.default_start = year + '-' + e(month) + '-' + e(day);
                this.default_end = year + '-' + e(defore_m) + '-' + e(end_day);
            }
            if (defore_m == 2) {
                if (isLeapYear(year)) {
                    var end_day = 29 - (10 - day);
                    this.default_start = year + '-' + e(month) + '-' + e(day);
                    this.default_end = year + '-' + e(defore_m) + '-' + e(end_day);
                }
                else {
                    var end_day = 28 - (10 - day);
                    this.default_start = year + '-' + e(month) + '-' + e(day);
                    this.default_end = year + '-' + e(defore_m) + '-' + e(end_day);
                }
            }
        }
        this.search();
    },
    page_search: function () {
        //分页搜索
        if (this.page_txt == null) {
            alerter("请输入页码");
            return;
        }
        if (this.page_txt > this.all) {
            alerter("请输入页码数不超过总页码数");
            return;
        } debugger
        this.cur = parseInt(this.page_txt);
        this.get_data();
    }
};
var table_data = [
    {
        name: '新增用户数',
        value: 'new_users',
        checked: true
    },
    {
        name: '新客量',
        value: 'new_storage',
        checked: false
    },
    {
        name: '复购用户数',
        value: 'pur_users',
        checked: true
    },
    {
        name: '订单总数',
        value: 'order_total',
        checked: true
    },
    {
        name: '完成订单总数',
        value: 'tot_comp_order',
        checked: true
    },
    {
        name: '完成订单金额',
        value: 'tot_comp_account',
        checked: true
    },
    {
        name: '支付金额',
        value: 'pay_account',
        checked: false
    },
    {
        name: '客单价',
        value: 'per_cus_trans',
        checked: false
    },
    {
        name: '完成订单包裹总数',
        value: 'tot_parcel',
        checked: false
    },
    {
        name: '件单价',
        value: 'unit_price',
        checked: false
    },
    {
        name: '用户取消订单数',
        value: 'can_orders',
        checked: false
    },
    {
        name: '过期取消订单',
        value: 'over_can_orders',
        checked: false
    },
    {
        name: '优惠券使用总数',
        value: 'tot_coup_use',
        checked: false
    },
    {
        name: '优惠券使用金额',
        value: 'acount_coup',
        checked: false
    },
    {
        name: '退款单数',
        value: 'ref_orders',
        checked: false
    },
    {
        name: '退款总金额',
        value: 'ref_account',
        checked: false
    },
    {
        name: '首重计件量',
        value: 'fir_qua',
        checked: true
    },
    {
        name: '完成企业件数',
        value: 'total_finish_enterprise_order',
        checked: false
    }
]