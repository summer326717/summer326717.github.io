﻿var gulp = require('gulp'),
    gulpSequence = require('gulp-sequence').use(gulp),
    less = require('gulp-less'),
    htmlmin = require('gulp-htmlmin'),
    imagemin = require('gulp-imagemin'),
    cssmin = require('gulp-minify-css'),
    clean = require('gulp-clean'),
    rev = require('gulp-rev-append'),
    uglify = require('gulp-uglify'),
    pump = require('pump'),
    babel = require("gulp-babel"),
    es2015 = require("babel-preset-es2015");

gulp.task('image', function () {
    gulp.src('newweb/img/*.{png,jpg,gif,ico}')
        .pipe(imagemin())
        .pipe(gulp.dest('src/img'));
});
gulp.task('css', function () {
    gulp.src('newweb/css/**/*.css')
        .pipe(cssmin())
        .pipe(gulp.dest('src/css/'));
});
gulp.task('jsmin', function (cb) {
    pump([
        gulp.src('newweb/js/**/**/*.js'),
        uglify(),
        gulp.dest('src/js')
    ], cb);
});
gulp.task('jscss', function () {
    gulp.src('newweb/js/**/*.css')
        .pipe(cssmin())
        .pipe(gulp.dest('src/js'));
});
gulp.task('jsimage', function () {
    gulp.src('newweb/js/**/*.{png,jpg,gif,ico}')
        .pipe(imagemin())
        .pipe(gulp.dest('src/js'));
});
gulp.task('index', function () {
    return gulp.src('newweb/config.json', { base: 'newweb' })
        .pipe(gulp.dest('src'));
});
gulp.task('index2', function () {
    return gulp.src('newweb/js/common/**/*')
        .pipe(gulp.dest('src/js/common'))
});
gulp.task('es6', function () {
    gulp.src(['newweb/js/*.js'])
        .pipe(babel({ presets: [es2015] }))
        .pipe(uglify())
        .pipe(gulp.dest('src/js'));
});
gulp.task('es62', function () {
    gulp.src(['newweb/js/usermanage/*.js'])
        .pipe(babel({ presets: [es2015] }))
        .pipe(uglify())
        .pipe(gulp.dest('src/js/usermanage'));
});
gulp.task('es63', function () {
    gulp.src(['newweb/js/promotemanage/*.js'])
        .pipe(babel({ presets: [es2015] }))
        .pipe(uglify())
        .pipe(gulp.dest('src/js/promotemanage'));
});
//生成版本号
//gulp.task('rev', function () {
//    gulp.src('newweb/**/*.html')
//        .pipe(rev())
//        .pipe(gulp.dest('src/html'));
//});
gulp.task('html', function () {
    var options = {
        removeComments: true,//清除HTML注释
        collapseWhitespace: true,//压缩HTML
        minifyJS: true,//压缩页面JS
        minifyCSS: true//压缩页面CSS
    };
    gulp.src('newweb/**/*.html')
        .pipe(htmlmin(options))
        .pipe(rev(options))
        .pipe(gulp.dest('src/'));
});
gulp.task('clean', function () {
    return gulp.src('src', { read: false }).pipe(clean());
});
gulp.task('cleanhtml', function () {
    return gulp.src('src/html', { read: false }).pipe(clean());
});

gulp.task('build', gulpSequence(['html', 'es6', 'es62', 'es63', 'jscss', 'index', 'index2', 'css', 'image', 'jsimage'], 'cleanhtml'));