﻿new Vue({
    el: '#app',
    data: {
        page_no: 1,
        page_size: 10,
        menu_type: 0,//0全部 1.分类 2.状态
        fund_type: 0,//0全部 1余额充值 2抵扣券购买 3余额支付 4抵扣券支付 5邀请好友
        fund_state: 2,//0成功 1待支付 2全部
        is_show: false,
        coupon_list: [],//抵扣券的列表
        data_list: [],//账单列表
    },
    created: function () {
        this.get_data();
    },
    methods: {
        get_data: function () {
            this.$dialog.loading.open('加载中...');
            var data = {
                'page_no': this.page_no,
                'page_size': this.page_size,
                'fund_type': this.fund_type,
                'fund_state': this.fund_state
            }
            var _this = this;
            axios_post(data, '/1/token/weChat/voucherBalance', function (res) {
                if (res.mark == 0) {
                    _this.data_list = res.obj.items;
                    for (var i = 0; i < _this.data_list.length; i++) {
                        _this.data_list[i].change_time = get_time(_this.data_list[i].change_time);
                    }
                }
                _this.$dialog.loading.close();
            });
        },
        UploadList: function () {
            this.page_no = 1;
            this.$dialog.loading.open('加载中...');
            var data = {
                'page_no': this.page_no,
                'page_size': this.page_size,
                'fund_type': this.fund_type,
                'fund_state': this.fund_state
            }
            var _this = this;
            axios_post(data, '/1/token/weChat/voucherBalance', function (res) {
                _this.data_list = res.obj.items;
                for (var i = 0; i < _this.data_list.length; i++) {
                    _this.data_list[i].change_time = get_time(_this.data_list[i].change_time);
                }
                _this.$refs.pullrefreshDemo.$emit('ydui.pullrefresh.finishLoad');
                _this.$refs.infinitescrollDemo.$emit('ydui.infinitescroll.reInit');
                _this.$dialog.loading.close();
            });
        },
        loadList: function () {
            this.$dialog.loading.open('加载中...');
            if (this.page_no == 1) {
                this.page_no = 2;
            }
            var data = {
                'page_no': this.page_no,
                'page_size': this.page_size,
                'fund_type': this.fund_type,
                'fund_state': this.fund_state
            }
            var _this = this;
            axios_post(data, '/1/token/weChat/voucherBalance', function (res) {
                _this.data_list = _this.data_list.concat(res.obj.items);
                for (var i = 0; i < _this.data_list.length; i++) {
                    _this.data_list[i].change_time = get_time(_this.data_list[i].change_time);
                }
                if (res.obj.items.length >= _this.page_size) {
                    _this.$refs.infinitescrollDemo.$emit('ydui.infinitescroll.finishLoad');
                    _this.page_no++;
                } else {
                    _this.$refs.infinitescrollDemo.$emit('ydui.infinitescroll.loadedDone');
                }
                _this.$dialog.loading.close();
            });
        },
        trans_menu: function (type) {
            this.is_show = !this.is_show;
            this.menu_type = type;
        },
        tab_category: function (type) {
            this.fund_type = type;
            this.is_show = !this.is_show;
            this.page_no = 1;
            this.data_list = [];
            this.get_data();
        },
        tab_status: function (type) {
            this.fund_state = type;
            this.is_show = !this.is_show;
            this.page_no = 1;
            this.data_list = [];
            this.get_data();
        }
    }
})