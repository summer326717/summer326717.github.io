﻿new Vue({
    el: '#app',
    methods: {
        invite: function () {
            axios_post('', '/1/token/findUserId', function (res) {
                var user_id = res.obj.user_info_id;
                var href = 'http://tempty.hotol.cn/views/activity.html?promote_code=' + user_id + '&channel_id=1';
            });
        }
    }
})