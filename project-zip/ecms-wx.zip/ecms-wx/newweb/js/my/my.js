﻿new Vue({
    el: '#app',
    data: {
        user_phone: '',
        user_balance: 0,//用户余额
        surplus_frequency: 0,//用户抵扣券数量
        coupon_list: [],//抵扣券的列表
        fund_type: 0,//0全部 1余额充值 2抵扣券购买 3余额支付 4抵扣券支付 5邀请好友
        fund_state: 2,//0成功 1待支付 2全部
        pay_id: 0,//抵扣券选中的
        data_list: [],//账单列表
        my_info: '',//我的页面的数据
        user_image: '',//头像
        recharge_list: [],
        r_amount: [],
        rech_amount: '',//输入充值的金额
        gift_amount: 0,//赠送金额
    },
    created: function () {
        if (location.pathname.indexOf('my.html') == -1) {
            this.get_data();
            this.get_recharge();
            this.get_coupon();
        } else {
            this.person_center()
        }
    },
    methods: {
        get_data: function () {//我的余额及账单列表
            this.$dialog.loading.open('加载中...');
            var data = {
                'page_no': 1,
                'page_size': 10,
                'fund_type': this.fund_type,
                'fund_state': this.fund_state
            }
            var _this = this;
            axios_post(data, '/1/token/findFundChangePage', function (res) {
                if (res.mark == 0) {
                    _this.user_balance = res.obj.user_balance;
                    _this.surplus_frequency = res.obj.surplus_frequency;
                }
                _this.$dialog.loading.close();
            });
        },
        person_center: function () {
            var _this = this;
            axios_post('', '/1/token/weChat/personCenter', function (res) {
                if (res.mark == 1) {
                    _this.user_balance = res.obj.user_balance;
                    _this.surplus_frequency = res.obj.surplus_frequency;
                    _this.user_phone = res.obj.user_phone;
                    _this.user_image = res.obj.user_image;
                }
                _this.$dialog.loading.close();
            });
        },
        get_recharge: function () {//获取充值模板
            var _this = this;
            axios_post('', '/1/findRechargePreferen', function (res) {
                if (res.mark == 0) {
                    _this.recharge_list = res.obj;
                    _this.r_amount = res.obj[0].pay_amount;
                }
            })
        },
        to_recharge: function () {//充值
            var data = {
                'change_channel': 2,
                'amount': this.r_amount
            }
            var _this = this;
            axios_post(data, '/1/token/rechargePay', function (res) {
                if (res.mark == 0) {
                    _this.recharge_list = res.obj;
                }
            })
        },
        trans_menu: function (type) {
            this.is_show = !this.is_show;
            this.menu_type = type;
        },
        get_coupon: function () {//获取抵扣券模板
            var _this = this;
            axios_post('', '/1/findDeductionPrice', function (res) {
                if (res.mark == 0) {
                    _this.coupon_list = res.obj;
                    _this.pay_id = res.obj[0].pay_id;
                }
            })
        },
        tab_category: function (type) {
            this.fund_type = type;
            this.is_show = !this.is_show;
            this.data_list = [];
            this.get_data();
        },
        tab_status: function (type) {
            this.fund_state = type;
            this.is_show = !this.is_show;
            this.data_list = [];
            this.get_data();
        },
        watch_input: function () {
            this.r_amount = 0;
            var l = this.recharge_list.length;
            for (var i = 0; i < l; i++) {
                if (this.recharge_list[0].pay_amount <= this.rech_amount * 100) {
                    if (this.recharge_list[i].pay_amount > this.rech_amount * 100) {
                        this.gift_amount = this.recharge_list[i - 1].give_amount;
                        console.log(this.gift_amount);
                        break;
                    }
                } else {
                    this.gift_amount = 0;
                }
                if (this.recharge_list[l - 1].pay_amount <= this.rech_amount * 100) {
                    this.gift_amount = this.recharge_list[l - 1].give_amount;
                    console.log(this.gift_amount);
                    break;
                }
            }
        },
        sign_out: function () {
            Cookies.remove('token');
            location.href = '../login.html';
        }
    }
})