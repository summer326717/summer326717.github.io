﻿new Vue({
    el: '#app',
    data: {
        change_channel: 2,//1支付宝 2微信 3余额 4抵扣券
        order_ids: getQueryString('ord_id'),//订单号
        amount: getQueryString('pay_amo'),//支付金额
        surplus_frequency: getQueryString('pay_fre'),//抵扣券
        user_balance: getQueryString('pay_bal'),//余额
    },
    methods: {
        pay_way: function (type) {
            this.change_channel = type;
        },
        pay_amount: function () {
            this.$dialog.loading.open('加载中...');
            if (this.change_channel != 2 && this.change_channel != 3 && this.change_channel != 4) {
                this.$dialog.toast({ mes: '请重新选择支付方式', timeout: 1000 });
                return;
            }
            if (this.order_ids == null || this.order_ids == undefined || this.order_ids == '') {
                this.$dialog.toast({ mes: '没有订单号', timeout: 1000 });
                return;
            }
            //var json = {
            //    'code': code,
            //    'third_id': third_id
            //}
            //axios_post(json, '/1/token/getOpenId', function () {

            //})
            //var data = {
            //    'order_ids': this.order_ids,
            //    'change_channel': this.change_channel,
            //    'openid': openid
            //}
            //var _this = this;
            //axios_post(data, '/1/token/weChat/orderPay', function (res) {
            //    if (res.mark == 0) {
            //        _this.$dialog.loading.close();
            //        _this.$dialog.toast({ mes: '支付成功！', timeout: 1500, icon: 'success' });
            //    } else {
            //        _this.$dialog.toast({ mes: res.msg, timeout: 1500, icon: 'success' });
            //    }
            //});
            var data = {
                'order_ids': this.order_ids,
                'change_channel': this.change_channel
            }
            var _this = this;
            axios_post(data, '/1/token/orderPay', function (res) {
                _this.$dialog.loading.close();
                if (res.mark == 0) {
                    _this.$dialog.toast({ mes: '支付成功！', timeout: 1500, icon: 'success' });
                }
            })
        }
    }
})