﻿new Vue({
    el: '#app',
    data: {
        data_list: [],
        order_type: 1,//订单类型
        page_no: 1,
        page_size: 10,
        pay_amount: 0,//支付金额
        is_all_check: false,//全选的切换
        surplus_frequency: 0,//账户抵扣券
        user_balance: 0,//账户余额
        is_delete: false,//是否显示删除
        touch_start: 0,//滑动删除时的开始
        touch_end: 0,//滑动删除时的结束
    },
    created: function () {
        this.get_data();
    },
    methods: {
        tab_click: function (type) {
            this.order_type = type;
            this.data_list = [];
            this.get_data();
        },
        get_data: function () {
            this.$dialog.loading.open('加载中...');
            this.page_no = 1;
            if (this.order_type == 1) {//未支付
                var data = {
                    'page_no': this.page_no,
                    'page_size': this.page_size
                }
                _this = this;
                axios_post(data, '/1/token/weChat/unpaidOrders', function (res) {
                    if (res.mark == 0) {
                        _this.data_list = res.obj.items;
                        _this.surplus_frequency = res.obj.surplus_frequency;
                        _this.user_balance = res.obj.user_balance;
                        for (var i = 0; i < res.obj.items.length; i++) {
                            _this.$set(_this.data_list[i], 'is_checked', false);
                            _this.$set(_this.data_list[i], 'is_delete', false);
                            _this.data_list[i].send_time = get_time(_this.data_list[i].send_time);
                        }
                        if (res.obj.items.length >= _this.page_size) {
                            _this.page_no++;
                        }
                    } else {
                        _this.$dialog.toast({ mes: res.tip, timeout: 1500 });
                    }
                    _this.$dialog.loading.close();
                });
            }
            if (this.order_type == 2) {//订单失败
                var data = {
                    'page_no': this.page_no,
                    'page_size': this.page_size
                }
                _this = this;
                axios_post(data, '/1/token/weChat/failedOrders', function (res) {
                    if (res.mark == 0) {
                        _this.data_list = res.obj.items;
                        for (var i = 0; i < res.obj.items.length; i++) {
                            _this.data_list[i].send_time = get_time(_this.data_list[i].send_time);
                        }
                        if (res.obj.items.length >= _this.page_size) {
                            _this.page_no++;
                        }
                    } else {
                        _this.$dialog.toast({ mes: res.tip, timeout: 1500 });
                    }
                    _this.$dialog.loading.close();
                });
                this.$dialog.loading.close();
            }
            if (this.order_type == 3) {//已完成
                var data = {
                    'page_no': this.page_no,
                    'page_size': this.page_size,
                    'start_time': '',
                    'end_time': '',
                    'express_id': 0,
                    'express_number': ''
                }
                _this = this;
                axios_post(data, '/1/token/weChat/completeOrder', function (res) {
                    if (res.mark == 0) {
                        _this.data_list = res.obj.items;
                        for (var i = 0; i < res.obj.items.length; i++) {
                            _this.data_list[i].send_time = get_time(_this.data_list[i].send_time);
                        }
                        if (res.obj.items.length >= _this.page_size) {
                            _this.page_no++;
                        }
                    } else {
                        _this.$dialog.toast({ mes: res.tip, timeout: 1500 });
                    }
                    _this.$dialog.loading.close();
                });
            }
        },
        UploadList: function () {//下拉刷新
            this.$dialog.loading.open('加载中...');
            this.page_no = 1;
            if (this.order_type == 1) {
                var data = {
                    'page_no': this.page_no,
                    'page_size': this.page_size
                }
                _this = this;
                axios_post(data, '/1/token/weChat/unpaidOrders', function (res) {
                    if (res.mark == 0) {
                        _this.data_list = res.obj.items;
                        for (var i = 0; i < res.obj.items.length; i++) {
                            _this.$set(_this.data_list[i], 'is_checked', false);
                            _this.$set(_this.data_list[i], 'is_delete', false);
                            _this.data_list[i].send_time = get_time(_this.data_list[i].send_time);
                        }
                    } else {
                        _this.$dialog.toast({ mes: res.tip, timeout: 1500 });
                    }
                    _this.$refs.pullrefreshDemo.$emit('ydui.pullrefresh.finishLoad');
                    _this.$refs.infinitescrollDemo.$emit('ydui.infinitescroll.reInit');
                    _this.$dialog.loading.close();
                });
            }
            if (this.order_type == 2) {
                var data = {
                    'page_no': this.page_no,
                    'page_size': this.page_size
                }
                _this = this;
                axios_post(data, '/1/token/weChat/orderfailedOrder', function (res) {
                    if (res.mark == 0) {
                        _this.data_list = res.obj.items;
                        for (var i = 0; i < res.obj.items.length; i++) {
                            _this.data_list[i].send_time = get_time(_this.data_list[i].send_time);
                        }
                    } else {
                        _this.$dialog.toast({ mes: res.tip, timeout: 1500 });
                    }
                    _this.$refs.pullrefreshDemo.$emit('ydui.pullrefresh.finishLoad');
                    _this.$refs.infinitescrollDemo.$emit('ydui.infinitescroll.reInit');
                    _this.$dialog.loading.close();
                });
                this.$dialog.loading.close();
            }
            if (this.order_type == 3) {
                var data = {
                    'page_no': this.page_no,
                    'page_size': this.page_size,
                    'start_time': '',
                    'end_time': '',
                    'express_id': 0,
                    'express_number': ''
                }
                _this = this;
                axios_post(data, '/1/token/weChat/completeOrder', function (res) {
                    if (res.mark == 0) {
                        _this.data_list = res.obj.items;
                        for (var i = 0; i < res.obj.items.length; i++) {
                            _this.data_list[i].send_time = get_time(_this.data_list[i].send_time);
                        }
                    } else {
                        _this.$dialog.toast({ mes: res.tip, timeout: 1500 });
                    }
                    _this.$refs.pullrefreshDemo.$emit('ydui.pullrefresh.finishLoad');
                    _this.$refs.infinitescrollDemo.$emit('ydui.infinitescroll.reInit');
                    _this.$dialog.loading.close();
                });
            }
        },
        loadList: function () {//上拉加载
            //return;
            this.$dialog.loading.open('加载中...');
            if (this.page_no == 1) {
                this.page_no = 2;
            }
            if (this.order_type == 1) {
                var data = {
                    'page_no': this.page_no,
                    'page_size': this.page_size
                }
                _this = this;
                axios_post(data, '/1/token/weChat/unpaidOrders', function (res) {
                    if (res.mark == 0) {
                        _this.data_list = _this.data_list.concat(res.obj.items);
                        for (var i = 0; i < res.obj.items.length; i++) {
                            _this.$set(_this.data_list[i], 'is_checked', false);
                            _this.$set(_this.data_list[i], 'is_delete', false);
                            _this.data_list[i].send_time = get_time(_this.data_list[i].send_time);
                        }
                        if (res.obj.items.length >= _this.page_size) {
                            _this.$refs.infinitescrollDemo.$emit('ydui.infinitescroll.finishLoad');
                            _this.page_no++;
                        } else {
                            _this.$refs.infinitescrollDemo.$emit('ydui.infinitescroll.loadedDone');
                        }
                    } else {
                        _this.$dialog.toast({ mes: res.tip, timeout: 1500 });
                        _this.$refs.infinitescrollDemo.$emit('ydui.infinitescroll.loadedDone');
                    }
                    _this.$dialog.loading.close();
                });
            }
            if (this.order_type == 2) {//订单失败
                var data = {
                    'page_no': this.page_no,
                    'page_size': this.page_size
                }
                _this = this;
                axios_post(data, '/1/token/weChat/failedOrders', function (res) {
                    if (res.mark == 0) {
                        _this.data_list = _this.data_list.concat(res.obj.items);
                        for (var i = 0; i < res.obj.items.length; i++) {
                            _this.data_list[i].send_time = get_time(_this.data_list[i].send_time);
                        }
                        if (res.obj.items.length >= _this.page_size) {
                            _this.$refs.infinitescrollDemo.$emit('ydui.infinitescroll.finishLoad');
                            _this.page_no++;
                        } else {
                            _this.$refs.infinitescrollDemo.$emit('ydui.infinitescroll.loadedDone');
                        }
                    } else {
                        _this.$dialog.toast({ mes: res.tip, timeout: 1500 });
                        _this.$refs.infinitescrollDemo.$emit('ydui.infinitescroll.loadedDone');
                    }
                    _this.$dialog.loading.close();
                });
            }
            if (this.order_type == 3) {
                var data = {
                    'page_no': this.page_no,
                    'page_size': this.page_size,
                    'start_time': '',
                    'end_time': '',
                    'express_id': 0,
                    'express_number': ''
                }
                _this = this;
                axios_post(data, '/1/token/weChat/completeOrder', function (res) {
                    if (res.mark == 0) {
                        _this.data_list = _this.data_list.concat(res.obj.items);
                        for (var i = 0; i < res.obj.items.length; i++) {
                            _this.data_list[i].send_time = get_time(_this.data_list[i].send_time);
                        }
                        if (res.obj.items.length >= _this.page_size) {
                            _this.$refs.infinitescrollDemo.$emit('ydui.infinitescroll.finishLoad');
                            _this.page_no++;
                        } else {
                            _this.$refs.infinitescrollDemo.$emit('ydui.infinitescroll.loadedDone');
                        }
                    } else {
                        _this.$dialog.toast({ mes: res.tip, timeout: 1500 });
                        _this.$refs.infinitescrollDemo.$emit('ydui.infinitescroll.loadedDone');
                    }
                    _this.$dialog.loading.close();
                });
            }
        },
        select_all: function () {//选择所有
            this.is_all_check = !this.is_all_check;
            for (var i = 0; i < this.data_list.length; i++) {
                this.data_list[i].is_checked = this.is_all_check;
            }
            this.get_amount();
        },
        select_order: function (i) {//单项选择
            this.data_list[i].is_checked = !this.data_list[i].is_checked;
            this.get_amount();
        },
        pay_order: function () {//支付订单
            var ord_id = '', index = 1;
            for (var i = 0; i < this.data_list.length; i++) {
                if (this.data_list[i].is_checked) {
                    if (index == 1) {
                        ord_id = this.data_list[i].eb_ord_id;
                    } else {
                        ord_id = ord_id + ',' + this.data_list[i].eb_ord_id;
                    }
                    index++;
                }
            }
            if (ord_id == '') {
                this.$dialog.toast({ mes: '请选择支付订单', timeout: 1500 });
                return;
            }
            location.href = '../pay/index.html?ord_id=' + ord_id + '&pay_amo=' + this.pay_amount + '&pay_fre=' + this.surplus_frequency + '&pay_bal=' + this.user_balance
        },
        get_amount: function () {
            this.pay_amount = 0;
            for (var i = 0; i < this.data_list.length; i++) {
                if (this.data_list[i].is_checked) {
                    this.pay_amount = this.pay_amount + this.data_list[i].total_amount;
                }
            }
        },
        check_delete: function (i) {
            this.data_list[i].is_delete = true;
        },
        delete_order: function (eb_ord_id) {
            var data = {
                'eb_ord_id': eb_ord_id,
            }
            var _this = this;
            axios_post(data, '/1/token/cancelOrder', function (res) {
                _this.$dialog.toast({ mes: '删除成功', timeout: 1500 });
                _this.get_data();
            })
        }
        //hand_start: function (e) {//滑动开始事件
        //    //this.touch_start = e.touches[0].pageX;
        //    //console.log(e.touches[0].clientX);
        //},
        //hand_end: function (e) {//滑动结束事件
        //    //if (this.order_type == 1) {
        //    //    this.touch_end = e.changedTouches[0].pageX;
        //    //    console.log(e.changedTouches[0].pageX);
        //    //    if (this.touch_start > this.touch_end + 20) {
        //    //        this.is_delete = true;
        //    //    } else {
        //    //        this.is_delete = false;
        //    //    }
        //    //}
        //}
    }
});