var app = new Vue({
    el: '#app',
    data: {
        express_id: '',//快递公司ID
        ex_com_list: [],//快递公司列表
        platform_id: '',//平台id
        plat_list: [],//平台列表
        reci_item: '',//寄件地址
        send_item: '',//收件地址
        platform_number: '',//输入发的平台编号
        express_weight: '1',//商品重量
    },
    created: function () {
        this.s_get_company();
        if (localStorage.getItem('r_address_id') == null || localStorage.getItem('r_address_id') == "") {
            if (localStorage.getItem('address_id') == null || localStorage.getItem('address_id') == "") {
                return
            } else {
                this.send_send_addr();
            }
        } else {
            this.send_reci_addr();
            if (localStorage.getItem('address_id') == null || localStorage.getItem('address_id') == "") {
                return
            } else {
                this.send_send_addr();
            }
        }
    },
    methods: {
        send_reci_addr: function () {
            var data = {
                address_id: localStorage.getItem('r_address_id'),
            }
            var _this = this;
            axios_post(data, '/1/token/findAddressById', function (res) {
                _this.reci_item = res.obj;
            })
        },
        send_send_addr: function () {
            var data = {
                address_id: localStorage.getItem('address_id'),
            }
            var _this = this;
            axios_post(data, '/1/token/findAddressById', function (res) {
                _this.send_item = res.obj;
            })
        },
        //提交
        send_submit: function () {
            if (localStorage.getItem('address_id') == null) {
                this.$dialog.toast({ mes: '请选择寄件地址', timeout: 1000 });
                return;
            }
            if (localStorage.getItem('r_address_id') == null) {
                this.$dialog.toast({ mes: '请选择收件地址', timeout: 1000 });
                return;
            }
            if (this.express_weight < 1) {
                this.$dialog.toast({ mes: '请输入重量', timeout: 1000 });
                return;
            }
            if (this.express_id <= 0) {
                this.$dialog.toast({ mes: '请选择快递', timeout: 1000 });
                return;
            }
            if (this.platform_id == '') {
                this.$dialog.toast({ mes: '请选择平台', timeout: 1000 });
                return;
            }
            if (this.platform_number == '') {
                this.$dialog.toast({ mes: '请输入平台编号', timeout: 1000 });
                return;
            }
            var data = {
                'rev_add_id': localStorage.getItem('r_address_id'),
                'send_add_id': localStorage.getItem('address_id'),
                'express_id': this.express_id,
                'express_weight': this.express_weight,
                'goods_name': '',
                'platform_id': this.platform_id,
                'platform_number': this.platform_number
            }
            var _this = this;
            axios_post(data, '/1/token/sendOnePackage', function (res) {//分页查询全部地址
                _this.$dialog.toast({ mes: '提交成功', timeout: 1000 });
                location.href = '../pay/index.html?ord_id=' + res.obj.eb_ord_id + '&pay_amo=' + res.obj.amount + '&pay_fre=' + res.obj.surplus_frequency + '&pay_bal=' + res.obj.user_balance
            })
        },
        s_get_company: function () {//获取快递公司列表
            var _this = this;
            axios_post('', '/1/findExpCompany', function (res) {
                _this.ex_com_list = res.obj;
                _this.express_id = res.obj[0].express_id;
                _this.get_plat();
            })
        },
        get_plat: function () {//获取平台列表
            var data = {
                'express_id': this.express_id
            }
            var _this = this;
            axios_post(data, '/1/token/findPlatform', function (res) {
                _this.plat_list = res.obj;
                _this.platform_id = res.obj[0].platform_id;
            });
        },
        tab_exp: function (express_id) {//选择快递公司切换平台
            this.express_id = express_id;
            this.get_plat();
        },
        tab_plat: function (platform_id) {
            this.platform_id = platform_id;
        },
        reci_fun: function () {
            location.href = 'recipient.html?type=0';
        },
        send_fun: function () {
            location.href = 'sender.html?type=0';
        }
    }
})