var app = new Vue({
    el: '#app',
    data: {
        type: '2',//类别 1发件 2收件
        page_no: '1',//请求的页码，，
        total_pages: '',
        page_size: 10,//每页显示的条数
        address_list: [],
    },
    created: function () {
        this.get_data();
    },
    methods: {
        get_data: function () {
            var data = {
                'page_no': this.page_no,
                'page_size': this.page_size,
                'type': this.type
            }
            var _this = this;
            axios_post(data, '/1/token/findAddressPage', function (res) {
                _this.page_no = res.obj.page_no;
                _this.total_pages = res.obj.total_pages;
                _this.address_list = res.obj.items;
            })
        },
        loadList: function () {
            this.$dialog.loading.open('加载中...');
            this.page_no = 1;
            var data = {
                'page_no': this.page_no,
                'page_size': this.page_size,
                'type': this.type
            }
            var _this = this;
            axios_post(data, '/1/token/findAddressPage', function (res) {
                if (res.mark == 0) {
                    _this.page_no = res.obj.page_no;
                    _this.total_pages = res.obj.total_pages;
                    _this.address_list = res.obj.items;
                    _this.$refs.pullrefreshDemo.$emit('ydui.pullrefresh.finishLoad');
                    _this.$refs.infinitescrollDemo.$emit('ydui.infinitescroll.reInit');
                    _this.$dialog.loading.close();
                } else {
                    _this.address_list = [];
                }
            });
        },
        loadListDown: function () {
            this.$dialog.loading.open('加载中...');
            if (this.page_no == 1) {
                this.page_no = 2;
            }
            var data = {
                'page_no': this.page_no,
                'page_size': this.page_size,
                'type': this.type
            }
            var _this = this;
            axios_post(data, '/1/token/findAddressPage', function (res) {
                if (res.mark == 0) {
                    _this.address_list = _this.address_list.concat(res.obj.items);
                    if (res.obj.items.length >= _this.page_size) {
                        _this.$refs.infinitescrollDemo.$emit('ydui.infinitescroll.finishLoad');
                        _this.page_no++;
                    } else {
                        _this.$refs.infinitescrollDemo.$emit('ydui.infinitescroll.loadedDone');
                    }
                } else {
                    _this.$refs.infinitescrollDemo.$emit('ydui.infinitescroll.loadedDone');
                }
                _this.$dialog.loading.close();
            });
        },
        //选择寄地址
        address: function (address_id) {
            localStorage.setItem("address_id", address_id)
            location.href = '../send/send.html'
        },
        //编辑
        is_edit: function (address_id) {
            location.href = '../send/recipient.html?address_id=' + address_id + '&type=1';
        },
        //删除信息
        is_del: function (address_id) {
            this.$dialog.confirm({
                title: '确认删除？',
                opts: () => {
                    var data = {
                        'address_id': address_id
                    }
                    var _this = this;
                    axios_post(data, '/1/token/delAddress', function (res) {
                        _this.$dialog.toast({ mes: '删除成功', timeout: 1000 });
                        _this.get_data();
                    })
                }
            });
        },
        to_default: function (id) {
            var data = {
                'address_id': id,
                'type': 2
            }
            var _this = this;
            axios_post(data, '/1/token/editDefault', function (res) {
                _this.$dialog.toast({ mes: '修改成功', timeout: 1000 });
                _this.get_data();
            })
        },
        append_btn: function () { }
    }
})