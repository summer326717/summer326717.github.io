﻿var app = new Vue({
    el: '#app',
    data: {
        switch1: false,
        show1: false,
        model1: '',
        address_id: '',//地址id
        user_name: '',//名字
        user_mobile: '',//电话
        province_id: 0,//省ID
        city_id: 0,//市ID
        region_id: 0,//区ID
        detailed_address: '',//详细地址
        is_default: false,//是否默认0默认 1非默认
        se_province_index: 0,
        se_city_index: 0,
        select_type: 0,//0省，1市，2区
        pcr_list: [],//选择省市区列表
        city_list: [],//市列表
        area_list: [],//区列表
        province_name: '',//用户选择省
        city_name: '',//用户选择市
        region_name: '',//用户选择区
        send_add_id: 0,
        rev_add_id: 0,
        type: getQueryString('type'),//1为列表进来
        h_address_id: getQueryString('address_id'),
    },
    created: function () {
        this.get_province();
        if (this.h_address_id != null) {
            var data = {
                address_id: this.h_address_id
            }
            var _this = this;
            axios_post(data, '/1/token/findAddressById', function (res) {
                _this.user_name = res.obj.name;
                _this.user_mobile = res.obj.phone;
                _this.province_id = res.obj.province_id;
                _this.province_name = res.obj.province_name;
                _this.region_name = res.obj.region_name;
                _this.detailed_address = res.obj.detailed_address;
                _this.city_name = res.obj.city_name;
                _this.city_id = res.obj.city_id;
                _this.region_id = res.obj.region_id;
                _this.detailed_address = res.obj.detailed_address;
                if (res.obj.is_default == 0) {
                    _this.switch1 = true;
                }
                document.getElementById('demo1').value = _this.province_name + _this.city_name + _this.region_name;
            })
        }
    },
    methods: {
        get_province: function () {
            axios_post('', '/1/findAllProvincialData', function (res) {
                var area1 = new LArea();
                area1.init({
                    'trigger': '#demo1', //触发选择控件的文本框，同时选择完毕后name属性输出到该位置
                    'valueTo': '#value1', //选择完毕后id属性输出到该位置
                    'keys': {
                        id: 'dict_id',
                        name: 'province_name'
                    }, //绑定数据源相关字段 id对应valueTo的value属性输出 name对应trigger的value属性输出
                    'type': 1, //数据源类型
                    'data': res.obj //数据源
                });
                area1.value = [10, 0, 9];//控制初始位置，注意：该方法并不会影响到input的value
            })
        },
        add_address: function () {
            var value = document.getElementById('value1').value;
            var arr = value.split(' ');
            this.province_id = arr[0];
            this.city_id = arr[1];
            this.region_id = arr[2];

            if (this.user_name == '') {
                this.$dialog.toast({ mes: '请输入姓名', timeout: 1000 });
                return;
            }
            if (this.user_mobile == '') {
                this.$dialog.toast({ mes: '请输入手机号码', timeout: 1000 });
                return;
            }
            if (!(/^1(3|4|5|7|8)\d{9}$/.test(this.user_mobile))) {
                this.$dialog.toast({ mes: '请输入正确手机号', timeout: 1000 });
                return;
            }
            if (this.province_id == '') {
                this.$dialog.toast({ mes: '请选择省份', timeout: 1000 });
                return;
            }
            if (this.city_id == '') {
                this.$dialog.toast({ mes: '请选择城市', timeout: 1000 });
                return;
            }
            if (this.region_id == '') {
                this.$dialog.toast({ mes: '请选择区县', timeout: 1000 });
                return;
            }
            if (this.detailed_address == '') {
                this.$dialog.toast({ mes: '请输入详细地址', timeout: 1000 });
                return;
            }
            if (this.switch1) {
                var be_default = 0;
            } else {
                var be_default = 1;
            }
            var data = {
                'user_name': this.user_name,
                'user_mobile': this.user_mobile,
                'province_id': this.province_id,
                'city_id': this.city_id,
                'region_id': this.region_id,
                'detailed_address': this.detailed_address,
                'type': 2,//收件
                'is_default': be_default
            }
            var _this = this;
            axios_post(data, '/1/token/addAddress', function (res) {
                _this.$dialog.toast({ mes: '添加成功', timeout: 1000 });
                _this.address_id = res.obj;
                localStorage.setItem('r_address_id', res.obj);
                if (be_default == 1) {
                    if (_this.type == 0) {
                        location.href = 'send.html';
                    } else {
                        location.href = 'recipientlist.html';
                    }
                } else {
                    location.href = 'send.html';
                }
            })
        },
        edit_address: function () {
            if (this.user_name == '') {
                this.$dialog.toast({ mes: '请输入姓名', timeout: 1000 });
                return;
            }
            if (this.user_mobile == '') {
                this.$dialog.toast({ mes: '请输入手机号码', timeout: 1000 });
                return;
            }
            if (this.province_id == '') {
                this.$dialog.toast({ mes: '请选择省份', timeout: 1000 });
                return;
            }
            if (this.city_id == '') {
                this.$dialog.toast({ mes: '请选择城市级', timeout: 1000 });
                return;
            }
            if (this.region_id == '') {
                this.$dialog.toast({ mes: '请选择区县级', timeout: 1000 });
                return;
            }
            if (this.detailed_address == '') {
                this.$dialog.toast({ mes: '请输入详细地址', timeout: 1000 });
                return;
            }
            if (this.switch1) {
                var be_default = 0;
            } else {
                var be_default = 1;
            }
            var data = {
                'address_id': this.address_id,
                'user_name': this.user_name,
                'user_mobile': this.user_mobile,
                'province_id': this.province_id,
                'city_id': this.city_id,
                'region_id': this.region_id,
                'detailed_address': this.detailed_address,
                'type': 2,
                'is_default': be_default
            }
            var _this = this;
            axios_post(data, '/1/token/editAddress', function (res) {
                _this.$dialog.toast({ mes: '修改成功', timeout: 1000 });
                location.href = 'recipientlist.html';
            })
        },
        append_btn: function () {
            if (this.h_address_id != null) {
                this.edit_address();
            } else {
                this.add_address();
            }
        },
    },
})