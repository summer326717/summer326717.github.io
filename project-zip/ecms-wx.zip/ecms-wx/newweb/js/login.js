var app = new Vue({
    el: '#app',
    data: {
        username: '',//登录用户名
        password: '',//登录密码
        r_username: '',//注册用户名
        r_password: '',//注册密码
        r_code: '',//注册的验证码
        f_username: '',//忘记用户名
        f_code: '',//忘记验证码
        f_password: '',//忘记密码
        is_wait: false,//获取验证码成功后，60秒倒计时
        num: 60,
        is_get_code: true,
    },
    methods: {
        get_gray: function () {
            if (this.num == 0) {
                this.is_get_code = true;
                this.num = 60;
            } else {
                this.num--;
                var _this = this;
                setTimeout(_this.get_gray, 1000);
            }
        },
        //登录
        l_login: function () {
            if (this.username == '') {
                this.$dialog.toast({ mes: '请输入手机号', timeout: 1500 });
                return;
            }
            if (!(/^1(3|4|5|7|8)\d{9}$/.test(this.username))) {
                this.$dialog.toast({ mes: '请输入正确手机号', timeout: 1500 });
                return;
            }
            if (this.password == '') {
                this.$dialog.toast({ mes: '请输入密码', timeout: 1500 });
                return;
            }
            var data = {
                'memb_phone': this.username,
                'memb_password': this.password
            }
            axios_post_login(data, '/1/login', function (res) {
                Cookies.set('token', res.obj.token, { expires: Infinity });
                Cookies.set('memb_phone', res.obj.memb_phone, { expires: Infinity });
                location.href = './send/send.html';
            })
        },
        //注册短信验证
        r_get_code: function () {
            if (this.r_username == '') {
                this.$dialog.toast({ mes: '请输入手机号', timeout: 1500 });
                return;
            }
            if (!(/^1(3|4|5|7|8)\d{9}$/.test(this.r_username))) {
                this.$dialog.toast({ mes: '请输入正确手机号', timeout: 1500 });
                return;
            }
            var data = {
                'phoneno': this.r_username
            }
            this.$dialog.loading.open('加载中......');
            var _this = this;
            axios_post_login(data, '/1/sendRegMsg', function (res) {
                _this.get_gray();
                _this.is_get_code = false;
                _this.$dialog.loading.close();
                _this.$dialog.toast({ mes: '手机验证码获取成功', timeout: 1500 });
            })
        },
        //注册
        reg_btn: function () {
            if (this.r_username == '') {
                this.$dialog.toast({ mes: '请输入手机号', timeout: 1500 });
                return;
            }
            if (!(/^1(3|4|5|7|8)\d{9}$/.test(this.r_username))) {
                this.$dialog.toast({ mes: '请输入正确手机号', timeout: 1500 });
                return;
            }
            if (this.r_code == '') {
                this.$dialog.toast({ mes: '请输入验证码', timeout: 1500 });
                return;
            }
            if (this.r_password == '') {
                this.$dialog.toast({ mes: '请输入密码', timeout: 1500 });
                return;
            }
            var data = {
                'memb_phone': this.r_username,
                'memb_password': this.r_password,
                'verification_code': this.r_code,
                'promote_code': 0
            }
            axios_post_login(data, '/1/register', function (res) {
                location.href = './login.html';
            })
        },
        //忘记密码验证
        f_get_code: function () {
            if (this.f_username == '') {
                this.$dialog.toast({ mes: '请输入手机号', timeout: 1500 });
                return;
            }
            if (!(/^1(3|4|5|7|8)\d{9}$/.test(this.f_username))) {
                this.$dialog.toast({ mes: '请输入正确手机号', timeout: 1500 });
                return;
            }
            var data = {
                'phoneno': this.f_username
            }
            this.$dialog.loading.open('加载中......');
            var _this = this;
            axios_post_login(data, '/1/sendForgetPassMsg', function (res) {
                _this.get_gray();
                _this.is_get_code = false;
                _this.$dialog.loading.close();
                _this.$dialog.toast({ mes: '手机验证码获取成功', timeout: 1500 });
            })
        },
        //忘记密码
        f_btn: function () {
            if (this.f_username == '') {
                this.$dialog.toast({ mes: '请输入手机号', timeout: 1500 });
                return;
            }
            if (!(/^1(3|4|5|7|8)\d{9}$/.test(this.f_username))) {
                this.$dialog.toast({ mes: '请输入正确手机号', timeout: 1500 });
                return;
            }
            if (this.f_code == '') {
                this.$dialog.toast({ mes: '请输入验证码', timeout: 1500 });
                return;
            }
            if (this.f_password == '') {
                this.$dialog.toast({ mes: '请输入密码', timeout: 1500 });
                return;
            }
            var data = {
                'memb_phone': this.f_username,
                'memb_password': this.f_password,
                'verification_code': this.f_code
            }
            axios_post_login(data, '/1/forgetPwd', function (res) {
                location.href = './login.html';
            })
        },
    }
})