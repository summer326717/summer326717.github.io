﻿new Vue({
    el: '#app',
    data: {
        l_username: localStorage.getItem('username'),
        user_type: 0,//0使用1冻结
        page_txt: '',//输入的页码
        page_no: 1,
        total_pages: 1,
        data_list: [],
        page_size: 10,
        username: '',//搜索时的用户名
        open_freeze: false,//是否显示确认冰冻用户
        freeze_user_id: 0,//冰冻时需要的用户id
    },
    created: function () {
        this.get_data();
    },
    methods: {
        sign_out: sign_out,
        btn_click: function (i) {
            this.page_no = i;
            this.get_data();
        },
        search_page: function () {
            if (this.page_txt == '') {
                alerter('请输入页码数');
                return;
            }
            if (isNaN(this.page_txt)) {
                alerter('请输入页码数');
                return;
            }
            if (this.page_txt > this.total_pages) {
                alerter('输入页码数不能大于总页码数');
                return;
            }
            this.page_no = parseInt(this.page_txt);
            this.get_data();
        },
        tab_click: function (type) {
            this.username = '';
            this.user_type = type;
            this.page_no = 1;
            this.get_data()
        },
        get_data: function () {
            if (isNaN(this.username)) {
                alerter('请输入正确用户名');
                return;
            }
            var data = {
                'state': this.user_type,
                'user_phone': this.username,
                'page_no': this.page_no,
                'page_size': this.page_size
            }
            var _this = this;
            axios_post(data, '/1/token/searchByUsername', function (res) {
                if (res.mark == 0) {
                    _this.data_list = res.obj.list;
                    for (var i = 0; i < _this.data_list.length; i++) {
                        _this.data_list[i].register_time = get_time(_this.data_list[i].register_time);
                    }
                    _this.total_pages = res.obj.total_pages;
                } else {
                    _this.data_list = [];
                }
                _this.page_txt = '';
            })
        },//确认要解冻或冻结
        to_freeze: function (id) {
            this.open_freeze = true;
            this.freeze_user_id = id;
        },//冻结、解冻用户
        freeze_user: function () {
            if (this.user_type == 0) {
                var data = {
                    'user_info_id': this.freeze_user_id
                }
                var _this = this;
                axios_post(data, '/1/token/blockedAccount', function (res) {
                    if (res.mark == 0) {
                        _this.open_freeze = false;
                        alerter('冰冻成功');
                        _this.get_data();
                    } else {
                        alerter(resp.tip);
                    }
                })
            }
            if (this.user_type == 1) {
                var data = {
                    'user_info_id': this.freeze_user_id
                }
                var _this = this;
                axios_post(data, '/1/token/unfreezeAccount', function (res) {
                    if (res.mark == 0) {
                        _this.open_freeze = false;
                        alerter('解冻成功');
                        _this.get_data();
                    } else {
                        alerter(resp.tip);
                    }
                })
            }
        },//点击搜索
        search_data: function () {
            if (this.username == '') {
                alerter('请输入用户名');
                return;
            }
            this.get_data();
        },
        to_gift: function (id) {
            var data = {
                'preferNumbe': id,
                'user_info_id': id
            }
            var _this = this;
            axios_post(data, '/1/token/unfreezeAccount', function (res) {
                if (res.mark == 0) {
                    alerter('发送礼物成功');
                    _this.get_data();
                } else {
                    alerter(resp.tip);
                }
            });
        }
    },
    computed: computed
})