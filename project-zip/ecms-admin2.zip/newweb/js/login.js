﻿new Vue({
    el: '#app',
    data: {
        l_username: '',
        l_password: '',
    },
    methods: {
        login_sub: function () {
            if (this.l_username == '') {
                alerter('请输入登录名');
                document.getElementById('l_username').focus();
                return;
            }
            if (this.l_password == '') {
                alerter('请输入密码');
                document.getElementById('l_password').focus();
                return;
            }
            var data = {
                'admin_phone': this.l_username,
                'admin_pass': this.l_password
            }
            axios_post_login(data, '/1/adminLogin', function (res) {
                if (res.mark == 0) {
                    localStorage.setItem('username', res.obj.admin_name)
                    location.href = 'views/user.html';
                }
            })
        },
    }
})