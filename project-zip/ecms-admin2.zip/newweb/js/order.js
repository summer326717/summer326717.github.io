﻿new Vue({
    el: '#app',
    data: {
        username: localStorage.getItem('username'),
        order_type: 1,//1单件未支付 2批量未支付 3单件失败 4批量失败 5批量订单 6已完成订单
        create_time: '',//创建时间
        end_time: '',//结束时间
        page_txt: '',
        page_no: 1,
        total_pages: 1,
        data_list: [],
        page_size: 10,
        to_pay_exp_number: '',//未支付的订单编号
        to_pay_user: '',//未支付的下单用户
        completed_user: '',//已完成下单用户
        completed_exp_number: '',//已完成快递单号
        exp_numbers: '',//批量未支付的批量订单号
        to_order_user: '',//批量未支付的下单用户
        order_number: '',//单件失败的订单编号
        order_numbers: '',//批量失败的批量订单号
        all_users: '',//批量订单的下单用户
        all_exp_numbers: '',//批量订单的批量订单号
        com_time_list: [],//完成时间
        all_time_list: [],//批量时间
        now: new Date(),
    },
    created: function () {
        this.get_data();
    },
    methods: {
        sign_out: sign_out,
        search_page: function () {
            if (this.page_txt == '') {
                alerter('请输入页码数');
                return;
            }
            if (isNaN(this.page_txt)) {
                alerter('请输入页码数');
                return;
            }
            if (this.page_txt > this.total_pages) {
                alerter('输入页码数不能大于总页码数');
                return;
            }
            this.page_no = parseInt(this.page_txt);
            this.get_data();
        },
        btn_click: function (d) {
            this.page_no = d;
            this.get_data();
        },
        tab_click: function (type) {
            this.order_type = type;
            this.page_no = 1;
            if (this.$children != '') {
                this.$children[0].y_now_day = (new Date).getDate();
                this.$children[0].last_time = '';
                this.$children[0].last_time2 = '';
                this.$children[0].y_date_show = false;
            }
            this.get_data()
        },
        get_data: function () {
            //未支付
            if (this.order_type == 1) {
                if (isNaN(this.to_pay_user)) {
                    alerter('请输入正确下单用户');
                    return;
                }
                var data = {
                    'page_no': this.page_no,
                    'page_size': this.page_size,
                    'order_type': this.order_type,
                    'express_number': '',
                    'user_phone': this.to_pay_user,
                    'start': '',
                    'ord_number': this.to_pay_exp_number,
                    'end': '',
                }
            }
            //批量未支付
            if (this.order_type == 2) {
                var data = {
                    'page_no': this.page_no,
                    'page_size': this.page_size,
                    'order_type': this.order_type,
                    'express_number': '',
                    'user_phone': this.to_order_user,
                    'start': '',
                    'ord_number': this.exp_numbers,
                    'end': '',
                }
            }
            //单件失败
            if (this.order_type == 3) {
                var data = {
                    'page_no': this.page_no,
                    'page_size': this.page_size,
                    'order_type': this.order_type,
                    'express_number': this.order_number,
                    'user_phone': '',
                    'start': '',
                    'ord_number': '',
                    'end': '',
                }
            }
            //批量失败
            if (this.order_type == 4) {
                var data = {
                    'page_no': this.page_no,
                    'page_size': this.page_size,
                    'order_type': this.order_type,
                    'express_number': '',
                    'user_phone': '',
                    'start': '',
                    'ord_number': this.order_numbers,
                    'end': '',
                }
            }
            //批量订单
            if (this.order_type == 5) {
                if (this.all_time_list[1] != '' && this.all_time_list[0] == '') {
                    alerter('请输入开始时间');
                    return;
                }
                if (this.all_time_list[0] != '' && this.all_time_list[1] == '') {
                    alerter('请输入结束时间');
                    return;
                }
                if (this.now < new Date(this.all_time_list[0])) {
                    alerter('开始时间不能大于当前时间');
                    return;
                }
                if (this.now < new Date(this.all_time_list[1])) {
                    alerter('结束时间不能大于当前时间');
                    return;
                }
                var data = {
                    'page_no': this.page_no,
                    'page_size': this.page_size,
                    'order_type': this.order_type,
                    'express_number': '',
                    'user_phone': this.all_users,
                    'start': this.all_time_list[0],
                    'ord_number': this.all_exp_numbers,
                    'end': this.all_time_list[1],
                }
            }
            //已完成
            if (this.order_type == 6) {
                if (isNaN(this.completed_user)) {
                    alerter('请输入正确下单用户');
                    return;
                }
                if (this.com_time_list[1] != '' && this.com_time_list[0] == '') {
                    alerter('请输入开始时间');
                    return;
                }
                if (this.com_time_list[0] != '' && this.com_time_list[1] == '') {
                    alerter('请输入结束时间');
                    return;
                }
                if (this.now < new Date(this.com_time_list[1])) {
                    alerter('结束时间不能大于当前时间');
                    return;
                }
                var data = {
                    'page_no': this.page_no,
                    'page_size': this.page_size,
                    'order_type': this.order_type,
                    'express_number': this.completed_exp_number,
                    'user_phone': this.completed_user,
                    'start': this.com_time_list[0],
                    'ord_number': '',
                    'end': this.com_time_list[1],
                }
            }
            var _this = this;
            axios_post(data, '/1/token/findOrderByCondition', function (res) {
                if (res.mark == 0) {
                    _this.data_list = res.obj.items;
                    _this.total_pages = res.obj.total_pages;
                    _this.page_txt = '';
                    for (var i = 0; i < _this.data_list.length; i++) {
                        _this.data_list[i].send_time = get_time(_this.data_list[i].send_time);
                    }
                } else {
                    _this.data_list = [];
                }
            })
        },
        serch_data: function () {
            this.get_data();
        },
        get_ex_number: function (eb_ord_id) {//失败订单的获取
            var data = {
                'eb_ord_id': eb_ord_id
            }
            var _this = this;
            axios_post(data, '/1/token/regainExpressNumber', function (res) {
                if (res.mark == 0) {
                    alerter('获取成功');
                    _this.get_data();
                } else {
                    alerter(resp.tip);
                }
            })
        },//批量订单的导出
        export_order: function (eb_ord_id) {
            axios.get('../config.json')
                .then(function (res) {
                    var con_url = res.data.url;
                    var data = 'eb_ord_id=' + eb_ord_id;
                    window.location.href = con_url + '/1/fileToken/exportOrderData?' + data;
                });
        }
    },
    computed: computed
})