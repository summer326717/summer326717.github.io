﻿new Vue({
    el: '#app',
    data: {
        l_username: localStorage.getItem('username'),
        page_txt: '',//输入的页码
        page_no: 1,
        total_pages: 1,
        data_list: [],
        page_size: 10,
        s_agent_name: '',
        state: 0,//0.使用中1.冻结
        close_work: false,//是否显示冻结弹框
        is_show_add: false,//是否显示添加代理商弹框
        is_add_info: false,//false为添加，反之为修改
        is_show_reason: false,//显示不通过原因弹框
        agent_id: 0,//修改代理商账户
        ice_agent_id: 0,//解除合作的id
        change_state: 0,//0处理 2不通过 3通过
        btn_type: 1,//1.解除合作，2.恢复合作
        agent_account: '',
        agent_password: '',
        agent_name: '',
        agent_phone: '',
        agent_province: 0,
        i_agent_province: 0,
        agent_city: 0,
        i_agent_city: 0,
        agent_region: 0,
        i_agent_region: 0,
        agent_address: '',
        agent_cost: '',
        reason: '',
        com_time_list: [],//提现tab的时间选择
        province_list: [],
        city_list: [],
        region_list: [],
        im_price: 0,//平台价
        now: new Date(),
    },
    created: function () {
        this.get_data();
        this.get_province();
        this.get_price();
    },
    methods: {
        sign_out: sign_out,
        btn_click: function (i) {
            this.page_no = i;
            if (this.state == 1 || this.state == 0) {
                this.get_data();
            } else {
                this.get_agent_data();
            }
        },
        page_data: function () {
            if (this.state == 1 || this.state == 0) {
                this.get_data();
            } else {
                this.get_agent_data();
            }
        },
        search_page: function () {
            if (this.page_txt == '') {
                alerter('请输入页码数');
                return;
            }
            if (isNaN(this.page_txt)) {
                alerter('请输入页码数');
                return;
            }
            if (this.page_txt > this.total_pages) {
                alerter('输入页码数不能大于总页码数');
                return;
            }
            this.page_no = parseInt(this.page_txt);
            if (this.state == 1 || this.state == 0) {
                this.get_data();
            } else {
                this.get_agent_data();
            }
        },
        tab_click: function (type) {
            this.s_agent_name = '';
            this.state = type;
            this.page_no = 1;
            if (this.$children != '') {
                this.$children[0].y_now_day = (new Date).getDate();
                this.$children[0].last_time = '';
                this.$children[0].last_time2 = '';
                this.$children[0].y_date_show = false;
            }
            if (type == 1 || type == 0) {
                this.get_data()
            } else {
                this.get_agent_data();
            }
        },
        get_data: function () {
            var data = {
                'state': this.state,
                'agent_name': this.s_agent_name,
                'page_no': this.page_no,
                'page_size': this.page_size
            }
            var _this = this;
            axios_post(data, '/1/token/findAgentPage', function (res) {
                if (res.mark == 0) {
                    _this.data_list = res.obj.items;
                    _this.total_pages = res.obj.total_pages;
                } else {
                    _this.data_list = [];
                }
                _this.page_txt = '';
            })
        },
        get_agent_data: function () {
            if (this.com_time_list[1] != '' && this.com_time_list[0] == '') {
                alerter('请输入开始时间');
                return;
            }
            if (this.com_time_list[0] != '' && this.com_time_list[1] == '') {
                alerter('请输入结束时间');
                return;
            }
            if (this.now < new Date(this.com_time_list[1])) {
                alerter('结束时间不能大于当前时间');
                return;
            }
            if (this.state == 2) {
                var a_state = 1;
            }
            if (this.state == 3) {
                var a_state = 3;
            }
            if (this.state == 4) {
                var a_state = 0;
            }
            if (this.state == 5) {
                var a_state = 2;
            }
            var data = {
                'state': a_state,
                'agent_name': this.s_agent_name,
                'page_no': this.page_no,
                'page_size': this.page_size,
                'start_str': this.com_time_list[0],
                'end_str': this.com_time_list[1]
            }
            var _this = this;
            axios_post(data, '/1/token/findAgentFundPage', function (res) {
                if (res.mark == 0) {
                    _this.data_list = res.obj.items;
                    _this.total_pages = res.obj.total_pages;
                    for (var i = 0; i < _this.data_list.length; i++) {
                        _this.data_list[i].created_time = get_time(_this.data_list[i].created_time);
                    }
                } else {
                    _this.data_list = [];
                }
                _this.page_txt = '';
            })
        },
        search: function () {
            if (this.state == 1 || this.state == 0) {
                this.get_data();
            } else {
                this.get_agent_data();
            }
        },
        get_province: function () {
            var _this = this;
            axios_post('', '/1/findAllProvincialData', function (res) {
                if (res.mark == 0) {
                    _this.province_list = res.obj;
                    _this.city_list = _this.province_list[0].city_list;
                    _this.region_list = _this.province_list[0].city_list[0].area_list;
                    _this.agent_province = _this.province_list[0].dict_id;
                    _this.agent_city = _this.province_list[0].city_list[0].dict_id;
                    _this.agent_region = _this.province_list[0].city_list[0].area_list[0].dict_id;
                }
            })
        },
        se_province: function () {
            var i = this.i_agent_province;
            this.city_list = this.province_list[i].city_list;
            this.region_list = this.province_list[i].city_list[0].area_list;
            this.agent_province = this.province_list[i].dict_id;
            this.agent_city = this.province_list[i].city_list[0].dict_id;
            this.agent_region = this.province_list[i].city_list[0].area_list[0].dict_id;
        },
        se_city: function () {
            var i = this.i_agent_province;
            var j = this.i_agent_city;
            this.region_list = this.province_list[i].city_list[j].area_list;
            this.agent_city = this.province_list[i].city_list[j].dict_id;
            this.agent_region = this.province_list[i].city_list[j].area_list[0].dict_id;
        },
        se_region: function () {
            var i = this.i_agent_province;
            var j = this.i_agent_city;
            var k = this.i_agent_region;
            this.agent_region = this.province_list[i].city_list[j].area_list[k].dict_id;
        },
        add_info: function () {
            if (this.agent_name == '') {
                alerter('请输入代理商姓名');
                return;
            }
            if (this.agent_phone == '') {
                alerter('请输入手机号码');
                return;
            }
            if (this.agent_province == '') {
                alerter('请输入完整省市区');
                return;
            }
            if (this.agent_city == '') {
                alerter('请输入完整省市区');
                return;
            }
            if (this.agent_region == '') {
                alerter('请输入完整省市区');
                return;
            }
            if (this.agent_cost == '') {
                alerter('请输入代理价格');
                return;
            }
            if (this.im_price > mul(this.agent_cost, 100)) {
                alerter('代理价必须比平台价高');
                return;
            }
            if (this.is_add_info) {
                if (!this.agent_id) {
                    alerter('请重新点击修改');
                    return;
                }
                var data = {
                    'agent_id': this.agent_id,
                    'agent_name': this.agent_name,
                    'agent_phone': this.agent_phone,
                    'agent_province': this.agent_province,
                    'agent_city': this.agent_city,
                    'agent_region': this.agent_region,
                    'agent_address': '',
                    'agent_cost': mul(this.agent_cost, 100)
                }
                var _this = this;
                axios_post(data, '/1/token/updateAgent', function (res) {
                    if (res.mark == 0) {
                        alerter('修改成功');
                        _this.is_show_add = false;
                        _this.get_data();
                    } else {
                        alerter(res.tip);
                    }
                })
            } else {
                if (this.agent_account == '') {
                    alerter('请输入代理商账号');
                    return;
                }
                if (this.agent_password == '') {
                    alerter('请输入密码');
                    return;
                }
                var data = {
                    'agent_account': this.agent_account,
                    'agent_password': this.agent_password,
                    'agent_name': this.agent_name,
                    'agent_phone': this.agent_phone,
                    'agent_province': this.agent_province,
                    'agent_city': this.agent_city,
                    'agent_region': this.agent_region,
                    'agent_address': '',
                    'agent_cost': mul(this.agent_cost, 100)
                }
                var _this = this;
                axios_post(data, '/1/token/addAgent', function (res) {
                    if (res.mark == 0) {
                        alerter('添加成功');
                        _this.is_show_add = false;
                        _this.get_data();
                    } else {
                        alerter(res.tip);
                    }
                })
            }
        },
        add_agent: function () {
            this.is_show_add = true;//弹出修改弹框
            this.is_add_info = false;//显示密码和账号的文本框
            this.agent_account = '';
            this.agent_password = '';
            this.agent_name = '';
            this.agent_phone = '';
            this.agent_address = '';
            this.agent_cost = '';
        },
        edite_info: function (agent_id, i) {
            this.is_show_add = true;
            this.is_add_info = true;
            if (agent_id) {
                this.agent_id = agent_id;
                this.agent_account = this.data_list[i].agent_account;
                this.agent_password = this.data_list[i].agent_password;
                this.agent_name = this.data_list[i].agent_name;
                this.agent_phone = this.data_list[i].agent_phone;
                this.agent_province = this.data_list[i].agent_province;
                this.agent_city = this.data_list[i].agent_city;
                this.agent_region = this.data_list[i].agent_region;
                this.agent_address = this.data_list[i].agent_address;
                this.agent_cost = this.data_list[i].agent_cost / 100;
            };
        },
        open_dialog: function (type, agent_id) {
            this.close_work = true;
            this.btn_type = type;
            this.reason = '';
            this.ice_agent_id = agent_id;
        },
        sure_btn: function () {
            if (this.btn_type == 1) {//解除合作
                var data = {
                    'agent_id': this.ice_agent_id,
                    'state': '1',
                }
                var _this = this;
                axios_post(data, '/1/token/updateAgentState', function (res) {
                    if (res.mark == 0) {
                        alerter('修改成功');
                        _this.close_work = false;
                        _this.get_data();
                    } else {
                        alerter(res.tip);
                    }
                })
            }
            if (this.btn_type == 2) {//恢复合作
                var data = {
                    'agent_id': this.ice_agent_id,
                    'state': '0',
                }
                var _this = this;
                axios_post(data, '/1/token/updateAgentState', function (res) {
                    if (res.mark == 0) {
                        alerter('修改成功');
                        _this.close_work = false;
                        _this.get_data();
                    } else {
                        alerter(res.tip);
                    }
                })
            }
            if (this.btn_type == 3) {
                this.handle_agent(3);
            }
            if (this.btn_type == 4) {
                this.handle_agent(0);
            }
        },
        handle_agent: function (change_state) {
            var data = {
                'agent_fund_change_id': this.ice_agent_id,
                'reason': this.reason,
                'change_state': change_state,
            }
            var _this = this;
            axios_post(data, '/1/token/updateAgentFundState', function (res) {
                if (res.mark == 0) {
                    alerter('修改成功');
                    _this.close_work = false;
                    _this.is_show_reason = false;
                    _this.get_agent_data();
                } else {
                    alerter(res.tip);
                }
            })
        },
        no_pass: function (agent_id) {
            this.is_show_reason = true;
            this.reason = '';
            this.ice_agent_id = agent_id;
        },
        save_info: function () {
            if (this.reason == '') {
                alerter('请输入原因');
                return;
            }
            this.handle_agent(2);
        },
        get_price: function () {
            var data = {
                'price_type': 1
            }
            var _this = this;
            axios_post(data, '/1/token/findPriceConfigByType', function (res) {
                if (res.mark == 0) {
                    _this.im_price = res.obj.price_amount;
                } else {
                    alerter(res.tip);
                }
            })
        }
    },
    computed: computed
})