﻿new Vue({
    el: '#app',
    data: {
        username: localStorage.getItem('username'),
        setting_type: 1,//0充值送1.抵扣券2.推广奖励3.价格设置
        recharge_list: [],//充值送
        recharge_list_length: 0,//充值数量
        coupon_list_length: [],//抵扣券
        new_coupon_list: [],//存放抵扣券位置
        promote_list: [],//推广奖励
        promote_list_length: 0,//
        chanel_promote_list: [],//渠道推广奖励
        chanel_promote_list_length: 0,//
        //unit_price: 0,//单价
        //exp_unit_price: 0,//快递单价
        //cou_unit_price: 0,//抵扣券单价
        price_list: [],//
        price_list_length: 0,
        promote_type: 1,//1.普通用户推广、2.渠道推广
        inclick:1
    },
    created: function () {
        this.get_data();
    },
    methods: {
        sign_out: sign_out,
        get_data: function () {
           
                var data = {
                    
                }
                var _this = this;
                axios_post(data, '/1/token/menu/config', function (res) {
                   
                 
                    if (res.mark == 0) {
                        var newlist = res.obj.list;
                        var newarr = res.obj.list.length;
                       
                        if (newarr < 9) {
                            for (var i = newarr; i < 9; i++) {
                                var obj = {
                                    'purchased_num': '',
                                    'gift_num': ''
                                }
                                newlist.push(obj);
                            }

                            
                            _this.new_coupon_list = newlist;
                        }else{
                            _this.new_coupon_list = res.obj.list;
                        }
                    } else {
                        alerter(resp.tip);
                    }
                })
            
            // if (this.setting_type == 1) {
            //     var data = {
            //         'recharge_type': 2
            //     }
            //     var _this = this;
            //     axios_post(data, '/1/token/findRechargeByType', function (res) {
            //         if (res.mark == 0) {
            //             _this.coupon_list_length = res.obj.length;
            //             _this.new_coupon_list = res.obj;
            //             for (var i = 0; i < res.obj.length; i++) {
            //                 _this.new_coupon_list[i].recharge_amount = _this.new_coupon_list[i].recharge_amount / 100;
            //             }
            //             if (_this.coupon_list_length < 9) {
            //                 for (var i = _this.coupon_list_length; i < 9; i++) {
            //                     var obj = {
            //                         'recharge_amount': '',
            //                         'preferen_amount': ''
            //                     }
            //                     _this.new_coupon_list.push(obj);
            //                 }
            //             }
            //         } else {
            //             alerter(resp.tip);
            //         }
            //     })
            // }
            // if (this.setting_type == 2) {
            //     var data = {
            //         'invite_type': this.promote_type
            //     }
            //     var _this = this;
            //     axios_post(data, '/1/token/findGeneralizeRewardByType', function (res) {
            //         if (res.mark == 0) {
            //             if (_this.promote_type == 2) {
            //                 _this.chanel_promote_list = res.obj;
            //                 _this.chanel_promote_list_length = res.obj.length;
            //                 for (var i = 0; i < res.obj.length; i++) {
            //                     _this.chanel_promote_list[i].reward_amount = _this.chanel_promote_list[i].reward_amount / 100;
            //                 }
            //                 if (_this.chanel_promote_list < 6) {
            //                     for (var i = _this.chanel_promote_list_length; i < 6; i++) {
            //                         var obj = {
            //                             'invite_amount': '',
            //                             'reward_amount': '',
            //                             'reward_deduction': ''
            //                         }
            //                         _this.chanel_promote_list.push(obj);
            //                     }
            //                 }
            //             } else {
            //                 _this.promote_list = res.obj;
            //                 _this.promote_list_length = res.obj.length;
            //                 for (var i = 0; i < res.obj.length; i++) {
            //                     _this.promote_list[i].reward_amount = _this.promote_list[i].reward_amount / 100;
            //                 }
            //                 if (_this.promote_list < 6) {
            //                     for (var i = _this.promote_list_length; i < 6; i++) {
            //                         var obj = {
            //                             'invite_amount': '',
            //                             'reward_amount': '',
            //                             'reward_deduction': ''
            //                         }
            //                         _this.promote_list.push(obj);
            //                     }
            //                 }
            //             }
            //         } else {
            //             alerter(resp.tip);
            //         }
            //     })
            // }
            // if (this.setting_type == 3) {//单价
            //     var data = {
            //         'price_type': this.promote_type//快递单价
            //     }
            //     var _this = this;
            //     axios_post(data, '/1/token/findPriceConfigByType', function (res) {
            //         if (res.mark == 0) {
            //             _this.price_list = res.obj;
            //         } else {
            //             alerter(resp.tip);
            //         }
            //     })
            // }
        },
        saveall(){
           var final_pay = [];
            var me = this;
            var turnback = 1;

            this.new_coupon_list.forEach(function(v,k){               
               if((isNaN(v.purchased_num)&&v.purchased_num.length>0)||(isNaN(v.gift_num) &&v.gift_num.length>0)){
                            alerter("您有抵扣卷规则的设置有误，请确认填入都为数字");
                            turnback =2;
                            return;
                        }
                 else if(v.purchased_num != ''&&v.gift_num != ''&&!v.package_id){
                    final_pay.push(v)
                }
                
                else if((v.purchased_num == ''&&v.gift_num != '')||(v.purchased_num != ''&&v.gift_num == ''&&typeof(v.gift_num) == 'string')){
                            alerter("您有抵扣卷规则的设置不完整，请检验赠送是否为空");
                            turnback =2;
                            return;
                        }
                else if((v.purchased_num == ''&&v.gift_num == '')&&v.package_id){
                    v.purchased_num = 0;
                    v.gift_num = 0;
                    final_pay.push(v)
                }else if(v.purchased_num !=''&& v.gift_num!=''){
                    final_pay.push(v)
                }
            })
            if(turnback ==2){
                            return;
                        }
            var data = final_pay;
            if(this.inclick == 1){
                this.inclick =2;
                 axios_post(data, '/1/token/menu/insert', function (res) {
                if(res.mark == 0){
                    alerter("保存成功");
                    setTimeout(function(){
                        location.reload();
                    },1500)
                    
                }else{
                      alerter(res.tip)  
                }
             })
            }
            
        },
        add_input: function (category, type) {
            if (category == 1) {//添加充值送
                this.recharge_list.push({ 'preferen_amount': '', 'recharge_amount': '', 'recharge_preferen_id': 0 }, { 'preferen_amount': '', 'recharge_amount': '', 'recharge_preferen_id': 0 });
            };
            if (category == 2) {//添加抵扣券
                this.new_coupon_list.push({ 'preferen_amount': '', 'recharge_amount': '', 'recharge_preferen_id': 0 }, { 'preferen_amount': '', 'recharge_amount': '', 'recharge_preferen_id': 0 }, { 'preferen_amount': '', 'recharge_amount': '', 'recharge_preferen_id': 0 });
            }
            if (category == 3) {//添加普通用户或渠道推广
                if (type == 2) {
                    this.chanel_promote_list.push({ 'invite_amount': '', 'reward_amount': '', 'reward_deduction': '' }, { 'invite_amount': '', 'reward_amount': '', 'reward_deduction': '' });
                } else {
                    this.promote_list.push({ 'invite_amount': '', 'reward_amount': '', 'reward_deduction': '' }, { 'invite_amount': '', 'reward_amount': '', 'reward_deduction': '' });
                }
            }
            if (category == 4) {//添加单价
                this.price_list.push({ 'price_amount': '' });
            }
        },
        add_setting: function (category, type) {
            if (category == 1) {//添加充值配置
                var data = [];
                for (var i = this.recharge_list_length; i < this.recharge_list.length; i++) {
                    if (this.recharge_list[i].preferen_amount == '') {
                        break;
                    }
                    if (this.recharge_list[i].recharge_amount == '') {
                        break;
                    }
                    var obj = {
                        'preferen_amount': this.recharge_list[i].preferen_amount * 100,
                        'recharge_amount': this.recharge_list[i].recharge_amount * 100,
                        'recharge_type': 1
                    }
                    data.push(obj);
                }
                if (data.length == 0) {
                    return;
                }
                console.log(data); return;
                axios_post(data, '/1/token/addRechargePreferen', function (res) {
                    if (res.mark == 0) {
                        alerter('操作成功');
                    } else {
                        alerter(resp.tip);
                    }
                })
            }
            if (category == 2) {//添加抵扣券配置
                var data = [];
                for (var i = this.coupon_list_length; i < this.new_coupon_list.length; i++) {
                    if (this.new_coupon_list[i].preferen_amount == '') {
                        break;
                    }
                    if (this.new_coupon_list[i].recharge_amount == '') {
                        break;
                    }
                    var obj = {
                        'preferen_amount': this.new_coupon_list[i].preferen_amount,
                        'recharge_amount': this.new_coupon_list[i].recharge_amount * 100,
                        'recharge_type': 2
                    }
                    data.push(obj);
                }
                if (data.length == 0) {
                    return;
                }
                console.log(data); return;
                axios_post(data, '/1/token/addRechargePreferen', function (res) {
                    if (res.mark == 0) {
                        alerter('操作成功');
                    } else {
                        alerter(resp.tip);
                    }
                })
            }
            if (category == 3) {//添加推广奖励
                if (type == 1) {//普通推广
                    var data = [];
                    for (var i = this.promote_list_length; i < this.promote_list.length; i++) {
                        if (this.promote_list[i].invite_amount == '') {
                            break;
                        }
                        if (this.promote_list[i].reward_amount == '') {
                            break;
                        }
                        if (this.promote_list[i].reward_deduction == '') {
                            break;
                        }
                        var obj = {
                            'invite_amount': this.promote_list[i].invite_amount,
                            'reward_amount': this.promote_list[i].reward_amount * 100,
                            'reward_deduction': this.promote_list[i].reward_deduction,
                            'invite_type': 1
                        }
                        data.push(obj);
                    }
                    if (data.length == 0) {
                        return;
                    }
                    console.log(data); return;
                    axios_post(data, '/1/token/addGeneralizeReward', function (res) {
                        if (res.mark == 0) {
                            alerter('操作成功');
                        } else {
                            alerter(resp.tip);
                        }
                    })
                }
                if (type == 2) {//渠道推广
                    var data = [];
                    for (var i = this.chanel_promote_list_length; i < this.chanel_promote_list.length; i++) {
                        if (this.chanel_promote_list[i].invite_amount == '') {
                            break;
                        }
                        if (this.chanel_promote_list[i].reward_amount == '') {
                            break;
                        }
                        if (this.chanel_promote_list[i].reward_deduction == '') {
                            break;
                        }
                        var obj = {
                            'invite_amount': this.chanel_promote_list[i].invite_amount,
                            'reward_amount': this.chanel_promote_list[i].reward_amount * 100,
                            'reward_deduction': this.chanel_promote_list[i].reward_deduction,
                            'invite_type': 2
                        }
                        data.push(obj);
                    }
                    if (data.length == 0) {
                        return;
                    }
                    console.log(data); return;
                    axios_post(data, '/1/token/addGeneralizeReward', function (res) {
                        if (res.mark == 0) {
                            alerter('操作成功');
                        } else {
                            alerter(resp.tip);
                        }
                    })
                }
            }
            if (category == 4) {//添加单价
                var data = [];
                for (var i = this.price_list_length; i < this.price_list.length; i++) {
                    if (this.price_list[i].price_amount == '') {
                        break;
                    }
                    var obj = {
                        'price_type': this.promote_type,
                        'price_amount': this.price_list[i].price_amount * 100,
                    }
                    data.push(obj);
                }
                if (data.length == 0) {
                    return;
                }
                console.log(data); return;
                axios_post(data, '/1/token/addPriceConfig', function (res) {
                    if (res.mark == 0) {
                        alerter('操作成功');
                    } else {
                        alerter(resp.tip);
                    }
                })
            }
        },
        update_setting: function (category, type) {
            if (category == 1) {//修改充值配置、抵扣券配置
                if (type == 1) {//修改充值配置
                    var data = [];
                    for (var i = 0; i < this.recharge_list_length; i++) {
                        var obj = {
                            'recharge_preferen_id': this.recharge_list[i].recharge_preferen_id,
                            'recharge_amount': this.recharge_list[i].recharge_amount * 100,
                            'preferen_amount': this.recharge_list[i].preferen_amount * 100
                        }
                        data.push(obj);
                    }
                }
                if (type == 2) {//抵扣券配置
                    var data = [];
                    for (var i = 0; i < this.coupon_list_length; i++) {
                        var obj = {
                            'recharge_preferen_id': this.new_coupon_list[i].recharge_preferen_id,
                            'recharge_amount': this.new_coupon_list[i].recharge_amount * 100,
                            'preferen_amount': this.new_coupon_list[i].preferen_amount
                        }
                        data.push(obj);
                    }
                }
                if (data.length == 0) {
                    return;
                }
                console.log(data); return;
                axios_post(data, '/1/token/updateRechargePreferen', function (res) {
                    if (res.mark == 0) {
                        alerter('操作成功');
                    } else {
                        alerter(resp.tip);
                    }
                })
            }
            if (category == 3) {//修改推广奖励
                if (type == 1) {
                    var data = [];
                    for (var i = 0; i < this.promote_list_length; i++) {
                        var obj = {
                            'invite_reward_id': this.promote_list[i].invite_reward_id,
                            'invite_amount': this.promote_list[i].invite_amount,
                            'reward_amount': this.promote_list[i].reward_amount * 100,
                            'reward_deduction': this.promote_list[i].reward_deduction
                        }
                        data.push(obj);
                    }
                }
                if (type == 2) {
                    var data = [];
                    for (var i = 0; i < this.chanel_promote_list_length; i++) {
                        var obj = {
                            'invite_reward_id': this.chanel_promote_list[i].invite_reward_id,
                            'invite_amount': this.chanel_promote_list[i].invite_amount,
                            'reward_amount': this.chanel_promote_list[i].reward_amount * 100,
                            'reward_deduction': this.chanel_promote_list[i].reward_deduction
                        }
                        data.push(obj);
                    }
                }
                if (data.length == 0) {
                    return;
                }
                console.log(data); return;
                axios_post(data, '/1/token/updateGeneralizeReward', function (res) {
                    if (res.mark == 0) {
                        alerter('操作成功');
                    } else {
                        alerter(resp.tip);
                    }
                })
            }
            if (category == 4) {//修改单价
                var data = [];
                for (var i = 0; i < this.price_list_length; i++) {
                    var obj = {
                        'price_id': this.price_list[i].price_id,
                        'price_amount': this.price_list[i].price_amount
                    }
                    data.push(obj);
                }
                if (data.length == 0) {
                    return;
                }
                console.log(data); return;
                axios_post(data, '/1/token/updatePriceConfig', function (res) {
                    if (res.mark == 0) {
                        alerter('操作成功');
                    } else {
                        alerter(resp.tip);
                    }
                })
            }
        },
        delete_setting: function (category) {
            if (category == 1) {//删除充值送
                alerter('...');
            }
            if (category == 2) {//删除抵扣券
                alerter('...');
            }
            if (category == 3) {//删除推广奖励
                alerter('...');
            }
        },
        check_num: function (completion) {//根据判断决定新增几组文本框

        },
        check_recharge: function (completion) {//判断充值的排列数据
            for (var i = 0; i < this.recharge_list.length; i++) {
                if (i != this.recharge_list.length - 1) {
                    if (this.recharge_list[i].recharge_amount > this.recharge_list[i + 1].recharge_amount) {
                        completion(false);
                        break;
                    }
                } else {
                    completion(true);
                }
            }
        },
        save_data: function (category, type) {
            this.check_recharge(function (res) {
                if (res) {
                    this.add_setting(1, 0);
                    this.update_setting(1, 1);
                } else {
                    alerter('充值金额请从小到大的顺序排列');
                }
            });
        }
    }
})