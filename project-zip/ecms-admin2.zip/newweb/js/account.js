﻿new Vue({
    el: '#app',
    data: {
        username: localStorage.getItem('username'),
        total_amount: 0,//总资产
        onroad_amount: 0,//在途资金
        onroad_coupon: 0,//在途抵扣券
        platform_profit: 0,//利润
        cat_type: 0,//0全部
        create_time: '',//创建时间
        end_time: '',//结束时间
        page_txt: '',
        page_no: 1,
        total_pages: 1,
        data_list: [],
        page_size: 10,
        time_list: [],
        user_phone: '',//下单用户
        now: new Date(),
    },
    created: function () {
        var _this = this;
        axios_post('', '/1/token/searchTotalAccount', function (res) {
            if (res.mark == 0) {
                _this.total_amount = res.obj.totalAccount;
                _this.onroad_amount = res.obj.currentCash;
                _this.onroad_coupon = res.obj.currentVoucher;
                _this.platform_profit = res.obj.platformProfit;
            }
        });
        //axios_post('', '/1/token/searchCashInTransit', function (res) {
        //    if (res.mark == 0) {
        //        _this.onroad_amount = res.obj.currentCash;
        //    }
        //});
        //axios_post('', '/1/token/searchInroadRebate', function (res) {
        //    if (res.mark == 0) {
        //        _this.onroad_coupon = res.obj.currentVoucher;
        //    }
        //});
        _this.get_data();
    },
    methods: {
        sign_out: sign_out,
        btn_click: function (d) {
            this.page_no = d;
            this.get_data();
        },
        tab_click: function (type) {
            this.cat_type = type;
            this.page_no = 1;
            this.time_list = [];
            if (this.$children != '') {
                this.$children[0].y_now_day = (new Date).getDate();
                this.$children[0].last_time = '';
                this.$children[0].last_time2 = '';
                this.$children[0].y_date_show = false;
            }
            this.user_phone = '';
            this.get_data();
        },
        search_page: function () {
            if (this.page_txt == '') {
                alerter('请输入页码数');
                return;
            }
            if (isNaN(this.page_txt)) {
                alerter('请输入页码数');
                return;
            }
            if (this.page_txt > this.total_pages) {
                alerter('输入页码数不能大于总页码数');
                return;
            }
            this.page_no = parseInt(this.page_txt);
            this.get_data();
        },
        get_data: function () {
            if (this.time_list[1] != '' && this.time_list[0] == '') {
                alerter('请输入开始时间');
                return;
            }
            if (this.time_list[0] != '' && this.time_list[1] == '') {
                alerter('请输入结束时间');
                return;
            }
            if (this.now < new Date(this.time_list[1])) {
                alerter('结束时间不能大于当前时间');
                return;
            }
            var data = {
                'type': this.cat_type,
                'start_time': this.time_list[0],
                'end_time': this.time_list[1],
                'page_no': this.page_no,
                'user_phone': this.user_phone,
                'page_size': this.page_size
            }
            var _this = this;
            axios_post(data, '/1/token/classifySearch', function (res) {
                console.log(res)
                if (res.mark == 0) {
                    _this.data_list = res.obj.list;
                    for (var i = 0; i < res.obj.list.length; i++) {
                        _this.data_list[i].created_time = get_time(_this.data_list[i].created_time);
                    }
                    _this.total_pages = res.obj.total_pages;
                    _this.page_txt = '';
                } else {
                    alerter(res.tip);
                }
            })
        },
        search_data_btn: function () {
            this.page_no = 1;
            this.get_data();
        }
    },
    computed: computed
})