﻿new Vue({
    el: '#app',
    data: {
        username: localStorage.getItem('username'),
        page_txt: '',
        page_no: 1,
        total_pages: 1,
        data_list: [],
        page_size: 10,
        use_type: 0,//0.使用中，1.已冻结，2.库存单号
        is_show_info: false,
        supplier_nick: '',//供应商
        supplier_state: 0,//0.有效，1.无效
        platform_id: 0,//平台id
        express_id: 0,//快递id
        supplier_id: 0,//供应商id
        add_supplier_nick: '',
        add_supplier_accounts: '',
        add_supplier_password: '',
        add_supplier_name: '',
        add_supplier_mobile: '',
        add_supplier_phone: '',
        plat_list: [],
        com_list: [],
        sur_list: [],
        open_freeze: false,//确定弹框
        freeze_supplier_id: 0,//冻结id
        btn_type: 1,//0.有效，1.无效
    },
    created: function () {
        this.get_data();
    },
    methods: {
        sign_out: sign_out,
        get_data: function () {//获取列表数据
            var data = {
                'page_no': this.page_no,
                'page_size': this.page_size,
                'supplier_nick': this.supplier_nick,
                'supplier_state': this.supplier_state
            }
            var _this = this;
            axios_post(data, '/1/token/findSupplierPage', function (res) {
                if (res.mark == 0) {
                    _this.data_list = res.obj.items;
                    _this.total_pages = res.obj.total_pages;
                } else {
                    _this.data_list = [];
                }
            })
        },
        get_exp_data: function () {//获取快递单号列表数据
            var data = {
                'page_no': this.page_no,
                'page_size': this.page_size,
                'platform_id': this.platform_id,
                'express_id': this.express_id,
                'supplier_id': this.supplier_id
            }
            var _this = this;
            axios_post(data, '/1/token/findExpressNumberPage', function (res) {
                if (res.mark == 0) {
                    _this.data_list = res.obj.items;
                    _this.total_pages = res.obj.total_pages;
                } else {
                    _this.data_list = [];
                }
            })
        },
        get_plat: function () {//获取平台
            var _this = this;
            axios_post('', '/1/token/searchPlatformName', function (res) {
                if (res.mark == 0) {
                    _this.plat_list = res.obj;
                } else {
                    _this.plat_list = [];
                }
            })
        },
        get_com: function () {//获取快递公司
            var _this = this;
            axios_post('', '/1/token/searchExpressCompanyName', function (res) {
                if (res.mark == 0) {
                    _this.com_list = res.obj;
                } else {
                    _this.com_list = [];
                }
            })
        },
        get_sur: function () {
            var _this = this;
            axios_post('', '/1/token/searchSupplierName', function (res) {
                if (res.mark == 0) {
                    _this.sur_list = res.obj;
                } else {
                    _this.sur_list = [];
                }
            })
        },
        tab_click: function (use_type) {
            this.page_no = 1;
            this.supplier_nick = '';
            this.use_type = use_type;
            if (use_type == 0 || use_type == 1) {
                this.supplier_state = use_type;
                this.get_data();
            }
            if (use_type == 2) {
                this.get_plat();
                this.get_com();
                this.get_sur();
                this.get_exp_data();
            }
        },
        search_data: function () {
            this.page_no = 1;
            this.get_data();
        },
        search_exp: function () {
            this.page_no = 1;
            this.get_exp_data();
        },
        btn_click: function (d) {
            this.page_no = d;
            if (this.use_type == 2) {
                this.get_exp_data();
            } else {
                this.get_data();
            }
        },
        get_page_data: function () {
            if (this.use_type == 2) {
                this.get_exp_data();
            } else {
                this.get_data();
            }
        },
        search_page: function () {
            if (this.page_txt == '') {
                alerter('请输入页码数');
                return;
            }
            if (isNaN(this.page_txt)) {
                alerter('请输入页码数');
                return;
            }
            if (this.page_txt > this.total_pages) {
                alerter('输入页码数不能大于总页码数');
                return;
            }
            this.page_no = parseInt(this.page_txt);
            if (this.use_type == 2) {
                this.get_exp_data();
            } else {
                this.get_data();
            }
        },
        add_info: function () {//添加供应商
            if (this.add_supplier_nick == '') {
                alerter('请输入供应商名称');
                return;
            }
            if (this.add_supplier_nick.length > 4) {
                alerter('请输入供应商名称不能大于4个字符');
                return;
            }
            if (this.add_supplier_accounts == '') {
                alerter('请输入供应商账号');
                return;
            }
            if (this.add_supplier_password == '') {
                alerter('请输入供应商密码');
                return;
            }
            if (this.add_supplier_name == '') {
                alerter('请输入供应商联系人');
                return;
            }
            if (this.add_supplier_mobile == '') {
                alerter('请输入供应商手机号');
                return;
            }
            if (!/^1(3|4|5|7|8)\d{9}$/.test(this.add_supplier_mobile)) {
                alerter("请输入正确供应商手机号");
                return;
            }
            if (this.add_supplier_phone == '') {
                alerter('请输入供应商电话');
                return;
            }
            if (!/^(\(\d{3,4}\)|\d{3,4}-|\s)?\d{7,14}$/.test(this.add_supplier_phone)) {
                alerter("请输入正确供应商电话");
                return;
            }
            var data = {
                'supplier_nick': this.add_supplier_nick,
                'supplier_accounts': this.add_supplier_accounts,
                'supplier_password': this.add_supplier_password,
                'supplier_name': this.add_supplier_name,
                'supplier_mobile': this.add_supplier_mobile,
                'supplier_phone': this.add_supplier_phone
            }
            var _this = this;
            axios_post(data, '/1/token/addSupplier', function (res) {
                if (res.mark == 0) {
                    alerter(res.tip);
                    _this.get_data();
                    _this.is_show_info = false;
                } else {
                    alerter(res.tip);
                }
            })
        },
        open_dialog: function (btn_type, freeze_supplier_id) {
            this.btn_type = btn_type;
            this.freeze_supplier_id = freeze_supplier_id;
            this.open_freeze = true;
        },
        ice_sur: function (state) {//冻结、解冻账号
            var data = {
                'supplier_id': this.freeze_supplier_id,
                'state': state,
            }
            var _this = this;
            axios_post(data, '/1/token/updateSupplierState', function (res) {
                if (res.mark == 0) {
                    alerter(res.tip);
                    _this.open_freeze = false;
                    _this.get_data();
                } else {
                    alerter(res.tip);
                }
            })
        },
        freeze_sure: function () {
            if (this.btn_type == 0) {
                this.ice_sur(0);
            }
            if (this.btn_type == 1) {
                this.ice_sur(1);
            }
            if (this.btn_type == 2) {
                this.re_pwd();
            }
        },
        re_pwd: function () {
            var data = {
                'supplier_id': this.freeze_supplier_id,
                'supplier_password': '123456',
            }
            var _this = this;
            axios_post(data, '/1/token/updateSupplierPassword', function (res) {
                if (res.mark == 0) {
                    alerter(res.tip);
                    _this.open_freeze = false;
                } else {
                    alerter(res.tip);
                }
            })
        }
    },
    computed: computed
})