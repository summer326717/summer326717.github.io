﻿new Vue({
    el: '#app',
    data: {
        l_username: localStorage.getItem('username'),
        page_txt: '',//输入的页码
        page_no: 1,
        total_pages: 1,
        data_list: [],
        page_size: 10,
        user_type: 1,//1.代理商2.用户
        name: '',//代理商
        grade: [],//等级
        start_str: '',
        end_str: '',
        com_time_list: [],
        now: new Date(),
    },
    created: function () {
        this.get_data();
    },
    methods: {
        sign_out: sign_out,
        btn_click: function (i) {
            this.page_no = i;
            this.get_data();
        },
        search_page: function () {
            if (this.page_txt == '') {
                alerter('请输入页码数');
                return;
            }
            if (isNaN(this.page_txt)) {
                alerter('请输入页码数');
                return;
            }
            if (this.page_txt > this.total_pages) {
                alerter('输入页码数不能大于总页码数');
                return;
            }
            this.page_no = parseInt(this.page_txt);
            this.get_data();
        },
        tab_click: function (type) {
            this.name = '';
            this.user_type = type;
            this.grade = [];
            this.page_no = 1;
            if (this.$children != '') {
                this.$children[0].y_now_day = (new Date).getDate();
                this.$children[0].last_time = '';
                this.$children[0].last_time2 = '';
                this.$children[0].y_date_show = false;
            }
            this.get_data()
        },
        get_data: function () {
            var grade = '';
            if (this.grade != '') {
                for (var i = 0; i < this.grade.length; i++) {
                    if (i + 1 == this.grade.length) {
                        grade = grade + this.grade[i];
                    } else {
                        grade = grade + this.grade[i] + ',';
                    }
                }
            }
            if (this.com_time_list[1] != '' && this.com_time_list[0] == '') {
                alerter('请输入开始时间');
                return;
            }
            if (this.com_time_list[0] != '' && this.com_time_list[1] == '') {
                alerter('请输入结束时间');
                return;
            }
            if (this.now < new Date(this.com_time_list[1])) {
                alerter('结束时间不能大于当前时间');
                return;
            }
            var data = {
                'type': this.user_type,
                'name': this.name,
                'grade': grade,
                'start_str': this.com_time_list[0],
                'end_str': this.com_time_list[1],
                'page_no': this.page_no,
                'page_size': this.page_size,
            }
            var _this = this;
            axios_post(data, '/1/token/findStatisticsPage', function (res) {
                if (res.mark == 0) {
                    _this.data_list = res.obj.items;
                    _this.total_pages = res.obj.total_pages;
                } else {
                    _this.data_list = [];
                }
                _this.page_txt = '';
            })
        },
        search_data: function () {//点击搜索
            this.page_no = 1;
            this.get_data();
        }
    },
    computed: computed
})