<template>
  <div>
      <div class="header">
            <span class="left back">
                <img src="../../static/images/06.png">
            </span>
            <span>修改密码</span>
        </div>
        <div class="updatepwd bt20">
            <p>
                <span>原密码</span><input type="password" placeholder="6~16位数字或字母">
            </p>
            <p>
                <span>新密码</span><input type="password" placeholder="6~16位数字或字母">
            </p>
            <p>
                <span>确认密码</span><input type="password" placeholder="6~16位数字或字母">
            </p>
            <div>
                <button class="w-btn mt80">确定</button>
            </div>
        </div>
  </div>
</template>
