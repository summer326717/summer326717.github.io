<template>
  <div>
        <div class="header">
            <span class="left back">
                <img src="../../static/images/06.png">
            </span>
            <input class="search_ipt" type="text">
        </div>
        <div class="item_list bt20 ptb20">
            <div class="item">
                <div class="left">
                    <img src="../../static/images/img_01.png" alt="">
                </div>
                <div class="right">
                    <p class="ltit">nsjadasidnsajk</p>
                    <p class="stit">dhuasdhsaidasdas</p>
                    <p>
                        <span class="lable_blue">tree</span>
                        <span class="lablue_green">rerwre</span>
                    </p>
                    <p>
                        <span class="totalprice">100万</span>
                        <span>3232元/平</span>
                    </p>
                </div>
            </div>
            <div class="item">
                <div class="left">
                    <img src="../../static/images/img_01.png" alt="">
                </div>
                <div class="right">
                    <p class="ltit">nsjadasidnsajk</p>
                    <p class="stit">dhuasdhsaidasdas</p>
                    <p>
                        <span class="lable_blue">tree</span>
                        <span class="lablue_green">rerwre</span>
                    </p>
                    <p>
                        <span class="totalprice">100万</span>
                        <span>3232元/平</span>
                    </p>
                </div>
            </div>
            <div class="item">
                <div class="left">
                    <img src="../../static/images/img_01.png" alt="">
                </div>
                <div class="right">
                    <p class="ltit">nsjadasidnsajk</p>
                    <p class="stit">dhuasdhsaidasdas</p>
                    <p>
                        <span class="lable_blue">tree</span>
                        <span class="lablue_green">rerwre</span>
                    </p>
                    <p>
                        <span class="totalprice">100万</span>
                        <span>3232元/平</span>
                    </p>
                </div>
            </div>
            <div class="item">
                <div class="left">
                    <img src="../../static/images/img_01.png" alt="">
                </div>
                <div class="right">
                    <p class="ltit">nsjadasidnsajk</p>
                    <p class="stit">dhuasdhsaidasdas</p>
                    <p>
                        <span class="lable_blue">tree</span>
                        <span class="lablue_green">rerwre</span>
                    </p>
                    <p>
                        <span class="totalprice">100万</span>
                        <span>3232元/平</span>
                    </p>
                </div>
            </div>
            <div class="item">
                <div class="left">
                    <img src="../../static/images/img_01.png" alt="">
                </div>
                <div class="right">
                    <p class="ltit">nsjadasidnsajk</p>
                    <p class="stit">dhuasdhsaidasdas</p>
                    <p>
                        <span class="lable_blue">tree</span>
                        <span class="lablue_green">rerwre</span>
                    </p>
                    <p>
                        <span class="totalprice">100万</span>
                        <span>3232元/平</span>
                    </p>
                </div>
            </div>
        </div>
    </div>
</template>
