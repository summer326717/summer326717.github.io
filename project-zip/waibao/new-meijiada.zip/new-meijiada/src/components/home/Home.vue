<template>
  <div class="index">
            <div class="header">
                <span class="selectcity">杭州
                    <img src="../../static/images/04.png">
                </span>
                <span>美佳达智慧销售</span>
                <img @click='checkLogin' class="hsetting" src="../../static/images/07.png">
            </div>
            <div class="banner">
                <img src="../../static/images/s16.png">
            </div>
            <div class="hot_hourse">
                <p class="mi_tit">热门房源
                    <span class="right" @click='viewMore'>查看更多</span>
                </p>
                <ul>
                    <li>
                        <a href="./hoursedetail.html">
                            <p>
                                <img src="../../static/images/img_02.png">
                            </p>
                            <p>dhsuadhiasda</p>
                            <p class="des">都hi速度哈收到后isa</p>
                        </a>
                    </li>
                    <li>
                        <a href="./hoursedetail.html">
                            <p>
                                <img src="../../static/images/img_02.png">
                            </p>
                            <p>dhsuadhiasda</p>
                            <p class="des">都hi速度哈收到后isa</p>
                        </a>
                    </li>
                    <li>
                        <a href="./hoursedetail.html">
                            <p>
                                <img src="../../static/images/img_02.png">
                            </p>
                            <p>dhsuadhiasda</p>
                            <p class="des">都hi速度哈收到后isa</p>
                        </a>
                    </li>
                </ul>
            </div>
            <div>
                <p class="mi_tit">为你推荐
                    <span class="right" @click='viewMore'>查看更多</span>
                </p>
                <div class="item_list">
                    <a href="./hoursedetail.html">
                        <div class="item">
                            <div class="left">
                                <img src="../../static/images/img_01.png" alt="">
                            </div>
                            <div class="right">
                                <p class="ltit">nsjadasidnsajk</p>
                                <p class="stit">dhuasdhsaidasdas</p>
                                <p>
                                    <span class="lable_blue">tree</span>
                                    <span class="lablue_green">rerwre</span>
                                </p>
                                <p>
                                    <span class="totalprice">100万</span>
                                    <span>3232元/平</span>
                                </p>
                            </div>
                        </div>
                    </a>
                    <a href="./hoursedetail.html">
                        <div class="item">
                            <div class="left">
                                <img src="../../static/images/img_01.png" alt="">
                            </div>
                            <div class="right">
                                <p class="ltit">nsjadasidnsajk</p>
                                <p class="stit">dhuasdhsaidasdas</p>
                                <p>
                                    <span class="lable_blue">tree</span>
                                    <span class="lablue_green">rerwre</span>
                                </p>
                                <p>
                                    <span class="totalprice">100万</span>
                                    <span>3232元/平</span>
                                </p>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
</template>
