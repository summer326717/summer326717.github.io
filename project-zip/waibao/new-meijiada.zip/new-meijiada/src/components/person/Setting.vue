<template>
  <div class="seeting">
      <p><span>修改密码</span><span>未设置</span></p>
      <p><span>关于我们</span><span></span></p>
      <p><span>意见反馈</span><span></span></p>
      <p><button>退出登录</button></p>
  </div>
</template>
