<template>
  <div class="my">
      <div class="top">
          <img src="" alt="">
          <span>13456789</span>
          <span>></span>
      </div>
      <p>邀请好友来买房，iphone大奖等你来</p>
      <div class="middle">
          <ul>
              <li>
                  <p><img src="" alt=""></p>
                  <p>我的房源</p>
              </li>
              <li>
                  <p><img src="" alt=""></p>
                  <p>我的合约</p>
              </li>
          </ul>
      </div>
      <div class="bottom">
          <p><img src="" alt="">我的消息</p>
          <p><img src="" alt="">我的收藏</p>
          <p><img src="" alt="">我的分享</p>
      </div>
      <div class="bottom">
          <p><img src="" alt="">我的银行卡</p>
          <p><img src="" alt="">优惠券</p>
      </div>
  </div>
</template>
